<?php
/**
 * The Kerf engine: the converter, the blocks and everything that draws a design.
 *
 * Kerf is a canvas: the mockup is the design, and Kerf's job is to get out of
 * its way. Since 1.1.0 Kerf is one product — the theme loads this from its
 * functions.php, and Kerf Pro after it (CLAUDE.md §5.49). This was the Kerf
 * Blocks plugin until WordPress.org declined a plugin that imports a design's
 * own CSS and JavaScript; it carries no plugin header now, so WordPress never
 * lists the folder as a plugin. kerf_theme_active() still guards what shapes
 * the whole page, for a child theme's sake.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KERF_VERSION', '1.1.2' );
define( 'KERF_PLUGIN_FILE', __FILE__ );
define( 'KERF_PLUGIN_DIR', trailingslashit( __DIR__ ) );
// The theme's address, not __FILE__'s: the lab's theme is a junction, and
// plugin_dir_url() only maps files under plugins/ (scar 92's lesson).
define( 'KERF_PLUGIN_URL', trailingslashit( get_template_directory_uri() ) . 'plugin/' );

/**
 * Absolute path to a file in the plugin.
 *
 * @param string $rel Path relative to the plugin root.
 * @return string
 */
function kerf_plugin_path( $rel = '' ) {
	return KERF_PLUGIN_DIR . ltrim( (string) $rel, '/' );
}

/**
 * URL of a file in the plugin.
 *
 * @param string $rel Path relative to the plugin root.
 * @return string
 */
function kerf_plugin_url( $rel = '' ) {
	return KERF_PLUGIN_URL . ltrim( (string) $rel, '/' );
}

/**
 * Is the Kerf theme (or a child of it) the active theme?
 *
 * What shapes the whole page — the canvas swap, routing, the header and footer
 * parts, the default style for undrawn pages, holding back WordPress' own CSS —
 * belongs to the Kerf theme's pages only. Since 1.1.0 the engine loads only
 * with the Kerf theme or a child of it, so this is true wherever it runs; the
 * checks stay, from when the engine was a plugin that outlived a theme switch.
 *
 * Checked when it is needed rather than once at load, so a theme preview and
 * the test suite's in-process switch see the right answer.
 *
 * Known by the theme's text domain, not its folder's name: a copy unpacked
 * into another folder (`kerf-premium`, Freemius's default for a paid version,
 * or `kerf-1.2.0`) is still Kerf, and every template and part it writes is
 * keyed by whatever folder that is (get_stylesheet()).
 *
 * @return bool
 */
function kerf_theme_active() {
	static $known = array();

	$template = get_template();
	if ( ! isset( $known[ $template ] ) ) {
		$known[ $template ] = 'kerf' === wp_get_theme( $template )->get( 'TextDomain' );
	}
	return $known[ $template ];
}

// Translations: the engine keeps its own domain, `kerf-blocks`, loaded from
// its languages/ folder (WordPress.org no longer hosts it).
load_textdomain( 'kerf-blocks', KERF_PLUGIN_DIR . 'languages/kerf-blocks-' . determine_locale() . '.mo' );

// ─────────────────────────────────────────────────────────────────────────────
// Modules
// ─────────────────────────────────────────────────────────────────────────────

// The SVG sanitizer: kerf/svg's markup and every staged SVG file.
require_once KERF_PLUGIN_DIR . 'inc/kerf-svg.php';

// The conversion engine. Zero WordPress dependencies beyond a handful of
// escaping helpers, so it also runs from tools/kerf-convert.php on the CLI.
require_once KERF_PLUGIN_DIR . 'inc/kerf-css-rules.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-converter-lib.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-converter-audit.php';

// Blocks.
require_once KERF_PLUGIN_DIR . 'inc/kerf-blocks.php';
// Who may add attributes that run code (Alpine, htmx…): checked on every save.
require_once KERF_PLUGIN_DIR . 'inc/kerf-directives.php';
// The design's forms send, by email (§5.35).
require_once KERF_PLUGIN_DIR . 'inc/kerf-forms.php';
// The business's details, shown wherever the design does (§5.36).
require_once KERF_PLUGIN_DIR . 'inc/kerf-site.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-bindings.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-core-inline-style.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-inline-assets.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-responsive.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-editor-ux.php';

// Every Kerf screen's frame (header, look, menu order), and the Dashboard.
require_once KERF_PLUGIN_DIR . 'inc/kerf-admin-ui.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-dashboard.php';

// The mockup's own assets, and the pipeline that puts a mockup on the site.
require_once KERF_PLUGIN_DIR . 'inc/kerf-assets.php';
// When a design's script dies, what it was going to show (§5.50).
require_once KERF_PLUGIN_DIR . 'inc/kerf-reveal.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-document.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-links.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-preflight.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-import.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-import-screen.php';
// The pause between an import's check and its writing. A Kerf Pro from before
// session 16 declared it too; Pro now loads after this file, from the theme.
if ( ! function_exists( 'kerf_import_pending_save' ) ) {
	require_once KERF_PLUGIN_DIR . 'inc/kerf-import-pending.php';
}
// The stamps an import writes, so a newer version of the design can be
// applied section by section — by Kerf Pro's Update from mockup.
require_once KERF_PLUGIN_DIR . 'inc/kerf-stamps.php';
// The last import or update, undone.
require_once KERF_PLUGIN_DIR . 'inc/kerf-undo.php';

// Every page the mockup did not draw: the default style, and its screen.
require_once KERF_PLUGIN_DIR . 'inc/kerf-shell.php';
// "Start here": the brief that makes an AI tool's design import cleanly.
require_once KERF_PLUGIN_DIR . 'inc/kerf-brief.php';
// What a design's scripts make (Tailwind's CSS, drawn icons), for the editor.
require_once KERF_PLUGIN_DIR . 'inc/kerf-capture.php';
// Background pictures, changed without touching the design's files.
require_once KERF_PLUGIN_DIR . 'inc/kerf-backgrounds.php';

// Site plumbing.
require_once KERF_PLUGIN_DIR . 'inc/kerf-settings.php';
require_once KERF_PLUGIN_DIR . 'inc/kerf-skip-link.php';
