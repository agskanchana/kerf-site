/**
 * When a design's script dies, show what it was going to show (§5.50, scar 133).
 *
 * A design's script is written for the pages its designer drew. On a page Kerf
 * draws — the blog, a post, search results, a plain page — the header and
 * footer are the design's but the home page's sections are not, so a script
 * that reaches for a home-only element throws there and stops before its
 * scroll reveal ever runs. The elements that reveal would have faded in stay at
 * `opacity: 0` in the footer or header. Once a script on the page has failed,
 * any element named as a scroll reveal that has sat invisible in view for a
 * second and a half is shown in its settled state — and a page whose scripts
 * all run, or anything named as a modal, menu, drawer or tooltip, is never
 * touched.
 *
 * @package kerf
 */

( function () {
	'use strict';

	var STYLE_ID = 'kerf-reveal-css';
	var SHOWN = 'data-kerf-shown';
	var WAIT = 1500;

	/**
	 * Whole class tokens that name an element as a scroll reveal — never plain
	 * `fade` (Bootstrap's closed modals and tab panes) or state words like
	 * `in`, `show`, `visible` or `animated`.
	 */
	var NAMES = [
		'reveal',
		'reveal-up',
		'reveal-down',
		'reveal-left',
		'reveal-right',
		'reveal-on-scroll',
		'js-reveal',
		'scroll-reveal',
		'fade-in',
		'fade-up',
		'fade-in-up',
		'fade-down',
		'fade-left',
		'fade-right',
		'animate-on-scroll',
		'scroll-animate',
		'rise',
		'wow',
		'ftco-animate',
		'aos-init',
		'animate__animated',
		'sal-animate'
	];

	/**
	 * Attributes that scroll-reveal libraries put on what they animate
	 * (kerf-canvas.js REVEAL_ATTRS).
	 */
	var ATTRS = [ 'data-aos', 'data-wow-delay', 'data-wow-duration', 'data-sal', 'data-sr-id', 'data-scroll-reveal', 'data-animate' ];

	/**
	 * Names that mean "hidden on purpose, and still hidden on the live page"
	 * (kerf-canvas.js DELIBERATELY_HIDDEN).
	 */
	var HIDDEN_GROUPS = [
		'modal|popup|pop-up|dialog|lightbox|backdrop|overlay|toast|tooltip|popover',
		'drawer|offcanvas|off-canvas|mobile|mmenu|burger|hamburger|submenu|sub-menu',
		'dropdown|drop-down|flyout|fly-out|mega|megamenu',
		'tab-pane|tabpanel|tab-content|accordion-collapse|collapse|panel-collapse',
		'sr-only|visually-hidden|screen-reader|d-none|hidden'
	];

	// Anchored on token boundaries, as the editor's: `mega` does not match
	// `omega-panel`, `hidden` does not match `hidden-gem`.
	var HIDDEN = new RegExp(
		'\\b(?:' + HIDDEN_GROUPS.join( '|' ) + ')\\b',
		'i'
	);

	/**
	 * Does the element's class list or attribute set name it as a scroll reveal?
	 *
	 * @param {string}   className
	 * @param {Function} hasAttribute
	 * @return {boolean}
	 */
	function isRevealNamed( className, hasAttribute ) {
		var named = String( className || '' ).toLowerCase().split( /\s+/ ).some( function ( token ) {
			return NAMES.indexOf( token ) >= 0;
		} );
		if ( named ) {
			return true;
		}
		return 'function' === typeof hasAttribute && ATTRS.some( function ( attr ) {
			return !! hasAttribute( attr );
		} );
	}

	/**
	 * Is the element hidden because it is UI that opens on demand (a modal, a
	 * menu, a tab panel, a tooltip) rather than an un-run scroll reveal?
	 *
	 * @param {string}       names
	 * @param {string|null}  role
	 * @param {boolean}      hidden
	 * @param {string|boolean|null} ariaHidden
	 * @return {boolean}
	 */
	function hiddenOnPurpose( names, role, hidden, ariaHidden ) {
		if ( hidden || true === ariaHidden || 'true' === ariaHidden ) {
			return true;
		}
		if ( /^(?:dialog|alertdialog|tabpanel|menu|tooltip)$/i.test( String( role || '' ) ) ) {
			return true;
		}
		return HIDDEN.test( String( names || '' ) );
	}

	/**
	 * Does this element hold anything a reader would miss (kerf-canvas.js)?
	 * Decorative layers and empty scrims stay at the opacity the design gave
	 * them.
	 *
	 * @param {Element} node
	 * @return {boolean}
	 */
	function hasContent( node ) {
		if ( ! node ) {
			return false;
		}
		if ( node.textContent && node.textContent.trim().length > 1 ) {
			return true;
		}
		return !! ( node.querySelector && node.querySelector( 'img, svg, video, iframe, canvas, picture, input, button' ) );
	}

	/**
	 * Should an element be forced visible now?
	 *
	 * Every condition must hold: a script on the page has failed, the element
	 * is named as a scroll reveal, it is not hidden-on-purpose UI, it is not
	 * fixed over the viewport, it is invisible (`opacity < 0.05` or
	 * `visibility === 'hidden'`), it has a laid-out box, its parent is visible
	 * (`visibility` inherits, so the element that decided is the one whose
	 * parent is visible), it holds content, and it has stayed in view for at
	 * least WAIT ms.
	 *
	 * @param {Object} f
	 * @return {boolean}
	 */
	function shouldShow( f ) {
		if ( ! f ) {
			return false;
		}
		return f.failed > 0
			&& !! f.named
			&& ! f.onPurpose
			&& 'fixed' !== f.position
			&& ( parseFloat( f.opacity ) < 0.05 || 'hidden' === f.visibility )
			&& ( f.width > 0 || f.height > 0 )
			&& 'hidden' !== f.parentVisibility
			&& !! f.hasContent
			&& f.inViewMs >= WAIT;
	}

	window.kerfReveal = {
		NAMES: NAMES,
		ATTRS: ATTRS,
		HIDDEN_GROUPS: HIDDEN_GROUPS,
		HIDDEN: HIDDEN,
		WAIT: WAIT,
		isRevealNamed: isRevealNamed,
		hiddenOnPurpose: hiddenOnPurpose,
		shouldShow: shouldShow,
		hasContent: hasContent
	};

	if ( ! window.document || ! window.IntersectionObserver ) {
		return;
	}

	try {
		var doc = window.document;
		var hasHeadListener = 'undefined' !== typeof window.kerfScriptFailed;
		var timers = new window.WeakMap();
		var waiting = [];
		var observer = null;

		/**
		 * Inject the settled-state rule once and mark the element shown.
		 *
		 * @param {Element} node
		 */
		var show = function ( node ) {
			var style = doc.getElementById( STYLE_ID );
			if ( ! style ) {
				style = doc.createElement( 'style' );
				style.id = STYLE_ID;
				style.textContent = '[' + SHOWN + ']{opacity:1!important;visibility:visible!important;transform:none!important;transition:none!important;animation:none!important}';
				( doc.head || doc.documentElement ).appendChild( style );
			}
			node.setAttribute( SHOWN, '' );
		};

		/**
		 * Remove an element from the "in view, waiting" list.
		 *
		 * @param {Element} node
		 */
		var unwait = function ( node ) {
			var at = waiting.indexOf( node );
			if ( at >= 0 ) {
				waiting.splice( at, 1 );
			}
		};

		/**
		 * Read the element's current facts and show it if shouldShow() agrees.
		 * When nothing has failed yet, keep it waiting while it stays in view.
		 *
		 * @param {Element} node
		 */
		var checkNode = function ( node ) {
			try {
				if ( ! node || node.hasAttribute( SHOWN ) ) {
					unwait( node );
					return;
				}
				var style = window.getComputedStyle( node );
				var parentStyle = node.parentElement ? window.getComputedStyle( node.parentElement ) : null;
				var className = node.getAttribute( 'class' ) || '';
				var facts = {
					named: isRevealNamed( className, function ( attr ) {
						return node.hasAttribute( attr );
					} ),
					onPurpose: hiddenOnPurpose(
						className + ' ' + ( node.id || '' ),
						node.getAttribute( 'role' ),
						node.hasAttribute( 'hidden' ),
						node.getAttribute( 'aria-hidden' )
					),
					position: style.position,
					opacity: parseFloat( style.opacity ),
					visibility: style.visibility,
					width: node.offsetWidth,
					height: node.offsetHeight,
					parentVisibility: parentStyle ? parentStyle.visibility : 'visible',
					hasContent: hasContent( node ),
					failed: window.kerfScriptFailed || 0,
					inViewMs: WAIT
				};

				if ( shouldShow( facts ) ) {
					unwait( node );
					if ( observer ) {
						observer.unobserve( node );
					}
					show( node );
					return;
				}

				if ( ! facts.failed && shouldShow( Object.assign( {}, facts, { failed: 1 } ) ) ) {
					if ( waiting.indexOf( node ) < 0 ) {
						waiting.push( node );
					}
				} else {
					unwait( node );
				}
			} catch ( error ) {
				// Never let an unexpected DOM state break the page.
			}
		};

		/**
		 * When a script fails later (e.g. a click handler), re-check anything
		 * already sitting in view after WAIT ms.
		 */
		var onFailure = function () {
			if ( ! hasHeadListener ) {
				window.kerfScriptFailed = ( window.kerfScriptFailed || 0 ) + 1;
			}
			window.setTimeout( function () {
				try {
					waiting.slice().forEach( checkNode );
				} catch ( error ) {
					// Ignore.
				}
			}, WAIT );
		};

		window.addEventListener( 'error', function ( event ) {
			var target = event && event.target;
			if ( ( window.ErrorEvent && event instanceof window.ErrorEvent ) || ( target && 'SCRIPT' === target.tagName ) ) {
				onFailure();
			}
		}, true );
		window.addEventListener( 'unhandledrejection', onFailure );

		/**
		 * Scan the loaded document for scroll-reveal candidates and observe them.
		 */
		var start = function () {
			try {
				var selector = '[class],' + ATTRS.map( function ( attr ) {
					return '[' + attr + ']';
				} ).join( ',' );
				var nodes = doc.querySelectorAll( selector );
				var candidates = [];

				Array.prototype.forEach.call( nodes, function ( node ) {
					if ( /^(?:script|style)$/i.test( node.tagName ) ) {
						return;
					}
					if ( isRevealNamed( node.getAttribute( 'class' ) || '', function ( attr ) {
						return node.hasAttribute( attr );
					} ) ) {
						candidates.push( node );
					}
				} );

				if ( ! candidates.length ) {
					return;
				}

				observer = new window.IntersectionObserver( function ( entries ) {
					try {
						entries.forEach( function ( entry ) {
							var node = entry.target;
							var existing = timers.get( node );
							if ( existing ) {
								window.clearTimeout( existing );
								timers.delete( node );
							}
							if ( entry.isIntersecting ) {
								timers.set( node, window.setTimeout( function () {
									timers.delete( node );
									checkNode( node );
								}, WAIT ) );
							} else {
								unwait( node );
							}
						} );
					} catch ( error ) {
						// Ignore.
					}
				}, { threshold: 0.15 } );

				candidates.forEach( function ( node ) {
					observer.observe( node );
				} );
			} catch ( error ) {
				// Ignore.
			}
		};

		if ( 'complete' === doc.readyState ) {
			start();
		} else {
			window.addEventListener( 'load', start );
		}
	} catch ( error ) {
		// Never throw on the front end.
	}
}() );
