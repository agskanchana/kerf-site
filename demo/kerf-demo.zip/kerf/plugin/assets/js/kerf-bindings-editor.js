/**
 * The editor half of Kerf's binding sources (inc/kerf-bindings.php).
 *
 * Inside a loop (kerf/loop provides the latest post as context) a bound field
 * shows that post's real title, date, excerpt, author, category and picture —
 * the designer's card filled the way the page will fill it, which is what core's
 * own Query Loop does. Outside one (a designer's single-post template has no
 * post to show), it says what it is connected to — "Post title", "Post date" —
 * so a template still reads as a template. Anything the editor cannot know
 * (a comment count, the next post) keeps its label; a URL or picture with no
 * value keeps the mockup's own placeholder.
 *
 * Post HTML (a rendered title, an excerpt) is read as text through DOMParser:
 * its document is inert, where innerHTML on a live element would load an
 * `<img onerror>` in the administrator's session.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	if ( ! wp || ! wp.blocks || 'function' !== typeof wp.blocks.registerBlockBindingsSource ) {
		return;
	}

	var data = window.KerfBindings || { keys: { post: {}, query: {} }, labels: {} };
	var TEXT_ATTRIBUTES = [ 'text', 'content' ];

	function plain( html ) {
		if ( ! html ) {
			return '';
		}
		var doc = new window.DOMParser().parseFromString( String( html ), 'text/html' );
		return ( doc.body.textContent || '' ).replace( /\s+/g, ' ' ).trim();
	}

	function trimWords( text, count ) {
		var list = text.split( ' ' ).filter( Boolean );
		return list.length > count ? list.slice( 0, count ).join( ' ' ) + '…' : text;
	}

	/**
	 * The smallest generated size that fills the designer's slot (`fit`, the
	 * sample picture's width and height), as the page asks for.
	 */
	function mediaUrl( media, args ) {
		var sizes = media.media_details && media.media_details.sizes ? media.media_details.sizes : {};
		var want = args && args.fit && args.fit[ 0 ] ? parseInt( args.fit[ 0 ], 10 ) : 0;
		var best = null;
		Object.keys( sizes ).forEach( function ( name ) {
			var size = sizes[ name ];
			if ( want && size.width >= want && ( ! best || size.width < best.width ) ) {
				best = size;
			}
		} );
		return best ? best.source_url : media.source_url;
	}

	/**
	 * A post's value for one key, as the page will show it. Undefined when the
	 * editor does not know it (yet — records load asynchronously, and this runs
	 * again when they arrive).
	 */
	function postValue( select, post, key, args ) {
		var core = select( 'core' );
		var media;

		switch ( key ) {
			case 'title':
				return plain( post.title && post.title.rendered );
			case 'permalink':
				return post.link;
			case 'date':
			case 'modified':
				if ( ! wp.date ) {
					return undefined;
				}
				// The GMT value, marked as such: the local one has no offset, and would be
				// read as the BROWSER's time and shifted into the site's.
				var gmt = 'date' === key ? post.date_gmt : post.modified_gmt;
				return wp.date.dateI18n( ( args && args.format ) || wp.date.getSettings().formats.date, gmt ? gmt + 'Z' : post.date );
			case 'excerpt':
				return trimWords( plain( post.excerpt && post.excerpt.rendered ), args && args.words ? parseInt( args.words, 10 ) : 30 );
			case 'author':
				var user = core.getUser( post.author );
				return user ? user.name : undefined;
			case 'category':
				var term = post.categories && post.categories.length ? core.getEntityRecord( 'taxonomy', 'category', post.categories[ 0 ] ) : null;
				return term ? plain( term.name ) : undefined;
			case 'tags':
				if ( ! post.tags || ! post.tags.length ) {
					return '';
				}
				var names = post.tags.map( function ( id ) {
					var tag = core.getEntityRecord( 'taxonomy', 'post_tag', id );
					return tag ? plain( tag.name ) : null;
				} );
				return -1 === names.indexOf( null ) ? names.join( ', ' ) : undefined;
			case 'image':
				media = post.featured_media ? core.getEntityRecord( 'postType', 'attachment', post.featured_media ) : null;
				return media ? mediaUrl( media, args ) : undefined;
			case 'image-alt':
				media = post.featured_media ? core.getEntityRecord( 'postType', 'attachment', post.featured_media ) : null;
				return media ? media.alt_text : undefined;
			case 'image-id':
				return post.featured_media || undefined;
		}

		return undefined;
	}

	function source( name, keys, usesContext ) {
		wp.blocks.registerBlockBindingsSource( {
			name: name,
			label: data.labels[ name.split( '/' )[ 1 ] ] || name,
			usesContext: usesContext,
			getValues: function ( args ) {
				var select = args.select;
				var context = args.context || {};
				var post = null;

				if ( 'kerf/post' === name && select && context.postId ) {
					post = select( 'core' ).getEntityRecord( 'postType', context.postType || 'post', context.postId );
				}

				var values = {};
				Object.keys( args.bindings || {} ).forEach( function ( attribute ) {
					var binding = args.bindings[ attribute ] || {};
					var bindingArgs = binding.args || {};
					var key = bindingArgs.key;
					var real = post ? postValue( select, post, key, bindingArgs ) : undefined;

					if ( undefined !== real && null !== real ) {
						// The words the designer wrote around it: "by " a name.
						values[ attribute ] = 'string' === typeof real && '' !== real && ( bindingArgs.before || bindingArgs.after )
							? ( bindingArgs.before || '' ) + real + ( bindingArgs.after || '' )
							: real;
					} else if ( -1 !== TEXT_ATTRIBUTES.indexOf( attribute ) && keys[ key ] ) {
						values[ attribute ] = keys[ key ];
					}
				} );
				return values;
			},
			canUserEditValue: function () {
				return false;
			}
		} );
	}

	source( 'kerf/post', data.keys.post, [ 'postId', 'postType' ] );
	source( 'kerf/query', data.keys.query, [] );
	source( 'kerf/comment', data.keys.comment || {}, [ 'commentId' ] );
	source( 'kerf/term', data.keys.term || {}, [ 'termId', 'taxonomy' ] );

	// The business's details (inc/kerf-site.php): the stored value, as the page
	// shows it. Changed under Kerf → Site details, never in the block.
	wp.blocks.registerBlockBindingsSource( {
		name: 'kerf/site',
		label: data.labels.site || 'kerf/site',
		getValues: function ( args ) {
			var values = {};
			Object.keys( args.bindings || {} ).forEach( function ( attribute ) {
				var bindingArgs = ( args.bindings[ attribute ] || {} ).args || {};
				var detail = ( data.site || {} )[ bindingArgs.key ];
				var value = detail ? ( 'href' === bindingArgs.part ? detail.href : detail.text ) : '';
				if ( value ) {
					// The words the design wrote around it: "Call " a number.
					values[ attribute ] = 'href' === bindingArgs.part ? value : ( bindingArgs.before || '' ) + value + ( bindingArgs.after || '' );
				}
			} );
			return values;
		},
		canUserEditValue: function () {
			return false;
		}
	} );
}( window.wp ) );
