/**
 * Canvas behaviour — making a converted mockup editable without breaking WYSIWYG.
 *
 * Kerf loads the mockup's own stylesheets into the editor canvas, so what you
 * edit is the real design. Two things get in the way of that, and neither is
 * solved by a "show me everything" mode:
 *
 * 1. SETTLED STATE (always on).
 *    Mockups ship reveal-on-scroll — AOS, WOW.js, ScrollReveal, or a hand-rolled
 *    `.reveal{opacity:0}` plus a class the page's JS adds. That JS does not run
 *    in the editor, so entire sections sit at `opacity:0` and the canvas shows
 *    blank space where the design is. That is not a structure problem the author
 *    should have to work around; it is the editor disagreeing with the page.
 *    Forcing those elements to their end state makes the canvas MORE faithful,
 *    not less: it is exactly what a visitor sees once the page has settled.
 *
 *    Detection is by MEASUREMENT, not by class name. Guessing at `.aos-init`,
 *    `.wow`, `[data-scroll]` only ever covers the libraries you thought of, and
 *    every second mockup rolls its own. Reading the computed style covers all of
 *    them and nothing else.
 *
 * 2. SELECTION (always on).
 *    Some UI is invisible at rest and SHOULD be: a dropdown, a mobile drawer, a
 *    modal, tab panel two. Revealing those globally would be a lie about the
 *    page. Instead, the canvas treats the selected block as the place a
 *    visitor's pointer is resting: the mockup's own `:hover` rules hold along
 *    the selection path, so the dropdown you are editing inside opens in its
 *    real open state and STAYS open until you select something outside it.
 *    Whatever is still hidden after that — JS-driven UI has no CSS state to
 *    borrow — is revealed directly and lifted above what overlaps it.
 *    Deselecting puts everything back. The rest of the page never changes.
 *
 * Neither touches content, and neither affects the front end.
 *
 * The two toggles under Troubleshoot are a last resort for when a mockup does
 * something none of this anticipated.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	if ( ! wp || ! wp.element || ! wp.data ) {
		return;
	}

	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var __ = wp.i18n.__;
	var ToggleControl = wp.components.ToggleControl;
	var PanelBody = wp.components.PanelBody;

	var STYLE_ID = 'kerf-canvas-css';
	var POSITION_STYLE_ID = 'kerf-canvas-position';
	var STORAGE_KEY = 'kerfCanvasModes';

	/** Applied to an element only because its reveal animation never fired. */
	var SETTLED = 'kerf-is-settled';

	/** Applied to a widget container whose init script never ran. */
	var WIDGET = 'kerf-is-widget';

	/** What such a container can be: a box that holds slides. */
	var WIDGET_TAGS = /^(?:div|section|ul|ol|article|aside|figure|main)$/i;

	/**
	 * Names that mean "hidden on purpose, and still hidden on the live page".
	 *
	 * This is the one place a name list is the right tool. Everything else in
	 * this file measures, because reveal animations are rolled by hand as often
	 * as they come from a library — but "is this thing hidden because it is a
	 * modal, or because its slider never booted?" is not answerable from the
	 * computed style. Both are `display:none` with content inside.
	 *
	 * Getting it wrong in this direction is cheap and the other direction is
	 * not: a missed carousel is reachable by selecting it, whereas expanding
	 * every mega-menu, tab panel and mobile drawer at once buries the page under
	 * UI a visitor would never see at the same time.
	 *
	 * Grouped by what they are:
	 *   overlays      shown over the page on demand
	 *   navigation    revealed on hover, focus or a viewport change
	 *   panel states  one of several, only one visible at a time
	 *   utilities     hidden by a framework class or for screen readers
	 */
	var DELIBERATELY_HIDDEN = new RegExp(
		// Anchored on token boundaries, so `mega` does not match `omega-panel`
		// and `hidden` does not match `hidden-gem`. Hyphens are not word
		// characters, so `\b` lands correctly on `off-canvas` and `d-none`.
		'\\b(?:' + [
			'modal|popup|pop-up|dialog|lightbox|backdrop|overlay|toast|tooltip|popover',
			'drawer|offcanvas|off-canvas|mobile|mmenu|burger|hamburger|submenu|sub-menu',
			'dropdown|drop-down|flyout|fly-out|mega|megamenu',
			'tab-pane|tabpanel|tab-content|accordion-collapse|collapse|panel-collapse',
			'sr-only|visually-hidden|screen-reader|d-none|hidden'
		].join( '|' ) + ')\\b',
		'i'
	);

	/**
	 * Markers the reveal-on-scroll libraries put on what they animate: AOS,
	 * WOW.js, Colorlib's `ftco-animate`, Animate.css, Sal, ScrollReveal.
	 *
	 * An element carrying one is a scroll-reveal even when it is absolutely
	 * positioned, which otherwise marks it as deliberately hidden (scar 22) —
	 * a hero's headline column is often both, and it stayed invisible in the
	 * editor. The DELIBERATELY_HIDDEN names still win: a modal that happens to
	 * fade in keeps its secret.
	 */
	var REVEAL_CLASS = /\b(?:wow|ftco-animate|aos-init|aos-animate|animate__animated|scroll-reveal|js-reveal|sal-animate)\b/i;
	var REVEAL_ATTRS = [ 'data-aos', 'data-wow-delay', 'data-wow-duration', 'data-sal', 'data-sr-id', 'data-scroll-reveal', 'data-animate' ];

	/**
	 * The selection path: the selected block's element and every ancestor —
	 * exactly the elements `:hover` matches while a pointer rests on that block.
	 * See holdHoverRules().
	 *
	 * The selection marks are attributes, not classes. React owns `className` on
	 * every block element and rewrites it whenever the block re-renders, and
	 * selecting a block re-renders its entire ancestor chain, because each one
	 * gains `has-child-selected`. A class added from outside survives until the
	 * next render; an attribute React never set, it never touches.
	 */
	var HOVER = 'data-kerf-hover';
	var HOVER_SELECTOR = '[' + HOVER + ']';

	/** Why an element was forced visible: the hiddenReason() values overridden. */
	var REVEAL = 'data-kerf-reveal';

	/** The outermost forced-visible element, which is what gets lifted. */
	var SPOTLIGHT = 'data-kerf-spotlight';

	/** Transitions off, for the length of one selection pass. See applySelection(). */
	var INSTANT = 'data-kerf-instant';

	/** A page preloader, hidden in the canvas. See applyPreloaders(). */
	var PRELOADER = 'data-kerf-preloader';

	/** The page's title field above a design, and the words naming it. See markTitle(). */
	var TITLE = 'data-kerf-title';

	/** An inline child the page has a space before. See applyGaps(). */
	var GAP = 'data-kerf-gap';

	/**
	 * Hidden at rest, as on the page before anything is clicked: the markers
	 * kerf.previewProps() puts where the design wrote `hidden`, `popover` or
	 * a closed `<dialog>`, REST_SHOW, which applyRest() sets where an Alpine
	 * `x-show` starts false, and SKIP, a "Skip to content" link. Shown while
	 * anything inside is selected (the selection path) or the element is
	 * revealed — see restHidden().
	 */
	var REST_MARKERS = [ 'data-kerf-hidden', 'data-kerf-popover', 'data-kerf-dialog', 'data-kerf-rest', 'data-kerf-skip' ];

	/**
	 * A design's "Skip to content" link: off the page until it has the
	 * keyboard's focus, which nothing gives it in the canvas — where the
	 * header part is drawn in the middle of the frame, it stood over the
	 * header (Parkdale's, Manhattan's). Known by its name or its words.
	 */
	var SKIP = 'data-kerf-skip';
	var SKIP_NAME = /\bskip/i;
	var SKIP_WORDS = /^\s*skip (?:to|navigation)\b/i;
	var REST_SHOW = 'data-kerf-rest';

	/**
	 * What preloaders are called: gymlife's `preloder` (sic), clark's
	 * `ftco-loader`, Plumberz's `spinner`, and the rest of the usual names.
	 * Only ever a second opinion — see applyPreloaders().
	 */
	var PRELOADER_NAME = /\b(?:pre-?loa?d(?:er|ing)?|(?:page-?|site-?|ftco-)?loader|loading|spinner)\b/i;

	/** The canvas-only stylesheet that paints script-set backgrounds. */
	var BACKGROUND_STYLE_ID = 'kerf-canvas-backgrounds';

	/**
	 * Attributes a template's script turns into a background image: Colorlib's
	 * `data-setbg` (every one of their templates), the ThemeForest staple
	 * `data-background`, `data-bg` and friends, and parallax.js's
	 * `data-image-src`. The converter resolves these to real URLs already
	 * (§5.22); only the script that applies them is missing in the editor.
	 */
	var BACKGROUND_ATTRS = [ 'data-setbg', 'data-background', 'data-bg', 'data-bg-image', 'data-background-image', 'data-bgimage', 'data-image-src' ];

	/**
	 * Selectors that belong to the editor rather than the mockup. Both passes
	 * that rewrite the mockup's CSS must leave these alone.
	 */
	var EDITOR_SELECTOR = /block-editor-|block-list__|components-|edit-post|edit-site|editor-styles-wrapper/;

	/**
	 * Hidden on the live page too, permanently — never a dropdown to open.
	 * It is often the ONLY hidden child of an icon link, which is precisely the
	 * shape the owned-dropdown test looks for.
	 */
	var SCREEN_READER_ONLY = /\b(?:sr-only|visually-hidden|screen-reader(?:-text)?)\b/i;

	/**
	 * Mockup stylesheets whose `:hover` rules are already rewritten. Keyed by
	 * the sheet object, so a <style> the editor re-renders — a settings change
	 * replaces its sheet — is a new key and gets rewritten again.
	 */
	var heldSheets = new WeakSet();

	/**
	 * Base stylesheet. Always injected; the mode rules below are appended when on.
	 *
	 * `display:revert` returns an element to its user-agent value, so a hidden
	 * <div> becomes block and a hidden <li> becomes list-item. That is right far
	 * more often than any single hard-coded value, and it is the only reasonable
	 * answer without knowing what the class would have set.
	 */
	var BASE_CSS = [
		'.' + SETTLED + '{',
		'opacity:1 !important;',
		'visibility:visible !important;',
		'transform:none !important;',
		/* The reveal is usually opacity+transform on a transition. Without this,
		   forcing the end state animates it every time the observer re-runs. */
		'transition:none !important;',
		'animation:none !important;',
		'}',

		/* A slider whose script never ran has its slides sitting as plain direct
		   children — the track markup is built by the init JS, which is exactly
		   what did not happen. Laying those children out as a card grid shows all
		   of them at once, side by side, at a size you can actually work with.
		   A nested scrollbox was the first attempt and it was worse than the
		   problem: one slide visible, the rest behind a scrollbar inside the
		   page, which is not how the section reads on the front end or in a
		   list of cards.
		   Where the direct child is a wrapper rather than a slide (Swiper), the
		   row holds one item and behaves exactly like block.

		   A wrapping FLEX row, not a grid. A grid area has a definite height,
		   so a slide written as `height: calc(100% - 30px)` — the usual way to
		   equalise carousel cards — resolved against it, came out shorter than
		   its content, and squeezed the card's image box: 250px in the editor,
		   280px on the page. In a flex row, as in the carousel's own track, the
		   percentage resolves to auto. */
		'.' + WIDGET + '{',
		'display:flex !important;',
		'flex-wrap:wrap !important;',
		'gap:16px !important;',
		'align-items:flex-start !important;',
		'max-height:none !important;',
		'overflow:visible !important;',
		'outline:1px dashed rgba(0,124,186,.35);',
		'outline-offset:-1px;',
		'}',

		/* Slides are laid out by the script that never ran, so they arrive
		   carrying widths and floats meant for a track that does not exist. */
		'.' + WIDGET + '>*{',
		'flex:1 1 280px !important;',
		'min-width:0 !important;',
		'width:auto !important;',
		'max-width:100% !important;',
		'margin:0 !important;',
		'float:none !important;',
		'transform:none !important;',
		'}',
		'.' + WIDGET + '[data-kerf-widget="stack"]>*{flex-basis:100% !important;}',

		/* One override per way of hiding something — see hiddenReason() — and
		   each applied ONLY to an element hidden that way. A missing reason means
		   a block that reports as selected and still cannot be seen. A blanket
		   override is the opposite failure: `display:revert` on a flex row and
		   `transform:none` on a panel centred with translate(-50%) both damage
		   an element that was never hidden by display or by transform. */
		'[' + REVEAL + ']{pointer-events:auto !important;transition:none !important;}',
		'[' + REVEAL + '~="display"]{display:revert !important;}',
		'[' + REVEAL + '~="visibility"]{visibility:visible !important;}',
		'[' + REVEAL + '~="opacity"]{opacity:1 !important;}',
		'[' + REVEAL + '~="content-visibility"]{content-visibility:visible !important;}',
		'[' + REVEAL + '~="clipped"]{clip-path:none !important;}',
		'[' + REVEAL + '~="collapsed"]{max-height:none !important;height:auto !important;overflow:visible !important;}',
		'[' + REVEAL + '~="offscreen"]{transform:none !important;}',

		/* High enough to clear any z-index a mockup plausibly uses (they top out
		   in the low thousands), low enough that it is still a normal number.
		   The previous value was 2147483000, which paints over everything in the
		   canvas including the block whose heading you were trying to read. */
		'[' + SPOTLIGHT + ']{',
		'z-index:100000 !important;',
		'outline:2px solid #007cba !important;',
		'outline-offset:2px !important;',
		'}',

		/* z-index needs a positioned box. Only a static one is given `relative`:
		   forcing it onto an absolutely positioned dropdown would drop it into
		   normal flow — scar 21, committed by the tool meant to repair it. */
		'[' + SPOTLIGHT + '="static"]{position:relative !important;}',

		'[' + INSTANT + ']{transition:none !important;}',

		/* A preloader the page's script would have removed. Selecting it (in the
		   List View) puts it on the selection path, and it shows again. */
		'[' + PRELOADER + ']:not([' + HOVER + ']){display:none !important;}',

		/* What the page hides until a script shows it — a site search panel, an
		   Alpine modal, a popover (REST_MARKERS). On the selection path, or
		   revealed as what the selected block owns, it shows as the design
		   draws it: the rule simply stops matching. */
		REST_MARKERS.map( function ( name ) {
			return '[' + name + ']:not([' + HOVER + ']):not([' + REVEAL + '])';
		} ).join( ',' ) + '{display:none !important;}',

		/* The page's title, above a design that has its own headline
		   (markTitle()): drawn as the editor's field it is, not as the
		   design's biggest heading. */
		'.editor-post-title[' + TITLE + ']{',
		'font:600 20px/1.35 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif !important;',
		'letter-spacing:normal !important;text-transform:none !important;text-shadow:none !important;',
		'color:#1e1e1e !important;background:#f6f7f7 !important;text-align:left !important;',
		'max-width:none !important;margin:0 !important;padding:12px 24px !important;',
		'border:0 !important;border-bottom:1px dashed #c3c4c7 !important;}',
		'.editor-post-title[' + TITLE + ']::before{',
		'content:attr(' + TITLE + ');display:block;margin-bottom:2px;',
		'font:500 11px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;',
		'letter-spacing:.04em;text-transform:uppercase;color:#757575;pointer-events:none;user-select:none;}',

		/* The space the page has between two inline pieces of an Element's
		   words (applyGaps()): drawn as the space it is, collapsing with one
		   already there, as white space does. */
		'[' + GAP + ']::before{content:" ";}'
	].join( '' );

	var OUTLINE_CSS = [
		'[data-type^="kerf/"]{outline:1px dashed rgba(0,124,186,.4);outline-offset:-1px;}',
		'[data-type^="kerf/"]:empty{min-height:18px;min-width:18px;background:rgba(0,124,186,.08);}'
	].join( '' );

	var XRAY_CSS = [
		'.kerf-xray *:not(svg):not(svg *){',
		'position:static !important;transform:none !important;z-index:auto !important;',
		'float:none !important;opacity:1 !important;visibility:visible !important;',
		'overflow:visible !important;clip-path:none !important;filter:none !important;',
		'max-height:none !important;animation:none !important;transition:none !important;}',
		'.kerf-xray div,.kerf-xray section,.kerf-xray article,.kerf-xray aside,',
		'.kerf-xray header,.kerf-xray footer,.kerf-xray nav,.kerf-xray main,',
		'.kerf-xray ul,.kerf-xray ol,.kerf-xray li,.kerf-xray p,.kerf-xray figure{',
		'display:block !important;width:auto !important;height:auto !important;',
		'min-height:0 !important;margin:0 0 2px !important;padding:2px 0 2px 10px !important;',
		'border-left:2px solid rgba(0,124,186,.25) !important;background-image:none !important;}',
		'.kerf-xray *::before,.kerf-xray *::after{display:none !important;}',
		'.kerf-xray img,.kerf-xray video,.kerf-xray iframe{max-width:180px !important;max-height:120px !important;}'
	].join( '' );

	// ─────────────────────────────────────────────────────────────────────────
	// Canvas plumbing
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Every document the block canvas might be in.
	 *
	 * The editor iframes its canvas in current WordPress and does not in some
	 * contexts, so both are handled rather than feature-detected.
	 *
	 * @return {Document[]}
	 */
	function canvasDocuments() {
		var docs = [];

		Array.prototype.forEach.call(
			document.querySelectorAll( 'iframe[name="editor-canvas"], iframe.edit-site-visual-editor__editor-canvas' ),
			function ( frame ) {
				try {
					if ( frame.contentDocument && frame.contentDocument.body ) {
						docs.push( frame.contentDocument );
					}
				} catch ( error ) {
					// Cannot happen same-origin, but a throw here would take the
					// whole editor down.
				}
			}
		);

		if ( document.querySelector( '.block-editor-block-list__layout' ) ) {
			docs.push( document );
		}

		return docs;
	}

	/**
	 * The element the blocks are rendered inside.
	 *
	 * @param {Document} doc
	 * @return {Element|null}
	 */
	function blockRoot( doc ) {
		return doc.querySelector( '.block-editor-block-list__layout' ) || doc.querySelector( '.editor-styles-wrapper' );
	}

	/**
	 * Ensure the stylesheet is present and current in a canvas document.
	 *
	 * @param {Document} doc
	 * @param {Object}   modes
	 */
	function ensureStyles( doc, modes ) {
		var css = BASE_CSS + ( modes.outline ? OUTLINE_CSS : '' ) + ( modes.xray ? XRAY_CSS : '' );
		var style = doc.getElementById( STYLE_ID );

		if ( ! style ) {
			style = doc.createElement( 'style' );
			style.id = STYLE_ID;
			( doc.head || doc.documentElement ).appendChild( style );
		}

		if ( style.textContent !== css ) {
			style.textContent = css;
		}

		if ( doc.body ) {
			doc.body.classList.toggle( 'kerf-xray', !! modes.xray );
		}
	}

	// ─────────────────────────────────────────────────────────────────────────
	// 0. Give the mockup its positioning back
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Re-assert every `position` the mockup's own stylesheets declare.
	 *
	 * The editor canvas ships this, from @wordpress/block-editor's content.css:
	 *
	 *     .block-editor-block-list__layout .block-editor-block-list__block {
	 *         position: relative;
	 *     }
	 *
	 * Two classes — specificity (0,2,0) — and every converted element carries
	 * both, because `useBlockProps` puts `block-editor-block-list__block` on the
	 * block and `useInnerBlocksProps` puts `block-editor-block-list__layout` on
	 * its parent. A mockup styling something with a single class, which is how
	 * essentially all of them are written, is (0,1,0) and loses.
	 *
	 * So `.dropdown { position: absolute }` silently became `relative` in the
	 * canvas: the dropdown dropped into normal flow, inflated its `<li>` to its
	 * own height, and `align-items:center` staggered the whole navigation into a
	 * diagonal. The same thing happens to every overlay, badge, caption, close
	 * button and sticky header in every mockup — the menu was just where it was
	 * most visible.
	 *
	 * Re-emitting the author's own declarations, in source order, with
	 * `!important`, is the narrowest fix available. It cannot invent a value: it
	 * only restores one the mockup already wrote and core happened to outrank.
	 *
	 * @param {Document} doc
	 */
	function reassertPositioning( doc ) {
		var existing = doc.getElementById( POSITION_STYLE_ID );
		var count    = doc.styleSheets.length;

		// Stylesheets load asynchronously and the canvas is remounted on
		// template switches, so "already done" also has to mean "done against
		// this many sheets".
		if ( existing && parseInt( existing.getAttribute( 'data-sheets' ), 10 ) === count ) {
			return;
		}

		var out = [];

		function walk( container, media ) {
			var rules;

			try {
				rules = container.cssRules;
			} catch ( error ) {
				return; // Cross-origin sheet (a CDN icon font). Nothing to read.
			}

			if ( ! rules ) {
				return;
			}

			for ( var i = 0; i < rules.length; i++ ) {
				var rule = rules[ i ];

				if ( 4 === rule.type ) { // @media
					walk( rule, rule.conditionText || ( rule.media && rule.media.mediaText ) || '' );
					continue;
				}
				if ( 12 === rule.type ) { // @supports
					walk( rule, media );
					continue;
				}
				if ( 1 !== rule.type || ! rule.selectorText || ! rule.style ) {
					continue;
				}

				var position = rule.style.getPropertyValue( 'position' );
				if ( ! position ) {
					continue;
				}

				// Never re-emit the editor's own rules. Doing so would pin
				// `.block-editor-block-list__block { position: relative }` with
				// !important and make the problem permanent.
				if ( EDITOR_SELECTOR.test( rule.selectorText ) ) {
					continue;
				}

				var declaration = rule.selectorText + '{position:' + position + ' !important}';
				out.push( media ? '@media ' + media + '{' + declaration + '}' : declaration );
			}
		}

		Array.prototype.forEach.call( doc.styleSheets, function ( sheet ) {
			var owner = sheet.ownerNode;

			// Skip anything this file injected, or the pass feeds on itself.
			if ( owner && owner.id && 0 === owner.id.indexOf( 'kerf-' ) ) {
				return;
			}

			walk( sheet, '' );
		} );

		if ( ! existing ) {
			existing = doc.createElement( 'style' );
			existing.id = POSITION_STYLE_ID;
			( doc.head || doc.documentElement ).appendChild( existing );
		}

		existing.setAttribute( 'data-sheets', count );
		existing.textContent = out.join( '\n' );
	}

	// ─────────────────────────────────────────────────────────────────────────
	// 1. Settled state
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Does this element hold anything a reader would miss?
	 *
	 * The whole point of the content test is to leave decorative layers alone. A
	 * gradient scrim, a hover glow, a `::before` overlay — those are SUPPOSED to
	 * sit at `opacity:0` and forcing them visible would put a grey sheet over the
	 * design. Something with text or a picture in it is different: if it is
	 * invisible in the editor, the author has lost a section.
	 *
	 * @param {Element} node
	 * @return {boolean}
	 */
	function hasContent( node ) {
		if ( node.textContent && node.textContent.trim().length > 1 ) {
			return true;
		}
		return !! node.querySelector( 'img, svg, video, iframe, canvas, picture, input, button' );
	}

	/**
	 * Is this element hidden on purpose, and still hidden for a real visitor?
	 *
	 * @param {Element}         node
	 * @param {CSSStyleDeclaration} style
	 * @return {boolean}
	 */
	function isDeliberatelyHidden( node, style ) {
		// Taken out of the flow AND positioned over the page: a modal, a drawer,
		// a tooltip. Nothing laid out in normal flow needs that.
		if ( 'fixed' === style.position || 'absolute' === style.position ) {
			return true;
		}

		if ( node.hasAttribute( 'hidden' ) || 'true' === node.getAttribute( 'aria-hidden' ) || restHidden( node ) ) {
			return true;
		}

		var role = node.getAttribute( 'role' );
		if ( 'dialog' === role || 'alertdialog' === role || 'tabpanel' === role || 'menu' === role ) {
			return true;
		}

		// The mockup's id, not the editor's `block-<clientId>` one.
		return DELIBERATELY_HIDDEN.test( ( node.getAttribute( 'class' ) || '' ) + ' ' + ( node.getAttribute( 'data-kerf-anchor' ) || node.id || '' ) );
	}

	/**
	 * Does the element announce itself as a reveal-on-scroll target — and is
	 * it not something hidden on purpose by name (a modal, a dropdown)?
	 *
	 * @param {Element} node
	 * @return {boolean}
	 */
	function isRevealAnimation( node ) {
		var names = ( node.getAttribute( 'class' ) || '' ) + ' ' + ( node.getAttribute( 'data-kerf-anchor' ) || '' );

		if ( DELIBERATELY_HIDDEN.test( names ) ) {
			return false;
		}
		if ( REVEAL_CLASS.test( node.getAttribute( 'class' ) || '' ) ) {
			return true;
		}
		return REVEAL_ATTRS.some( function ( attr ) {
			return node.hasAttribute( attr );
		} );
	}

	/**
	 * Why can't the user see this element? '' when they can.
	 *
	 * `display:none` is only the most obvious way to hide something, and a
	 * spotlight that tested for nothing else left three very common widgets
	 * unreachable — selected in the List View and still invisible on the canvas,
	 * which reads as the editor being broken:
	 *
	 *   collapsed   `max-height:0; overflow:hidden` — how nearly every
	 *               hand-rolled and jQuery accordion rests
	 *   content-visibility  a closed native `<details>`, hidden by the UA rather
	 *               than by any author CSS
	 *   offscreen   `transform:translateX(-100%)` — how nearly every slide-in
	 *               drawer and off-canvas menu rests
	 *
	 * The collapsed and offscreen tests are deliberately narrow. A zero-height
	 * wrapper whose children are all absolutely positioned is normal and not
	 * hidden, so a size test alone would fire on healthy markup and put a blue
	 * outline round it every time something inside was selected.
	 *
	 * @param {Element}             node
	 * @param {CSSStyleDeclaration} style
	 * @param {Element|null}        root  Canvas block root, for the offscreen test.
	 * @return {string} Reason, or ''.
	 */
	function hiddenReason( node, style, root ) {
		if ( 'none' === style.display ) {
			return 'display';
		}
		if ( 'hidden' === style.visibility || 'collapse' === style.visibility ) {
			return 'visibility';
		}
		if ( parseFloat( style.opacity ) < 0.05 ) {
			return 'opacity';
		}
		if ( 'hidden' === style.contentVisibility ) {
			return 'content-visibility';
		}
		if ( style.clipPath && 0 === style.clipPath.indexOf( 'inset(100%' ) ) {
			return 'clipped';
		}

		var rect = node.getBoundingClientRect();

		// Collapsed to nothing while still holding content. Requiring the clip
		// as well as the size is what separates a closed accordion from an
		// ordinary wrapper that happens to measure zero.
		if ( rect.height < 2 && hasContent( node ) ) {
			if ( 'hidden' === style.overflowY || '0px' === style.maxHeight || '0px' === style.height ) {
				return 'collapsed';
			}
		}

		// Entirely outside the canvas horizontally. An element in normal flow
		// cannot be, so this only ever catches something deliberately parked.
		if ( root && ( rect.width || rect.height ) ) {
			var bounds = root.getBoundingClientRect();
			if ( rect.right <= bounds.left || rect.left >= bounds.right ) {
				return 'offscreen';
			}
		}

		return '';
	}

	/**
	 * Reveal everything that is invisible only because its JS never ran.
	 *
	 * Two shapes, and they need different tests:
	 *
	 *   opacity / visibility   a reveal-on-scroll animation waiting for a class
	 *                          the page's JS adds. Laid out, just transparent.
	 *   display:none           a widget container — an Owl/Slick/Swiper carousel
	 *                          hides itself until its init script adds `.loaded`.
	 *                          Not laid out at all, so the box tests below cannot
	 *                          apply and the name list has to decide instead.
	 *
	 * A visitor sees both of these. Leaving them blank in the canvas is the
	 * editor disagreeing with the page, which is the thing this whole file is for.
	 *
	 * BOTH shapes run isDeliberatelyHidden() first, and both have to. A hover
	 * dropdown rests at `opacity:0` just as often as at `display:none`, and
	 * skipping the check on the transparent path force-opened every submenu and
	 * mega-panel in a converted header at once.
	 *
	 * @param {Document} doc
	 */
	function applySettled( doc ) {
		var root = blockRoot( doc );
		if ( ! root ) {
			return;
		}

		var view = doc.defaultView;

		if ( ! view ) {
			return;
		}

		// What was hidden at one width may be the design's own layout at
		// another: Dreamtime's menu, `display:none` under 1080px, was judged
		// a carousel whose script never ran while the canvas was 1037px wide,
		// and stayed a dashed two-column grid once it was drawn at a
		// desktop's width (§5.47). The marks are made again at a new width.
		var width = String( view.innerWidth );
		if ( doc.documentElement.getAttribute( 'data-kerf-width' ) !== width ) {
			Array.prototype.forEach.call( root.querySelectorAll( '.' + SETTLED + ',.' + WIDGET ), function ( node ) {
				node.classList.remove( SETTLED, WIDGET );
				node.removeAttribute( 'data-kerf-widget' );
			} );
			doc.documentElement.setAttribute( 'data-kerf-width', width );
		}

		var nodes = root.querySelectorAll( '*' );

		// A pathological mockup should degrade to "slow once", not "hangs".
		var limit = Math.min( nodes.length, 5000 );

		for ( var i = 0; i < limit; i++ ) {
			var node = nodes[ i ];

			if ( node.classList.contains( SETTLED )
				|| node.classList.contains( WIDGET )
				|| node.hasAttribute( REVEAL ) ) {
				continue;
			}

			var style = view.getComputedStyle( node );

			if ( 'none' === style.display ) {
				if ( isDeliberatelyHidden( node, style ) || ! hasContent( node ) ) {
					continue;
				}

				// A carousel is a box of slides. A link, a button or a span
				// hidden by the design is the design's: Brighton's header has a
				// phone link shown only in its phone menu and an address hidden
				// under 1280px, and each became a dashed row in the editor.
				if ( ! WIDGET_TAGS.test( node.tagName ) ) {
					continue;
				}

				// Only the outermost hidden container is marked. Revealing it
				// makes everything inside visible anyway, and marking each
				// descendant as well would cap and outline every slide
				// individually.
				if ( node.parentElement && node.parentElement.closest( '.' + WIDGET ) ) {
					continue;
				}

				node.classList.add( WIDGET );

				// A slider of full-height HERO slides is not a row of cards:
				// each slide was designed at the page's full width, and two side
				// by side squeezed a headline column to overflow the canvas. A
				// slide most of a viewport tall is stacked at full width instead.
				var first = node.firstElementChild;
				if ( first && first.getBoundingClientRect().height > view.innerHeight * 0.6 ) {
					node.setAttribute( 'data-kerf-widget', 'stack' );
				}
				continue;
			}

			var invisible = parseFloat( style.opacity ) < 0.05 || 'hidden' === style.visibility;

			if ( ! invisible ) {
				continue;
			}

			// `visibility` is INHERITED. Every item inside a closed dropdown
			// reports `hidden` too, and a plain `<li>` or `<a>` in normal flow
			// with an ordinary class looks exactly like a scroll-reveal — so
			// every menu item of every dropdown in a converted header was being
			// "settled" (66 in one real mockup): `transform:none` killed their
			// hover effects, and `visibility:visible` on a child overrides the
			// inherited value, so a menu hidden by visibility alone would render
			// its items floating over the page with no panel behind them.
			//
			// The element that decided is the one whose parent is visible, and
			// this walk is in document order, so that element has already been
			// judged on its own terms by the time its children come up.
			if ( node.parentElement && 'hidden' === view.getComputedStyle( node.parentElement ).visibility ) {
				continue;
			}

			// The same test the display:none branch runs, and leaving it out of
			// this one was a real bug: a hover-opened dropdown or mega-menu rests
			// at `opacity:0` (or `visibility:hidden`) rather than `display:none`,
			// so every submenu in a converted header was being force-revealed —
			// all of them at once, absolutely positioned, on top of each other.
			//
			// A scroll-reveal animation is usually on an element in normal flow,
			// so `position:absolute` separates the two cases — unless the
			// element says outright that it is a reveal. See REVEAL_CLASS.
			if ( isDeliberatelyHidden( node, style ) && ! isRevealAnimation( node ) ) {
				continue;
			}

			// Laid out but transparent is the reveal-animation signature. A box
			// with no size is collapsed for some other reason entirely.
			if ( ! node.offsetWidth && ! node.offsetHeight ) {
				continue;
			}

			if ( ! hasContent( node ) ) {
				continue;
			}

			node.classList.add( SETTLED );
		}
	}

	/**
	 * Hide the page preloader — the one thing a visitor sees that the editor
	 * should not.
	 *
	 * Most free templates cover the page with a full-screen loader (gymlife's
	 * `#preloder`, clark's `#ftco-loader`, Plumberz's `#spinner`) and take it
	 * away from a `load` handler. That script never runs in the editor, so the
	 * loader sat over the whole canvas: a black page with a spinner in the
	 * middle, and the template underneath painted over. A visitor sees it for
	 * half a second; the editor shows what they see after.
	 *
	 * A preloader is: shown; fixed or absolute over at least 80% of the canvas
	 * in both directions; stacked ABOVE the page (a positive z-index); with no
	 * text to speak of and nothing to click; and either spinning — it or
	 * something inside it runs an infinite animation — or named like one. The
	 * last test is what keeps a full-screen BACKGROUND layer on the canvas:
	 * Massively's `.bg` is fixed, empty and stacked the same way, and is the
	 * page's backdrop.
	 *
	 * Only the first few levels of the block tree are searched: a preloader is
	 * a top-level element in the mockup, and in the canvas it sits at most a
	 * template part and a frame deeper.
	 *
	 * @param {Document} doc
	 */
	function applyPreloaders( doc ) {
		var root = blockRoot( doc );
		var view = doc.defaultView;
		if ( ! root || ! view ) {
			return;
		}

		var spins = function ( node ) {
			var all = [ node ].concat( Array.prototype.slice.call( node.querySelectorAll( '*' ), 0, 40 ) );
			return all.some( function ( el ) {
				var s = view.getComputedStyle( el );
				return 'none' !== s.animationName && 'infinite' === s.animationIterationCount;
			} );
		};

		var visit = function ( parent, depth ) {
			Array.prototype.forEach.call( parent.children, function ( node ) {
				if ( node.hasAttribute( PRELOADER ) ) {
					return;
				}

				var style = view.getComputedStyle( node );
				var positioned = 'fixed' === style.position || 'absolute' === style.position;
				var shown = 'none' !== style.display && 'hidden' !== style.visibility && parseFloat( style.opacity ) >= 0.05;
				var above = parseInt( style.zIndex, 10 ) >= 1;

				if ( positioned && shown && above ) {
					var rect = node.getBoundingClientRect();
					if ( rect.width >= view.innerWidth * 0.8 && rect.height >= view.innerHeight * 0.8
						&& node.textContent.trim().length <= 30
						&& ! node.querySelector( 'a[href], button, input, select, textarea, iframe, video, form' )
						&& ( spins( node ) || PRELOADER_NAME.test( ( node.getAttribute( 'class' ) || '' ) + ' ' + ( node.getAttribute( 'data-kerf-anchor' ) || '' ) ) ) ) {
						node.setAttribute( PRELOADER, '' );
						return;
					}
				}

				if ( depth < 5 ) {
					visit( node, depth + 1 );
				}
			} );
		};

		visit( root, 0 );
	}

	/**
	 * Is the element hidden at rest by the canvas (REST_MARKERS), and not on
	 * the selection path or revealed?
	 *
	 * @param {Element} node
	 * @return {boolean}
	 */
	function restHidden( node ) {
		if ( node.hasAttribute( HOVER ) || node.hasAttribute( REVEAL ) ) {
			return false;
		}
		return REST_MARKERS.some( function ( name ) {
			return node.hasAttribute( name );
		} );
	}

	/**
	 * Hide what Alpine's `x-show` hides before anything is clicked.
	 *
	 * `<div class="overlay" x-show="modal" x-cloak>` under `x-data="{ modal:
	 * false }"` is a closed modal on the page; in the canvas, where Alpine
	 * does not run, it was a full-screen overlay over the design. The
	 * expression is read, never run — this is the admin's editor, and the
	 * design's code does not run here (§5.16): only names from the nearest
	 * `x-data` objects written as plain values (`{ open: false, tab: 'one' }`),
	 * literals, `!`, comparisons, `&&`, `||` and brackets. False → REST_SHOW.
	 * Anything else is unknown: hidden when the designer also wrote `x-cloak`
	 * (Alpine's "keep this out of sight until I decide"), shown otherwise.
	 *
	 * @param {Document} doc
	 */
	function applyRest( doc ) {
		var root = blockRoot( doc );
		if ( ! root ) {
			return;
		}

		Array.prototype.forEach.call( root.querySelectorAll( '[data-kerf-x-show]' ), function ( node ) {
			var shown = alpineShown( node );
			var hide = null === shown ? node.hasAttribute( 'data-kerf-x-cloak' ) : ! shown;

			if ( hide && ! node.hasAttribute( REST_SHOW ) ) {
				node.setAttribute( REST_SHOW, '' );
			} else if ( ! hide && node.hasAttribute( REST_SHOW ) ) {
				node.removeAttribute( REST_SHOW );
			}
		} );
	}

	/**
	 * Mark a design's skip links (SKIP), hidden at rest like a closed panel.
	 *
	 * @param {Document} doc
	 */
	function applySkipLinks( doc ) {
		var root = blockRoot( doc );
		if ( ! root ) {
			return;
		}
		Array.prototype.forEach.call( root.querySelectorAll( 'a' ), function ( node ) {
			if ( node.hasAttribute( SKIP ) ) {
				return;
			}
			var names = ( node.getAttribute( 'class' ) || '' ) + ' ' + ( node.getAttribute( 'data-kerf-anchor' ) || '' );
			var words = node.textContent || '';
			if ( words.length < 60 && ( SKIP_NAME.test( names ) || SKIP_WORDS.test( words ) ) ) {
				node.setAttribute( SKIP, '' );
			}
		} );
	}

	/**
	 * What an `x-show` starts as: true, false, or null when it cannot be told
	 * without running code.
	 *
	 * @param {Element} node
	 * @return {boolean|null}
	 */
	function alpineShown( node ) {
		var scope = {};

		// Nearest first: an inner x-data's name hides an outer one's.
		for ( var current = node; current; current = current.parentElement ) {
			if ( current.hasAttribute( 'data-kerf-x-data' ) ) {
				var values = alpineData( current.getAttribute( 'data-kerf-x-data' ) );
				Object.keys( values ).forEach( function ( key ) {
					if ( ! Object.prototype.hasOwnProperty.call( scope, key ) ) {
						scope[ key ] = values[ key ];
					}
				} );
			}
		}

		try {
			var value = alpineExpression( node.getAttribute( 'data-kerf-x-show' ), scope );
			return undefined === value ? null : !! value;
		} catch ( error ) {
			return null;
		}
	}

	/**
	 * The plain values of an `x-data` object: `{ open: false, tab: 'one',
	 * n: 0 }` → those three. A method, a getter or a call is left out, and a
	 * name only it could answer stays unknown. Only the object's own names:
	 * whatever is nested deeper (`list: [{ open: true }]`) is blanked first,
	 * its brackets kept, so the list itself still reads as a value.
	 *
	 * @param {string} source
	 * @return {Object}
	 */
	function alpineData( source ) {
		var values = {};
		var pair = /(?:^|[{,])\s*([A-Za-z_$][\w$]*|'[^']*'|"[^"]*")\s*:\s*(true|false|null|-?\d+(?:\.\d+)?|'[^']*'|"[^"]*"|\[\s*\]|\{\s*\})\s*(?=[,}])/g;
		var text = String( source || '' );
		var flat = '';
		var depth = 0;
		var quote = '';
		var match;

		for ( var i = 0; i < text.length; i++ ) {
			var ch = text.charAt( i );
			if ( quote ) {
				quote = ch === quote && '\\' !== text.charAt( i - 1 ) ? '' : quote;
			} else if ( '\'"`'.indexOf( ch ) > -1 ) {
				quote = ch;
			} else if ( '{[('.indexOf( ch ) > -1 ) {
				depth++;
				flat += depth <= 2 ? ch : ' ';
				continue;
			} else if ( '}])'.indexOf( ch ) > -1 ) {
				flat += depth <= 2 ? ch : ' ';
				depth--;
				continue;
			}
			flat += depth <= 1 ? ch : ' ';
		}

		while ( ( match = pair.exec( flat ) ) ) {
			var key = match[ 1 ].replace( /^['"]|['"]$/g, '' );
			if ( ! Object.prototype.hasOwnProperty.call( values, key ) ) {
				values[ key ] = alpineLiteral( match[ 2 ] );
			}
		}
		return values;
	}

	/**
	 * @param {string} token
	 * @return {*}
	 */
	function alpineLiteral( token ) {
		if ( 'true' === token || 'false' === token ) {
			return 'true' === token;
		}
		if ( 'null' === token ) {
			return null;
		}
		if ( /^['"]/.test( token ) ) {
			return token.slice( 1, -1 );
		}
		if ( /^-?\d/.test( token ) ) {
			return parseFloat( token );
		}
		return {}; // An empty list or object: truthy, which is all a test asks.
	}

	/**
	 * Evaluate the small part of JavaScript an `x-show` is usually written in.
	 * Throws on anything else; an unknown name answers undefined, which makes
	 * the whole answer unknown.
	 *
	 * @param {string} source
	 * @param {Object} scope
	 * @return {*}
	 */
	function alpineExpression( source, scope ) {
		var tokens = String( source || '' ).match( /\s*(===|!==|==|!=|>=|<=|&&|\|\||[!()<>]|'[^']*'|"[^"]*"|-?\d+(?:\.\d+)?|[A-Za-z_$][\w$]*|\S)/g ) || [];
		var at = 0;
		var UNKNOWN = {};

		tokens = tokens.map( function ( token ) {
			return token.trim();
		} );

		function peek() {
			return tokens[ at ];
		}
		function next() {
			return tokens[ at++ ];
		}
		function known( a, b, fn ) {
			return UNKNOWN === a || UNKNOWN === b ? UNKNOWN : fn( a, b );
		}

		function primary() {
			var token = next();
			if ( undefined === token ) {
				throw new Error( 'end' );
			}
			if ( '(' === token ) {
				var inner = or();
				if ( ')' !== next() ) {
					throw new Error( 'bracket' );
				}
				return inner;
			}
			if ( /^(?:true|false|null)$/.test( token ) || /^['"]/.test( token ) || /^-?\d/.test( token ) ) {
				return alpineLiteral( token );
			}
			if ( 'undefined' === token ) {
				return undefined;
			}
			if ( /^[A-Za-z_$][\w$]*$/.test( token ) ) {
				// `open.length`, `items[0]`, `toggle()`: more than a name.
				if ( peek() && /^[.[(]/.test( peek() ) ) {
					throw new Error( 'member' );
				}
				return Object.prototype.hasOwnProperty.call( scope, token ) ? scope[ token ] : UNKNOWN;
			}
			throw new Error( 'token' );
		}
		function unary() {
			if ( '!' === peek() ) {
				next();
				var value = unary();
				return UNKNOWN === value ? UNKNOWN : ! value;
			}
			return primary();
		}
		function relational() {
			var left = unary();
			while ( peek() && /^(?:<|>|<=|>=)$/.test( peek() ) ) {
				var op = next();
				var right = unary();
				left = known( left, right, function ( a, b ) {
					return '<' === op ? a < b : '>' === op ? a > b : '<=' === op ? a <= b : a >= b;
				} );
			}
			return left;
		}
		function equality() {
			var left = relational();
			while ( peek() && /^(?:===|!==|==|!=)$/.test( peek() ) ) {
				var op = next();
				var right = relational();
				left = known( left, right, function ( a, b ) {
					/* eslint-disable eqeqeq */
					return '===' === op ? a === b : '!==' === op ? a !== b : '==' === op ? a == b : a != b;
					/* eslint-enable eqeqeq */
				} );
			}
			return left;
		}
		function and() {
			var left = equality();
			while ( '&&' === peek() ) {
				next();
				var right = equality();
				// false && unknown is false whatever the unknown is.
				left = ( UNKNOWN !== left && ! left ) || ( UNKNOWN !== right && ! right ) ? false : known( left, right, function ( a, b ) {
					return a && b;
				} );
			}
			return left;
		}
		function or() {
			var left = and();
			while ( '||' === peek() ) {
				next();
				var right = and();
				left = ( UNKNOWN !== left && left ) || ( UNKNOWN !== right && right ) ? true : known( left, right, function ( a, b ) {
					return a || b;
				} );
			}
			return left;
		}

		var result = or();
		if ( at !== tokens.length ) {
			throw new Error( 'trailing' );
		}
		return UNKNOWN === result ? undefined : result;
	}

	/**
	 * The design's sheets the editor could not read, as written. See
	 * applyUnparsed(). An attribute, not an id: the hover and positioning
	 * passes leave sheets with an id alone, and this one is the design's.
	 */
	var UNPARSED = 'data-kerf-unparsed';
	var unparsedFor = null;
	var unparsedCss = '';
	var scopedSheets = [];

	/**
	 * Put in the canvas each of the design's stylesheets the editor dropped.
	 *
	 * The editor runs every stylesheet it is given through a strict CSS parser
	 * (`wp.blockEditor.transformStyles()`), and one it cannot parse is dropped
	 * WHOLE — while a browser drops only the rule it cannot read. The owner's
	 * chiropractic design was Times New Roman in the editor and right on the
	 * page: its stylesheet ended with rules saved in another encoding (UTF-16,
	 * a null byte after every letter), which the page simply skips. A sheet
	 * Kerf gave the editor (`kerfDesign`, inc/kerf-assets.php) that comes back
	 * from the editor's own transform as nothing is printed into the canvas as
	 * written, its relative `url()`s made absolute against where it lives —
	 * what the editor's transform would have done — so the canvas's browser
	 * reads it exactly as the page's does. Asked once per set of styles: the
	 * editor keeps each sheet's transform, so this costs nothing it had not
	 * already paid.
	 *
	 * After them, in the Site Editor, the sheets only some pages or templates
	 * load (§5.26) — those of what is shown (scopeApplies()).
	 *
	 * @param {Document} doc
	 */
	function applyUnparsed( doc ) {
		var store = wp.data.select( 'core/block-editor' );
		var settings = store && store.getSettings ? store.getSettings() : null;
		var styles = settings && settings.styles;
		var transform = wp.blockEditor && wp.blockEditor.transformStyles;

		if ( styles && transform && styles !== unparsedFor ) {
			unparsedFor = styles;
			unparsedCss = styles.filter( function ( style ) {
				if ( ! style || ! style.kerfDesign || ! style.css ) {
					return false;
				}
				try {
					return ! transform( [ style ] )[ 0 ];
				} catch ( error ) {
					return true;
				}
			} ).map( function ( style ) {
				return rebaseUrls( String( style.css ), style.baseURL || '' );
			} ).join( '\n' );
			scopedSheets = styles.filter( function ( style ) {
				return style && style.kerfScope && style.kerfCss;
			} ).map( function ( style ) {
				return { scope: style.kerfScope, css: rebaseUrls( String( style.kerfCss ), style.baseURL || '' ) };
			} );
		}

		// One element for both, in the design's order: a page's own sheets
		// come after the site's.
		var editor = wp.data.select( 'core/editor' );
		var type = editor && editor.getCurrentPostType ? editor.getCurrentPostType() : '';
		var id = editor && editor.getCurrentPostId ? editor.getCurrentPostId() : '';
		var css = [ unparsedCss ].concat( scopedSheets.filter( function ( sheet ) {
			return scopeApplies( sheet.scope, type, id );
		} ).map( function ( sheet ) {
			return sheet.css;
		} ) ).filter( Boolean ).join( '\n' );

		var node = doc.querySelector( 'style[' + UNPARSED + ']' );
		if ( ! css ) {
			if ( node ) {
				node.parentNode.removeChild( node );
			}
			return;
		}
		if ( ! node ) {
			node = doc.createElement( 'style' );
			node.setAttribute( UNPARSED, '' );
		}
		// Last in the body, with the design's other sheets (scar 89).
		if ( node.parentNode !== doc.body || node.nextSibling ) {
			doc.body.appendChild( node );
		}
		if ( node.textContent !== css ) {
			node.textContent = css;
		}
	}

	/**
	 * The page's title, when its content is a design: named as the field it is.
	 *
	 * With "Show template" off, WordPress draws a page's title above its
	 * content as an `<h1>` — in the design's own heading style, since the
	 * design's sheets style every `h1`. A page made of Kerf blocks renders
	 * through `kerf-mockup`, which shows no title: the owner's inner page
	 * opened under a huge "Inner Page" in the design's serif, which read as
	 * part of the page and is not on it. The title is the browser tab's and
	 * search results', and WordPress's lists'.
	 *
	 * @param {Document} doc
	 */
	function markTitle( doc ) {
		var title = doc.querySelector( '.editor-post-title' );
		if ( ! title ) {
			return;
		}
		var store = wp.data.select( 'core/block-editor' );
		var design = store && store.getBlocks && store.getBlocks().some( function ( block ) {
			return block && 0 === String( block.name ).indexOf( 'kerf/' );
		} );
		if ( ! design ) {
			if ( title.hasAttribute( TITLE ) ) {
				title.removeAttribute( TITLE );
			}
			return;
		}
		var words = __( 'Page title · shown in the browser tab and search results, not on the page', 'kerf-blocks' );
		if ( title.getAttribute( TITLE ) !== words ) {
			title.setAttribute( TITLE, words );
		}
	}

	/**
	 * Which of an Element's children the page has a space before: `gaps` holds
	 * one 1/0 per gap — before the first child, between each two, after the
	 * last (§5.20, kerf_apply_gaps()) — and a space before the first or after
	 * the last is no space between words.
	 *
	 * @param {string} gaps
	 * @param {number} count How many children.
	 * @return {number[]} The children (by index) with a space before them.
	 */
	function gapChildren( gaps, count ) {
		var out = [];
		gaps = String( gaps || '' );
		if ( gaps.length !== count + 1 || /[^01]/.test( gaps ) ) {
			return out;
		}
		for ( var i = 1; i < count; i++ ) {
			if ( '1' === gaps.charAt( i ) ) {
				out.push( i );
			}
		}
		return out;
	}

	var gapsFor = null;
	var gapTargets = [];

	/**
	 * The spaces between the pieces of an Element's words.
	 *
	 * `<li><a>Call us</a> or <a>book online</a></li>` is three blocks — two
	 * links and the bare word between them — and the page writes the spaces
	 * between them where the design had them (`gaps`, §5.20); the editor
	 * draws its blocks side by side with nothing between, so the list item
	 * read "Call usorbook online" there. AI writes such lines all the time
	 * (§5.48). A child the page has a space before is drawn with one — as a
	 * space of its own `::before`, which collapses into one already there —
	 * where white space shows: an inline child (a link, a word, a span, not
	 * a box laid out as one), in a parent that lays out text (a flex or grid
	 * parent drops spaces between its children on the page too), and only
	 * when the design draws nothing `::before` it already.
	 *
	 * @param {Document} doc
	 */
	function applyGaps( doc ) {
		var store = wp.data.select( 'core/block-editor' );
		if ( ! store || ! store.getBlocks ) {
			return;
		}
		var blocks = store.getBlocks();
		if ( blocks !== gapsFor ) {
			gapsFor = blocks;
			gapTargets = [];
			var walk = function ( list ) {
				list.forEach( function ( block ) {
					var inner = block.innerBlocks || [];
					if ( ( 'kerf/div' === block.name || 'kerf/figure' === block.name ) && inner.length > 1 ) {
						gapChildren( block.attributes && block.attributes.gaps, inner.length ).forEach( function ( i ) {
							gapTargets.push( inner[ i ].clientId );
						} );
					}
					walk( inner );
				} );
			};
			walk( blocks );
		}

		var view = doc.defaultView;
		var wanted = {};
		gapTargets.forEach( function ( id ) {
			wanted[ id ] = true;
		} );
		Array.prototype.forEach.call( doc.querySelectorAll( '[' + GAP + ']' ), function ( node ) {
			if ( ! wanted[ node.getAttribute( 'data-block' ) ] ) {
				node.removeAttribute( GAP );
			}
		} );
		if ( ! view ) {
			return;
		}
		gapTargets.forEach( function ( id ) {
			var node = doc.querySelector( '[data-block="' + id + '"]' );
			if ( ! node || ! node.parentElement ) {
				return;
			}
			var shown = 'inline' === view.getComputedStyle( node ).display && ! /flex|grid/.test( view.getComputedStyle( node.parentElement ).display );
			if ( ! shown ) {
				if ( node.hasAttribute( GAP ) ) {
					node.removeAttribute( GAP );
				}
				return;
			}
			if ( ! node.hasAttribute( GAP ) ) {
				var before = view.getComputedStyle( node, '::before' ).content;
				if ( ! before || 'none' === before || 'normal' === before ) {
					node.setAttribute( GAP, '' );
				}
			}
		} );
	}

	/**
	 * Does a stylesheet only some pages or templates load (§5.26) belong to
	 * what the Site Editor shows: one of its templates (`kerf//single`), or one
	 * of its pages? The server gives the Site Editor every such sheet apart
	 * (`kerfScope`, inc/kerf-assets.php), for it shows one template, part and
	 * page after another without loading again; a post's editor gets the ones
	 * it needs in their place, and none apart.
	 *
	 * @param {Object}        scope { pages: number[], templates: string[] }.
	 * @param {string}        type  The post type shown.
	 * @param {string|number} id    Its id: a template's is `theme//slug`.
	 * @return {boolean}
	 */
	function scopeApplies( scope, type, id ) {
		if ( ! scope ) {
			return false;
		}
		if ( 'wp_template' === type ) {
			var slug = String( id || '' );
			slug = slug.indexOf( '//' ) >= 0 ? slug.slice( slug.indexOf( '//' ) + 2 ) : slug;
			return ( scope.templates || [] ).indexOf( slug ) >= 0;
		}
		if ( 'wp_template_part' === type || 'wp_navigation' === type ) {
			return false;
		}
		return ( scope.pages || [] ).map( Number ).indexOf( parseInt( id, 10 ) ) >= 0;
	}

	/**
	 * `url(img/x.png)` → an absolute address, against the sheet's own.
	 *
	 * @param {string} css
	 * @param {string} base
	 * @return {string}
	 */
	function rebaseUrls( css, base ) {
		if ( ! base ) {
			return css;
		}
		return css.replace( /url\(\s*(['"]?)([^'")]+)\1\s*\)/gi, function ( all, quote, path ) {
			if ( /^(?:[a-z][a-z0-9+.-]*:|#)/i.test( path.trim() ) ) {
				return all;
			}
			try {
				return 'url(' + quote + new URL( path.trim(), base ).href + quote + ')';
			} catch ( error ) {
				return all;
			}
		} );
	}

	/**
	 * Paint the backgrounds a template's script would have set.
	 *
	 * `<div class="set-bg" data-setbg="img/hero.jpg">` is a background image
	 * only after `$('.set-bg').each(… css('background-image', …))` runs — and
	 * it does not run in the editor. gymlife's hero was a white box there, with
	 * the header's white links invisible on it, and every card, banner and
	 * featured post drawn the same way lost its picture.
	 *
	 * One rule per value, keyed on the attribute itself: nothing is added to
	 * the element, so React has nothing to take back (scar 28), and a block
	 * whose value changes simply matches a different rule. `!important`
	 * because on the page the script writes an inline style, which beats
	 * whatever the stylesheet says.
	 *
	 * @param {Document} doc
	 */
	function applyDataBackgrounds( doc ) {
		var root = blockRoot( doc );
		if ( ! root ) {
			return;
		}

		var quote = function ( value ) {
			return '"' + value.replace( /["\\]/g, '\\$&' ).replace( /[\n\r]/g, '' ) + '"';
		};
		var rules = [];
		var seen = {};

		BACKGROUND_ATTRS.forEach( function ( attr ) {
			Array.prototype.forEach.call( root.querySelectorAll( '[' + attr + ']' ), function ( node ) {
				var value = ( node.getAttribute( attr ) || '' ).trim();
				if ( ! value || /^(?:img|video|source|iframe|picture)$/i.test( node.tagName ) || seen[ attr + value ] ) {
					return;
				}
				// A background, not a lightbox's full-size link: an image URL.
				if ( ! /\.(?:jpe?g|png|gif|webp|avif|svg)(?:[?#].*)?$/i.test( value ) ) {
					return;
				}
				seen[ attr + value ] = true;
				rules.push( '[' + attr + '=' + quote( value ) + ']{background-image:url(' + quote( value ) + ') !important;}' );
			} );
		} );

		var css = rules.join( '' );
		var style = doc.getElementById( BACKGROUND_STYLE_ID );
		if ( ! style ) {
			if ( ! css ) {
				return;
			}
			style = doc.createElement( 'style' );
			style.id = BACKGROUND_STYLE_ID;
			( doc.head || doc.documentElement ).appendChild( style );
		}
		if ( style.textContent !== css ) {
			style.textContent = css;
		}
	}

	// ─────────────────────────────────────────────────────────────────────────
	// 2. Selection
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Teach the mockup's `:hover` rules to answer to the selection as well.
	 *
	 * On the page, pointing at a nav item opens its dropdown and keeps it open
	 * for as long as the pointer stays inside. In the canvas the pointer is
	 * busy: it clicks an item inside the dropdown, then leaves for the toolbar
	 * or the sidebar — and the dropdown closes under the block being edited.
	 * That is what made a converted menu close to impossible to edit.
	 *
	 * So every selector that uses `:hover` or `:focus-within` also gets a copy
	 * with `[data-kerf-hover]` in its place, and applySelection() puts that
	 * attribute on the selected block and each of its ancestors: exactly the
	 * elements `:hover` matches for a pointer resting on that block. The
	 * dropdown then opens by the mockup's OWN rule, at its own position with its
	 * own transform, instead of by an override guessing at what "open" means.
	 * The guess was `transform:none`, which un-centred every mega-menu built on
	 * `translate(-50%)`.
	 *
	 * Rewritten in place. A copy in a new stylesheet would sit after every rule
	 * the mockup wrote and win ties it should lose; in place, the copy keeps the
	 * original's position in the cascade, and an attribute selector has the
	 * same specificity as the pseudo-class it stands in for.
	 *
	 * Which sheets: add_editor_style() files reach the canvas as bare <style>
	 * elements. Skipped are the ones positively known not to be the design —
	 * anything with an id (core, plugins, this file) and WordPress's own CSS
	 * modules (`data-wp-hash`). A little editor UI still gets through (7.1's
	 * collaboration overlay renders a bare <style> into the canvas), and that is
	 * harmless by construction: a rewritten selector only matches along the
	 * selection path, and the path only ever runs through blocks. Narrowing
	 * further by guessing where the mockup's <style> elements sit would fail in
	 * the expensive direction — the day core moves them, holding stops, silently.
	 *
	 * @param {Document} doc
	 */
	function holdHoverRules( doc ) {
		Array.prototype.forEach.call( doc.styleSheets, function ( sheet ) {
			var owner = sheet.ownerNode;

			if ( ( owner && ( owner.id || ( owner.hasAttribute && owner.hasAttribute( 'data-wp-hash' ) ) ) )
				|| heldSheets.has( sheet ) ) {
				return;
			}

			heldSheets.add( sheet );
			holdRules( sheet );
		} );
	}

	/**
	 * @param {CSSStyleSheet|CSSRule} container
	 */
	function holdRules( container ) {
		var rules;

		try {
			rules = container.cssRules;
		} catch ( error ) {
			return; // Cross-origin: unreadable, and so unwritable too.
		}

		if ( ! rules ) {
			return;
		}

		for ( var i = 0; i < rules.length; i++ ) {
			var rule = rules[ i ];

			if ( rule.selectorText ) {
				var anchored = anchorSelector( rule.selectorText );
				var held = holdSelector( anchored || rule.selectorText );
				var next = held || anchored;

				// A selector the browser cannot parse is ignored rather than
				// thrown, so the worst a mis-rewrite can do is leave the rule as
				// it was.
				if ( next ) {
					rule.selectorText = next;
				}
			}

			// @media, @supports, @layer, @container, and nested style rules.
			if ( rule.cssRules ) {
				holdRules( rule );
			}

			// @import.
			if ( rule.styleSheet ) {
				holdRules( rule.styleSheet );
			}
		}
	}

	/**
	 * A selector list that also matches along the selection path, or '' when it
	 * has nothing to hold.
	 *
	 * `:focus-within` is held too. It is how an accessible dropdown opens from
	 * the keyboard, and it means the same thing as hover here: "on the path to
	 * the thing in use". Plain `:focus` is not — it matches one element, never
	 * its ancestors, so holding it along the path would be wrong.
	 *
	 * @param {string} selector
	 * @return {string}
	 */
	function holdSelector( selector ) {
		if ( ! /:(?:hover|focus-within)/i.test( selector )
			|| EDITOR_SELECTOR.test( selector )
			|| -1 !== selector.indexOf( HOVER_SELECTOR ) ) {
			return '';
		}

		var extra = [];

		splitSelectorList( selector ).forEach( function ( complex ) {
			var held = holdComplex( complex );
			if ( held ) {
				extra.push( held );
			}
		} );

		return extra.length ? selector + ', ' + extra.join( ', ' ) : '';
	}

	/**
	 * Make every `#id` in a selector also match the block that carries that id.
	 *
	 * In the canvas a block's element has WordPress's `id="block-<clientId>"`;
	 * the mockup's id is only printed on the front end. So every `#hero`,
	 * `#back-to-top`, `#header` rule applied on the page and silently not in
	 * the editor. The mockup id is exposed as `data-kerf-anchor` (see the
	 * BlockListBlock filter below), and `#x` becomes
	 * `:is(#x,[data-kerf-anchor="x"])` — `:is()` takes its argument's highest
	 * specificity, so the rule keeps an id's weight and its cascade position.
	 *
	 * @param {string} selector
	 * @return {string} The rewritten selector, or '' when it has no id.
	 */
	function anchorSelector( selector ) {
		if ( -1 === selector.indexOf( '#' ) || -1 !== selector.indexOf( 'data-kerf-anchor' ) || EDITOR_SELECTOR.test( selector ) ) {
			return '';
		}

		var out = '';
		var quote = '';
		var brackets = 0;
		var changed = false;

		for ( var i = 0; i < selector.length; i++ ) {
			var ch = selector.charAt( i );

			if ( '\\' === ch ) {
				out += selector.substr( i, 2 );
				i++;
				continue;
			}
			if ( quote ) {
				if ( ch === quote ) {
					quote = '';
				}
				out += ch;
				continue;
			}
			if ( '"' === ch || "'" === ch ) {
				quote = ch;
			} else if ( '[' === ch ) {
				brackets++;
			} else if ( ']' === ch ) {
				brackets--;
			} else if ( '#' === ch && ! brackets ) {
				// An identifier, escapes included: `#foo`, `#item-2`, `#a\:b`,
				// and `#\31 23` — how the browser serializes an id that starts
				// with a digit.
				var m = /^(?:[\w-]|\\[0-9a-fA-F]{1,6} ?|\\.|[^\x00-\x7f])+/.exec( selector.slice( i + 1 ) );
				if ( m ) {
					var raw = m[ 0 ];
					var id = raw
						.replace( /\\([0-9a-fA-F]{1,6}) ?/g, function ( all, hex ) {
							return String.fromCodePoint( parseInt( hex, 16 ) );
						} )
						.replace( /\\(.)/g, '$1' );
					out += ':is(#' + raw + ',[data-kerf-anchor="' + id.replace( /["\\]/g, '\\$&' ) + '"])';
					i += raw.length;
					changed = true;
					continue;
				}
			}

			out += ch;
		}

		return changed ? out : '';
	}

	/**
	 * Split a selector list at its top-level commas — not the ones inside
	 * `:is()`, an attribute value, or an escape.
	 *
	 * @param {string} selector
	 * @return {string[]}
	 */
	function splitSelectorList( selector ) {
		var parts = [];
		var depth = 0;
		var quote = '';
		var start = 0;

		for ( var i = 0; i < selector.length; i++ ) {
			var ch = selector.charAt( i );

			if ( '\\' === ch ) {
				i++;
				continue;
			}
			if ( quote ) {
				if ( ch === quote ) {
					quote = '';
				}
				continue;
			}

			if ( '"' === ch || "'" === ch ) {
				quote = ch;
			} else if ( '(' === ch || '[' === ch ) {
				depth++;
			} else if ( ')' === ch || ']' === ch ) {
				depth--;
			} else if ( ',' === ch && 0 === depth ) {
				parts.push( selector.slice( start, i ).trim() );
				start = i + 1;
			}
		}

		parts.push( selector.slice( start ).trim() );

		return parts;
	}

	/**
	 * One complex selector with `:hover` / `:focus-within` replaced by the
	 * path attribute, or '' when it has neither.
	 *
	 * Also '' when either sits inside `:not()`. There the swap inverts the rule
	 * for an element the pointer really is over: `.menu:not(:hover) .item`
	 * would go on matching while you hover the menu, because the attribute is
	 * absent. Leaving such a rule alone costs nothing — the original still
	 * works exactly as before.
	 *
	 * Tailwind escapes its variant colons (`.hover\:underline:hover`), which is
	 * why escapes are stepped over rather than read.
	 *
	 * @param {string} selector
	 * @return {string}
	 */
	function holdComplex( selector ) {
		var out = '';
		var quote = '';
		var brackets = 0;
		var functions = []; // Open functional pseudo-classes, innermost last.
		var held = false;

		for ( var i = 0; i < selector.length; i++ ) {
			var ch = selector.charAt( i );

			if ( '\\' === ch ) {
				out += selector.substr( i, 2 );
				i++;
				continue;
			}
			if ( quote ) {
				if ( ch === quote ) {
					quote = '';
				}
				out += ch;
				continue;
			}

			if ( '"' === ch || "'" === ch ) {
				quote = ch;
			} else if ( '[' === ch ) {
				brackets++;
			} else if ( ']' === ch ) {
				brackets--;
			} else if ( '(' === ch ) {
				functions.push( '' );
			} else if ( ')' === ch ) {
				functions.pop();
			} else if ( ':' === ch && ! brackets ) {
				var rest = selector.slice( i + 1 );
				var state = /^(?:hover|focus-within)(?![\w-])/i.exec( rest );

				if ( state ) {
					if ( -1 !== functions.indexOf( 'not' ) ) {
						return '';
					}
					out += HOVER_SELECTOR;
					i += state[ 0 ].length;
					held = true;
					continue;
				}

				var fn = /^([\w-]+)\(/.exec( rest );

				if ( fn ) {
					functions.push( fn[ 1 ].toLowerCase() );
					out += ':' + fn[ 0 ];
					i += fn[ 0 ].length;
					continue;
				}
			}

			out += ch;
		}

		return held ? out : '';
	}

	/**
	 * Put the hover attribute on exactly the elements in `path`.
	 *
	 * A diff rather than clear-and-set. The passes after this one measure, a
	 * measurement is a style change, and a dropdown that loses its hold for the
	 * length of one starts a closing transition the user sees.
	 *
	 * @param {Document}  doc
	 * @param {Element[]} path
	 */
	function holdPath( doc, path ) {
		Array.prototype.forEach.call( doc.querySelectorAll( HOVER_SELECTOR ), function ( node ) {
			if ( -1 === path.indexOf( node ) ) {
				node.removeAttribute( HOVER );
			}
		} );

		path.forEach( function ( node ) {
			if ( ! node.hasAttribute( HOVER ) ) {
				node.setAttribute( HOVER, '' );
			}
		} );
	}

	/**
	 * Force an element visible, overriding only what hid it.
	 *
	 * One reason at a time, re-measuring after each, because an element is often
	 * hidden two ways at once — `opacity:0` AND `visibility:hidden` is how most
	 * dropdowns rest — and hiddenReason() names one per call.
	 *
	 * @param {Element}      node
	 * @param {Window}       view
	 * @param {Element|null} root
	 * @return {boolean} Whether anything had to be overridden.
	 */
	function reveal( node, view, root ) {
		var reasons = [];

		// Hidden at rest by the canvas itself (REST_MARKERS): lifting that
		// first, alone, shows the element as the design draws it. Measured
		// as `display`, the override would be `display:revert` — a block
		// where the design's panel is a grid or a flex row.
		if ( restHidden( node ) ) {
			reasons.push( 'rest' );
			node.setAttribute( REVEAL, 'rest' );
		}

		// Bounded: an override that does not take (a mockup `!important` with
		// more specificity) reports the same reason again.
		while ( reasons.length < 8 ) {
			var reason = hiddenReason( node, view.getComputedStyle( node ), root );

			if ( ! reason || -1 !== reasons.indexOf( reason ) ) {
				break;
			}

			reasons.push( reason );
			node.setAttribute( REVEAL, reasons.join( ' ' ) );
		}

		return reasons.length > 0;
	}

	/**
	 * Hidden elements up to two levels inside `node` — the dropdown it owns.
	 *
	 * @param {Element} node
	 * @param {Window}  view
	 * @return {Element[]} Stops at two: past one, the answer is "none" anyway.
	 */
	function hiddenWithin( node, view ) {
		var found = [];

		function scan( el, depth ) {
			if ( depth > 2 || found.length > 1 ) {
				return;
			}
			if ( hiddenReason( el, view.getComputedStyle( el ), null ) ) {
				if ( ! SCREEN_READER_ONLY.test( el.getAttribute( 'class' ) || '' ) ) {
					found.push( el );
				}
				return; // Do not descend into something already hidden.
			}
			Array.prototype.forEach.call( el.children, function ( child ) {
				scan( child, depth + 1 );
			} );
		}

		Array.prototype.forEach.call( node.children, function ( child ) {
			scan( child, 1 );
		} );

		return found;
	}

	/**
	 * Show the selected block, and keep it shown while it is selected.
	 *
	 * Three steps, each only for what the one before left hidden:
	 *
	 *   hold    the selection path gets HOVER, so every hover dropdown on it
	 *           opens exactly as it does for a visitor pointing there, and stays
	 *           open wherever the real pointer goes
	 *   reveal  whatever on the path is STILL hidden — a JS-driven modal, tab or
	 *           drawer has no CSS state to borrow — is forced visible
	 *   owned   nothing on the path was hidden: open the one hidden thing the
	 *           selected element owns, if there is exactly one
	 *
	 * Selecting a nav `<li>` from the List View is what "owned" is for, when its
	 * dropdown is not a hover dropdown. EXACTLY ONE, within two levels: selecting
	 * the `<ul>` that holds six items should open none of their panels.
	 *
	 * Runs on every selection change and on every poll, so it must be idempotent
	 * and, when nothing changed, invisible. Transitions are what make that hard —
	 * see INSTANT below.
	 *
	 * @param {Document}    doc
	 * @param {string|null} clientId
	 */
	function applySelection( doc, clientId ) {
		var view = doc.defaultView;
		var root = blockRoot( doc );

		if ( ! view || ! root ) {
			return;
		}

		var node = clientId ? doc.querySelector( '[data-block="' + clientId + '"]' ) : null;
		var path = [];

		for ( var current = node; current && current !== root && current !== doc.body; current = current.parentElement ) {
			path.push( current );
		}

		// Everything below is measured straight after it changes, and a change
		// that animates cannot be measured: mid-fade, a panel that is opening
		// reads as hidden and one that is closing reads as visible. Clearing the
		// last pass's reveals with the mockup's transitions live made every
		// revealed panel start to fade, read as visible, not get re-revealed,
		// finish fading, and come back a poll later — a blink every few seconds.
		// INSTANT turns transitions off for exactly the elements in play, for
		// exactly this pass.
		var instant = [];

		function freeze( el ) {
			el.setAttribute( INSTANT, '' );
			instant.push( el );
		}

		Array.prototype.forEach.call( doc.querySelectorAll( '[' + REVEAL + '],[' + SPOTLIGHT + ']' ), function ( el ) {
			freeze( el );
			el.removeAttribute( REVEAL );
			el.removeAttribute( SPOTLIGHT );
		} );

		// Whatever the hold is about to open has to be measurable open straight
		// away, so it opens at once rather than fading in.
		path.concat( node ? hiddenWithin( node, view ) : [] ).forEach( function ( el ) {
			if ( hiddenReason( el, view.getComputedStyle( el ), root ) ) {
				freeze( el );
			}
		} );

		holdPath( doc, path );

		// Outermost first. `visibility` is inherited, so measured from the block
		// upward, every element inside a hidden panel reports hidden as well,
		// and each one used to get the full override — `display:revert` turned a
		// flex row of mega-menu columns into a stack. Top-down, revealing the
		// panel makes its contents visible and they are left alone.
		var lifted = null;

		for ( var i = path.length - 1; i >= 0; i-- ) {
			if ( reveal( path[ i ], view, root ) && ! lifted ) {
				lifted = path[ i ];
			}
		}

		if ( ! lifted && node ) {
			var owned = hiddenWithin( node, view );

			if ( 1 === owned.length && hasContent( owned[ 0 ] ) && reveal( owned[ 0 ], view, null ) ) {
				lifted = owned[ 0 ];
			}
		}

		// Only a forced reveal is lifted and outlined. Whatever the hold opened
		// is already painted where the page paints it, and lifting it would be
		// the tool rearranging a design that works.
		if ( lifted ) {
			lifted.setAttribute( SPOTLIGHT, 'static' === view.getComputedStyle( lifted ).position ? 'static' : '' );
		}

		showClipped( node, view, root );

		// Let every change above land while transitions are still off, then turn
		// them back on. Removing INSTANT changes only `transition` itself, which
		// starts nothing.
		instant.forEach( function ( el ) {
			view.getComputedStyle( el ).getPropertyValue( 'opacity' );
			el.removeAttribute( INSTANT );
		} );
	}

	/** Boxes showClipped() scrolled, with where they were: [ el, left, top ]. */
	var clipScrolled = [];

	/**
	 * Scroll the selected block into the box that clips it.
	 *
	 * A carousel's track is wider than its window (`overflow:hidden`), and
	 * its script moves it; in the canvas nothing does, so the second card,
	 * selected in the List View, stayed half cut off at the window's edge —
	 * the editor scrolls the PAGE to a block, never a box inside it (the
	 * owner's report, Elevation's before-and-after cards). A box that hides
	 * its overflow can still be scrolled from a script: each one round the
	 * block is scrolled just enough to show it, and put back when the
	 * selection leaves it, so the section rests as the page draws it.
	 *
	 * @param {Element|null} node
	 * @param {Window}       view
	 * @param {Element}      root
	 */
	function showClipped( node, view, root ) {
		clipScrolled = clipScrolled.filter( function ( entry ) {
			if ( node && entry[ 0 ].isConnected && entry[ 0 ].contains( node ) ) {
				return true;
			}
			entry[ 0 ].scrollLeft = entry[ 1 ];
			entry[ 0 ].scrollTop = entry[ 2 ];
			return false;
		} );

		if ( ! node ) {
			return;
		}

		for ( var box = node.parentElement; box && box !== root && box !== node.ownerDocument.body; box = box.parentElement ) {
			var style = view.getComputedStyle( box );
			var across = 'visible' !== style.overflowX && 'clip' !== style.overflowX && box.scrollWidth > box.clientWidth + 1;
			var down = 'visible' !== style.overflowY && 'clip' !== style.overflowY && box.scrollHeight > box.clientHeight + 1;

			if ( ! across && ! down ) {
				continue;
			}

			var outer = box.getBoundingClientRect();
			var inner = node.getBoundingClientRect();
			// Its start first: a block wider than the box shows from its left.
			var dx = ! across ? 0
				: inner.left < outer.left ? inner.left - outer.left
				: inner.right > outer.right ? Math.min( inner.right - outer.right, inner.left - outer.left ) : 0;
			var dy = ! down ? 0
				: inner.top < outer.top ? inner.top - outer.top
				: inner.bottom > outer.bottom ? Math.min( inner.bottom - outer.bottom, inner.top - outer.top ) : 0;

			if ( Math.abs( dx ) < 1 && Math.abs( dy ) < 1 ) {
				continue;
			}

			var known = clipScrolled.some( function ( entry ) {
				return entry[ 0 ] === box;
			} );
			if ( ! known ) {
				clipScrolled.push( [ box, box.scrollLeft, box.scrollTop ] );
			}
			box.scrollLeft += dx;
			box.scrollTop += dy;
		}
	}

	/**
	 * Remove every selection mark in a document.
	 *
	 * @param {Document} doc
	 */
	function clearSelection( doc ) {
		Array.prototype.forEach.call(
			doc.querySelectorAll( HOVER_SELECTOR + ',[' + REVEAL + '],[' + SPOTLIGHT + '],[' + INSTANT + ']' ),
			function ( node ) {
				node.removeAttribute( HOVER );
				node.removeAttribute( REVEAL );
				node.removeAttribute( SPOTLIGHT );
				node.removeAttribute( INSTANT );
			}
		);
	}

	// ─────────────────────────────────────────────────────────────────────────
	// Driver
	// ─────────────────────────────────────────────────────────────────────────

	var modes = load();
	var lastSelection = null;
	var scheduled = null;

	/**
	 * @return {Object}
	 */
	function load() {
		try {
			return JSON.parse( window.localStorage.getItem( STORAGE_KEY ) ) || {};
		} catch ( error ) {
			return {};
		}
	}

	/**
	 * @param {Object} next
	 */
	function save( next ) {
		try {
			window.localStorage.setItem( STORAGE_KEY, JSON.stringify( next ) );
		} catch ( error ) {
			// Private browsing; the mode still works for this session.
		}
	}

	/**
	 * The width a desktop visitor's page is laid out at: past the design's
	 * tablet width (KerfResponsive, inc/kerf-responsive.php), and never under
	 * 1200 — a menu that turns into a phone's button at 1199 is common even
	 * where the design's tablet layout starts lower — nor over a laptop's 1280.
	 *
	 * @return {number}
	 */
	function desktopWidth() {
		var widths = window.KerfResponsive || {};
		var tablet = parseInt( widths.tablet, 10 ) || 1199;
		return Math.min( 1280, Math.max( 1200, tablet + 1 ) );
	}

	/** The canvas frame Kerf sized; see fitCanvas(). */
	var FIT = 'data-kerf-fit';
	var fitWatched = typeof WeakSet === 'function' ? new WeakSet() : null;

	/**
	 * Lay the canvas out at a desktop's width, scaled to the room there is.
	 *
	 * The canvas is as wide as what the sidebars leave: about 1000px on a
	 * laptop with the List View and the settings open. The design's own media
	 * queries then answer as they would on a tablet — the header's menu became
	 * its phone button and the mega menu, revealed for editing, stood squeezed
	 * in the tablet's column (the owner's report). A visitor on a desktop never
	 * sees that page. So the frame is given the desktop width and drawn at the
	 * scale that fits (CSS `zoom`: its box stays the room's size, and the
	 * editor's toolbars, which read the frame's scale, still land on the
	 * block). Never in a device preview or a width the owner chose (the
	 * resizable canvas has a width in pixels then), nor zoomed out, where the
	 * editor scales the page itself; "Show the canvas at its own width" under
	 * Troubleshoot turns it off.
	 *
	 * @return {boolean} Whether a frame's size changed.
	 */
	function fitCanvas() {
		var changed = false;
		var editor = wp.data.select( 'core/editor' );
		var device = editor && editor.getDeviceType ? editor.getDeviceType() : 'Desktop';
		var want = desktopWidth();

		Array.prototype.forEach.call( document.querySelectorAll( 'iframe[name="editor-canvas"]' ), function ( frame ) {
			var box = frame.parentElement;
			if ( ! box ) {
				return;
			}

			// The sidebars opening and closing resize the room, not the window.
			if ( fitWatched && window.ResizeObserver && ! fitWatched.has( box ) ) {
				fitWatched.add( box );
				new window.ResizeObserver( schedule ).observe( box );
			}

			var sized = frame.closest( '.editor-resizable-editor' );
			var chosen = sized && /px$/.test( sized.style.width || '' );
			var zoomed = box.classList.contains( 'is-zoomed-out' );
			var room = box.clientWidth;
			var scale = ! modes.actual && 'Desktop' === device && ! chosen && ! zoomed && room > 0 && room < want - 1
				? Math.max( 0.5, room / want )
				: 1;

			if ( scale < 1 ) {
				var zoom = String( Math.floor( scale * 1000 ) / 1000 );
				if ( frame.style.zoom !== zoom || frame.style.width !== want + 'px' ) {
					frame.style.zoom = zoom;
					frame.style.width = want + 'px';
					frame.setAttribute( FIT, '' );
					changed = true;
				}
			} else if ( frame.hasAttribute( FIT ) ) {
				frame.style.removeProperty( 'zoom' );
				frame.style.removeProperty( 'width' );
				frame.removeAttribute( FIT );
				changed = true;
			}
		} );

		return changed;
	}

	/**
	 * Re-apply everything. Idempotent — the canvas iframe is remounted whenever
	 * the editor changes template, device preview or edit mode, and anything
	 * written into the old document goes with it.
	 */
	function refresh() {
		var selected = wp.data.select( 'core/block-editor' )
			? wp.data.select( 'core/block-editor' ).getSelectedBlockClientId()
			: null;

		// First: everything below measures the page at the width it is drawn.
		// A frame just resized lays out again on the browser's next pass, not
		// at once: measured now, the design's narrower layout would answer.
		if ( fitCanvas() ) {
			schedule();
			return;
		}

		canvasDocuments().forEach( function ( doc ) {
			ensureStyles( doc, modes );

			// Before the passes that read the design's sheets.
			applyUnparsed( doc );
			markTitle( doc );
			applyGaps( doc );

			// First, so the positioning pass below reads the selectors in their
			// final form and the two stay consistent.
			holdHoverRules( doc );

			// Before anything measures a computed style, because everything
			// below reads positions and sizes that this corrects.
			reassertPositioning( doc );

			// X-ray already forces everything visible, so the measured pass
			// would find nothing and the spotlight outline would be noise.
			if ( modes.xray ) {
				clearSelection( doc );
				return;
			}

			// Before the settled pass, which would take a closed Alpine panel
			// for a carousel whose script never ran.
			applyRest( doc );
			applySkipLinks( doc );
			applyPreloaders( doc );
			applyDataBackgrounds( doc );
			applySettled( doc );
			applySelection( doc, selected );
		} );

		lastSelection = selected;
	}

	/**
	 * Coalesce bursts of work into one pass on the next frame.
	 */
	function schedule() {
		if ( scheduled ) {
			return;
		}
		scheduled = window.setTimeout( function () {
			scheduled = null;
			refresh();
		}, 120 );
	}

	// Selection changes are the spotlight trigger, and they are frequent, so
	// only do work when the selected block actually changed.
	wp.data.subscribe( function () {
		var store = wp.data.select( 'core/block-editor' );
		if ( ! store ) {
			return;
		}
		if ( store.getSelectedBlockClientId() !== lastSelection ) {
			schedule();
		}
	} );

	// The canvas mounts late, remounts on template switch, and re-renders as
	// blocks are edited. A slow poll is far simpler than tracking every event
	// that can replace the document, and the work is cheap because both passes
	// skip anything already marked.
	window.setInterval( schedule, 1500 );

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', schedule );
	} else {
		schedule();
	}

	// ─────────────────────────────────────────────────────────────────────────
	// Sidebar panel
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Troubleshooting toggles. Deliberately collapsed and deliberately last:
	 * both of them trade away the real design for legibility, which is a thing
	 * you should reach for after the automatic behaviour has failed you, not
	 * before.
	 *
	 * @return {Object} Element.
	 */
	function CanvasPanel() {
		var state = useState( modes );
		var current = state[ 0 ];
		var setCurrent = state[ 1 ];

		useEffect( function () {
			modes = current;
			save( current );
			refresh();
		}, [ current.outline, current.xray, current.actual ] );

		function toggle( key ) {
			return function ( next ) {
				var updated = Object.assign( {}, current );
				updated[ key ] = next;
				setCurrent( updated );
			};
		}

		return el( PanelBody, { title: __( 'Troubleshoot', 'kerf-blocks' ), initialOpen: false },
			el( 'p', { className: 'kerf-help' },
				__( 'Kerf already shows sections whose scroll animation cannot run here, keeps a dropdown open while you edit inside it, and reveals a hidden block when you select it. These are for when a mockup does something that defeats all three.', 'kerf-blocks' )
			),
			el( ToggleControl, {
				label: __( 'Outline every block', 'kerf-blocks' ),
				checked: !! current.outline,
				onChange: toggle( 'outline' ),
				help: __( 'Draws a boundary around each block without changing the layout.', 'kerf-blocks' ),
				__nextHasNoMarginBottom: true
			} ),
			el( ToggleControl, {
				label: __( 'Show the canvas at its own width', 'kerf-blocks' ),
				checked: !! current.actual,
				onChange: toggle( 'actual' ),
				help: __( 'Where the sidebars leave less room than a desktop screen, Kerf draws the page at a desktop width, made smaller to fit, so you edit the layout desktop visitors see. On: the page is laid out at the room there is, as a tablet would show it. The Preview menu shows tablet and mobile.', 'kerf-blocks' ),
				__nextHasNoMarginBottom: true
			} ),
			el( ToggleControl, {
				label: __( 'Flatten the page', 'kerf-blocks' ),
				checked: !! current.xray,
				onChange: toggle( 'xray' ),
				help: __( 'Strips all positioning so nothing can overlap or hide. Destroys the design while it is on — switch it off when you have found what you were looking for.', 'kerf-blocks' ),
				__nextHasNoMarginBottom: true
			} )
		);
	}

	window.kerf = window.kerf || {};
	window.kerf.CanvasPanel = CanvasPanel;

	// Every block with an anchor carries it as `data-kerf-anchor` in the
	// canvas, where its real id is WordPress' `block-<clientId>`. Core blocks
	// too — a mockup heading keeps its id as an anchor. anchorSelector() is the
	// other half.
	if ( wp.hooks && wp.compose ) {
		wp.hooks.addFilter( 'editor.BlockListBlock', 'kerf/anchor-attribute', wp.compose.createHigherOrderComponent( function ( BlockListBlock ) {
			return function ( props ) {
				var anchor = props.attributes && props.attributes.anchor;

				if ( ! anchor ) {
					return el( BlockListBlock, props );
				}

				return el( BlockListBlock, Object.assign( {}, props, {
					wrapperProps: Object.assign( {}, props.wrapperProps, { 'data-kerf-anchor': anchor } )
				} ) );
			};
		}, 'withKerfAnchor' ) );
	}
}( window.wp ) );
