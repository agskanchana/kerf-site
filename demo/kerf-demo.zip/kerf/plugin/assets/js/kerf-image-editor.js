/**
 * kerf/image — a bare <img>.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var MediaPlaceholder = blockEditor.MediaPlaceholder;
	var MediaUpload = blockEditor.MediaUpload;
	var components = wp.components;
	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;
	var TextareaControl = components.TextareaControl;
	var ToggleControl = components.ToggleControl;
	var SelectControl = components.SelectControl;
	var Button = components.Button;
	var Notice = components.Notice;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/image', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;
			var blockProps = useBlockProps();
			// Client mode (kerf-client-mode.js): the picture and its words are the
			// client's; its size, fit and loading are the design's, and so is
			// whether it links — a link added here would wrap it in an <a>.
			var full = kerf.fullEditing();
			var links = !! ( attributes.linkUrl || attributes.linkType );
			// A description kept from the picture that was there before.
			var staleAlt = wp.element.useState( false );

			function onSelect( media ) {
				// The new picture's own description, from the media library.
				// Without one the old description stays — flagged: it describes
				// the picture that was there.
				staleAlt[ 1 ]( ! media.alt && !! attributes.alt );
				var next = {
					src: media.url,
					mediaId: media.id,
					alt: media.alt || attributes.alt || ''
				};

				// Swapping the photo keeps the image's dimension STATE. One the
				// mockup sized gets the new file's numbers, so the attributes do
				// not lie about its aspect ratio. One the mockup left unsized stays
				// unsized: adding width/height there pins the rendered height, and
				// under `max-width:100%` without `height:auto` that distorts the
				// image the moment its column is narrower than the file.
				if ( attributes.width || attributes.height ) {
					next.width = media.width ? String( media.width ) : '';
					next.height = media.height ? String( media.height ) : '';
				}

				setAttributes( next );
			}

			if ( ! attributes.src ) {
				return el( 'div', blockProps,
					el( MediaPlaceholder, {
						icon: 'format-image',
						labels: { title: __( 'Image', 'kerf-blocks' ) },
						allowedTypes: [ 'image' ],
						onSelect: onSelect,
						onSelectURL: function ( url ) {
							setAttributes( { src: url, mediaId: 0 } );
						}
					} )
				);
			}

			// An unattached src means the converter could not match the mockup's
			// filename to anything in the library, so the page is pointing at a
			// path that will 404 in production. Saying so here is the difference
			// between finding out now and finding out after launch.
			var unresolved = ! attributes.mediaId && ! /^https?:\/\//i.test( attributes.src );

			var preview = kerf.previewProps( attributes );
			if ( attributes.objectFit ) {
				preview.style = Object.assign( { objectFit: attributes.objectFit }, preview.style || {} );
			}

			// A post's picture in the designer's slot is cropped to the sample's
			// size, as kerf_render_image_block() does on the page (scar 52):
			// the slot's width and height, and `object-fit: cover`.
			var width = attributes.width;
			var height = attributes.height;
			var boundSrc = attributes.metadata && attributes.metadata.bindings && attributes.metadata.bindings.src;
			var fit = boundSrc && boundSrc.args && boundSrc.args.fit;
			if ( fit && fit[ 0 ] && fit[ 1 ] ) {
				if ( ! width && ! height ) {
					width = String( fit[ 0 ] );
					height = String( fit[ 1 ] );
				}
				preview.style = Object.assign( { objectFit: 'cover' }, preview.style || {} );
			}

			var imgProps = Object.assign( blockProps, preview, {
				src: attributes.src,
				alt: attributes.alt || '',
				width: width || undefined,
				height: height || undefined,
				style: Object.assign( {}, blockProps.style || {}, preview.style || {} )
			} );

			return el( Fragment, null,
				el( InspectorControls, null,
					unresolved && el( 'div', { className: 'kerf-help kerf-help--warn', style: { padding: '0 16px' } },
						__( 'This image is not in the media library — it still points at the mockup\'s path and will 404 once the staged files are cleaned up. Pick a replacement, or re-import with "Import images" ticked.', 'kerf-blocks' )
					),
					el( PanelBody, { title: __( 'Image', 'kerf-blocks' ), initialOpen: true },
						el( MediaUpload, {
							allowedTypes: [ 'image' ],
							value: attributes.mediaId,
							onSelect: onSelect,
							render: function ( uploader ) {
								return el( Button, { variant: 'secondary', onClick: uploader.open },
									__( 'Replace image', 'kerf-blocks' ) );
							}
						} ),
						el( TextareaControl, {
							label: __( 'Alt text', 'kerf-blocks' ),
							value: attributes.alt || '',
							onChange: function ( next ) {
								staleAlt[ 1 ]( false );
								setAttributes( { alt: next } );
							},
							rows: 2,
							help: __( 'Leave empty if the image is decorative.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} ),
						staleAlt[ 0 ] && el( 'p', { className: 'kerf-help kerf-help--warn' },
							__( 'This description was written for the previous picture. Check that it describes the new one.', 'kerf-blocks' )
						),
						full && el( TextControl, {
							label: __( 'Width', 'kerf-blocks' ),
							value: attributes.width || '',
							onChange: function ( next ) {
								setAttributes( { width: next } );
							},
							__nextHasNoMarginBottom: true
						} ),
						full && el( TextControl, {
							label: __( 'Height', 'kerf-blocks' ),
							value: attributes.height || '',
							onChange: function ( next ) {
								setAttributes( { height: next } );
							},
							__nextHasNoMarginBottom: true
						} ),
						full && el( SelectControl, {
							label: __( 'Object fit', 'kerf-blocks' ),
							value: attributes.objectFit || '',
							options: [
								{ label: __( 'Not set', 'kerf-blocks' ), value: '' },
								{ label: 'cover', value: 'cover' },
								{ label: 'contain', value: 'contain' },
								{ label: 'fill', value: 'fill' },
								{ label: 'none', value: 'none' },
								{ label: 'scale-down', value: 'scale-down' }
							],
							onChange: function ( next ) {
								setAttributes( { objectFit: next } );
							},
							__nextHasNoMarginBottom: true
						} ),
						full && el( ToggleControl, {
							label: __( 'Above the fold', 'kerf-blocks' ),
							checked: !! attributes.hero,
							onChange: function ( next ) {
								setAttributes( { hero: next } );
							},
							help: __( 'Loads eagerly at high priority. Use for the one image visible on load; using it for more than that slows all of them down.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} )
					),
					( full || links ) && el( PanelBody, { title: __( 'Link', 'kerf-blocks' ), initialOpen: false },
						el( kerf.LinkTargetControl, {
							attributes: attributes,
							setAttributes: setAttributes,
							urlKey: 'linkUrl'
						} ),
						el( ToggleControl, {
							label: __( 'Open in a new tab', 'kerf-blocks' ),
							checked: !! attributes.linkNewTab,
							onChange: function ( next ) {
								setAttributes( { linkNewTab: next } );
							},
							__nextHasNoMarginBottom: true
						} )
					),
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				// The <img> IS the block, as it is on the page. It used to sit inside
				// a <div> that carried the block props, and every rule written
				// against the image's parent then measured the wrapper instead:
				// `.blog-img img { height:100%; object-fit:cover }` filled a div of
				// auto height, so the photo stopped short of its 280px frame in
				// the editor while the front end was fine.
				el( 'img', imgProps )
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
