/**
 * kerf/post-content — where the post's body goes, inside the designer's
 * article element. A marker in the editor; the content itself is edited on
 * each post.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var __ = wp.i18n.__;

	wp.blocks.registerBlockType( 'kerf/post-content', {
		edit: function () {
			var blockProps = wp.blockEditor.useBlockProps( { className: 'kerf-post-content-marker' } );

			return el( 'div', blockProps,
				el( 'p', null, __( 'The post\'s content appears here — headings, paragraphs, images, lists — styled by your mockup\'s CSS for this area.', 'kerf-blocks' ) )
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
