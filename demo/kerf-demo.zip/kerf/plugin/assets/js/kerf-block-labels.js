/**
 * What each Kerf block is, at a glance — in the List View, the breadcrumb and
 * the block card.
 *
 * A converted page is a deep tree of essentially one block type, so by default
 * every row of the List View reads "Element", and finding the fourth link of the
 * second dropdown means opening rows one at a time until the right one lights up
 * in the canvas. Two things fix that:
 *
 *   LABELS   each row says what the element is — `nav.main-nav`, `li.menu-item`,
 *            `a → /about/` — and a text block says what it says, so a menu item
 *            is found by reading its name.
 *   COLOUR   the icon is coloured by the KIND of element its tag makes it, so
 *            the tree's structure reads before any label does: landmarks,
 *            lists, links, controls, tables, media. `div` and `span` — most of
 *            any mockup — stay uncoloured, which is what lets the rest stand
 *            out. The label always names the tag, so colour is never the only
 *            signal.
 *
 * Colour is carried by block variations: one per tag, matched on `tagName`, and
 * scoped to nowhere, so none of them appears in the inserter or a transform
 * menu. The List View draws the active variation's icon, and a block icon may
 * carry a foreground colour — that is the whole mechanism. As a side effect the
 * block card names the element too: a selected `<li>` says "List item".
 *
 * Applied with a `blocks.registerBlockType` filter, which only reaches blocks
 * registered AFTER it is added — so this script is a declared dependency of
 * every Kerf block script (see kerf_register_blocks()).
 *
 * This used to be a PHP closure passed through `register_block_type_args`.
 * WordPress hands the editor a JSON copy of each block type, a closure has no
 * JSON, and it was dropped on the way without a word: every row said "Element"
 * while the code meant to label them sat in the theme looking finished.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	if ( ! wp || ! wp.hooks || ! wp.i18n ) {
		return;
	}

	var __ = wp.i18n.__;

	/**
	 * Each kind's colour and default icon.
	 *
	 * All 700-weight hues, every one at least 5:1 against the white List View
	 * row: they are drawn at icon size, where a pale colour reads as a disabled
	 * row rather than as a category.
	 */
	var KINDS = {
		landmark: { color: '#6d28d9', icon: 'layout' },
		list:     { color: '#15803d', icon: 'editor-ul' },
		link:     { color: '#1d4ed8', icon: 'admin-links' },
		control:  { color: '#c2410c', icon: 'button' },
		table:    { color: '#854d0e', icon: 'editor-table' },
		media:    { color: '#be185d', icon: 'format-image' }
	};

	/**
	 * Every tag that gets a colour: [ kind, name in the block card, icon when
	 * the kind's own would say the wrong thing ].
	 *
	 * Tags missing from here — div, span, p, headings, inline text — are the
	 * uncoloured majority by design, not by omission.
	 */
	var TAGS = {
		header:     [ 'landmark', __( 'Header', 'kerf-blocks' ) ],
		nav:        [ 'landmark', __( 'Navigation', 'kerf-blocks' ), 'menu' ],
		main:       [ 'landmark', __( 'Main', 'kerf-blocks' ) ],
		footer:     [ 'landmark', __( 'Footer', 'kerf-blocks' ) ],
		section:    [ 'landmark', __( 'Section', 'kerf-blocks' ) ],
		article:    [ 'landmark', __( 'Article', 'kerf-blocks' ) ],
		aside:      [ 'landmark', __( 'Aside', 'kerf-blocks' ) ],
		search:     [ 'landmark', __( 'Search', 'kerf-blocks' ), 'search' ],
		address:    [ 'landmark', __( 'Address', 'kerf-blocks' ) ],
		hgroup:     [ 'landmark', __( 'Heading group', 'kerf-blocks' ) ],

		ul:         [ 'list', __( 'List', 'kerf-blocks' ) ],
		ol:         [ 'list', __( 'Numbered list', 'kerf-blocks' ), 'editor-ol' ],
		menu:       [ 'list', __( 'Menu list', 'kerf-blocks' ) ],
		li:         [ 'list', __( 'List item', 'kerf-blocks' ) ],
		dl:         [ 'list', __( 'Description list', 'kerf-blocks' ) ],
		dt:         [ 'list', __( 'Term', 'kerf-blocks' ) ],
		dd:         [ 'list', __( 'Description', 'kerf-blocks' ) ],

		a:          [ 'link', __( 'Link', 'kerf-blocks' ) ],

		button:     [ 'control', __( 'Button', 'kerf-blocks' ) ],
		details:    [ 'control', __( 'Details', 'kerf-blocks' ) ],
		summary:    [ 'control', __( 'Summary', 'kerf-blocks' ) ],
		dialog:     [ 'control', __( 'Dialog', 'kerf-blocks' ) ],
		form:       [ 'control', __( 'Form', 'kerf-blocks' ), 'feedback' ],
		fieldset:   [ 'control', __( 'Fieldset', 'kerf-blocks' ), 'feedback' ],
		legend:     [ 'control', __( 'Legend', 'kerf-blocks' ), 'feedback' ],
		label:      [ 'control', __( 'Label', 'kerf-blocks' ), 'feedback' ],
		input:      [ 'control', __( 'Input', 'kerf-blocks' ), 'feedback' ],
		textarea:   [ 'control', __( 'Text area', 'kerf-blocks' ), 'feedback' ],
		select:     [ 'control', __( 'Select', 'kerf-blocks' ), 'feedback' ],
		optgroup:   [ 'control', __( 'Option group', 'kerf-blocks' ), 'feedback' ],
		option:     [ 'control', __( 'Option', 'kerf-blocks' ), 'feedback' ],
		datalist:   [ 'control', __( 'Data list', 'kerf-blocks' ), 'feedback' ],
		output:     [ 'control', __( 'Output', 'kerf-blocks' ), 'feedback' ],
		progress:   [ 'control', __( 'Progress bar', 'kerf-blocks' ), 'feedback' ],
		meter:      [ 'control', __( 'Meter', 'kerf-blocks' ), 'feedback' ],

		table:      [ 'table', __( 'Table', 'kerf-blocks' ) ],
		caption:    [ 'table', __( 'Table caption', 'kerf-blocks' ) ],
		colgroup:   [ 'table', __( 'Column group', 'kerf-blocks' ) ],
		col:        [ 'table', __( 'Column', 'kerf-blocks' ) ],
		thead:      [ 'table', __( 'Table head', 'kerf-blocks' ) ],
		tbody:      [ 'table', __( 'Table body', 'kerf-blocks' ) ],
		tfoot:      [ 'table', __( 'Table foot', 'kerf-blocks' ) ],
		tr:         [ 'table', __( 'Table row', 'kerf-blocks' ) ],
		th:         [ 'table', __( 'Header cell', 'kerf-blocks' ) ],
		td:         [ 'table', __( 'Table cell', 'kerf-blocks' ) ],

		figure:     [ 'media', __( 'Figure', 'kerf-blocks' ), 'format-gallery' ],
		figcaption: [ 'media', __( 'Caption', 'kerf-blocks' ), 'format-gallery' ],
		picture:    [ 'media', __( 'Picture', 'kerf-blocks' ) ],
		source:     [ 'media', __( 'Source', 'kerf-blocks' ) ],
		video:      [ 'media', __( 'Video', 'kerf-blocks' ), 'format-video' ],
		audio:      [ 'media', __( 'Audio', 'kerf-blocks' ), 'format-audio' ],
		track:      [ 'media', __( 'Track', 'kerf-blocks' ), 'format-video' ],
		iframe:     [ 'media', __( 'Embed', 'kerf-blocks' ), 'embed-generic' ],
		canvas:     [ 'media', __( 'Canvas', 'kerf-blocks' ), 'art' ],
		map:        [ 'media', __( 'Image map', 'kerf-blocks' ) ],
		area:       [ 'media', __( 'Map area', 'kerf-blocks' ) ]
	};

	/**
	 * Blocks whose element never changes kind, coloured once on the block type.
	 * Their tag is fixed or, for kerf/icon, cosmetic.
	 */
	var FIXED = {
		'kerf/link':   'link',
		'kerf/image':  'media',
		'kerf/figure': 'media',
		'kerf/video':  'media',
		'kerf/svg':    'media',
		'kerf/icon':   'media',
		'kerf/loop':         'list',
		'kerf/pagination':   'link',
		'kerf/post-content': 'landmark',
		'kerf/comments':     'landmark'
	};

	/**
	 * @param {Object} attributes
	 * @param {string} fallback
	 * @return {string}
	 */
	function tagOf( attributes, fallback ) {
		return String( attributes.tagName || fallback ).toLowerCase();
	}

	/**
	 * `.first-class`, or `#anchor` when there is no class.
	 *
	 * The first class is almost always the semantic one the designer chose
	 * (`site-header`, `hero`, `menu-item`), and it identifies a row far better
	 * than the tag alone. The List View already prints the anchor as a badge
	 * beside the label, so there it is not repeated.
	 *
	 * @param {Object} attributes
	 * @param {string} context
	 * @return {string}
	 */
	function selectorSuffix( attributes, context ) {
		var first = String( attributes.className || '' ).trim().split( /\s+/ )[ 0 ];

		if ( first ) {
			return '.' + first;
		}
		if ( attributes.anchor && 'list-view' !== context ) {
			return '#' + attributes.anchor;
		}
		return '';
	}

	/**
	 * Text fit for a label: tags stripped, entities decoded, whitespace
	 * collapsed, cut to what a row can show.
	 *
	 * Parsed with DOMParser, never assigned to innerHTML. This text came from a
	 * third party's mockup, and `<img src=x onerror=…>` assigned to the
	 * innerHTML of even a detached element runs. A parsed document is inert.
	 *
	 * @param {*} value
	 * @return {string}
	 */
	function plainText( value ) {
		var text = String( value || '' );

		if ( /[<&]/.test( text ) ) {
			text = new window.DOMParser().parseFromString( text, 'text/html' ).body.textContent || '';
		}

		text = text.replace( /\s+/g, ' ' ).trim();

		return text.length > 48 ? text.slice( 0, 47 ) + '…' : text;
	}

	/**
	 * `hero.jpg` from a URL, or '' for a data: URI, which has no name to show.
	 *
	 * @param {*} src
	 * @return {string}
	 */
	function fileName( src ) {
		var url = String( src || '' );

		if ( ! url || /^data:/i.test( url ) ) {
			return '';
		}

		return plainText( url.split( /[?#]/ )[ 0 ].split( '/' ).pop() );
	}

	/**
	 * Each block's label, from its attributes alone: the callback is never
	 * given the block's children.
	 */
	var LABELS = {
		'kerf/div': function ( attributes, context ) {
			var tag = tagOf( attributes, 'div' );
			var label = tag + selectorSuffix( attributes, context );
			var href = attributes.customAttributes && attributes.customAttributes.href;

			// An anchor's text is on its child rows. What the row itself can add
			// is where it goes — which, in a menu, is how you tell items apart.
			if ( 'a' === tag && href ) {
				label += ' → ' + href;
			}

			return label;
		},
		'kerf/text': function ( attributes ) {
			return plainText( attributes.text ) || tagOf( attributes, 'span' );
		},
		'kerf/link': function ( attributes ) {
			return plainText( attributes.text ) || plainText( attributes.url ) || 'a';
		},
		'kerf/icon': function ( attributes ) {
			return plainText( attributes.iconClass ) || tagOf( attributes, 'i' );
		},
		'kerf/image': function ( attributes ) {
			return plainText( attributes.alt ) || fileName( attributes.src ) || 'img';
		},
		'kerf/svg': function ( attributes, context ) {
			return plainText( attributes.ariaLabel ) || 'svg' + selectorSuffix( attributes, context );
		},
		'kerf/video': function ( attributes ) {
			return fileName( attributes.src ) || 'video';
		},
		'kerf/figure': function ( attributes, context ) {
			return 'figure' + selectorSuffix( attributes, context );
		},
		'kerf/frame': function () {
			return __( 'Page frame', 'kerf-blocks' );
		},
		'kerf/loop': function ( attributes ) {
			switch ( attributes.query ) {
				case 'main':
					return __( 'Loop · each post on this page', 'kerf-blocks' );
				case 'comments':
					return __( 'Loop · each comment', 'kerf-blocks' );
				case 'tags':
					return __( 'Loop · each tag', 'kerf-blocks' );
				case 'categories':
					return __( 'Loop · each category', 'kerf-blocks' );
			}
			return __( 'Loop · latest posts', 'kerf-blocks' ) + ' (' + ( attributes.perPage || 3 ) + ')';
		},
		'kerf/post-content': function () {
			return __( 'Post body', 'kerf-blocks' );
		},
		'kerf/pagination': function () {
			return __( 'Page links', 'kerf-blocks' );
		},
		'kerf/comments': function () {
			return __( 'Post comments', 'kerf-blocks' );
		}
	};

	/**
	 * What a bound block is connected to — "Post title" — or ''.
	 *
	 * @param {Object} attributes
	 * @return {string}
	 */
	function boundLabel( attributes ) {
		var bindings = attributes.metadata && attributes.metadata.bindings;
		var keys = window.KerfBindings && window.KerfBindings.keys;
		if ( ! bindings || ! keys ) {
			return '';
		}
		var names = [];
		Object.keys( bindings ).forEach( function ( attribute ) {
			var binding = bindings[ attribute ] || {};
			var group = { 'kerf/post': keys.post, 'kerf/query': keys.query, 'kerf/comment': keys.comment, 'kerf/term': keys.term }[ binding.source ] || null;
			var key = binding.args && binding.args.key;
			if ( group && group[ key ] && -1 === names.indexOf( group[ key ] ) ) {
				names.push( group[ key ] );
			}
		} );
		return names.join( ', ' );
	}

	/**
	 * Wrap a label so a block the user renamed keeps its name.
	 *
	 * Renaming ("Rename" in the List View menu) is implemented by core as a
	 * label callback of its own, installed only on blocks that bring none. A
	 * block that brings one replaces it, so without this, renaming would
	 * silently stop working on every Kerf block. Same contexts as core.
	 *
	 * @param {Function} label
	 * @return {Function}
	 */
	function honourRename( label ) {
		return function ( attributes, options ) {
			var context = options && options.context;
			var name = attributes.metadata && attributes.metadata.name;

			if ( name && ( 'list-view' === context || 'breadcrumb' === context ) ) {
				return name;
			}

			var text = label( attributes, context );

			// A field filled from WordPress reads as what it shows, not as the
			// mockup's sample text it will never display.
			var bound = boundLabel( attributes );
			if ( bound && ( 'list-view' === context || 'breadcrumb' === context ) ) {
				text = '⟵ ' + bound;
			}

			// A block that is absent from every page but one should say so where
			// you find it: in the header part it looks like everything else.
			if ( 'front' === attributes.kerfOnly && 'list-view' === context ) {
				text += ' · ' + __( 'home page only', 'kerf-blocks' );
			}

			return text;
		};
	}

	/**
	 * @param {string|Object} icon
	 * @return {string|Object}
	 */
	function iconSource( icon ) {
		return icon && icon.src ? icon.src : icon;
	}

	/**
	 * One variation per coloured tag.
	 *
	 * @param {string|null} blockIcon Icon to keep for every tag, or null to use
	 *                                the kind's own (kerf/div, whose icon says
	 *                                nothing about the element it renders).
	 * @return {Object[]}
	 */
	function tagVariations( blockIcon ) {
		return Object.keys( TAGS ).map( function ( tag ) {
			var entry = TAGS[ tag ];
			var kind = KINDS[ entry[ 0 ] ];

			return {
				name: 'tag-' + tag,
				title: entry[ 1 ],
				icon: { src: blockIcon || entry[ 2 ] || kind.icon, foreground: kind.color },
				attributes: { tagName: tag },

				// Nowhere. These exist to be MATCHED, not offered: an unscoped
				// variation defaults to the inserter and the placeholder picker,
				// which would put fifty-odd entries named after tags into both.
				scope: [],

				isActive: function ( attributes ) {
					return tag === String( attributes.tagName || '' ).toLowerCase();
				}
			};
		} );
	}

	wp.hooks.addFilter( 'blocks.registerBlockType', 'kerf/block-labels', function ( settings, name ) {
		var label = LABELS[ name ];

		if ( ! label ) {
			return settings;
		}

		settings.__experimentalLabel = honourRename( label );

		if ( 'kerf/div' === name ) {
			settings.variations = ( settings.variations || [] ).concat( tagVariations( null ) );
		} else if ( 'kerf/text' === name ) {
			// A text block keeps its own icon — it is still text — but takes the
			// colour of what its tag makes it: a `<td>` reads as a table cell,
			// an `<li>` as a list item.
			settings.variations = ( settings.variations || [] ).concat( tagVariations( iconSource( settings.icon ) ) );
		} else if ( FIXED[ name ] ) {
			settings.icon = { src: iconSource( settings.icon ), foreground: KINDS[ FIXED[ name ] ].color };
		}

		return settings;
	} );
}( window.wp ) );
