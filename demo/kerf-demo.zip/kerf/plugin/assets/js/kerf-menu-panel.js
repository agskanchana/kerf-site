/**
 * The Menu panel: a converted menu edited as a menu.
 *
 * A mockup's navigation converts as the designer's own markup — a <ul> of
 * <li> blocks with links in them (§5.2) — which keeps every class the CSS and
 * the dropdown script need, and makes "add a page to the menu" a matter of
 * duplicating the right block three levels down. This panel finds the menu
 * around the selected block and lists its items: move, remove, edit, and
 * "Add menu item", which copies one of the designer's own items — so the new
 * one is styled like the rest — and opens its link picker.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var useSelect = wp.data.useSelect;
	var useDispatch = wp.data.useDispatch;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var Button = wp.components.Button;

	function tagOf( block ) {
		return block && 'kerf/div' === block.name ? String( block.attributes.tagName || 'div' ).toLowerCase() : '';
	}

	function isList( block ) {
		var tag = tagOf( block );
		return 'ul' === tag || 'ol' === tag || 'menu' === tag;
	}

	/** The item's link: a text link, or an <a> holding an icon and a label. */
	function linkIn( block ) {
		if ( ! block ) {
			return null;
		}
		if ( 'kerf/link' === block.name || 'a' === tagOf( block ) ) {
			return block;
		}
		for ( var i = 0; i < ( block.innerBlocks || [] ).length; i++ ) {
			if ( ! isList( block.innerBlocks[ i ] ) ) {
				var found = linkIn( block.innerBlocks[ i ] );
				if ( found ) {
					return found;
				}
			}
		}
		return null;
	}

	function subList( item ) {
		for ( var i = 0; i < ( item.innerBlocks || [] ).length; i++ ) {
			var child = item.innerBlocks[ i ];
			if ( isList( child ) ) {
				return child;
			}
			var deeper = 'li' !== tagOf( child ) && ! linkIn( child ) ? subList( child ) : null;
			if ( deeper ) {
				return deeper;
			}
		}
		return null;
	}

	/** Is this list a menu: list items, most of which hold a link? */
	function isMenu( block ) {
		if ( ! isList( block ) || ! block.innerBlocks || block.innerBlocks.length < 1 ) {
			return false;
		}
		var withLinks = block.innerBlocks.filter( function ( item ) {
			return 'li' === tagOf( item ) && linkIn( item );
		} );
		return withLinks.length >= Math.max( 1, Math.ceil( block.innerBlocks.length / 2 ) );
	}

	/** A nav's first menu, searched breadth-first. */
	function menuInside( block ) {
		var queue = [ block ];
		while ( queue.length ) {
			var next = queue.shift();
			if ( isMenu( next ) ) {
				return next;
			}
			queue = queue.concat( next.innerBlocks || [] );
		}
		return null;
	}

	function label( link ) {
		if ( ! link ) {
			return __( '(no link)', 'kerf-blocks' );
		}
		if ( 'kerf/link' === link.name ) {
			return link.attributes.text || __( '(no text)', 'kerf-blocks' );
		}
		var text = '';
		( function walk( blocks ) {
			blocks.forEach( function ( b ) {
				if ( ! text && ( b.attributes.text || b.attributes.content ) ) {
					text = String( b.attributes.text || b.attributes.content ).replace( /<[^>]+>/g, '' );
				}
				walk( b.innerBlocks || [] );
			} );
		}( link.innerBlocks || [] ) );
		return text || ( link.attributes.customAttributes && link.attributes.customAttributes[ 'aria-label' ] ) || __( '(an icon)', 'kerf-blocks' );
	}

	function destination( link, titles ) {
		if ( ! link ) {
			return '';
		}
		var a = link.attributes;
		if ( 'home' === a.linkType ) {
			return __( 'Home page', 'kerf-blocks' );
		}
		if ( 'post' === a.linkType && a.linkId ) {
			/* translators: %d: a page ID. */
			return titles[ a.linkId ] ? '→ ' + titles[ a.linkId ] : sprintf( __( 'Page #%d', 'kerf-blocks' ), a.linkId );
		}
		return 'kerf/link' === link.name ? a.url || '' : ( a.customAttributes && a.customAttributes.href ) || '';
	}

	/**
	 * id => title, from the records core-data returned for the items' pages and
	 * posts. Titles are rendered HTML: read as text through an inert document.
	 *
	 * @param {Object[]} lists getEntityRecords() results.
	 * @return {Object}
	 */
	function titlesOf( lists ) {
		var titles = {};
		lists.forEach( function ( records ) {
			( records || [] ).forEach( function ( record ) {
				var doc = new window.DOMParser().parseFromString( ( record.title && record.title.rendered ) || '', 'text/html' );
				titles[ record.id ] = doc.body.textContent || '';
			} );
		} );
		return titles;
	}

	/** A copy of the designer's item, made new: no ids, no submenu, an empty link. */
	function freshItem( template ) {
		var copy = wp.blocks.cloneBlock( template );
		( function clean( block ) {
			delete block.attributes.anchor;
			delete block.attributes.kerfSource;
			block.innerBlocks = ( block.innerBlocks || [] ).filter( function ( child ) {
				return ! isList( child );
			} );
			block.innerBlocks.forEach( clean );
		}( copy ) );
		var link = linkIn( copy );
		if ( link ) {
			link.attributes.linkType = 'post';
			link.attributes.linkId = 0;
			if ( 'kerf/link' === link.name ) {
				link.attributes.text = __( 'New page', 'kerf-blocks' );
				link.attributes.url = '#';
			} else {
				link.attributes.customAttributes = Object.assign( {}, link.attributes.customAttributes || {}, { href: '#' } );
			}
		}
		return { block: copy, link: link };
	}

	function MenuPanel( props ) {
		var data = useSelect( function ( select ) {
			var editor = select( 'core/block-editor' );
			var chain = [ props.clientId ].concat( editor.getBlockParents( props.clientId, true ) );
			for ( var i = 0; i < chain.length; i++ ) {
				var block = editor.getBlock( chain[ i ] );
				if ( isMenu( block ) ) {
					return { menu: block };
				}
				if ( 'nav' === tagOf( block ) || 'header' === tagOf( block ) ) {
					var inside = menuInside( block );
					if ( inside ) {
						return { menu: inside };
					}
				}
			}
			return { menu: null };
		}, [ props.clientId ] );

		var editor = useDispatch( 'core/block-editor' );
		var menu = data.menu;
		var items = menu ? menu.innerBlocks.filter( function ( item ) {
			return 'li' === tagOf( item );
		} ) : [];

		// Called on every render (rules of hooks), with no ids when there is
		// no menu.
		var ids = items.map( function ( item ) {
			var link = linkIn( item );
			return link && 'post' === link.attributes.linkType ? parseInt( link.attributes.linkId, 10 ) || 0 : 0;
		} ).filter( Boolean ).sort();
		// One request per type for every item's page; core-data's results are
		// stable, so the map is rebuilt only when they change.
		var records = useSelect( function ( select ) {
			if ( ! ids.length ) {
				return { pages: null, posts: null };
			}
			var query = { include: ids, per_page: 100, _fields: 'id,title', status: [ 'publish', 'draft', 'private', 'future', 'pending' ] };
			return {
				pages: select( 'core' ).getEntityRecords( 'postType', 'page', query ),
				posts: select( 'core' ).getEntityRecords( 'postType', 'post', query )
			};
		}, [ ids.join( ',' ) ] );
		var titles = wp.element.useMemo( function () {
			return titlesOf( [ records.pages, records.posts ] );
		}, [ records.pages, records.posts ] );

		if ( ! menu ) {
			return null;
		}

		function add() {
			var plain = items.filter( function ( item ) {
				return ! subList( item );
			} );
			var template = plain.length ? plain[ plain.length - 1 ] : items[ items.length - 1 ];
			if ( ! template ) {
				return;
			}
			var made = freshItem( template );
			var at = menu.innerBlocks.indexOf( items[ items.length - 1 ] ) + 1;
			editor.insertBlocks( made.block, at, menu.clientId, false );
			editor.selectBlock( made.link ? made.link.clientId : made.block.clientId );
		}

		return el( InspectorControls, null,
			el( PanelBody, {
				/* translators: %d: number of items. */
				title: sprintf( __( 'Menu (%d items)', 'kerf-blocks' ), items.length ),
				initialOpen: true,
				className: 'kerf-menu-panel'
			},
				el( 'ul', { className: 'kerf-menu-panel__items' },
					items.map( function ( item, index ) {
						var link = linkIn( item );
						var sub = subList( item );
						return el( 'li', { key: item.clientId, className: 'kerf-menu-panel__item' },
							el( 'span', { className: 'kerf-menu-panel__label' },
								el( 'strong', null, label( link ) ),
								el( 'small', null, destination( link, titles ) ),
								sub ? el( 'small', null,
									/* translators: %d: number of items in a submenu. */
									sprintf( __( '+ a menu of %d', 'kerf-blocks' ), sub.innerBlocks.length ) ) : null
							),
							el( 'span', { className: 'kerf-menu-panel__actions' },
								el( Button, { size: 'small', icon: 'arrow-up-alt2', label: __( 'Move up', 'kerf-blocks' ), disabled: 0 === index, onClick: function () {
									editor.moveBlocksUp( [ item.clientId ], menu.clientId );
								} } ),
								el( Button, { size: 'small', icon: 'arrow-down-alt2', label: __( 'Move down', 'kerf-blocks' ), disabled: index === items.length - 1, onClick: function () {
									editor.moveBlocksDown( [ item.clientId ], menu.clientId );
								} } ),
								el( Button, { size: 'small', icon: 'edit', label: __( 'Edit this item', 'kerf-blocks' ), onClick: function () {
									editor.selectBlock( link ? link.clientId : item.clientId );
								} } ),
								sub ? el( Button, { size: 'small', icon: 'menu', label: __( 'Edit its menu', 'kerf-blocks' ), onClick: function () {
									editor.selectBlock( sub.clientId );
								} } ) : null,
								el( Button, { size: 'small', icon: 'trash', isDestructive: true, label: __( 'Remove from the menu', 'kerf-blocks' ), onClick: function () {
									editor.removeBlock( item.clientId, false );
								} } )
							)
						);
					} )
				),
				el( Button, { variant: 'secondary', onClick: add }, __( 'Add menu item', 'kerf-blocks' ) ),
				el( 'p', { className: 'kerf-help' },
					__( 'A new item copies one of the design\'s own, so it looks like the rest; choose its page in the Link panel that opens.', 'kerf-blocks' ) )
			)
		);
	}

	// Client mode (kerf-client-mode.js) locks a block to its content. Read from
	// the block's context: WordPress does not pass the mode to editor.BlockEdit
	// filters as a prop, and a gate reading props.blockEditingMode let every
	// panel through. A hook — call it first, unconditionally.
	function fullEditing() {
		return 'default' === ( wp.blockEditor.useBlockEditingMode ? wp.blockEditor.useBlockEditingMode() : 'default' );
	}

	wp.hooks.addFilter( 'editor.BlockEdit', 'kerf/menu-panel', wp.compose.createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			var full = fullEditing();
			// Not in client mode (kerf-client-mode.js): a menu's items are the design's.
			var relevant = props.isSelected && full && ( 'kerf/div' === props.name || 'kerf/link' === props.name || 'kerf/text' === props.name );
			return el( Fragment, null,
				el( BlockEdit, props ),
				relevant ? el( MenuPanel, { clientId: props.clientId } ) : null
			);
		};
	}, 'withKerfMenuPanel' ) );
}( window.wp ) );
