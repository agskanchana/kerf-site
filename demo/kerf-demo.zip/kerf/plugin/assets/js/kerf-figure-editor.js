/**
 * kerf/figure — a <figure> wrapper.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var useInnerBlocksProps = blockEditor.useInnerBlocksProps;
	var InnerBlocks = blockEditor.InnerBlocks;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/figure', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			var blockProps = useBlockProps( kerf.previewProps( attributes ) );
			// @see kerf-div-editor.js — an appender on every block buries the design.
			var innerProps = useInnerBlocksProps( blockProps, {
				template: [ [ 'kerf/image' ] ],
				templateLock: false,
				renderAppender: props.isSelected ? InnerBlocks.ButtonBlockAppender : false
			} );

			return el( Fragment, null,
				el( InspectorControls, null,
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				el( 'figure', innerProps )
			);
		},

		save: function () {
			return el( InnerBlocks.Content );
		}
	} );
}( window.wp ) );
