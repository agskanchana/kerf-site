/**
 * Kerf's admin screens: what every one of them shares.
 *
 * Plain DOM, no build step. Each part looks for its own markup and does
 * nothing on a screen without it; every form still works with this script
 * off — it only makes them kinder: a file dropped onto the import, a brief
 * copied in one click, a line saying the server is working while it does.
 *
 * @package kerf
 */
( function () {
	'use strict';

	var __ = window.wp && window.wp.i18n ? window.wp.i18n.__ : function ( text ) {
		return text;
	};
	var sprintf = window.wp && window.wp.i18n ? window.wp.i18n.sprintf : function ( text ) {
		return text;
	};

	function each( selector, fn, root ) {
		Array.prototype.forEach.call( ( root || document ).querySelectorAll( selector ), fn );
	}

	function size( bytes ) {
		if ( bytes < 1024 * 1024 ) {
			/* translators: %s: a size in kilobytes. */
			return sprintf( __( '%s KB', 'kerf-blocks' ), Math.max( 1, Math.round( bytes / 1024 ) ) );
		}
		/* translators: %s: a size in megabytes. */
		return sprintf( __( '%s MB', 'kerf-blocks' ), ( bytes / ( 1024 * 1024 ) ).toFixed( 1 ) );
	}

	// ── Copy: a brief, a prompt — the button copies the field it names. ──
	// Without the clipboard API (a site not on HTTPS), through a field of its
	// own: the source may be folded away, and a hidden field cannot be selected.
	function copyByHand( text ) {
		var field = document.createElement( 'textarea' );
		field.value = text;
		field.setAttribute( 'readonly', '' );
		field.style.position = 'fixed';
		field.style.opacity = '0';
		document.body.appendChild( field );
		field.select();
		try {
			document.execCommand( 'copy' );
		} catch ( e ) {}
		document.body.removeChild( field );
	}

	// One listener for the whole page: a copy button drawn later — an AI's
	// answer, say — copies too.
	document.addEventListener( 'click', function ( event ) {
		var button = event.target && event.target.closest ? event.target.closest( '[data-copy]' ) : null;
		if ( ! button || button.classList.contains( 'is-copied' ) ) {
			return;
		}
		var source = document.getElementById( button.getAttribute( 'data-copy' ) );
		if ( ! source ) {
			return;
		}
		var label = button.innerHTML;
		var text = source.value || source.textContent;

		function done() {
			button.classList.add( 'is-copied' );
			button.textContent = __( 'Copied', 'kerf-blocks' );
			window.setTimeout( function () {
				button.classList.remove( 'is-copied' );
				button.innerHTML = label;
			}, 1800 );
		}

		if ( navigator.clipboard && window.isSecureContext ) {
			navigator.clipboard.writeText( text ).then( done, function () {
				copyByHand( text );
				done();
			} );
		} else {
			copyByHand( text );
			done();
		}
	} );

	// ── The drop: a ZIP dropped on it, or chosen, shows as that file. ──
	each( '.kerf-drop', function ( drop ) {
		var input = drop.querySelector( 'input[type="file"]' );
		var name = drop.querySelector( '[data-file-name]' );
		var meta = drop.querySelector( '[data-file-meta]' );
		var form = drop.closest( 'form' );
		var go = form ? form.querySelector( '[data-needs-source]' ) : null;
		if ( ! input ) {
			return;
		}

		function show() {
			var file = input.files && input.files[ 0 ];
			drop.classList.toggle( 'has-file', !! file );
			if ( file ) {
				name.textContent = file.name;
				meta.textContent = size( file.size );
			}
			if ( go ) {
				go.disabled = ! file && ! hasPaste();
			}
		}

		function hasPaste() {
			var paste = form ? form.querySelector( '.kerf-paste textarea' ) : null;
			return !! ( paste && ! paste.closest( '[hidden]' ) && paste.value.trim() );
		}

		input.addEventListener( 'change', show );

		[ 'dragenter', 'dragover' ].forEach( function ( type ) {
			drop.addEventListener( type, function ( event ) {
				event.preventDefault();
				drop.classList.add( 'is-over' );
			} );
		} );
		[ 'dragleave', 'dragend', 'drop' ].forEach( function ( type ) {
			drop.addEventListener( type, function () {
				drop.classList.remove( 'is-over' );
			} );
		} );
		drop.addEventListener( 'drop', function ( event ) {
			event.preventDefault();
			var files = event.dataTransfer && event.dataTransfer.files;
			if ( ! files || ! files.length ) {
				return;
			}
			if ( ! /\.zip$/i.test( files[ 0 ].name ) ) {
				name.textContent = files[ 0 ].name;
				meta.textContent = __( 'Not a ZIP — zip the design\'s folder and drop that.', 'kerf-blocks' );
				drop.classList.add( 'has-file' );
				if ( go ) {
					go.disabled = true;
				}
				return;
			}
			try {
				var list = new DataTransfer();
				list.items.add( files[ 0 ] );
				input.files = list.files;
			} catch ( e ) {
				input.files = files;
			}
			show();
		} );

		if ( form ) {
			each( '.kerf-paste textarea', function ( area ) {
				area.addEventListener( 'input', show );
			}, form );
		}
		show();
	} );

	// ── Where the design comes from: the ZIP, or HTML pasted in. ──
	each( '.kerf-source-switch', function ( group ) {
		var form = group.closest( 'form' );
		var buttons = group.querySelectorAll( 'button[data-source]' );
		var field = form ? form.querySelector( 'input[name="kerf_source"]' ) : null;

		function pick( which ) {
			Array.prototype.forEach.call( buttons, function ( button ) {
				var on = button.getAttribute( 'data-source' ) === which;
				button.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
				var panel = document.getElementById( button.getAttribute( 'aria-controls' ) );
				if ( panel ) {
					panel.hidden = ! on;
				}
			} );
			if ( field ) {
				field.value = which;
			}
			var input = form ? form.querySelector( '.kerf-drop input[type="file"]' ) : null;
			if ( input ) {
				input.dispatchEvent( new Event( 'change' ) );
			}
		}

		Array.prototype.forEach.call( buttons, function ( button ) {
			button.addEventListener( 'click', function () {
				pick( button.getAttribute( 'data-source' ) );
			} );
		} );
	} );

	// ── While the server works: one line over the screen, saying what. ──
	each( 'form[data-working]', function ( form ) {
		form.addEventListener( 'submit', function ( event ) {
			var submitter = event.submitter;
			if ( submitter && submitter.hasAttribute( 'data-no-working' ) ) {
				return;
			}
			var text = ( submitter && submitter.getAttribute( 'data-working' ) ) || form.getAttribute( 'data-working' );
			var veil = document.querySelector( '.kerf-working' );
			if ( ! veil || ! text ) {
				return;
			}
			veil.querySelector( '.kerf-working__text' ).textContent = text;
			veil.classList.add( 'is-on' );
			veil.setAttribute( 'aria-hidden', 'false' );
		} );
	} );

	// Coming back to a screen through the browser's history shows it as it was.
	window.addEventListener( 'pageshow', function () {
		each( '.kerf-working.is-on', function ( veil ) {
			veil.classList.remove( 'is-on' );
			veil.setAttribute( 'aria-hidden', 'true' );
		} );
	} );

	// ── A live page, small: laid out at a laptop's width, then scaled to fit. ──
	each( '.kerf-preview', function ( box ) {
		var frame = box.querySelector( 'iframe' );
		var width = parseInt( box.getAttribute( 'data-width' ), 10 ) || 1440;
		if ( ! frame ) {
			return;
		}
		function fit() {
			var scale = box.clientWidth / width;
			if ( ! scale ) {
				return;
			}
			frame.style.width = width + 'px';
			frame.style.height = Math.ceil( box.clientHeight / scale ) + 'px';
			frame.style.transform = 'scale(' + scale + ')';
		}
		fit();
		window.addEventListener( 'resize', fit );
	} );

	// ── Links: a changed destination marks its row, and the save bar counts. ──
	each( 'form.kerf-links-form', function ( form ) {
		var count = form.querySelector( '[data-changed-count]' );
		var save = form.querySelector( '[data-save-links]' );

		function update() {
			var changed = form.querySelectorAll( '.kerf-link-row.is-changed' ).length;
			if ( count ) {
				count.textContent = changed ? sprintf(
					/* translators: %d: number of links. */
					__( '%d changed', 'kerf-blocks' ),
					changed
				) : __( 'Pick where a link goes, then save.', 'kerf-blocks' );
			}
			if ( save ) {
				save.disabled = ! changed;
			}
		}

		each( 'select[data-was]', function ( select ) {
			select.addEventListener( 'change', function () {
				var row = select.closest( '.kerf-link-row' );
				if ( row ) {
					row.classList.toggle( 'is-changed', select.value !== select.getAttribute( 'data-was' ) );
				}
				update();
			} );
		}, form );
		update();
	} );
}() );
