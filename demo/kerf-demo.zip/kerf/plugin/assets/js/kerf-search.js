/**
 * A design's search searches the site (inc/kerf-bindings.php, §5.25).
 *
 * The binder points a design's search form at WordPress search — the site's
 * address, `s` for its field — but the design's own script still answered
 * the submit first. A mockup has no server to ask, so its script searched the
 * page it was on ("No section on this page contains …", Brighton's search
 * panel), showed a message or did nothing, and stopped the form going
 * anywhere: on the WordPress site the search never reached WordPress. Here,
 * before any of the design's own handlers hear it, a search with words in it
 * is let through to WordPress; an empty one is left to the design, which has
 * its own words for that.
 *
 * A design's search is not always a form (scar 136, the owner's question
 * "does the search work … a modal or any kind"):
 *   - a search box with no form round it — Gajjar's overlay is a text field
 *     "Search our site…" and a close button, and Enter in it did nothing.
 *     Enter in such a field, in the header, a dialog or anything named search,
 *     with words in it, goes to WordPress search, as does a search button
 *     beside it (not the one that opens or closes it);
 *   - a search icon with no search box anywhere on the page — Chiro's `<a
 *     class="search-btn" href="#">`, Dreamtime's linked to the practice's old
 *     website — opens WordPress's search page, which has a box. Where the page
 *     has a search box, the icon is the design's: it opens that box.
 * A filter for the page's own content ("Search our FAQs") is neither, and a
 * link with a real page of this site to go to is left alone.
 *
 * The site's address comes from `window.kerfSearchHome`, printed before this
 * file (kerf_enqueue_front_script()).
 */
( function () {
	'use strict';

	var NOT_SITE = /(?:^|[\s_-])(?:faqs?|questions?|filters?)(?:$|[\s_-])/;
	var OPENER = /(?:^|[\s_-])(?:toggle|toggler|open|opener|trigger|close|dismiss)(?:$|[\s_-])/;

	/**
	 * Names as words: `searchToggle` → "search toggle", lower case.
	 *
	 * @param {string} text
	 * @return {string}
	 */
	function words( text ) {
		return String( text || '' ).replace( /([a-z])([A-Z])/g, '$1 $2' ).toLowerCase();
	}

	/**
	 * Does "search" stand as a word in these names? Never inside another one:
	 * `research-team` is not a search.
	 *
	 * @param {string} names Already words().
	 * @return {boolean}
	 */
	function isSearchNamed( names ) {
		return /(?:^|[\s_-])search(?:$|[\s_-])/.test( names );
	}

	/**
	 * Is a field, by what is known of it, the site's search box with no form?
	 *
	 * @param {Object} f { tag, type, inForm, readOnly, names, inPlace }
	 * @return {boolean}
	 */
	function isSiteSearchField( f ) {
		var type = String( f.type || 'text' ).toLowerCase();
		if ( 'INPUT' !== f.tag || f.inForm || f.readOnly || ( 'search' !== type && 'text' !== type ) ) {
			return false;
		}
		if ( NOT_SITE.test( f.names ) ) {
			return false;
		}
		return !! f.inPlace && ( 'search' === type || isSearchNamed( f.names ) );
	}

	/**
	 * Is a control — a link or button, by what is known of it — a search
	 * icon or a search button?
	 *
	 * @param {Object} c { names, label, href }
	 * @return {boolean}
	 */
	function isSearchControl( c ) {
		var label = words( c.label ).trim();
		if ( ! isSearchNamed( c.names ) && ! ( 'search' === label || 'search icon' === label ) ) {
			return false;
		}
		// Words other than "Search" make it a link somewhere ("Search jobs").
		if ( label && 'search' !== label && 'search icon' !== label && ! isSearchNamed( c.names ) ) {
			return false;
		}
		return true;
	}

	/**
	 * May a link's own address be passed over? Only when it goes nowhere, to
	 * a spot on the page, or to another site — never a page of this one.
	 *
	 * @param {string|null} href
	 * @param {string}      origin This site's.
	 * @param {string}      base   The page's address.
	 * @return {boolean}
	 */
	function deadEnd( href, origin, base ) {
		var at = String( null === href || undefined === href ? '' : href ).trim();
		if ( '' === at || '#' === at.charAt( 0 ) || /^javascript:/i.test( at ) ) {
			return true;
		}
		try {
			return new URL( at, base ).origin !== origin;
		} catch ( error ) {
			return false;
		}
	}

	/**
	 * WordPress's search for these words, on this site.
	 *
	 * @param {string} home The site's address.
	 * @param {string} text Words.
	 * @return {string}
	 */
	function searchUrl( home, text ) {
		return home + ( -1 === home.indexOf( '?' ) ? '?' : '&' ) + 's=' + encodeURIComponent( text );
	}

	window.kerfSearch = {
		words: words,
		isSearchNamed: isSearchNamed,
		isSiteSearchField: isSiteSearchField,
		isSearchControl: isSearchControl,
		deadEnd: deadEnd,
		searchUrl: searchUrl,
	};

	if ( ! window.document || ! window.addEventListener ) {
		return;
	}

	// The capture phase on the window: before every handler on the document,
	// the form or anything between.
	window.addEventListener( 'submit', function ( event ) {
		var form = event.target;
		// WordPress's own search block is left as it is.
		if ( ! form || 'FORM' !== form.tagName || form.closest( '.wp-block-search' ) ) {
			return;
		}

		var field = form.querySelector( 'input[name="s"]' );
		if ( ! field || 'get' !== String( form.getAttribute( 'method' ) || '' ).toLowerCase() || '' === field.value.trim() ) {
			return;
		}

		var target;
		try {
			target = new window.URL( form.getAttribute( 'action' ) || '', window.location.href );
		} catch ( error ) {
			return;
		}
		if ( target.origin !== window.location.origin ) {
			return;
		}

		// Nothing after this hears the submit, so nothing stops it: the browser
		// sends the form to WordPress search.
		event.stopImmediatePropagation();
	}, true );

	var home = window.kerfSearchHome;
	if ( 'string' !== typeof home || '' === home ) {
		return;
	}

	function namesOf( el ) {
		return words( [ el.id, 'string' === typeof el.className ? el.className : '', el.getAttribute( 'name' ), el.getAttribute( 'aria-label' ), el.getAttribute( 'title' ), el.getAttribute( 'placeholder' ) ].join( ' ' ) );
	}

	// In the site's header, a dialog, or anything named search.
	function inPlace( el ) {
		for ( var e = el.parentElement; e && e !== document.body; e = e.parentElement ) {
			if ( 'HEADER' === e.tagName || 'DIALOG' === e.tagName || 'dialog' === e.getAttribute( 'role' ) || 'true' === e.getAttribute( 'aria-modal' ) || isSearchNamed( namesOf( e ) ) ) {
				return true;
			}
		}
		return false;
	}

	function siteSearchField( el ) {
		return !! el && 'INPUT' === el.tagName && isSiteSearchField( {
			tag: el.tagName,
			type: el.getAttribute( 'type' ),
			inForm: !! el.form,
			readOnly: el.readOnly || el.disabled,
			names: namesOf( el ),
			inPlace: inPlace( el ),
		} );
	}

	// Any search box the page has, in a form or not: then a search icon is
	// the design's, opening it.
	function pageHasSearchBox() {
		return Array.prototype.some.call( document.querySelectorAll( 'input' ), function ( i ) {
			var type = String( i.getAttribute( 'type' ) || 'text' ).toLowerCase();
			return 's' === i.name || 'search' === type || ( 'text' === type && isSearchNamed( namesOf( i ) ) && ! NOT_SITE.test( namesOf( i ) ) );
		} );
	}

	function go( text ) {
		window.location.assign( searchUrl( home, text ) );
	}

	// Enter in a search box that has no form.
	window.addEventListener( 'keydown', function ( event ) {
		if ( 'Enter' !== event.key || event.isComposing || ! siteSearchField( event.target ) ) {
			return;
		}
		var text = event.target.value.trim();
		if ( '' === text ) {
			return;
		}
		event.preventDefault();
		event.stopImmediatePropagation();
		go( text );
	}, true );

	// A search button beside such a box, or a search icon with no box at all.
	window.addEventListener( 'click', function ( event ) {
		var control = event.target && event.target.closest ? event.target.closest( 'a, button, [role="button"]' ) : null;
		// A form's own button is the form's (the submit, above).
		if ( ! control || control.form || control.closest( '.wp-block-search' ) ) {
			return;
		}
		var names = namesOf( control );
		if ( ! isSearchControl( { names: names, label: control.textContent.trim().slice( 0, 40 ) } ) ) {
			return;
		}
		if ( 'A' === control.tagName && ! deadEnd( control.getAttribute( 'href' ), window.location.origin, window.location.href ) ) {
			return;
		}
		var opener = OPENER.test( names ) || control.hasAttribute( 'aria-controls' ) || control.hasAttribute( 'aria-expanded' ) || control.hasAttribute( 'data-toggle' ) || control.hasAttribute( 'data-bs-toggle' );

		// The nearest box round it that holds a search field with words.
		if ( ! opener ) {
			for ( var box = control.parentElement; box && box !== document.body; box = box.parentElement ) {
				var field = Array.prototype.find.call( box.querySelectorAll( 'input' ), siteSearchField );
				if ( field ) {
					if ( '' !== field.value.trim() ) {
						event.preventDefault();
						event.stopImmediatePropagation();
						go( field.value.trim() );
					}
					return;
				}
			}
		}

		if ( ! pageHasSearchBox() ) {
			event.preventDefault();
			event.stopImmediatePropagation();
			go( '' );
		}
	}, true );
}() );
