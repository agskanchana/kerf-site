/**
 * Shared editor controls for the Kerf block suite.
 *
 * Exposed on `window.kerf` rather than bundled into each block, because all
 * eight blocks need the same three panels and a mockup page renders hundreds of
 * them — eight copies of this code is eight copies in every editor load.
 *
 * No build step. The theme ships readable source that a site owner can open and
 * change, which matters more here than the few kilobytes a bundler would save:
 * the whole premise is that you own your markup.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var useMemo = wp.element.useMemo;
	var useSelect = wp.data.useSelect;
	var useDebounce = wp.compose.useDebounce;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var components = wp.components;
	var MediaUpload = wp.blockEditor.MediaUpload;
	var MediaUploadCheck = wp.blockEditor.MediaUploadCheck;
	var decodeEntities = ( wp.htmlEntities && wp.htmlEntities.decodeEntities ) || function ( text ) {
		return text;
	};

	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;
	var TextareaControl = components.TextareaControl;
	var SelectControl = components.SelectControl;
	var ComboboxControl = components.ComboboxControl;
	var Button = components.Button;
	var Notice = components.Notice;

	/**
	 * Tags offered in the tag picker, grouped so the list is scannable.
	 *
	 * Not the full set the renderer accepts — this is a convenience menu, and a
	 * converted block can legitimately carry a tag that is not listed (the
	 * converter preserves whatever the mockup used). The "Other" field below the
	 * picker is what keeps that honest: anything the menu lacks can still be
	 * typed, so the control never becomes a narrower contract than the converter.
	 */
	var TAG_GROUPS = [
		{
			label: __( 'Layout', 'kerf-blocks' ),
			tags: [ 'div', 'section', 'article', 'aside', 'header', 'footer', 'main', 'nav', 'figure', 'figcaption' ]
		},
		{
			label: __( 'Text', 'kerf-blocks' ),
			tags: [ 'p', 'span', 'a', 'button', 'strong', 'em', 'small', 'label', 'blockquote', 'pre', 'code', 'time' ]
		},
		{
			label: __( 'Lists', 'kerf-blocks' ),
			tags: [ 'ul', 'ol', 'li', 'dl', 'dt', 'dd' ]
		},
		{
			label: __( 'Tables', 'kerf-blocks' ),
			tags: [ 'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption' ]
		},
		{
			label: __( 'Forms', 'kerf-blocks' ),
			tags: [ 'form', 'fieldset', 'legend', 'input', 'textarea', 'select', 'option' ]
		},
		{
			label: __( 'Other', 'kerf-blocks' ),
			tags: [ 'details', 'summary', 'dialog', 'iframe', 'canvas', 'picture', 'hr', 'br' ]
		}
	];

	/**
	 * Tags that close themselves. Mirrors kerf_void_tags() in PHP.
	 */
	var VOID_TAGS = [ 'area', 'br', 'col', 'hr', 'img', 'input', 'source', 'track', 'wbr' ];

	/**
	 * Is this a void element?
	 *
	 * @param {string} tag Tag name.
	 * @return {boolean}
	 */
	function isVoid( tag ) {
		return VOID_TAGS.indexOf( String( tag || '' ).toLowerCase() ) !== -1;
	}

	/**
	 * Tag picker with a free-text escape hatch.
	 *
	 * @param {Object}   props
	 * @param {string}   props.value    Current tag.
	 * @param {Function} props.onChange Receives the new tag.
	 * @return {Object} Element.
	 */
	function TagControl( props ) {
		var value = String( props.value || 'div' ).toLowerCase();
		var known = TAG_GROUPS.some( function ( group ) {
			return group.tags.indexOf( value ) !== -1;
		} );

		var options = [];
		TAG_GROUPS.forEach( function ( group ) {
			options.push( { label: '— ' + group.label + ' —', value: '', disabled: true } );
			group.tags.forEach( function ( tag ) {
				options.push( { label: tag, value: tag } );
			} );
		} );

		if ( ! known ) {
			options.unshift( { label: value + ' ' + __( '(from your mockup)', 'kerf-blocks' ), value: value } );
		}

		return el( Fragment, null,
			el( SelectControl, {
				label: __( 'Tag', 'kerf-blocks' ),
				value: value,
				options: options,
				onChange: props.onChange,
				__nextHasNoMarginBottom: true
			} ),
			el( TextControl, {
				label: __( 'Or type any tag', 'kerf-blocks' ),
				value: value,
				onChange: function ( next ) {
					props.onChange( String( next || '' ).trim().toLowerCase().replace( /[^a-z0-9-]/g, '' ) );
				},
				help: __( 'Kerf renders whatever element you name. Changing this does not touch the children.', 'kerf-blocks' ),
				__nextHasNoMarginBottom: true
			} )
		);
	}

	/**
	 * Is the block being edited in full — not locked to its content by client
	 * mode (kerf-client-mode.js)? A hook: call it unconditionally, first.
	 *
	 * @return {boolean}
	 */
	function fullEditing() {
		var mode = wp.blockEditor.useBlockEditingMode ? wp.blockEditor.useBlockEditingMode() : 'default';
		return 'default' === mode;
	}

	/**
	 * Does a front-end framework run this attribute as code? The same list as
	 * kerf_mc_is_directive_attribute() in PHP — keep the two in step.
	 *
	 * @param {string} name
	 * @return {boolean}
	 */
	function isDirective( name ) {
		return /^(?:[@:#]|x-|v-|hx-|data-hx-|ng-|data-ng-|data-on[-:]|data-signals|data-computed|data-effect)|^(?:_|script|data-script|data-bind|on[a-z]+)$/.test( String( name || '' ).toLowerCase() );
	}

	/**
	 * Editor for the block's `customAttributes` map.
	 *
	 * A repeater rather than a set of named fields, because the whole point of
	 * the attribute map is that it is not a fixed list — a mockup can carry
	 * `data-aos`, `hx-get`, `x-data`, `name`, `placeholder`, `allowfullscreen`,
	 * and none of those deserve bespoke UI.
	 *
	 * @param {Object}   props
	 * @param {Object}   props.value    Current attribute map.
	 * @param {Function} props.onChange Receives the new map.
	 * @return {Object} Element.
	 */
	function AttributesPanel( props ) {
		// Client mode (kerf-client-mode.js): a content block's words, picture and
		// link are open; its attributes are the design's.
		if ( ! fullEditing() ) {
			return null;
		}
		var value = props.value && typeof props.value === 'object' ? props.value : {};
		var keys = Object.keys( value );

		function update( nextKeys, nextValues ) {
			var next = {};
			nextKeys.forEach( function ( key, i ) {
				if ( key ) {
					next[ key ] = nextValues[ i ];
				}
			} );
			props.onChange( next );
		}

		var values = keys.map( function ( key ) {
			return value[ key ];
		} );

		var rows = keys.map( function ( key, index ) {
			return el( 'div', { className: 'kerf-attr-row', key: 'row-' + index },
				el( TextControl, {
					label: index === 0 ? __( 'Name', 'kerf-blocks' ) : '',
					value: key,
					onChange: function ( next ) {
						var nextKeys = keys.slice();
						nextKeys[ index ] = String( next || '' ).trim().toLowerCase();
						update( nextKeys, values );
					},
					__nextHasNoMarginBottom: true
				} ),
				el( TextControl, {
					label: index === 0 ? __( 'Value', 'kerf-blocks' ) : '',
					value: typeof values[ index ] === 'boolean' ? '' : String( values[ index ] === undefined ? '' : values[ index ] ),
					onChange: function ( next ) {
						var nextValues = values.slice();
						nextValues[ index ] = next;
						update( keys, nextValues );
					},
					__nextHasNoMarginBottom: true
				} ),
				el( Button, {
					isDestructive: true,
					variant: 'tertiary',
					label: __( 'Remove', 'kerf-blocks' ),
					icon: 'no-alt',
					onClick: function () {
						var nextKeys = keys.slice();
						var nextValues = values.slice();
						nextKeys.splice( index, 1 );
						nextValues.splice( index, 1 );
						update( nextKeys, nextValues );
					}
				} )
			);
		} );

		// Handlers, Alpine, htmx and the like run these as code; someone who
		// may not add scripts cannot add or change one — the save takes it out
		// (inc/kerf-directives.php). Saying so here beats a silent loss.
		var mayAddCode = ! window.kerfEditor || false !== window.kerfEditor.unfiltered;
		var hasCode = ! mayAddCode && keys.some( isDirective );

		return el( PanelBody, { title: __( 'HTML attributes', 'kerf-blocks' ), initialOpen: false },
			hasCode && el( Notice, { status: 'warning', isDismissible: false },
				__( 'Attributes like onclick, @click, x-data and hx-get run code. Only an administrator who may add scripts can add or change them: a new or changed one is removed when you save. The ones already here stay.', 'kerf-blocks' )
			),
			rows,
			el( Button, {
				variant: 'secondary',
				onClick: function () {
					update( keys.concat( [ '' ] ), values.concat( [ '' ] ) );
				}
			}, __( 'Add attribute', 'kerf-blocks' ) ),
			el( 'p', { className: 'kerf-help' },
				__( 'class, id and style have their own controls above. Everything else your mockup wrote is here, and is rendered verbatim.', 'kerf-blocks' )
			)
		);
	}

	/**
	 * Inline style panel.
	 *
	 * @param {Object}   props
	 * @param {Object}   props.attributes    Block attributes.
	 * @param {Function} props.setAttributes Setter.
	 * @return {Object} Element.
	 */
	function StylePanel( props ) {
		if ( ! fullEditing() ) {
			return null;
		}
		var attributes = props.attributes;
		var setAttributes = props.setAttributes;

		return el( PanelBody, { title: __( 'CSS', 'kerf-blocks' ), initialOpen: false },
			el( TextareaControl, {
				label: __( 'Inline style', 'kerf-blocks' ),
				value: attributes.inlineStyle || '',
				onChange: function ( next ) {
					setAttributes( { inlineStyle: next } );
				},
				rows: 3,
				help: __( 'Declarations only, as they would appear in a style attribute: color:#fff;border-radius:4px', 'kerf-blocks' ),
				__nextHasNoMarginBottom: true
			} )
		);
	}

	/**
	 * Post statuses the page picker lists. A link can be bound to a draft — an
	 * import's "create the missing pages" makes drafts to hold the slugs — so a
	 * draft has to be findable and shown as one. kerf_resolve_link_url() sends
	 * visitors to it only once it is published.
	 */
	var LINKABLE_STATUSES = [ 'publish', 'future', 'draft', 'pending', 'private' ];

	var POST_FIELDS = 'id,title,status,link,type';

	/**
	 * @param {string} status
	 * @return {string} '' for a published post.
	 */
	function statusLabel( status ) {
		var labels = {
			future: __( 'scheduled', 'kerf-blocks' ),
			draft: __( 'draft', 'kerf-blocks' ),
			pending: __( 'pending review', 'kerf-blocks' ),
			'private': __( 'private', 'kerf-blocks' )
		};
		return labels[ status ] || '';
	}

	/**
	 * @param {Object} record A post from the REST API.
	 * @return {string}
	 */
	function postTitle( record ) {
		var title = record && record.title ? decodeEntities( record.title.rendered || record.title.raw || '' ) : '';
		var status = statusLabel( record && record.status );
		title = title || __( '(no title)', 'kerf-blocks' );
		return status ? title + ' (' + status + ')' : title;
	}

	/**
	 * getEntityRecords() for a post type, falling back to published posts for
	 * someone who may not list that type's drafts: the REST API refuses the
	 * whole query (an Author asking for draft pages gets an error, not pages).
	 *
	 * @param {Object} core  select( 'core' ).
	 * @param {string} type  Post type.
	 * @param {Object} query
	 * @return {{records: (Object[]|null), done: boolean}}
	 */
	function queryPosts( core, type, query ) {
		var records = core.getEntityRecords( 'postType', type, query );
		var done = core.hasFinishedResolution( 'getEntityRecords', [ 'postType', type, query ] );
		if ( null === records && done ) {
			var published = Object.assign( {}, query, { status: 'publish' } );
			records = core.getEntityRecords( 'postType', type, published );
			done = core.hasFinishedResolution( 'getEntityRecords', [ 'postType', type, published ] );
		}
		return { records: records, done: done };
	}

	/**
	 * The post types a link can point at: every public one but attachments
	 * (files are the media source), pages first, then posts, then the rest by
	 * name. Pages and posts until the list of types arrives.
	 *
	 * @param {Object[]|null} types getPostTypes() result.
	 * @return {Object[]} { slug, label }
	 */
	function linkableTypes( types ) {
		var list = ( types || [] ).filter( function ( type ) {
			return type && type.viewable && 'attachment' !== type.slug;
		} ).map( function ( type ) {
			return {
				slug: type.slug,
				label: ( type.labels && type.labels.singular_name ) || type.name || type.slug
			};
		} );

		if ( ! list.length ) {
			list = [
				{ slug: 'page', label: __( 'Page', 'kerf-blocks' ) },
				{ slug: 'post', label: __( 'Post', 'kerf-blocks' ) }
			];
		}

		var rank = { page: 0, post: 1 };
		return list.sort( function ( a, b ) {
			var ra = undefined === rank[ a.slug ] ? 2 : rank[ a.slug ];
			var rb = undefined === rank[ b.slug ] ? 2 : rank[ b.slug ];
			return ra - rb || String( a.label ).localeCompare( String( b.label ) );
		} );
	}

	/**
	 * Where the markup contract sends this link (§5.25), if it does: a card's
	 * title goes to its post, "next" to the next post, a tag to its archive.
	 * kerf_apply_element_fields() and the bindings decide that at render and
	 * override any choice made here, so the sidebar says so instead of offering
	 * a choice that would do nothing.
	 *
	 * @param {Object} attributes
	 * @param {string} urlKey
	 * @return {string} An explanation, or ''.
	 */
	function contractDestination( attributes, urlKey ) {
		var bindings = attributes.metadata && attributes.metadata.bindings;
		var fields = ' ' + ( attributes.kerfFields || '' ) + ' ' + ( ( attributes.customAttributes || {} )[ 'data-kerf-field' ] || '' ) + ' ';

		if ( /\s(?:prev|next)\s/.test( fields ) ) {
			return __( 'This link goes to the previous or next post. The template sets it (data-kerf-field), so it is not chosen here.', 'kerf-blocks' );
		}
		if ( /\sterm-link\s/.test( fields ) ) {
			return __( 'This link goes to the tag or category it shows. The template sets it (data-kerf-field), so it is not chosen here.', 'kerf-blocks' );
		}
		if ( /\s(?:permalink|title)\s/.test( fields ) || ( bindings && 'href' !== urlKey && bindings[ urlKey ] ) ) {
			return __( 'This link goes to the post it shows. The template sets it (data-kerf-field), so it is not chosen here.', 'kerf-blocks' );
		}
		return '';
	}

	/**
	 * Does this href look like a page of this site — the kind the import binds?
	 * The editor's half of kerf_links_normalize(): not `#…`, `mailto:`, `tel:`,
	 * another host, or a file.
	 *
	 * @param {string} url
	 * @return {boolean}
	 */
	function looksLikePage( url ) {
		url = String( url || '' ).trim();
		if ( ! url || '#' === url.charAt( 0 ) || /^(?:mailto|tel|sms|callto|javascript|vbscript|data|ftp):/i.test( url ) ) {
			return false;
		}
		if ( /^(?:https?:)?\/\//i.test( url ) ) {
			try {
				if ( new window.URL( url, window.location.href ).host !== window.location.host ) {
					return false;
				}
			} catch ( e ) {
				return false;
			}
		}
		var path = url.replace( /[?#].*$/, '' );
		return ! ( /\.[a-z][a-z0-9]{0,4}$/i.test( path ) && ! /\.(?:html?|php|aspx?)$/i.test( path ) );
	}

	/**
	 * Pick a page, a post or anything else public: a Type, then a search box.
	 *
	 * Searches as you type (debounced) instead of listing the first hundred, so
	 * a site with a thousand posts can still link to any of them. The type of
	 * an existing binding is not stored — the import binds by ID alone — so it
	 * is found by asking each type for that ID, pages first.
	 *
	 * @param {Object}   props
	 * @param {number}   props.linkId   Bound post ID, or 0.
	 * @param {string}   props.fallback The URL as written.
	 * @param {Function} props.onPick   Receives the chosen ID (0 to clear).
	 * @return {Object} Element.
	 */
	function PostPicker( props ) {
		var linkId = props.linkId;
		var typeState = useState( '' );
		var searchState = useState( '' );
		var setSearch = useDebounce( searchState[ 1 ], 300 );

		var postTypes = useSelect( function ( select ) {
			return select( 'core' ).getPostTypes( { per_page: -1 } );
		}, [] );
		var types = useMemo( function () {
			return linkableTypes( postTypes );
		}, [ postTypes ] );

		// The bound post, whichever type it is. Selector results are returned
		// as they come (core-data keeps them stable), so nothing re-renders
		// unless the data did.
		var bound = useSelect( function ( select ) {
			var core = select( 'core' );
			if ( ! linkId ) {
				return { record: null, pending: false };
			}
			// Asked type by type, so a page binding costs one request.
			for ( var i = 0; i < types.length; i++ ) {
				var found = queryPosts( core, types[ i ].slug, { include: [ linkId ], status: LINKABLE_STATUSES, _fields: POST_FIELDS } );
				if ( found.records && found.records.length ) {
					return { record: found.records[ 0 ], pending: false };
				}
				if ( ! found.done ) {
					return { record: null, pending: true };
				}
			}
			return { record: null, pending: false };
		}, [ linkId, types ] );

		var type = typeState[ 0 ] || ( bound.record && bound.record.type ) || types[ 0 ].slug;
		var typeInfo = types.filter( function ( item ) {
			return item.slug === type;
		} )[ 0 ] || { slug: type, label: type };

		var results = useSelect( function ( select ) {
			var query = {
				per_page: 50,
				orderby: 'title',
				order: 'asc',
				status: LINKABLE_STATUSES,
				_fields: POST_FIELDS
			};
			if ( searchState[ 0 ] ) {
				query.search = searchState[ 0 ];
			}
			return queryPosts( select( 'core' ), type, query ).records;
		}, [ type, searchState[ 0 ] ] );

		var options = useMemo( function () {
			var list = ( results || [] ).map( function ( record ) {
				return { value: String( record.id ), label: postTitle( record ) };
			} );
			// The bound post is always an option, or the box shows empty while
			// the link is in fact bound — before the first search, or when the
			// post is not among the first fifty by title.
			if ( bound.record && bound.record.type === type && ! list.some( function ( option ) {
				return option.value === String( bound.record.id );
			} ) ) {
				list.unshift( { value: String( bound.record.id ), label: postTitle( bound.record ) } );
			}
			return list;
		}, [ results, bound.record, type ] );

		var note = null;
		var fallback = props.fallback
			? el( 'code', null, props.fallback )
			: __( 'no link at all', 'kerf-blocks' );

		if ( ! linkId ) {
			note = el( 'p', { className: 'kerf-help' },
				__( 'Until one is chosen, visitors get the URL as written:', 'kerf-blocks' ), ' ', fallback );
		} else if ( bound.record && ( 'publish' === bound.record.status || 'private' === bound.record.status ) ) {
			note = el( 'p', { className: 'kerf-help kerf-link-target' },
				__( 'Links to', 'kerf-blocks' ), ' ', el( 'code', null, bound.record.link ) );
		} else if ( bound.record ) {
			note = el( Notice, { status: 'warning', isDismissible: false },
				__( 'Not published yet. Until it is, visitors get the URL as written:', 'kerf-blocks' ), ' ', fallback );
		} else if ( ! bound.pending ) {
			note = el( Notice, { status: 'warning', isDismissible: false },
				/* translators: %d: a post ID. */
				sprintf( __( 'The post this link was bound to (#%d) no longer exists. Visitors get the URL as written:', 'kerf-blocks' ), linkId ),
				' ', fallback );
		}

		return el( Fragment, null,
			el( SelectControl, {
				label: __( 'Type', 'kerf-blocks' ),
				value: type,
				options: types.map( function ( item ) {
					return { label: item.label, value: item.slug };
				} ),
				onChange: function ( next ) {
					typeState[ 1 ]( next );
				},
				__next40pxDefaultSize: true,
				__nextHasNoMarginBottom: true
			} ),
			el( ComboboxControl, {
				label: typeInfo.label,
				value: bound.record && bound.record.type === type ? String( linkId ) : null,
				options: options,
				onChange: function ( next ) {
					props.onPick( next ? parseInt( next, 10 ) || 0 : 0 );
				},
				onFilterValueChange: setSearch,
				help: __( 'Type to search by title.', 'kerf-blocks' ),
				__next40pxDefaultSize: true,
				__nextHasNoMarginBottom: true
			} ),
			note
		);
	}

	/**
	 * Pick any file in the media library — an image, a PDF, a video. Bound by
	 * attachment, so the link follows the file if it is replaced or the site
	 * moves to another address.
	 *
	 * @param {Object}   props
	 * @param {number}   props.linkId   Attachment ID, or 0.
	 * @param {string}   props.fallback The URL as written.
	 * @param {Function} props.onPick   Receives the chosen ID (0 to clear).
	 * @return {Object} Element.
	 */
	function MediaPicker( props ) {
		var linkId = props.linkId;

		var file = useSelect( function ( select ) {
			var core = select( 'core' );
			if ( ! linkId ) {
				return { record: null, done: true };
			}
			return {
				record: core.getEntityRecord( 'postType', 'attachment', linkId ),
				done: core.hasFinishedResolution( 'getEntityRecord', [ 'postType', 'attachment', linkId ] )
			};
		}, [ linkId ] );

		var fallback = props.fallback
			? el( 'code', null, props.fallback )
			: __( 'no link at all', 'kerf-blocks' );
		var note = null;

		if ( linkId && file.record ) {
			var url = file.record.source_url || '';
			note = el( 'p', { className: 'kerf-help kerf-link-target' },
				el( 'strong', null, decodeEntities( ( file.record.title && file.record.title.rendered ) || '' ) || url.split( '/' ).pop() ),
				' ', el( 'code', null, url ) );
		} else if ( linkId && file.done ) {
			note = el( Notice, { status: 'warning', isDismissible: false },
				/* translators: %d: an attachment ID. */
				sprintf( __( 'The file this link was bound to (#%d) is no longer in the media library. Visitors get the URL as written:', 'kerf-blocks' ), linkId ),
				' ', fallback );
		} else if ( ! linkId ) {
			note = el( 'p', { className: 'kerf-help' },
				__( 'Until one is chosen, visitors get the URL as written:', 'kerf-blocks' ), ' ', fallback );
		}

		return el( Fragment, null,
			note,
			el( MediaUploadCheck, {
				fallback: el( 'p', { className: 'kerf-help' }, __( 'Choosing a file needs permission to upload files.', 'kerf-blocks' ) )
			},
				el( MediaUpload, {
					// Deliberately any type: a lightbox opens an image or a video,
					// a brochure link a PDF.
					value: linkId || undefined,
					onSelect: function ( media ) {
						if ( media && media.id ) {
							props.onPick( media.id );
						}
					},
					render: function ( upload ) {
						return el( 'div', { className: 'kerf-link-file-actions' },
							el( Button, { variant: 'secondary', onClick: upload.open },
								linkId ? __( 'Replace file', 'kerf-blocks' ) : __( 'Choose file', 'kerf-blocks' ) ),
							linkId ? el( Button, {
								variant: 'link',
								isDestructive: true,
								onClick: function () {
									props.onPick( 0 );
								}
							}, __( 'Clear', 'kerf-blocks' ) ) : null
						);
					}
				} )
			)
		);
	}

	/**
	 * Where a link points: a URL, a page or post, a file in the media library,
	 * or the home page.
	 *
	 * Stored as `linkType` + `linkId` and resolved when the page renders
	 * (kerf_resolve_link_url()), so a bound link follows its target through a
	 * slug change, a move under a parent, a replaced file:
	 *
	 *   ''       nothing chosen: the URL as written. The import could not bind
	 *            it, or it never was a page (`#top`, `tel:`, another site). A
	 *            re-scan under Kerf → Links may still bind it.
	 *   'url'    a URL chosen or typed here. A re-scan leaves it alone.
	 *   'post'   a page, a post or any public post type, by ID.
	 *   'media'  a file in the media library, by attachment ID.
	 *   'home'   the site's front page.
	 *
	 * The URL as written — the mockup's href — is never discarded: a page or
	 * file that is deleted or unpublished falls back to it, and choosing
	 * "External URL" brings it back into the field.
	 *
	 * @param {Object}   props
	 * @param {Object}   props.attributes    Block attributes.
	 * @param {Function} props.setAttributes Setter.
	 * @param {string}   props.urlKey        Attribute holding the literal href.
	 * @return {Object} Element.
	 */
	function LinkTargetControl( props ) {
		var attributes = props.attributes;
		var setAttributes = props.setAttributes;
		var urlKey = props.urlKey || 'url';
		var linkType = attributes.linkType || '';
		var linkId = parseInt( attributes.linkId, 10 ) || 0;

		/**
		 * The literal href, wherever this block keeps it.
		 *
		 * kerf/link uses `url`, kerf/image uses `linkUrl`, and kerf/div — which
		 * is what an anchor with element children becomes — keeps it in
		 * `customAttributes.href` along with every other attribute. Reading and
		 * writing through one pair of helpers is what lets all three share this
		 * control instead of a card link being editable only by hand-typing into
		 * the raw attribute list.
		 *
		 * @return {string}
		 */
		function readUrl() {
			if ( 'href' === urlKey ) {
				return ( attributes.customAttributes && attributes.customAttributes.href ) || '';
			}
			return attributes[ urlKey ] || '';
		}

		/**
		 * A URL typed here is a URL chosen here (`url`), which a re-scan leaves
		 * alone and the "no page" warning no longer questions.
		 *
		 * @param {string} next
		 */
		function writeUrl( next ) {
			var patch = '' === linkType ? { linkType: 'url' } : {};
			if ( 'href' === urlKey ) {
				var custom = Object.assign( {}, attributes.customAttributes || {} );
				if ( next ) {
					custom.href = next;
				} else {
					delete custom.href;
				}
				patch.customAttributes = custom;
			} else {
				patch[ urlKey ] = next;
			}
			setAttributes( patch );
		}

		var contract = contractDestination( attributes, urlKey );
		if ( contract ) {
			return el( Notice, { status: 'info', isDismissible: false }, contract );
		}

		var source = ( 'post' === linkType || 'media' === linkType || 'home' === linkType ) ? linkType : 'url';
		var url = readUrl();
		var pick = function ( id ) {
			setAttributes( { linkId: id } );
		};
		var detail;

		if ( 'post' === source ) {
			detail = el( PostPicker, { linkId: linkId, fallback: url, onPick: pick } );
		} else if ( 'media' === source ) {
			detail = el( MediaPicker, { linkId: linkId, fallback: url, onPick: pick } );
		} else if ( 'home' === source ) {
			detail = el( 'p', { className: 'kerf-help' },
				__( 'Goes to the site’s front page, wherever Settings → Reading puts it.', 'kerf-blocks' ) );
		} else {
			detail = el( Fragment, null,
				el( TextControl, {
					label: __( 'URL', 'kerf-blocks' ),
					value: url,
					onChange: writeUrl,
					type: 'url',
					placeholder: 'https://example.com',
					help: __( 'Rendered exactly as written: another site, #anchor, mailto: or tel:.', 'kerf-blocks' ),
					__next40pxDefaultSize: true,
					__nextHasNoMarginBottom: true
				} ),
				// The mockup's `services.html` with no page to bind to: on the
				// site it leads nowhere, and this is where someone looking at the
				// link finds that out (Kerf → Links lists them all).
				'' === linkType && looksLikePage( url ) && el( Notice, { status: 'warning', isDismissible: false },
					__( 'No page on this site was found for this address, so it probably leads to “Page not found”. Choose “Existing page or post” to point it at one.', 'kerf-blocks' ) )
			);
		}

		return el( 'div', { className: 'kerf-link-source' },
			el( SelectControl, {
				label: __( 'Link source', 'kerf-blocks' ),
				value: source,
				options: [
					{ label: __( 'External URL', 'kerf-blocks' ), value: 'url' },
					{ label: __( 'Existing page or post', 'kerf-blocks' ), value: 'post' },
					{ label: __( 'Media file (from library)', 'kerf-blocks' ), value: 'media' },
					{ label: __( 'Home page', 'kerf-blocks' ), value: 'home' }
				],
				onChange: function ( next ) {
					// An ID means nothing to another source: a page ID is not
					// an attachment's. The URL as written stays, as the fallback.
					setAttributes( { linkType: next, linkId: 0 } );
				},
				__next40pxDefaultSize: true,
				__nextHasNoMarginBottom: true
			} ),
			detail
		);
	}

	window.kerf = window.kerf || {};
	window.kerf.LinkTargetControl = LinkTargetControl;
	window.kerf.TagControl = TagControl;
	window.kerf.AttributesPanel = AttributesPanel;
	window.kerf.StylePanel = StylePanel;
	window.kerf.isVoid = isVoid;
	window.kerf.fullEditing = fullEditing;
	window.kerf.VOID_TAGS = VOID_TAGS;

	/**
	 * Turn a block's attributes into the props its editor preview should render.
	 *
	 * The editor loads the mockup's own stylesheets into the canvas, so a preview
	 * that renders the real tag with the real classes looks like the real page.
	 * That is worth more than any custom editor chrome: what you are editing is a
	 * design someone already approved, and being unable to see it is the single
	 * loudest complaint about block-converted markup.
	 *
	 * @param {Object} attributes Block attributes.
	 * @return {Object} Props for createElement.
	 */
	window.kerf.previewProps = function ( attributes ) {
		var props = {};
		var custom = attributes.customAttributes || {};

		Object.keys( custom ).forEach( function ( key ) {
			// React refuses unknown non-lowercase props and rejects handlers
			// outright; data-/aria- pass through untouched, which covers the
			// attributes that actually affect how a mockup looks.
			if ( /^(data|aria)-/.test( key ) ) {
				props[ key ] = custom[ key ];
			}
		} );

		// What the page keeps out of sight until a script shows it: `hidden`,
		// a `popover`, a closed `<dialog>`, and what Alpine's `x-show` hides
		// (with `x-cloak` until Alpine starts). Never forwarded as itself: none
		// of it was in the canvas, so a site search panel or an Alpine modal
		// covered the page there and nothing under it could be clicked; and as
		// itself it could not be shown again — `display:revert` answers
		// `[hidden]` and a closed dialog with the browser's own `none`. Markers
		// instead, which kerf-canvas.js hides at rest and shows while something
		// inside is selected, the way it opens a dropdown (REST there).
		if ( undefined !== custom.hidden ) {
			props[ 'data-kerf-hidden' ] = '';
		}
		if ( undefined !== custom.popover ) {
			props[ 'data-kerf-popover' ] = '';
		}
		if ( 'dialog' === String( attributes.tagName || '' ).toLowerCase() ) {
			// Drawn open, so the design's styles for it apply; at rest the
			// marker hides it unless the design opened it.
			props.open = true;
			if ( undefined === custom.open ) {
				props[ 'data-kerf-dialog' ] = '';
			}
		}
		[ 'x-show', 'x-data', 'x-cloak' ].forEach( function ( name ) {
			if ( undefined !== custom[ name ] ) {
				props[ 'data-kerf-' + name ] = String( custom[ name ] );
			}
		} );

		// The block's own inline style. The front end has always printed it;
		// the canvas never applied it, so every `style="…"` in a mockup — a
		// width, a colour, a progress bar's percentage — was missing while you
		// edited, and the editor disagreed with the page.
		var style = parseStyle( attributes.inlineStyle || '' );

		// A background kept only in backgroundImage (blocks converted before
		// the style was kept whole, or set from the sidebar) leads, as it does
		// on the front end.
		if ( attributes.backgroundImage && -1 === ( attributes.inlineStyle || '' ).indexOf( attributes.backgroundImage ) ) {
			// Bound to the post's picture (§5.25), the binding's value replaces
			// the sample in the style, as kerf_apply_bound_background() does on
			// the page; otherwise the style the mockup wrote leads.
			var bound = attributes.metadata && attributes.metadata.bindings && attributes.metadata.bindings.backgroundImage;
			style = bound
				? Object.assign( {}, style, { backgroundImage: 'url(' + attributes.backgroundImage + ')' } )
				: Object.assign( { backgroundImage: 'url(' + attributes.backgroundImage + ')' }, style );
		}

		if ( Object.keys( style ).length ) {
			props.style = style;
		}

		return props;
	};

	/**
	 * CSS declarations → a React style object.
	 *
	 * Split on semicolons outside parentheses and quotes, because
	 * `url(data:image/png;base64,…)` has one inside. Custom properties keep
	 * their name, as React expects. `!important` cannot be expressed in a React
	 * style object and is dropped; the value still applies.
	 *
	 * @param {string} css
	 * @return {Object}
	 */
	function parseStyle( css ) {
		var out = {};
		var depth = 0;
		var quote = '';
		var start = 0;
		var parts = [];

		for ( var i = 0; i < css.length; i++ ) {
			var ch = css.charAt( i );
			if ( quote ) {
				if ( ch === quote ) {
					quote = '';
				}
			} else if ( '"' === ch || "'" === ch ) {
				quote = ch;
			} else if ( '(' === ch ) {
				depth++;
			} else if ( ')' === ch ) {
				depth--;
			} else if ( ';' === ch && ! depth ) {
				parts.push( css.slice( start, i ) );
				start = i + 1;
			}
		}
		parts.push( css.slice( start ) );

		parts.forEach( function ( part ) {
			var colon = part.indexOf( ':' );
			if ( colon < 1 ) {
				return;
			}
			var name = part.slice( 0, colon ).trim().toLowerCase();
			var value = part.slice( colon + 1 ).replace( /\s*!important\s*$/i, '' ).trim();
			if ( ! name || ! value ) {
				return;
			}
			if ( 0 !== name.indexOf( '--' ) ) {
				name = name.replace( /^-ms-/, 'ms-' ).replace( /-([a-z])/g, function ( m, c ) {
					return c.toUpperCase();
				} );
			}
			out[ name ] = value;
		} );

		return out;
	}

	window.kerf.parseStyle = parseStyle;

	/**
	 * The SVG allowlist — the same lists as kerf_sanitize_svg_markup() in
	 * inc/kerf-svg.php. Keep the two in step.
	 */
	var SVG_TAGS = [
		'svg', 'g', 'defs', 'symbol', 'use', 'title', 'desc',
		'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
		'text', 'tspan', 'textpath',
		'lineargradient', 'radialgradient', 'stop', 'pattern',
		'clippath', 'mask', 'marker', 'switch',
		'filter', 'fegaussianblur', 'feoffset', 'feblend', 'feflood',
		'fecomposite', 'femerge', 'femergenode', 'fecolormatrix', 'fedropshadow'
	];

	var SVG_ATTRS = [
		'id', 'class', 'style', 'transform', 'viewbox', 'xmlns', 'xmlns:xlink',
		'width', 'height', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry',
		'd', 'points', 'fill', 'fill-rule', 'fill-opacity', 'clip-rule', 'clip-path',
		'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray',
		'stroke-dashoffset', 'stroke-opacity', 'stroke-miterlimit',
		'opacity', 'offset', 'stop-color', 'stop-opacity', 'gradientunits',
		'gradienttransform', 'patternunits', 'patterncontentunits', 'maskunits',
		'clippathunits', 'markerwidth', 'markerheight', 'refx', 'refy', 'orient',
		'preserveaspectratio', 'overflow', 'vector-effect', 'paint-order',
		'font-family', 'font-size', 'font-weight', 'font-style', 'text-anchor',
		'dominant-baseline', 'letter-spacing', 'dx', 'dy',
		'stddeviation', 'in', 'in2', 'result', 'mode', 'type', 'values', 'flood-color',
		'flood-opacity', 'operator',
		'role', 'aria-label', 'aria-hidden', 'aria-labelledby', 'focusable'
	];

	/**
	 * Sanitize SVG markup for the EDITOR preview, with the render allowlist.
	 *
	 * The front end has always sanitized on render. The editor did not: it put
	 * the stored markup into the canvas with dangerouslySetInnerHTML, and the
	 * converter strips only <script> from an svg — so `<svg onload="…">` from a
	 * third-party mockup ran in the administrator's editor. Parsed as XML into
	 * an inert document, filtered, and only then handed to the canvas.
	 *
	 * @param {string} markup
	 * @return {{attrs: Object, inner: string}|null} The root's attributes and
	 *         its sanitized children, or null when nothing usable survives.
	 */
	window.kerf.sanitizeSvg = function ( markup ) {
		if ( ! markup || ! /<svg\b/i.test( markup ) ) {
			return null;
		}

		// XML needs the namespaces the HTML parser supplies implicitly: the
		// SVG one, and every prefix used without a declaration — `xlink:href`
		// in an icon sprite, `sketch:type` from an export. Undeclared, a prefix
		// is a parse error in XML, and the whole graphic was left out of the
		// preview while the page (PHP's parser recovers) showed it.
		var source = String( markup );
		var declare = /<svg\b[^>]*\bxmlns\s*=/i.test( source ) ? '' : ' xmlns="http://www.w3.org/2000/svg"';
		var prefixes = {};
		source.replace( /(?:\s|<\/?)([A-Za-z_][\w.-]*):[A-Za-z_]/g, function ( match, prefix ) {
			if ( 'xml' !== prefix && 'xmlns' !== prefix && ! prefixes[ prefix ]
				&& ! new RegExp( 'xmlns:' + prefix.replace( /[.]/g, '\\.' ) + '\\s*=' ).test( source ) ) {
				prefixes[ prefix ] = true;
				declare += ' xmlns:' + prefix + '="' + ( 'xlink' === prefix ? 'http://www.w3.org/1999/xlink' : 'urn:x-kerf:' + prefix ) + '"';
			}
			return match;
		} );
		if ( declare ) {
			source = source.replace( /<svg\b/i, function ( tag ) {
				return tag + declare;
			} );
		}

		var doc = new window.DOMParser().parseFromString( source, 'image/svg+xml' );
		var root = doc.documentElement;

		// The page's parser takes <SVG> too (inc/kerf-svg.php), so this does.
		if ( ! root || 'svg' !== root.localName.toLowerCase() || doc.getElementsByTagName( 'parsererror' ).length ) {
			return null;
		}

		( function clean( node ) {
			Array.prototype.slice.call( node.childNodes ).forEach( function ( child ) {
				// CDATA is text, as it is on the page (LIBXML_NOCDATA).
				if ( 4 === child.nodeType ) {
					node.replaceChild( doc.createTextNode( child.data ), child );
					return;
				}
				if ( 1 !== child.nodeType ) {
					if ( 3 !== child.nodeType ) {
						node.removeChild( child );
					}
					return;
				}
				if ( -1 === SVG_TAGS.indexOf( child.localName.toLowerCase() ) ) {
					node.removeChild( child );
					return;
				}
				cleanAttributes( child );
				clean( child );
			} );
		}( root ) );

		cleanAttributes( root );

		var attrs = {};
		Array.prototype.forEach.call( root.attributes, function ( attr ) {
			attrs[ attr.name ] = attr.value;
		} );

		var inner = new window.XMLSerializer().serializeToString( root );
		inner = inner.replace( /^<svg\b[^>]*>/i, '' ).replace( /<\/svg>\s*$/i, '' );

		return { attrs: attrs, inner: inner };
	};

	function cleanAttributes( el ) {
		Array.prototype.slice.call( el.attributes ).forEach( function ( attr ) {
			var name = attr.name.toLowerCase();
			var value = attr.value;

			if ( 'href' === name || 'xlink:href' === name ) {
				// Same-document fragments only, as on the front end.
				if ( ! /^#[A-Za-z0-9_:.-]+$/.test( value.trim() ) ) {
					el.removeAttribute( attr.name );
				}
				return;
			}
			if ( -1 === SVG_ATTRS.indexOf( name ) ) {
				el.removeAttribute( attr.name );
				return;
			}
			if ( 'style' === name && /(?:javascript|vbscript|data)\s*:|expression\s*\(|behaviou?r\s*:|@import/i.test( value ) ) {
				el.removeAttribute( attr.name );
			}
		} );
	}
}( window.wp ) );
