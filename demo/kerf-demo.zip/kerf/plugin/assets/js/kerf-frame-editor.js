/**
 * kerf/frame — the mockup's page wrapper, in the editor.
 *
 * Templates wrap the header part, the content and the footer part in this
 * block; the front end re-emits the designer's wrapper element around them
 * (kerf_render_frame_block()). The canvas draws the same element, from the same
 * stored attributes, so a mockup whose whole design hangs off `#wrapper` looks
 * the same while its templates are edited. With no frame recorded the block is
 * `display: contents` — present for the editor, invisible to layout, exactly
 * as it is absent from the page.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var useInnerBlocksProps = wp.blockEditor.useInnerBlocksProps;
	var InnerBlocks = wp.blockEditor.InnerBlocks;

	var frame = ( window.KerfFrame && Array.isArray( window.KerfFrame.frame ) ) ? window.KerfFrame.frame : [];

	// The elements a frame plausibly is. Anything else draws as a div: the tag
	// comes from an import, but the editor is no place to find out it was odd.
	var TAGS = [ 'div', 'section', 'article', 'main', 'aside', 'body' ];

	function tagOf( attrs ) {
		var tag = String( attrs.tagName || 'div' ).toLowerCase();
		return TAGS.indexOf( tag ) === -1 || 'body' === tag ? 'div' : tag;
	}

	function elementProps( attrs ) {
		var props = ( window.kerf && window.kerf.previewProps ) ? window.kerf.previewProps( attrs ) : {};
		if ( attrs.className ) {
			props.className = attrs.className;
		}
		// WordPress owns the block's id; the canvas rewrites `#wrapper` rules to
		// match this attribute instead (see anchorSelector() in kerf-canvas.js).
		if ( attrs.anchor ) {
			props[ 'data-kerf-anchor' ] = attrs.anchor;
		}
		return props;
	}

	wp.blocks.registerBlockType( 'kerf/frame', {
		edit: function () {
			var outer = frame[ 0 ] || null;
			var innermost = frame.length > 1 ? frame[ frame.length - 1 ] : null;

			// Both hooks run on every render, whatever the frame looks like:
			// hook order must not depend on data (scar 9).
			var blockProps = useBlockProps( outer ? elementProps( outer ) : { style: { display: 'contents' } } );
			var innerProps = useInnerBlocksProps( innermost ? elementProps( innermost ) : blockProps, { renderAppender: false } );

			if ( ! innermost ) {
				return el( outer ? tagOf( outer ) : 'div', innerProps );
			}

			var tree = el( tagOf( innermost ), innerProps );
			for ( var i = frame.length - 2; i >= 1; i-- ) {
				tree = el( tagOf( frame[ i ] ), elementProps( frame[ i ] ), tree );
			}

			return el( tagOf( outer ), blockProps, tree );
		},

		save: function () {
			return el( InnerBlocks.Content );
		}
	} );
}( window.wp ) );
