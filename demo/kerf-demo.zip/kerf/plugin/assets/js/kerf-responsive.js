/**
 * Per-block "hide on device" control.
 *
 * Adds three toggles to every kerf/* block. The classes they set are injected
 * server-side onto the block's own outermost element (see
 * kerf_responsive_inject_classes) rather than onto a wrapper — a wrapper would
 * break every flex and grid child in the mockup, which is the one thing this
 * theme must never do.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var addFilter = wp.hooks.addFilter;
	var createHigherOrderComponent = wp.compose.createHigherOrderComponent;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var ToggleControl = wp.components.ToggleControl;

	// Client mode (kerf-client-mode.js) locks a block to its content. Read from
	// the block's context: WordPress does not pass the mode to editor.BlockEdit
	// filters as a prop, and a gate reading props.blockEditingMode let every
	// panel through. A hook — call it first, unconditionally.
	function fullEditing() {
		return 'default' === ( wp.blockEditor.useBlockEditingMode ? wp.blockEditor.useBlockEditingMode() : 'default' );
	}

	// The widths the design's own stylesheets change layout at
	// (kerf_responsive_breakpoints()), so each toggle says where it hides.
	var widths = window.KerfResponsive || {};
	var mobile = parseInt( widths.mobile, 10 ) || 599;
	var tablet = parseInt( widths.tablet, 10 ) || 1199;

	var TOGGLES = [
		[
			'kerfHideDesktop',
			__( 'Hide on desktop', 'kerf-blocks' ),
			/* translators: %d: a width in pixels. */
			sprintf( __( '%dpx and wider', 'kerf-blocks' ), tablet + 1 )
		],
		[
			'kerfHideTablet',
			__( 'Hide on tablet', 'kerf-blocks' ),
			/* translators: 1: narrowest width, 2: widest width, in pixels. */
			sprintf( __( '%1$d to %2$dpx', 'kerf-blocks' ), mobile + 1, tablet )
		],
		[
			'kerfHideMobile',
			__( 'Hide on mobile', 'kerf-blocks' ),
			/* translators: %d: a width in pixels. */
			sprintf( __( 'Up to %dpx', 'kerf-blocks' ), mobile )
		]
	];

	/**
	 * Does this block take the visibility attributes?
	 *
	 * @param {string} name Block name.
	 * @return {boolean}
	 */
	function supports( name ) {
		return typeof name === 'string' && name.indexOf( 'kerf/' ) === 0;
	}

	// Declare the attributes client-side so the editor stores them. The server
	// declares the same three in kerf_responsive_register_attributes(); both are
	// required, and a mismatch shows up as the toggle resetting itself on reload.
	addFilter( 'blocks.registerBlockType', 'kerf/responsive-attributes', function ( settings, name ) {
		if ( ! supports( name ) ) {
			return settings;
		}

		settings.attributes = Object.assign( {}, settings.attributes, {
			kerfHideDesktop: { type: 'boolean', default: false },
			kerfHideTablet: { type: 'boolean', default: false },
			kerfHideMobile: { type: 'boolean', default: false },
			kerfOnly: { type: 'string', default: '' }
		} );

		return settings;
	} );

	addFilter( 'editor.BlockEdit', 'kerf/responsive-controls', createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			var full = fullEditing();
			if ( ! supports( props.name ) ) {
				return el( BlockEdit, props );
			}

			// Client mode (kerf-client-mode.js): where a block shows is the design's.
			if ( ! full ) {
				return el( BlockEdit, props );
			}

			var hiddenEverywhere = TOGGLES.every( function ( row ) {
				return props.attributes[ row[ 0 ] ];
			} );

			return el( Fragment, null,
				el( BlockEdit, props ),
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'Visibility', 'kerf-blocks' ), initialOpen: 'front' === props.attributes.kerfOnly },
						el( ToggleControl, {
							label: __( 'Home page only', 'kerf-blocks' ),
							help: __( 'Rendered on the page this mockup was imported as, and left out everywhere else. Kerf sets it on an intro that sits in the header part.', 'kerf-blocks' ),
							checked: 'front' === props.attributes.kerfOnly,
							onChange: function ( next ) {
								props.setAttributes( { kerfOnly: next ? 'front' : '' } );
							},
							__nextHasNoMarginBottom: true
						} ),
						TOGGLES.map( function ( row ) {
							return el( ToggleControl, {
								key: row[ 0 ],
								label: row[ 1 ],
								help: row[ 2 ],
								checked: !! props.attributes[ row[ 0 ] ],
								onChange: function ( next ) {
									var patch = {};
									patch[ row[ 0 ] ] = next;
									props.setAttributes( patch );
								},
								__nextHasNoMarginBottom: true
							} );
						} ),
						hiddenEverywhere && el( 'p', { className: 'kerf-help kerf-help--warn' },
							__( 'Hidden at every size. The block still renders and still downloads its images — delete it instead if you meant to remove it.', 'kerf-blocks' )
						),
						el( 'p', { className: 'kerf-help' },
							( '1' === String( widths.design )
								? __( 'These are your design\'s own widths, where its stylesheets change layout.', 'kerf-blocks' )
								: __( 'Your design changes layout at no width Kerf could read, so these are Kerf\'s.', 'kerf-blocks' ) )
							+ ' ' + __( 'Hiding is visual only: the markup is still in the page and still read by search engines.', 'kerf-blocks' )
						)
					)
				)
			);
		};
	}, 'kerfResponsiveControls' ) );
}( window.wp ) );
