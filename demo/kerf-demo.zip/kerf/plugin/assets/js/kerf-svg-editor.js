/**
 * kerf/svg — inline SVG markup.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var components = wp.components;
	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;
	var TextareaControl = components.TextareaControl;
	var Notice = components.Notice;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/svg', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;
			var svg = attributes.svg || '';

			// Sanitized with the same allowlist the front end renders through —
			// never the raw stored markup, which is third-party.
			var parsed = wp.element.useMemo( function () {
				return kerf.sanitizeSvg( svg );
			}, [ svg ] );

			var ref = wp.element.useRef();

			// The <svg> IS the block, as on the page, instead of sitting two
			// <div>s deep. Its own class joins the block's; everything else from
			// the root is set on the element directly, because React cannot map
			// SVG's attribute vocabulary without a table of it.
			var ownClass = parsed && parsed.attrs[ 'class' ] ? parsed.attrs[ 'class' ] : '';
			// The block's width and height only when set: assigned as
			// `undefined`, they wiped the SVG's own `style="width:15px"` and
			// a button's icon filled the header (Manhattan's phone).
			var size = {};
			if ( attributes.width ) {
				size.width = attributes.width;
			}
			if ( attributes.height ) {
				size.height = attributes.height;
			}
			var blockProps = useBlockProps( Object.assign( kerf.previewProps( attributes ), {
				ref: ref,
				className: parsed ? ownClass : 'kerf-svg-edit__empty',
				style: Object.assign( {}, kerf.previewProps( attributes ).style || {}, kerf.parseStyle( parsed && parsed.attrs.style ? parsed.attrs.style : '' ), size )
			} ) );

			wp.element.useLayoutEffect( function () {
				var node = ref.current;
				if ( ! node || ! parsed ) {
					return;
				}
				Object.keys( parsed.attrs ).forEach( function ( name ) {
					if ( 'class' !== name && 'style' !== name && 'xmlns' !== name ) {
						node.setAttribute( name, parsed.attrs[ name ] );
					}
				} );
				node.innerHTML = parsed.inner;
			}, [ parsed ] );

			// The server sanitizes on render; this only warns, so the author finds
			// out while editing rather than wondering why the page differs.
			var hasScript = /<script|\son[a-z]+\s*=/i.test( svg );

			return el( Fragment, null,
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'SVG', 'kerf-blocks' ), initialOpen: true },
						el( TextareaControl, {
							label: __( 'Markup', 'kerf-blocks' ),
							value: svg,
							onChange: function ( next ) {
								setAttributes( { svg: next } );
							},
							rows: 10,
							help: __( 'Sanitized against an allowlist when rendered. Scripts, event handlers and external references are removed.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} ),
						el( TextControl, {
							label: __( 'Width', 'kerf-blocks' ),
							value: attributes.width || '',
							onChange: function ( next ) {
								setAttributes( { width: next } );
							},
							help: __( 'Any CSS length: 24px, 2rem, 100%.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} ),
						el( TextControl, {
							label: __( 'Height', 'kerf-blocks' ),
							value: attributes.height || '',
							onChange: function ( next ) {
								setAttributes( { height: next } );
							},
							__nextHasNoMarginBottom: true
						} ),
						el( TextControl, {
							label: __( 'Accessible label', 'kerf-blocks' ),
							value: attributes.ariaLabel || '',
							onChange: function ( next ) {
								setAttributes( { ariaLabel: next } );
							},
							help: __( 'Leave empty for a decorative graphic — it will be hidden from screen readers.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} )
					),
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					hasScript && el( Notice, { status: 'warning', isDismissible: false },
						__( 'This SVG contains a script or an event handler. It is stripped here and when the page renders.', 'kerf-blocks' )
					)
				),
				parsed
					? el( 'svg', blockProps )
					: el( 'span', blockProps, __( 'Paste SVG markup in the sidebar.', 'kerf-blocks' ) )
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
