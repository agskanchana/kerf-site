/**
 * kerf/loop — the designer's card, repeated once per post on the page.
 *
 * In the editor the card is shown once — it is the template every post fills
 * in — and filled with the LATEST post, the way core's Query Loop previews
 * real posts: the loop provides that post as block context, and the binding
 * sources (kerf-bindings-editor.js) read its title, date, excerpt and picture.
 * With no posts, the fields say what they are ("Post title"). The block
 * itself is `display: contents`, as it adds no element to the page; select it
 * from the List View.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var be = wp.blockEditor;
	var c = wp.components;

	wp.blocks.registerBlockType( 'kerf/loop', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var blockProps = be.useBlockProps( { style: { display: 'contents' } } );
			var innerProps = be.useInnerBlocksProps( blockProps, { renderAppender: false } );
			var latest = 'main' !== attributes.query;

			var first = wp.data.useSelect( function ( select ) {
				var posts = select( 'core' ).getEntityRecords( 'postType', 'post', { per_page: 1, orderby: 'date', order: 'desc' } );
				return posts && posts.length ? posts[ 0 ] : null;
			}, [] );

			var card = el( 'div', innerProps );
			if ( first && be.BlockContextProvider ) {
				card = el( be.BlockContextProvider, { value: { postId: first.id, postType: 'post' } }, card );
			}

			return el( Fragment, null,
				el( be.InspectorControls, null,
					el( c.PanelBody, { title: __( 'Posts', 'kerf-blocks' ) },
						el( c.SelectControl, {
							label: __( 'Which posts', 'kerf-blocks' ),
							value: latest ? 'latest' : 'main',
							options: [
								{ value: 'main', label: __( 'The posts of this page (blog, archive, search)', 'kerf-blocks' ) },
								{ value: 'latest', label: __( 'The latest posts', 'kerf-blocks' ) }
							],
							onChange: function ( value ) {
								props.setAttributes( { query: value } );
							},
							__nextHasNoMarginBottom: true,
							__next40pxDefaultSize: true
						} ),
						latest && el( c.RangeControl, {
							label: __( 'How many', 'kerf-blocks' ),
							value: attributes.perPage,
							min: 1,
							max: 24,
							onChange: function ( value ) {
								props.setAttributes( { perPage: value } );
							},
							__nextHasNoMarginBottom: true,
							__next40pxDefaultSize: true
						} ),
						el( 'p', { className: 'kerf-help' },
							__( 'The card is repeated for each post, with the marked parts filled in — here it shows your latest post. With no posts, nothing is shown — never the mockup\'s sample cards.', 'kerf-blocks' )
						)
					)
				),
				card
			);
		},

		save: function () {
			return el( be.InnerBlocks.Content );
		}
	} );
}( window.wp ) );
