/**
 * kerf/icon — an icon element whose classes pass through verbatim.
 *
 * There is no icon PICKER here, and that is the design. Kerf ships no icon font,
 * so there is no set to pick from — the icons are whatever the mockup's own
 * stylesheet provides, which might be Font Awesome, Remix, Lucide, Phosphor, or
 * a bespoke sheet the designer built. A picker could only offer a set Kerf
 * bundled, and bundling one would mean rewriting the designer's classes to
 * match it, which is exactly the behaviour this theme exists to avoid.
 *
 * What you get instead is the class string, editable, with a live preview
 * rendered by the mockup's own CSS.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var components = wp.components;
	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/icon', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;
			var tag = ( attributes.tagName || 'i' ).toLowerCase();
			var iconClass = attributes.iconClass || '';

			// The icon element IS the block, as on the page: `<i class="ri-…">`,
			// not a <span> around it. The wrapper broke `a > i`, counted as an
			// extra flex item, and made the icon's parent measure the span.
			// Only a missing class needs a marker, since an empty icon is
			// invisible and unclickable.
			var blockProps = useBlockProps( Object.assign( kerf.previewProps( attributes ), {
				className: ( iconClass + ( iconClass ? '' : ' kerf-icon-edit__empty' ) ).trim(),
				'aria-hidden': 'true'
			} ) );

			return el( Fragment, null,
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'Icon', 'kerf-blocks' ), initialOpen: true },
						el( TextControl, {
							label: __( 'Icon classes', 'kerf-blocks' ),
							value: iconClass,
							onChange: function ( next ) {
								setAttributes( { iconClass: next } );
							},
							help: __( 'Exactly as your icon set spells them — fa-solid fa-house, ri-home-line, bi-house, lucide-home. Rendered by the stylesheet that came with your mockup.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} ),
						el( kerf.TagControl, {
							value: tag,
							onChange: function ( next ) {
								setAttributes( { tagName: next || 'i' } );
							}
						} )
					),
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				kerf.isVoid( tag )
					? el( tag, blockProps )
					: el( tag, blockProps, iconClass ? null : __( 'No icon class set', 'kerf-blocks' ) )
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
