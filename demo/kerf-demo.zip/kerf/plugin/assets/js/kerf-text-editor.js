/**
 * kerf/text — a run of text in an inline element.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var RichText = blockEditor.RichText;
	var PanelBody = wp.components.PanelBody;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/text', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;
			var tag = ( attributes.tagName || 'span' ).toLowerCase();
			// Client mode (kerf-client-mode.js): the tag is the design's.
			var full = kerf.fullEditing();

			// Bare text has no element on the page, but a block needs one here.
			// A <span> was the obvious stand-in and the wrong one: the mockup's
			// `span` rules matched it — gymlife's `.so-categories a span { float:
			// right }` floated every category's NAME along with its count, and
			// the list came apart. An unknown element is inline like a span and
			// matches no rule written for one.
			var editTag = attributes.bare ? 'kerf-text' : tag;

			var blockProps = useBlockProps( kerf.previewProps( attributes ) );

			return el( Fragment, null,
				el( InspectorControls, null,
					full && el( PanelBody, { title: __( 'Element', 'kerf-blocks' ), initialOpen: true },
						// Bare text was plain text beside an element in the mockup.
						// Choosing a tag is choosing to make it an element.
						attributes.bare && el( 'p', { className: 'kerf-help' },
							__( 'Plain text on the page, exactly as in your mockup — it has no element of its own. It is an element here only so it can be edited. Pick a tag to wrap it in one.', 'kerf-blocks' )
						),
						el( kerf.TagControl, {
							value: tag,
							onChange: function ( next ) {
								setAttributes( { tagName: next || 'span', bare: false } );
							}
						} )
					),
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				el( RichText, Object.assign( {}, blockProps, {
					tagName: editTag,
					value: attributes.text || '',
					// The renderer escapes this value, so formatting typed here
					// would be shown as literal markup on the page. Offering the
					// toolbar anyway would be a lie about what the block can do.
					allowedFormats: [],
					onChange: function ( next ) {
						setAttributes( { text: next } );
					},
					placeholder: __( 'Text…', 'kerf-blocks' )
				} ) )
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
