/**
 * Background pictures: the pure helpers (§5.41).
 *
 * Shared by the editor's Background picture panel (kerf-background-panel.js)
 * and the update screen's check (kerf-sync-backgrounds.js), and lifted by
 * name by tests/js/background.test.js. No dependencies: nothing here touches
 * the DOM or WordPress.
 *
 * @package kerf
 */

( function () {
	'use strict';

	/**
	 * Split on commas outside parentheses and quotes: a background-image value
	 * into its layers, a selector list into its selectors.
	 *
	 * @param {string} value
	 * @return {string[]}
	 */
	function splitTopLevel( value ) {
		var out = [];
		var depth = 0;
		var quote = '';
		var start = 0;
		value = String( value || '' );
		for ( var i = 0; i < value.length; i++ ) {
			var ch = value.charAt( i );
			if ( quote ) {
				if ( ch === quote && '\\' !== value.charAt( i - 1 ) ) {
					quote = '';
				}
				continue;
			}
			if ( '"' === ch || "'" === ch ) {
				quote = ch;
			} else if ( '(' === ch || '[' === ch ) {
				depth++;
			} else if ( ')' === ch || ']' === ch ) {
				depth--;
			} else if ( ',' === ch && 0 === depth ) {
				out.push( value.slice( start, i ).trim() );
				start = i + 1;
			}
		}
		var last = value.slice( start ).trim();
		if ( last ) {
			out.push( last );
		}
		return out;
	}

	/**
	 * The address in a `url(…)` layer, or '' for a gradient or `none`.
	 *
	 * @param {string} layer
	 * @return {string}
	 */
	function layerUrl( layer ) {
		var match = /^url\(\s*(["']?)(.*?)\1\s*\)$/i.exec( String( layer || '' ).trim() );
		return match ? match[ 2 ] : '';
	}

	/**
	 * The value with layer `index` showing `url` — every other layer (a
	 * gradient, a texture) as the designer wrote it.
	 *
	 * @param {string} value
	 * @param {number} index
	 * @param {string} url
	 * @return {string}
	 */
	function swapLayer( value, index, url ) {
		var layers = splitTopLevel( value );
		layers[ index ] = 'url("' + String( url ).replace( /["'\\\s()]/g, function ( ch ) {
			return '%' + ch.charCodeAt( 0 ).toString( 16 ).toUpperCase();
		} ) + '")';
		return layers.join( ', ' );
	}

	/**
	 * The design's own selector back from the canvas's copy: Kerf shows a
	 * mockup id as `data-kerf-anchor` and rewrites `#x` in place
	 * (kerf-canvas.js anchorSelector()).
	 *
	 * @param {string} selector
	 * @return {string}
	 */
	function designSelector( selector ) {
		return String( selector || '' ).replace( /:is\(#((?:\\.|[^,()\\])+),\[data-kerf-anchor="(?:\\.|[^"\\])*"\]\)/g, '#$1' );
	}

	/**
	 * Which layer a selector draws on: '::before', '::after' or ''.
	 *
	 * @param {string} selector
	 * @return {string}
	 */
	function pseudoOf( selector ) {
		var match = /::?(before|after)\b/i.exec( String( selector || '' ) );
		return match ? '::' + match[ 1 ].toLowerCase() : '';
	}

	/**
	 * A selector without its ::before/::after, to test against the element.
	 *
	 * @param {string} selector
	 * @return {string}
	 */
	function withoutPseudo( selector ) {
		return String( selector || '' ).replace( /::?(?:before|after)\b/gi, '' ).trim() || '*';
	}

	/**
	 * A selector's weight, as the cascade counts it: [ids, classes, types].
	 * Close enough to choose between the design's rules for one element.
	 *
	 * @param {string} selector
	 * @return {number[]}
	 */
	function specificity( selector ) {
		var s = String( selector || '' )
			.replace( /"[^"]*"|'[^']*'/g, '' )
			.replace( /:where\([^)]*\)/g, '' )
			.replace( /::?(?:before|after|first-line|first-letter|placeholder|selection|marker)\b/gi, ' x' );
		var ids = ( s.match( /#[\w-]+/g ) || [] ).length;
		var classes = ( s.match( /\.[\w-]+|\[[^\]]*\]|:(?!:)[\w-]+/g ) || [] ).length;
		var types = ( s.replace( /#[\w-]+|\.[\w-]+|\[[^\]]*\]|::?[\w-]+(?:\([^)]*\))?/g, ' ' ).match( /(?:^|[\s>+~])[a-z][\w-]*/gi ) || [] ).length;
		return [ ids, classes, types ];
	}

	/**
	 * Does weight `a` beat or equal weight `b`?
	 *
	 * @param {number[]} a
	 * @param {number[]} b
	 * @return {boolean}
	 */
	function weighsAtLeast( a, b ) {
		for ( var i = 0; i < 3; i++ ) {
			if ( a[ i ] !== b[ i ] ) {
				return a[ i ] > b[ i ];
			}
		}
		return true;
	}

	/**
	 * A staged file's place in the design: `…/kerf-blocks/mockup-…/site/img/bg.jpg`
	 * is `site/img/bg.jpg`, the same in every version of the design.
	 *
	 * @param {string} url
	 * @return {string}
	 */
	function designPath( url ) {
		var clean = String( url || '' ).split( /[?#]/ )[ 0 ];
		var match = /\/(?:kerf-blocks|kerf-assets)\/mockup-[^/]+\/(.+)$/.exec( clean );
		try {
			return match ? decodeURIComponent( match[ 1 ] ) : clean;
		} catch ( e ) {
			return match ? match[ 1 ] : clean;
		}
	}

	/**
	 * A declaration added at the end of a style, where it wins.
	 *
	 * @param {string} style
	 * @param {string} decl
	 * @return {string}
	 */
	function addDecl( style, decl ) {
		var base = String( style || '' ).replace( /[\s;]+$/, '' );
		return base ? base + '; ' + decl : decl;
	}

	/**
	 * A declaration Kerf added, taken back out — exactly that text, so the
	 * designer's own declarations around it stay as they were.
	 *
	 * @param {string} style
	 * @param {string} decl
	 * @return {string}
	 */
	function removeDecl( style, decl ) {
		var s = String( style || '' );
		var at = decl ? s.lastIndexOf( decl ) : -1;
		if ( -1 === at ) {
			return s;
		}
		return ( s.slice( 0, at ) + s.slice( at + decl.length ) )
			.replace( /;\s*;/g, ';' )
			.replace( /^[\s;]+|[\s;]+$/g, '' );
	}

	/**
	 * The CSS for the "everywhere" changes, as inc/kerf-backgrounds.php prints
	 * it on the page: the designer's selector, after the design's own CSS. A
	 * rule for each page's featured image (`featured`) draws with this page's,
	 * and not at all where there is none — the design's picture shows.
	 *
	 * @param {Object} list     Key => rule.
	 * @param {string} featured The featured image of the page being edited, or ''.
	 * @return {string}
	 */
	function rulesCss( list, featured ) {
		return Object.keys( list || {} ).map( function ( key ) {
			var rule = list[ key ];
			var value = rule.value;
			if ( rule.featured ) {
				if ( ! featured ) {
					return '';
				}
				value = swapLayer( value, rule.layer || 0, featured );
			}
			var block = rule.selector + '{background-image:' + value + ( rule.important ? ' !important' : '' ) + '}';
			return rule.media ? '@media ' + rule.media + '{' + block + '}' : block;
		} ).join( '' );
	}

	window.kerfBackgroundCore = {
		splitTopLevel: splitTopLevel,
		layerUrl: layerUrl,
		swapLayer: swapLayer,
		designSelector: designSelector,
		pseudoOf: pseudoOf,
		withoutPseudo: withoutPseudo,
		specificity: specificity,
		weighsAtLeast: weighsAtLeast,
		designPath: designPath,
		addDecl: addDecl,
		removeDecl: removeDecl,
		rulesCss: rulesCss
	};
}() );
