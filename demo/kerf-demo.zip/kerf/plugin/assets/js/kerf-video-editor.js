/**
 * kerf/video — a bare <video>.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var MediaPlaceholder = blockEditor.MediaPlaceholder;
	var MediaUpload = blockEditor.MediaUpload;
	var components = wp.components;
	var PanelBody = components.PanelBody;
	var ToggleControl = components.ToggleControl;
	var SelectControl = components.SelectControl;
	var Button = components.Button;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/video', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;
			var blockProps = useBlockProps();

			if ( ! attributes.src ) {
				return el( 'div', blockProps,
					el( MediaPlaceholder, {
						icon: 'video-alt3',
						labels: { title: __( 'Video', 'kerf-blocks' ) },
						allowedTypes: [ 'video' ],
						onSelect: function ( media ) {
							setAttributes( { src: media.url } );
						},
						onSelectURL: function ( url ) {
							setAttributes( { src: url } );
						}
					} )
				);
			}

			var toggles = [
				[ 'autoplay', __( 'Autoplay', 'kerf-blocks' ), __( 'Browsers only autoplay muted video, so Kerf adds muted for you when this is on.', 'kerf-blocks' ) ],
				[ 'loop', __( 'Loop', 'kerf-blocks' ), '' ],
				[ 'muted', __( 'Muted', 'kerf-blocks' ), '' ],
				[ 'playsinline', __( 'Play inline', 'kerf-blocks' ), __( 'Stops iOS taking the video fullscreen.', 'kerf-blocks' ) ],
				[ 'controls', __( 'Show controls', 'kerf-blocks' ), '' ]
			];

			return el( Fragment, null,
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'Video', 'kerf-blocks' ), initialOpen: true },
						el( MediaUpload, {
							allowedTypes: [ 'video' ],
							onSelect: function ( media ) {
								setAttributes( { src: media.url } );
							},
							render: function ( uploader ) {
								return el( Button, { variant: 'secondary', onClick: uploader.open },
									__( 'Replace video', 'kerf-blocks' ) );
							}
						} ),
						el( MediaUpload, {
							allowedTypes: [ 'image' ],
							onSelect: function ( media ) {
								setAttributes( { poster: media.url } );
							},
							render: function ( uploader ) {
								return el( Button, { variant: 'tertiary', onClick: uploader.open },
									attributes.poster ? __( 'Replace poster', 'kerf-blocks' ) : __( 'Set poster image', 'kerf-blocks' ) );
							}
						} ),
						toggles.map( function ( row ) {
							return el( ToggleControl, {
								key: row[ 0 ],
								label: row[ 1 ],
								checked: !! attributes[ row[ 0 ] ],
								onChange: function ( next ) {
									var patch = {};
									patch[ row[ 0 ] ] = next;
									setAttributes( patch );
								},
								help: row[ 2 ] || undefined,
								__nextHasNoMarginBottom: true
							} );
						} ),
						el( SelectControl, {
							label: __( 'Preload', 'kerf-blocks' ),
							value: attributes.preload || '',
							options: [
								{ label: __( 'Automatic', 'kerf-blocks' ), value: '' },
								{ label: 'none', value: 'none' },
								{ label: 'metadata', value: 'metadata' },
								{ label: 'auto', value: 'auto' }
							],
							onChange: function ( next ) {
								setAttributes( { preload: next } );
							},
							__nextHasNoMarginBottom: true
						} )
					),
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				el( 'div', blockProps,
					el( 'video', {
						src: attributes.src,
						poster: attributes.poster || undefined,
						className: attributes.className,
						// Always controlled and never autoplaying in the canvas:
						// an editor where three hero videos start playing at once
						// is unusable, and the front end is unaffected.
						controls: true,
						muted: true
					} )
				)
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
