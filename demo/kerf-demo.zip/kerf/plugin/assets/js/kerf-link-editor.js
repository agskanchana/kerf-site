/**
 * kerf/link — a text-only anchor.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var RichText = blockEditor.RichText;
	var components = wp.components;
	var PanelBody = components.PanelBody;
	var TextControl = components.TextControl;
	var ToggleControl = components.ToggleControl;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/link', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;

			var blockProps = useBlockProps( kerf.previewProps( attributes ) );

			return el( Fragment, null,
				el( InspectorControls, null,
					el( PanelBody, { title: __( 'Link', 'kerf-blocks' ), initialOpen: true },
						el( kerf.LinkTargetControl, {
							attributes: attributes,
							setAttributes: setAttributes,
							urlKey: 'url'
						} ),
						el( ToggleControl, {
							label: __( 'Open in a new tab', 'kerf-blocks' ),
							checked: !! attributes.newTab,
							onChange: function ( next ) {
								setAttributes( { newTab: next } );
							},
							__nextHasNoMarginBottom: true
						} ),
						el( TextControl, {
							label: __( 'rel', 'kerf-blocks' ),
							value: attributes.rel || '',
							onChange: function ( next ) {
								setAttributes( { rel: next } );
							},
							help: __( 'noopener noreferrer is added automatically for new-tab links.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} )
					),
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				el( RichText, Object.assign( {}, blockProps, {
					tagName: 'a',
					value: attributes.text || '',
					allowedFormats: [],
					onChange: function ( next ) {
						setAttributes( { text: next } );
					},
					placeholder: __( 'Link text…', 'kerf-blocks' )
				} ) )
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
