/**
 * Editor-wide Kerf tools: the Kerf sidebar, and the warning before a save
 * empties the page's inline SVGs.
 *
 * The sidebar holds the canvas's Troubleshoot toggles (kerf-canvas.js) and a
 * slot, `KerfSidebar`, for panels another plugin adds — Kerf Pro's Convert
 * HTML (paste a section's HTML, insert it or replace the selected block)
 * fills it. Without Kerf Pro, one quiet line says what it would add.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	// wp.editor is the unified sidebar API (WP 6.6+) and works in the post editor
	// AND the site editor. wp.editPost is the older post-editor-only namespace,
	// kept as a fallback. Registering through wp.editPost alone would mean the
	// view modes are missing from the site editor — which is exactly where a
	// converted header, full of absolutely-positioned flyouts, needs them most.
	var host = ( wp.editor && wp.editor.PluginSidebar ) ? wp.editor : wp.editPost;

	if ( ! wp.plugins || ! host || ! host.PluginSidebar ) {
		return;
	}

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var Slot = wp.components.Slot;

	var PluginSidebar = host.PluginSidebar;
	var PluginSidebarMoreMenuItem = host.PluginSidebarMoreMenuItem;

	// Someone without unfiltered_html saves through KSES, which keeps no <svg>:
	// every inline SVG on the page would be emptied by the next save, and
	// WordPress would not say a word (§5.32). Say so while there are any —
	// before the save, which is when it can still be avoided.
	if ( window.kerfEditor && ! window.kerfEditor.unfiltered && wp.data && wp.data.subscribe ) {
		var svgCount = -1;
		wp.data.subscribe( function () {
			var store = wp.data.select( 'core/block-editor' );
			var count = store && store.getGlobalBlockCount ? store.getGlobalBlockCount( 'kerf/svg' ) : 0;
			if ( count === svgCount ) {
				return;
			}
			svgCount = count;

			var notices = wp.data.dispatch( 'core/notices' );
			if ( ! count ) {
				notices.removeNotice( 'kerf-svg-kses' );
				return;
			}
			notices.createWarningNotice(
				wp.i18n.sprintf(
					/* translators: %d: number of graphics. */
					wp.i18n._n(
						'This has %d inline SVG graphic, and saving will remove it: WordPress removes <svg> from whatever is saved by a user who may not add unfiltered HTML (on a network, anyone but a super admin). Ask one to make changes here.',
						'This has %d inline SVG graphics, and saving will remove them: WordPress removes <svg> from whatever is saved by a user who may not add unfiltered HTML (on a network, anyone but a super admin). Ask one to make changes here.',
						count,
						'kerf-blocks'
					),
					count
				),
				{ id: 'kerf-svg-kses', isDismissible: false }
			);
		} );
	}

	wp.plugins.registerPlugin( 'kerf-converter', {
		icon: 'editor-code',
		render: function () {
			// The view toggles live in the same sidebar as Kerf Pro's
			// converter so there is one place to look for anything Kerf adds. Registered
			// separately in kerf-canvas.js because they are useful in the
			// site editor too, where this sidebar does not exist.
			var CanvasPanel = window.kerf && window.kerf.CanvasPanel;

			return el( Fragment, null,
				PluginSidebarMoreMenuItem && el( PluginSidebarMoreMenuItem, { target: 'kerf-converter', icon: 'editor-code' },
					__( 'Kerf', 'kerf-blocks' )
				),
				el( PluginSidebar, {
					name: 'kerf-converter',
					title: __( 'Kerf', 'kerf-blocks' ),
					icon: 'editor-code'
				},
					CanvasPanel ? el( CanvasPanel ) : null,
					// Kerf Pro's panels (its kerf-convert-panel.js), or a line
					// saying what it adds here.
					Slot ? el( Slot, { name: 'KerfSidebar' }, function ( fills ) {
						return fills.length ? fills : el( 'div', { className: 'kerf-sidebar-note' },
							el( 'p', { className: 'kerf-help' }, __( 'Kerf Pro adds Convert HTML here: paste a section\'s new HTML, and insert it or replace the selected block.', 'kerf-blocks' ) )
						);
					} ) : null
				)
			);
		}
	} );
}( window.wp ) );
