/**
 * Forms Kerf sends (inc/kerf-forms.php): sent in place, and answered with the
 * designer's own thank-you or error message.
 *
 * A form is Kerf's when its address is Kerf's handler — nothing is added to
 * the markup to find it. Without JavaScript the same form posts and the page
 * comes back with its message shown; this only saves the reload.
 *
 * Printed inline, once, on pages that have such a form.
 */
( function () {
	'use strict';

	function isKerfForm( form ) {
		return !! form && 'FORM' === form.tagName && /[?&]action=kerf_form(?:&|$)/.test( form.getAttribute( 'action' ) || '' );
	}

	// The designer's message for this form: inside it, else beside it.
	function message( form, ok ) {
		var selector = ok ? '[data-kerf-form-success]' : '[data-kerf-form-error]';
		return form.querySelector( selector ) || ( form.parentNode ? form.parentNode.querySelector( selector ) : null );
	}

	function show( el ) {
		el.hidden = false;
		el.removeAttribute( 'hidden' );
		if ( 'none' === window.getComputedStyle( el ).display ) {
			el.style.display = 'block';
		}
	}

	/**
	 * @param {Element} form
	 * @param {boolean} ok
	 * @param {string}  text   The server's words.
	 * @param {boolean} reason They name what to change (a file too large), which
	 *                         the designer's own error message cannot know.
	 */
	function answer( form, ok, text, reason ) {
		var mine = message( form, ok );
		var other = message( form, ! ok );
		var existing = form.nextElementSibling && form.nextElementSibling.hasAttribute( 'data-kerf-form-note' )
			? form.nextElementSibling
			: null;
		if ( other ) {
			other.hidden = true;
		}
		if ( mine ) {
			show( mine );
		}
		if ( ! mine || ( reason && text ) ) {
			// The design drew no message for this, or the reason is the
			// visitor's to act on: a plain line after the form.
			var note = existing || form.parentNode.insertBefore( document.createElement( 'p' ), form.nextSibling );
			note.setAttribute( 'data-kerf-form-note', '' );
			note.setAttribute( 'role', 'status' );
			note.textContent = text;
		} else if ( existing ) {
			existing.parentNode.removeChild( existing );
		}
		if ( ok ) {
			form.reset();
		}
	}

	document.addEventListener( 'submit', function ( event ) {
		var form = event.target;
		if ( ! isKerfForm( form ) || ! window.fetch || ! window.FormData ) {
			return;
		}
		event.preventDefault();

		var button = form.querySelector( 'button[type="submit"], button:not([type]), input[type="submit"]' );
		if ( button ) {
			button.disabled = true;
		}

		var data = new window.FormData( form );
		data.append( 'kerf_js', '1' );

		window.fetch( form.getAttribute( 'action' ), {
			method: 'POST',
			body: data,
			credentials: 'same-origin',
			headers: { Accept: 'application/json' }
		} ).then( function ( response ) {
			return response.json();
		} ).then( function ( result ) {
			answer( form, !! ( result && result.ok ), ( result && result.message ) || '', !! ( result && result.reason ) );
		} ).catch( function () {
			answer( form, false, 'Sorry, that did not send. Please try again.' );
		} ).then( function () {
			if ( button ) {
				button.disabled = false;
			}
		} );
	}, true );
}() );
