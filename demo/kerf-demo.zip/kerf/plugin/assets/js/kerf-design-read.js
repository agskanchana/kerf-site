/**
 * Read a page the way a visitor sees it, for its editor.
 *
 * The editor gets a design's stylesheets, never its scripts (§5.16), so what
 * scripts make — the CSS a browser build of Tailwind writes, icons Lucide or
 * Feather draw — was missing there. After an import the page is loaded in a
 * same-origin frame from wp-admin and that is copied (capture()), for the
 * editor (inc/kerf-capture.php); the page itself is unchanged.
 *
 * read() loads the frame. An add-on may give `window.kerfDesignRead` a
 * `measure( doc, win )`: Kerf Pro measures the home page's fonts and colours
 * for the blog and the other undrawn pages (its kerf-design-measure.js), in
 * the same reading.
 *
 * The small pure functions below are named on purpose: tests/js/design-read
 * .test.js lifts them out of this file by name.
 *
 * @package kerf
 */

( function () {
	'use strict';

	/**
	 * Is this a stylesheet a browser build of Tailwind wrote? v4 says so in a
	 * banner; v3's Play CDN has none and opens on its `--tw-` variables.
	 *
	 * @param {string} text
	 * @return {boolean}
	 */
	function isGeneratedCss( text ) {
		var head = String( text || '' ).slice( 0, 400 );
		// \x7b is an opening brace: a literal one here unbalanced the test harness's extraction.
		return /^\s*\/\*!?\s*!?\s*tailwindcss v\d/i.test( head ) || /^\s*\*,\s*::before,\s*::after\s*\x7b\s*--tw-/.test( head );
	}

	/**
	 * Words that may be classes: every class on the page, and the quoted
	 * strings in its Alpine/Vue bindings and its scripts — `:class="open ?
	 * 'rotate-180' : ''"` only puts that class on the page after a click, so
	 * Tailwind never made its CSS for a page that was only loaded.
	 *
	 * @param {string} text
	 * @param {Object} into Set-like object.
	 */
	function classWords( text, into ) {
		String( text || '' ).split( /[\s"'`,;{}()]+/ ).forEach( function ( word ) {
			if ( word.length > 1 && word.length < 80 && /[a-z]/i.test( word ) && /^[!-]?[a-z0-9@:[\]\-/_.%#=]+$/i.test( word ) ) {
				into[ word ] = true;
			}
		} );
	}

	/**
	 * An icon a script drew, as a standalone SVG: no class, style or size of its
	 * own — the editor sizes and colours it as the page's element.
	 *
	 * @param {Element} svg
	 * @return {string}
	 */
	function iconMarkup( svg ) {
		var copy = svg.cloneNode( true );
		[ 'class', 'style', 'width', 'height', 'data-lucide', 'aria-hidden', 'tabindex' ].forEach( function ( name ) {
			copy.removeAttribute( name );
		} );
		copy.setAttribute( 'xmlns', 'http://www.w3.org/2000/svg' );
		var markup = new window.XMLSerializer().serializeToString( copy );
		return markup.length < 6000 ? markup : '';
	}

	/**
	 * What scripts made in the page that the editor cannot make itself: the CSS
	 * a browser build of Tailwind generated, and icons Lucide or Feather drew.
	 * The editor gets the page's stylesheets, never its scripts — a Tailwind
	 * design was unstyled there, and every script-drawn icon blank.
	 *
	 * Tailwind is first asked for every class the design may use, by putting
	 * them on a hidden element it watches; then its output is copied.
	 *
	 * @param {Document} doc
	 * @param {Window}   win
	 * @return {Promise<{css:string,icons:Object}>}
	 */
	function capture( doc, win ) {
		function generated() {
			var css = '';
			Array.prototype.forEach.call( doc.querySelectorAll( 'style' ), function ( style ) {
				if ( isGeneratedCss( style.textContent ) ) {
					css += style.textContent + '\n';
				}
			} );
			return css;
		}

		function icons() {
			var found = {};
			Array.prototype.forEach.call( doc.querySelectorAll( 'svg[data-lucide]' ), function ( svg ) {
				var name = 'lucide:' + svg.getAttribute( 'data-lucide' );
				if ( ! found[ name ] ) {
					found[ name ] = iconMarkup( svg );
				}
			} );
			Array.prototype.forEach.call( doc.querySelectorAll( 'svg.feather' ), function ( svg ) {
				var match = ( svg.getAttribute( 'class' ) || '' ).match( /\bfeather-([a-z0-9-]+)/ );
				if ( match && ! found[ 'feather:' + match[ 1 ] ] ) {
					found[ 'feather:' + match[ 1 ] ] = iconMarkup( svg );
				}
			} );
			return found;
		}

		return new Promise( function ( resolve ) {
			if ( ! generated() ) {
				resolve( { css: '', icons: icons() } );
				return;
			}

			var words = {};
			Array.prototype.forEach.call( doc.querySelectorAll( '*' ), function ( element ) {
				Array.prototype.forEach.call( element.attributes, function ( attribute ) {
					if ( 'class' === attribute.name || /^(?:[:@#]|x-|v-)/.test( attribute.name ) ) {
						classWords( attribute.value, words );
					}
				} );
			} );
			Array.prototype.forEach.call( doc.querySelectorAll( 'script:not([src])' ), function ( script ) {
				classWords( script.textContent, words );
			} );

			var probe = doc.createElement( 'div' );
			probe.hidden = true;
			probe.className = Object.keys( words ).join( ' ' );
			doc.body.appendChild( probe );

			// Tailwind writes on the next tick of its observer.
			win.setTimeout( function () {
				var css = generated();
				probe.parentNode.removeChild( probe );
				resolve( { css: css, icons: icons() } );
			}, 700 );
		} );
	}

	/**
	 * Load a page in a hidden same-origin frame and read it: what its scripts
	 * made (`captured`), and — when an add-on gave this object a `measure`, as
	 * Kerf Pro does — the page measured, beside it.
	 *
	 * @param {string} url
	 * @return {Promise<Object>}
	 */
	function read( url ) {
		return new Promise( function ( resolve, reject ) {
			var frame = document.createElement( 'iframe' );
			frame.setAttribute( 'aria-hidden', 'true' );
			frame.tabIndex = -1;
			frame.style.cssText = 'position:fixed;left:-20000px;top:0;width:1440px;height:900px;border:0;opacity:0;pointer-events:none;';

			var done = false;
			function finish( fn, value ) {
				if ( done ) {
					return;
				}
				done = true;
				window.clearTimeout( timeout );
				if ( frame.parentNode ) {
					frame.parentNode.removeChild( frame );
				}
				fn( value );
			}
			var timeout = window.setTimeout( function () {
				finish( reject, new Error( 'The page took too long to load.' ) );
			}, 30000 );

			frame.addEventListener( 'load', function () {
				var win = frame.contentWindow;
				var doc = frame.contentDocument;
				if ( ! doc || ! doc.body ) {
					finish( reject, new Error( 'The page could not be read.' ) );
					return;
				}
				var fonts = doc.fonts && doc.fonts.ready ? doc.fonts.ready : Promise.resolve();
				Promise.race( [ fonts, new Promise( function ( r ) {
					window.setTimeout( r, 6000 );
				} ) ] ).then( function () {
					// Give sliders and entrance scripts a moment to lay out.
					window.setTimeout( function () {
						var measurement = {};
						var api = window.kerfDesignRead;
						if ( api && 'function' === typeof api.measure ) {
							try {
								measurement = api.measure( doc, win );
							} catch ( error ) {
								finish( reject, error );
								return;
							}
						}
						// And what the editor cannot make itself: Tailwind's CSS,
						// script-drawn icons (saved apart from the measurement).
						capture( doc, win ).then( function ( captured ) {
							measurement.captured = captured;
							finish( resolve, measurement );
						}, function () {
							finish( resolve, measurement );
						} );
					}, 800 );
				} );
			} );

			frame.src = url;
			document.body.appendChild( frame );
		} );
	}

	window.kerfDesignRead = {
		read: read,
		capture: capture,
		helpers: {
			isGeneratedCss: isGeneratedCss,
			classWords: classWords
		}
	};
}() );
