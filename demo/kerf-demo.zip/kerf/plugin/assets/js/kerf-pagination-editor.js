/**
 * kerf/pagination — the designer's page links, previewed with three pages.
 *
 * Drawn from the same recorded shape the front end uses
 * (kerf_render_pagination_block()), so the canvas shows the mockup's own
 * pagination styling rather than a placeholder.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;

	function classes( spec, current ) {
		var list = spec && spec.class ? spec.class : '';
		if ( current && spec && spec.currentClass ) {
			list = ( list + ' ' + spec.currentClass ).trim();
		}
		return list || undefined;
	}

	function item( pattern, label, current, key ) {
		var wrap = pattern.wrap || null;
		var link = pattern.link || { tag: 'a' };
		var tag = current && 'span' === link.currentTag ? 'span' : 'a';
		var inner = [];

		if ( label.icon ) {
			inner.push( el( 'i', { key: 'i', className: label.icon } ) );
		}
		if ( label.text ) {
			inner.push( label.text );
		}

		var node = el( tag, {
			key: wrap ? undefined : key,
			className: classes( link, current ),
			href: 'a' === tag ? '#' : undefined,
			onClick: function ( event ) {
				event.preventDefault();
			}
		}, inner );

		return wrap ? el( wrap.tag || 'li', { key: key, className: classes( wrap, current ) }, node ) : node;
	}

	wp.blocks.registerBlockType( 'kerf/pagination', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var pattern = attributes.item || {};
			var blockProps = wp.blockEditor.useBlockProps( { style: { display: 'contents' } } );
			var items = [];

			if ( attributes.prev && ( attributes.prev.text || attributes.prev.icon ) ) {
				items.push( item( pattern, attributes.prev, false, 'prev' ) );
			}
			[ '1', '2', '3' ].forEach( function ( n ) {
				items.push( item( pattern, { text: n }, '1' === n, 'p' + n ) );
			} );
			if ( attributes.next && ( attributes.next.text || attributes.next.icon ) ) {
				items.push( item( pattern, attributes.next, false, 'next' ) );
			}

			return el( 'div', blockProps, el( Fragment, null, items ) );
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
