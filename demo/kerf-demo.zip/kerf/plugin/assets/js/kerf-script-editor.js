/**
 * kerf/script — a mockup script that writes into the page where it stands.
 *
 * Nothing to edit, deliberately. The block holds only a reference; the code is
 * kept with the imported assets, which only an administrator can change. In
 * the editor it cannot run (a `document.write` there would write into the
 * editor), so it shows as a marker: removable and movable like any block, but
 * never a place to type script.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var useBlockProps = wp.blockEditor.useBlockProps;

	wp.blocks.registerBlockType( 'kerf/script', {
		edit: function () {
			var blockProps = useBlockProps( { className: 'kerf-void-marker' } );

			return el( 'span', Object.assign( {}, blockProps, {
				title: __( 'Runs on the page, where your mockup put it. Its code is kept with the imported assets.', 'kerf-blocks' )
			} ), '<script>' );
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
