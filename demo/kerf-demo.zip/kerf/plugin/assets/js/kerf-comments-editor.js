/**
 * kerf/comments — where the post's comments go, in the designer's comments
 * area. A marker in the editor: the comments themselves belong to each post.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var __ = wp.i18n.__;

	wp.blocks.registerBlockType( 'kerf/comments', {
		edit: function ( props ) {
			var blockProps = wp.blockEditor.useBlockProps( { className: 'kerf-post-content-marker' } );

			return el( props.attributes.items ? 'li' : 'div', blockProps,
				el( 'p', null, props.attributes.form
					? __( 'The post\'s comments appear here, followed by WordPress\'s comment form.', 'kerf-blocks' )
					: __( 'The post\'s comments appear here. Your mockup\'s own form takes new ones.', 'kerf-blocks' )
				)
			);
		},

		save: function () {
			return null;
		}
	} );
}( window.wp ) );
