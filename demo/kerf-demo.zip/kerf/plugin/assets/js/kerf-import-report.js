/**
 * After an import: read the page the import made for its editor.
 *
 * Every `.kerf-capture-after-import` item in the import's report is a page to
 * read (kerf-design-read.js): the home page after an import for the whole
 * site, a page of its own after one for it (Kerf Pro). What its scripts made
 * is saved for its editor (inc/kerf-capture.php), and the item says how that
 * went. What was read is also announced — `kerf-page-read` on the document,
 * { page, url, result } or { page, failed } — for whoever else wants it: Kerf
 * Pro keeps the home page's measurement from the same reading.
 *
 * @package kerf
 */

( function () {
	'use strict';

	function announce( detail ) {
		document.dispatchEvent( new window.CustomEvent( 'kerf-page-read', { detail: detail } ) );
	}

	Array.prototype.forEach.call( document.querySelectorAll( '.kerf-capture-after-import' ), function ( item ) {
		var page = parseInt( item.getAttribute( 'data-page' ), 10 ) || 0;
		var url = item.getAttribute( 'data-url' );
		if ( ! window.kerfDesignRead || ! window.wp || ! window.wp.apiFetch ) {
			item.textContent = item.getAttribute( 'data-failed' );
			announce( { page: page, url: url, failed: true } );
			return;
		}
		window.kerfDesignRead.read( url ).then( function ( result ) {
			var captured = result.captured || { css: '', icons: {} };
			delete result.captured;
			captured.page = page;
			announce( { page: page, url: url, result: result } );
			return window.wp.apiFetch( { path: '/kerf/v1/captured', method: 'POST', data: captured } );
		} ).then( function () {
			item.textContent = item.getAttribute( 'data-done' );
		} ).catch( function () {
			item.textContent = item.getAttribute( 'data-failed' );
			announce( { page: page, url: url, failed: true } );
		} );
	} );
}() );
