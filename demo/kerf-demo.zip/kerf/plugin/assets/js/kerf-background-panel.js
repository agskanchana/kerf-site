/**
 * The Background picture panel (§5.41, inc/kerf-backgrounds.php).
 *
 * A design puts a background photo in one of three places: the element's own
 * `style`, an attribute a script reads (`data-setbg`), or — most often — its
 * stylesheet, which nothing in WordPress could reach. This panel lists every
 * picture the selected element shows, wherever it comes from, as the BROWSER
 * draws it: the canvas holds the design's CSS, so the computed style and the
 * rules that match the element are read here rather than guessed from files.
 *
 * A picture from the stylesheet changes in one of two ways:
 *
 *   only here    a `background-image` added to the block's own style — the
 *                designer's value with just the photo swapped, so a darkening
 *                gradient over it stays — and `kerfBg` recording what it
 *                replaced, for Reset and for Update from mockup.
 *   everywhere   a rule stored apart from the stylesheet (REST, kerf/v1/
 *                backgrounds) and printed after it with the designer's own
 *                selector. Only for someone who may change the theme, and
 *                Kerf Pro's: its action arrives through the
 *                `kerf.backgroundPanel.rule` filter below. What it changed is
 *                drawn here, and put back to the design's picture, without it.
 *
 * A picture on a ::before/::after layer, or one for other screen sizes, can
 * only change everywhere: a style attribute reaches neither.
 *
 * Or the picture can be each page's featured image (Kerf Pro's action again,
 * here as everywhere): a stylesheet's, through a stored rule marked
 * `featured`, drawn in the canvas with the edited page's picture
 * (featuredUrl()); the element's own, by binding its style to the post's
 * image, or marking it for its script (`image`). Shown here, and put back to
 * the design's picture here, without Pro.
 *
 * In client mode (kerf-client-mode.js) an element showing a picture is opened
 * for this panel alone, so a client can change a photo and nothing else.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var MediaUpload = wp.blockEditor.MediaUpload;
	var MediaUploadCheck = wp.blockEditor.MediaUploadCheck;
	var PanelBody = wp.components.PanelBody;
	var Button = wp.components.Button;
	var ToggleControl = wp.components.ToggleControl;

	var data = window.kerfBackgrounds || {};
	var rules = data.rules || {};

	var BLOCKS = [ 'kerf/div', 'kerf/text', 'kerf/link' ];
	// What a design's script reads a background from — kerf-canvas.js's
	// BACKGROUND_ATTRS; keep the two in step.
	var ATTRS = [ 'data-setbg', 'data-background', 'data-bg', 'data-bg-image', 'data-background-image', 'data-bgimage', 'data-image-src' ];
	var PSEUDOS = [ '', '::before', '::after' ];
	var LIVE_ID = 'kerf-bg-live';
	// Kerf's own canvas sheets, which are not the design's.
	var OWN_SHEETS = /^kerf-(?:canvas|bg-live)/;

	// The pure helpers (kerf-background-core.js).
	var core = window.kerfBackgroundCore;
	var splitTopLevel = core.splitTopLevel;
	var layerUrl = core.layerUrl;
	var swapLayer = core.swapLayer;
	var designSelector = core.designSelector;
	var pseudoOf = core.pseudoOf;
	var withoutPseudo = core.withoutPseudo;
	var specificity = core.specificity;
	var weighsAtLeast = core.weighsAtLeast;
	var designPath = core.designPath;
	var addDecl = core.addDecl;
	var removeDecl = core.removeDecl;
	var rulesCss = core.rulesCss;

	// ── The canvas ──────────────────────────────────────────────────────────

	/**
	 * The documents blocks are drawn in: the editor canvas, or the editor itself
	 * where it has no iframe.
	 *
	 * @return {Document[]}
	 */
	function canvasDocuments() {
		var docs = [];
		Array.prototype.forEach.call( document.querySelectorAll( 'iframe[name="editor-canvas"]' ), function ( frame ) {
			try {
				if ( frame.contentDocument ) {
					docs.push( frame.contentDocument );
				}
			} catch ( e ) {
				// Not ours to read.
			}
		} );
		return docs.length ? docs : [ document ];
	}

	/**
	 * The block's element in the canvas: for a Kerf block, the element is the
	 * block (§4).
	 *
	 * @param {string} clientId
	 * @return {Element|null}
	 */
	function canvasElement( clientId ) {
		var docs = canvasDocuments();
		for ( var i = 0; i < docs.length; i++ ) {
			var node = docs[ i ].querySelector( '[data-block="' + clientId + '"]' );
			if ( node ) {
				return node;
			}
		}
		return null;
	}

	/**
	 * The featured image of the page or post being edited: what a rule for
	 * "each page's featured image" draws here. '' in a template, or with none.
	 *
	 * @return {string}
	 */
	function featuredUrl() {
		var editor = wp.data.select( 'core/editor' );
		var id = editor && editor.getEditedPostAttribute ? editor.getEditedPostAttribute( 'featured_media' ) : 0;
		if ( ! id ) {
			return '';
		}
		var media = wp.data.select( 'core' ).getEntityRecord( 'postType', 'attachment', id );
		return media && media.source_url ? media.source_url : '';
	}

	/**
	 * Is this element's own picture the page's featured image — bound in its
	 * style, or marked for its script (`data-kerf-field="image"`)?
	 *
	 * @param {Object} attributes
	 * @param {string} kind 'style' or 'attr'.
	 * @return {boolean}
	 */
	function followsFeatured( attributes, kind ) {
		if ( 'style' === kind ) {
			var bound = attributes.metadata && attributes.metadata.bindings && attributes.metadata.bindings.backgroundImage;
			return !! ( bound && 'kerf/post' === bound.source && bound.args && 'image' === bound.args.key );
		}
		var fields = ' ' + ( attributes.kerfFields || '' ) + ' ' + ( ( attributes.customAttributes || {} )[ 'data-kerf-field' ] || '' ) + ' ';
		return /\simage\s/.test( fields );
	}

	/**
	 * The attributes that stop an element following the featured image: the
	 * binding taken out of its metadata, or `image` out of its markers.
	 *
	 * @param {Object} attributes
	 * @param {string} kind
	 * @return {Object}
	 */
	function unfollow( attributes, kind ) {
		if ( 'style' === kind ) {
			var metadata = Object.assign( {}, attributes.metadata || {} );
			var bindings = Object.assign( {}, metadata.bindings || {} );
			delete bindings.backgroundImage;
			delete bindings.backgroundImageId;
			if ( Object.keys( bindings ).length ) {
				metadata.bindings = bindings;
			} else {
				delete metadata.bindings;
			}
			return { metadata: metadata };
		}
		var drop = function ( value ) {
			return String( value || '' ).split( /\s+/ ).filter( function ( word ) {
				return word && 'image' !== word;
			} ).join( ' ' );
		};
		var custom = Object.assign( {}, attributes.customAttributes || {} );
		if ( undefined !== custom[ 'data-kerf-field' ] ) {
			var left = drop( custom[ 'data-kerf-field' ] );
			if ( left ) {
				custom[ 'data-kerf-field' ] = left;
			} else {
				delete custom[ 'data-kerf-field' ];
			}
		}
		return { kerfFields: drop( attributes.kerfFields ), customAttributes: custom };
	}

	/**
	 * Keep the "everywhere" changes drawn in every canvas, as the page draws
	 * them: after the design's sheets.
	 */
	function paintRules() {
		var featured = featuredUrl();
		var stored = rulesCss( rules, featured );
		canvasDocuments().forEach( function ( doc ) {
			var css = stored + markedCss( doc, featured );
			var style = doc.getElementById( LIVE_ID );
			if ( ! style ) {
				if ( ! css ) {
					return;
				}
				style = doc.createElement( 'style' );
				style.id = LIVE_ID;
			}
			// After the design's sheets, which the editor puts in the canvas's
			// <body>, not its <head>: first in the head, an "everywhere" change
			// lost to the very rule it replaces. Kept last as the editor adds
			// sheets.
			var parent = doc.body || doc.documentElement;
			var sheets = parent.querySelectorAll( 'style, link[rel="stylesheet"]' );
			if ( sheets[ sheets.length - 1 ] !== style ) {
				parent.appendChild( style );
			}
			if ( style.textContent !== css ) {
				style.textContent = css;
			}
		} );
	}

	/**
	 * In one canvas, the elements the design marked for the featured image
	 * (`data-kerf-field="image"`) whose picture its stylesheet draws: each
	 * layer's winning rule with the page's picture in the photo's place, for
	 * that block alone — what kerf_bg_mark() prints on the page. A card in a
	 * loop shows its own post, and is left to the loop.
	 *
	 * @param {Document} doc
	 * @param {string}   featured
	 * @return {string}
	 */
	function markedCss( doc, featured ) {
		if ( ! featured ) {
			return '';
		}
		var css = '';
		Array.prototype.forEach.call( doc.querySelectorAll( '[data-kerf-field][data-block]' ), function ( node ) {
			if ( ! /(?:^|\s)image(?:\s|$)/.test( node.getAttribute( 'data-kerf-field' ) || '' ) || node.closest( '[data-type="kerf/loop"]' ) ) {
				return;
			}
			var all = matchingRules( node );
			PSEUDOS.forEach( function ( pseudo ) {
				var now = winner( all.filter( function ( rule ) {
					return rule.pseudo === pseudo && rule.active;
				} ) );
				if ( ! now ) {
					return;
				}
				var layers = splitTopLevel( now.value );
				var photo = -1;
				layers.forEach( function ( layer, index ) {
					if ( layerUrl( layer ) ) {
						photo = index;
					}
				} );
				if ( photo < 0 ) {
					return;
				}
				css += '[data-block="' + node.getAttribute( 'data-block' ) + '"]' + pseudo
					+ '{background-image:' + swapLayer( now.value, photo, featured ) + ( now.important ? ' !important' : '' ) + '}';
			} );
		} );
		return css;
	}

	/**
	 * Every design rule that draws a picture on this element (or its ::before /
	 * ::after), in any screen size: selector part, media, value, weight, order.
	 *
	 * @param {Element} node
	 * @return {Object[]}
	 */
	function matchingRules( node ) {
		var found = [];
		var order = 0;
		var doc = node.ownerDocument;
		var win = doc.defaultView;

		function walk( list, media ) {
			Array.prototype.forEach.call( list || [], function ( rule ) {
				order++;
				if ( rule.cssRules && ! rule.selectorText ) {
					var condition = rule.media && rule.media.mediaText ? rule.media.mediaText : '';
					walk( rule.cssRules, condition ? media.concat( condition ) : media );
					return;
				}
				if ( ! rule.selectorText || ! rule.style ) {
					return;
				}
				var value = rule.style.getPropertyValue( 'background-image' );
				if ( ! value || -1 === value.indexOf( 'url(' ) || /data-kerf-hover/.test( rule.selectorText ) ) {
					return;
				}
				splitTopLevel( rule.selectorText ).forEach( function ( part ) {
					// A picture shown only on hover or focus is a state, not the
					// element's background.
					if ( /:(?:hover|focus|active|focus-within|focus-visible)\b/.test( part ) ) {
						return;
					}
					var matches = false;
					try {
						matches = node.matches( withoutPseudo( part ) );
					} catch ( e ) {
						matches = false;
					}
					if ( ! matches ) {
						return;
					}
					var mediaText = media.join( ' and ' );
					found.push( {
						selector: designSelector( part ),
						pseudo: pseudoOf( part ),
						media: mediaText,
						active: ! mediaText || win.matchMedia( mediaText ).matches,
						value: value,
						important: 'important' === rule.style.getPropertyPriority( 'background-image' ),
						weight: specificity( part ),
						order: order
					} );
				} );
			} );
		}

		Array.prototype.forEach.call( doc.styleSheets, function ( sheet ) {
			var owner = sheet.ownerNode;
			if ( owner && owner.id && OWN_SHEETS.test( owner.id ) ) {
				return;
			}
			try {
				walk( sheet.cssRules, [] );
			} catch ( e ) {
				// A cross-origin sheet (a CDN): its rules are not readable here.
			}
		} );
		return found;
	}

	/**
	 * The rule that wins among those for one layer and one screen size: the
	 * heaviest, and of equal weight the last.
	 *
	 * @param {Object[]} list
	 * @return {Object|null}
	 */
	function winner( list ) {
		var best = null;
		list.forEach( function ( rule ) {
			if ( ! best || ( weighsAtLeast( rule.weight, best.weight ) && ( rule.order > best.order || ! weighsAtLeast( best.weight, rule.weight ) ) ) ) {
				best = rule;
			}
		} );
		return best;
	}

	/**
	 * Every picture the element shows, wherever it comes from.
	 *
	 * @param {Object}       attributes
	 * @param {Element|null} node
	 * @return {Object[]}
	 */
	function pictures( attributes, node ) {
		var items = [];
		var custom = attributes.customAttributes || {};

		// 1. In the element's own style (the converter's handle).
		if ( attributes.backgroundImage ) {
			items.push( { kind: 'style', url: attributes.backgroundImage } );
		}

		// 2. In an attribute the design's script reads.
		ATTRS.forEach( function ( name ) {
			var value = custom[ name ];
			if ( value && /\.(?:jpe?g|png|gif|webp|avif|svg)(?:[?#].*)?$/i.test( String( value ) ) ) {
				items.push( { kind: 'attr', name: name, url: String( value ) } );
			}
		} );

		if ( ! node ) {
			return items;
		}

		// 3. In the design's stylesheet: per layer of the element, the rule
		// that wins now, each url in it — and the ones for other screen sizes.
		var all = matchingRules( node );
		PSEUDOS.forEach( function ( pseudo ) {
			var mine = all.filter( function ( rule ) {
				return rule.pseudo === pseudo;
			} );
			var now = winner( mine.filter( function ( rule ) {
				return rule.active;
			} ) );
			var others = {};
			mine.forEach( function ( rule ) {
				if ( rule !== now && rule.media && ! rule.active ) {
					others[ rule.media ] = winner( ( others[ rule.media ] ? [ others[ rule.media ] ] : [] ).concat( rule ) );
				}
			} );

			[ now ].concat( Object.keys( others ).map( function ( media ) {
				return others[ media ];
			} ) ).forEach( function ( rule ) {
				if ( ! rule ) {
					return;
				}
				splitTopLevel( rule.value ).forEach( function ( layer, index ) {
					var url = layerUrl( layer );
					// The element's own style draws over any stylesheet picture
					// on the element itself, at every size: those are not seen.
					if ( ! url || ( attributes.backgroundImage && ! pseudo ) ) {
						return;
					}
					items.push( {
						kind: 'rule',
						rule: rule,
						layer: index,
						url: url,
						variant: rule !== now,
						key: ruleKey( rule.selector, rule.media )
					} );
				} );
			} );
		} );

		return items;
	}

	/**
	 * A rule's key, as inc/kerf-backgrounds.php keys it.
	 *
	 * @param {string} selector
	 * @param {string} media
	 * @return {string}
	 */
	function ruleKey( selector, media ) {
		return String( selector ).trim() + '|' + String( media || '' ).trim();
	}

	/**
	 * The stored "everywhere" change for a rule's layer, if there is one.
	 *
	 * @param {Object} item
	 * @return {Object|null}
	 */
	function everywhereFor( item ) {
		var found = null;
		Object.keys( rules ).forEach( function ( key ) {
			var rule = rules[ key ];
			if ( ruleKey( rule.selector, rule.media ) === item.key && rule.layer === item.layer ) {
				found = Object.assign( { storeKey: key }, rule );
			}
		} );
		return found;
	}

	/**
	 * Does this block show a background picture? For client mode, which opens
	 * such an element to this panel alone.
	 *
	 * @param {string} clientId
	 * @param {Object} attributes
	 * @return {boolean|null} Null while the canvas has not drawn the element.
	 */
	function hasPicture( clientId, attributes ) {
		if ( attributes.backgroundImage || attributes.kerfBg ) {
			return true;
		}
		var custom = attributes.customAttributes || {};
		if ( ATTRS.some( function ( name ) {
			return !! custom[ name ];
		} ) ) {
			return true;
		}
		var node = canvasElement( clientId );
		if ( ! node ) {
			return null;
		}
		var win = node.ownerDocument.defaultView;
		return PSEUDOS.some( function ( pseudo ) {
			return /url\(/.test( win.getComputedStyle( node, pseudo || null ).backgroundImage || '' );
		} );
	}

	// ── The panel ───────────────────────────────────────────────────────────

	/**
	 * What a script-set picture says about itself.
	 *
	 * @param {string} name The attribute.
	 * @return {string}
	 */
	function scriptSays( name ) {
		/* translators: %s: an attribute name, e.g. data-setbg. */
		return sprintf( __( 'Set by the design\'s script (%s).', 'kerf-blocks' ), name );
	}

	/**
	 * A picture, small.
	 *
	 * @param {string} url
	 * @return {Object}
	 */
	function thumb( url ) {
		return el( 'span', {
			className: 'kerf-bg-thumb',
			role: 'img',
			'aria-label': designPath( url ),
			style: { backgroundImage: 'url("' + String( url ).replace( /"/g, '%22' ) + '")' }
		} );
	}

	/**
	 * A media-library button.
	 *
	 * @param {string}   label
	 * @param {Function} onSelect
	 * @param {string}   variant
	 * @return {Object}
	 */
	function pick( label, onSelect, variant ) {
		return el( MediaUploadCheck, null,
			el( MediaUpload, {
				allowedTypes: [ 'image' ],
				onSelect: onSelect,
				render: function ( uploader ) {
					return el( Button, { variant: variant || 'secondary', onClick: uploader.open }, label );
				}
			} )
		);
	}

	function BackgroundPanel( props ) {
		var attributes = props.attributes;
		var setAttributes = props.setAttributes;
		var full = window.kerf && window.kerf.fullEditing ? window.kerf.fullEditing() : true;
		var tickState = useState( 0 );
		var busyState = useState( '' );

		// The canvas draws after the sidebar: look again once it has.
		useEffect( function () {
			var timer = window.setTimeout( function () {
				tickState[ 1 ]( tickState[ 0 ] + 1 );
			}, 700 );
			return function () {
				window.clearTimeout( timer );
			};
		}, [ props.clientId ] );

		var node = canvasElement( props.clientId );
		var items = pictures( attributes, node );
		var mine = attributes.kerfBg || null;

		if ( ! items.length && ! full ) {
			return null;
		}

		function save( list ) {
			rules = list || {};
			paintRules();
			tickState[ 1 ]( tickState[ 0 ] + 1 );
		}

		function resetEverywhere( stored ) {
			busyState[ 1 ]( __( 'Saving…', 'kerf-blocks' ) );
			wp.apiFetch( {
				path: '/kerf/v1/backgrounds?post=' + ( data.post || 0 ) + '&key=' + encodeURIComponent( stored.storeKey ),
				method: 'DELETE'
			} ).then( function ( response ) {
				busyState[ 1 ]( '' );
				save( response.rules );
			} ).catch( function ( error ) {
				busyState[ 1 ]( ( error && error.message ) || __( 'That background could not be saved.', 'kerf-blocks' ) );
			} );
		}

		function here( item, media ) {
			var value = swapLayer( item.rule.value, item.layer, media.url );
			var decl = 'background-image: ' + value + ( item.rule.important ? ' !important' : '' );
			var style = mine ? removeDecl( attributes.inlineStyle, mine.decl ) : ( attributes.inlineStyle || '' );
			setAttributes( {
				inlineStyle: addDecl( style, decl ),
				kerfBg: {
					decl: decl,
					selector: item.rule.selector,
					media: item.rule.media,
					layer: item.layer,
					// The rule still holds the design's own picture: only the
					// block's style carries the owner's.
					design: designPath( item.url ),
					designUrl: item.url,
					id: media.id,
					url: media.url
				}
			} );
		}

		function resetHere() {
			setAttributes( {
				inlineStyle: removeDecl( attributes.inlineStyle, mine.decl ) || undefined,
				kerfBg: undefined
			} );
		}

		// What else may change the element's own picture: Kerf Pro's "Use this
		// page's featured image" (kerf-background-everywhere.js), through the
		// `kerf.backgroundPanel.element` filter — as `kerf.backgroundPanel.rule`
		// does for a stylesheet's picture.
		function elementMore( item, follows ) {
			var more = wp.hooks.applyFilters( 'kerf.backgroundPanel.element', { actions: [], notes: [] }, {
				item: item,
				follows: follows,
				full: full,
				attributes: attributes,
				setAttributes: setAttributes,
				post: data.post || 0,
				setBusy: busyState[ 1 ]
			} ) || {};
			return {
				actions: Array.isArray( more.actions ) ? more.actions : [],
				notes: Array.isArray( more.notes ) ? more.notes : []
			};
		}

		// Following the featured image, the element says so, and putting the
		// design's picture back stays free: nothing Kerf Pro set is stuck.
		var FOLLOWS = __( 'This page\'s featured image. Where a page has none, the design\'s picture.', 'kerf-blocks' );
		function backFromFeatured( kind ) {
			return full && el( Button, {
				variant: 'tertiary',
				onClick: function () {
					setAttributes( unfollow( attributes, kind ) );
				}
			}, __( 'Back to the design\'s picture', 'kerf-blocks' ) );
		}

		var rows = [];

		items.forEach( function ( item, index ) {
			var key = 'bg-' + index;
			var parts = [];

			if ( 'style' === item.kind ) {
				var styleFollows = followsFeatured( attributes, 'style' );
				var styleMore = elementMore( item, styleFollows );
				parts.push(
					thumb( item.url ),
					el( 'p', { className: 'kerf-help' }, styleFollows ? FOLLOWS : __( 'In this element\'s own style.', 'kerf-blocks' ) ),
					el.apply( null, [ 'div', { className: 'kerf-bg-actions' },
						! styleFollows && pick( __( 'Replace', 'kerf-blocks' ), function ( media ) {
							setAttributes( Object.assign( { backgroundImage: media.url, backgroundImageId: media.id }, swapStyleUrl( attributes, media.url ) ) );
						} ),
						! styleFollows && full && el( Button, {
							isDestructive: true,
							variant: 'tertiary',
							onClick: function () {
								setAttributes( Object.assign( { backgroundImage: '', backgroundImageId: 0 }, swapStyleUrl( attributes, '' ) ) );
							}
						}, __( 'Remove', 'kerf-blocks' ) ),
						styleFollows && backFromFeatured( 'style' )
					].concat( styleMore.actions ) ),
					full && el( ToggleControl, {
						label: __( 'Lazy-load', 'kerf-blocks' ),
						checked: !! attributes.lazyBg,
						onChange: function ( next ) {
							setAttributes( { lazyBg: next } );
						},
						help: __( 'Defers the image until the element scrolls into view.', 'kerf-blocks' ),
						__nextHasNoMarginBottom: true
					} ),
					full && el( ToggleControl, {
						label: __( 'Above the fold', 'kerf-blocks' ),
						checked: !! attributes.preloadBg,
						onChange: function ( next ) {
							setAttributes( { preloadBg: next, lazyBg: next ? false : attributes.lazyBg } );
						},
						help: __( 'Loads immediately. Use for the hero — lazy-loading the first thing a visitor sees costs you the LCP score it was meant to save.', 'kerf-blocks' ),
						__nextHasNoMarginBottom: true
					} )
				);
				parts = parts.concat( styleMore.notes );
			} else if ( 'attr' === item.kind ) {
				var original = mine && 'attr' === mine.kind && mine.name === item.name ? mine.designUrl : '';
				var attrFollows = followsFeatured( attributes, 'attr' );
				var attrMore = elementMore( item, attrFollows );
				parts.push(
					thumb( attrFollows && featuredUrl() ? featuredUrl() : item.url ),
					el( 'p', { className: 'kerf-help' }, attrFollows ? FOLLOWS : ( original ? __( 'Your picture.', 'kerf-blocks' ) : scriptSays( item.name ) ) ),
					el.apply( null, [ 'div', { className: 'kerf-bg-actions' },
						! attrFollows && pick( __( 'Replace', 'kerf-blocks' ), function ( media ) {
							var next = Object.assign( {}, attributes.customAttributes || {} );
							next[ item.name ] = media.url;
							setAttributes( {
								customAttributes: next,
								kerfBg: { kind: 'attr', name: item.name, designUrl: original || item.url, design: designPath( original || item.url ), id: media.id, url: media.url }
							} );
						} ),
						! attrFollows && original && el( Button, {
							variant: 'tertiary',
							onClick: function () {
								var next = Object.assign( {}, attributes.customAttributes || {} );
								next[ item.name ] = original;
								setAttributes( { customAttributes: next, kerfBg: undefined } );
							}
						}, __( 'Back to the design\'s picture', 'kerf-blocks' ) ),
						attrFollows && backFromFeatured( 'attr' )
					].concat( attrMore.actions ) )
				);
				parts = parts.concat( attrMore.notes );
			} else {
				var rule = item.rule;

				// The design marked the element for the featured image: the page
				// shows it in place of this picture (kerf_bg_mark()), and so does
				// the canvas (markedCss()). Nothing else to choose.
				if ( ! item.variant && followsFeatured( attributes, 'attr' ) && ! ( mine && mine.decl ) ) {
					parts.push(
						thumb( featuredUrl() || item.url ),
						el( 'p', { className: 'kerf-help' }, FOLLOWS, rule.pseudo ? el( 'br' ) : null,
							/* translators: %s: ::before or ::after. */
							rule.pseudo ? sprintf( __( 'Drawn on a layer of this element (%s).', 'kerf-blocks' ), rule.pseudo ) : null ),
						el( 'div', { className: 'kerf-bg-actions' }, backFromFeatured( 'attr' ) )
					);
					rows.push( el( 'div', { key: key, className: 'kerf-bg-item' }, parts ) );
					return;
				}

				var stored = everywhereFor( item );
				var isHere = !! ( mine && mine.decl && mine.selector === rule.selector && mine.layer === item.layer && ! rule.pseudo && ! item.variant );
				var canHere = ! rule.pseudo && ! item.variant;
				var shown = isHere ? mine.url : ( stored ? ( stored.featured ? featuredUrl() || item.url : stored.url ) : item.url );

				// What else may change this picture: Kerf Pro's "Replace
				// everywhere" (pro/assets/js/kerf-background-everywhere.js).
				// Elements go in the row of buttons (`actions`) or below it
				// (`notes`); `setRules` takes the stored changes the server
				// answers with and redraws them in the canvas.
				var more = wp.hooks.applyFilters( 'kerf.backgroundPanel.rule', { actions: [], notes: [] }, {
					item: item,
					stored: stored,
					isHere: isHere,
					canHere: canHere,
					post: data.post || 0,
					pick: pick,
					setBusy: busyState[ 1 ],
					setRules: save
				} ) || {};
				var moreActions = Array.isArray( more.actions ) ? more.actions : [];
				var moreNotes = Array.isArray( more.notes ) ? more.notes : [];
				var extended = moreActions.length > 0 || moreNotes.length > 0;

				var where = '';
				if ( item.variant ) {
					/* translators: %s: a media condition, e.g. (max-width: 767px). */
					where = sprintf( __( 'On screens matching %s.', 'kerf-blocks' ), rule.media );
				} else if ( rule.pseudo ) {
					/* translators: %s: ::before or ::after. */
					where = sprintf( __( 'Drawn on a layer of this element (%s).', 'kerf-blocks' ), rule.pseudo );
				}

				/* translators: %s: a CSS selector, e.g. .page-header. */
				var state = sprintf( __( 'From the design\'s style: %s', 'kerf-blocks' ), rule.selector );
				if ( isHere ) {
					state = __( 'Your picture, on this element only.', 'kerf-blocks' );
				} else if ( stored && stored.featured ) {
					state = __( 'Each page\'s featured image, everywhere this style is used. A page without one shows the design\'s picture.', 'kerf-blocks' );
				} else if ( stored ) {
					state = __( 'Your picture, everywhere this style is used.', 'kerf-blocks' );
				}

				// Without Kerf Pro, a picture "here" cannot reach (a layer, another
				// screen size) says who or what can change it.
				var stuck = null;
				if ( ! canHere && ! extended ) {
					stuck = data.canManage
						? __( 'Only a change to the design\'s style reaches this picture: Kerf Pro\'s "Replace everywhere".', 'kerf-blocks' )
						: __( 'This picture is part of a style shared across the site; ask an administrator to change it.', 'kerf-blocks' );
				}

				parts.push(
					thumb( shown ),
					el( 'p', { className: 'kerf-help' }, state, where ? el( 'br' ) : null, where ),
					el.apply( null, [ 'div', { className: 'kerf-bg-actions' },
						canHere && pick( isHere ? __( 'Replace', 'kerf-blocks' ) : __( 'Replace here', 'kerf-blocks' ), function ( media ) {
							here( item, media );
						} ),
						isHere && el( Button, { variant: 'tertiary', onClick: resetHere }, __( 'Back to the design\'s picture', 'kerf-blocks' ) )
					].concat( moreActions, [
						// Putting the design's picture back stays free: a change
						// Kerf Pro made is never stuck.
						data.canManage && stored && ! isHere && el( Button, {
							variant: 'tertiary',
							onClick: function () {
								resetEverywhere( stored );
							}
						}, __( 'Back to the design\'s picture', 'kerf-blocks' ) )
					] ) ),
					stuck && el( 'p', { className: 'kerf-help' }, stuck )
				);
				parts = parts.concat( moreNotes );
			}

			rows.push( el( 'div', { key: key, className: 'kerf-bg-item' }, parts ) );
		} );

		// An element the design gave no picture: one can be added (a design
		// change, so full editing only).
		if ( ! items.length ) {
			rows.push( el( 'div', { key: 'add', className: 'kerf-bg-item' },
				pick( __( 'Choose image', 'kerf-blocks' ), function ( media ) {
					setAttributes( { backgroundImage: media.url, backgroundImageId: media.id } );
				} )
			) );
		}

		return el( InspectorControls, null,
			el( PanelBody, { title: __( 'Background picture', 'kerf-blocks' ), initialOpen: !! items.length, className: 'kerf-bg-panel' },
				rows,
				busyState[ 0 ] && el( 'p', { className: 'kerf-help' }, busyState[ 0 ] )
			)
		);
	}

	/**
	 * Carry a background swap into the inline style that renders it.
	 *
	 * A converted element keeps its background inside `inlineStyle`, exactly as
	 * the mockup wrote it (`background: url(x) center/cover`), and
	 * `backgroundImage` is only the handle the panel works through. Changing the
	 * handle alone would leave the old url rendering, so the url inside the
	 * style is swapped too — for `none` on removal, which keeps a shorthand's
	 * position and size valid.
	 *
	 * @param {Object} attributes Current block attributes.
	 * @param {string} next       New image URL, or '' to remove.
	 * @return {Object} An `inlineStyle` patch, or {} when the style has no url.
	 */
	function swapStyleUrl( attributes, next ) {
		var style = attributes.inlineStyle || '';
		var old = attributes.backgroundImage || '';

		if ( ! old || -1 === style.indexOf( old ) ) {
			return {};
		}

		var pattern = new RegExp( 'url\\(\\s*[\'"]?' + old.replace( /[.*+?^${}()|[\]\\]/g, '\\$&' ) + '[\'"]?\\s*\\)', 'g' );

		return { inlineStyle: style.replace( pattern, next ? 'url(' + next + ')' : 'none' ) };
	}

	wp.hooks.addFilter( 'editor.BlockEdit', 'kerf/background-panel', wp.compose.createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			var relevant = props.isSelected && -1 !== BLOCKS.indexOf( props.name );
			return el( Fragment, null,
				el( BlockEdit, props ),
				relevant ? el( BackgroundPanel, props ) : null
			);
		};
	}, 'withKerfBackgroundPanel' ) );

	// The "everywhere" changes in every canvas, now and whenever the editor
	// builds one (a template opened, the device preview switched).
	var pending = null;
	wp.data.subscribe( function () {
		if ( pending ) {
			return;
		}
		pending = window.setTimeout( function () {
			pending = null;
			paintRules();
		}, 400 );
	} );

	window.kerfBackground = {
		hasPicture: hasPicture,
		pictures: pictures,
		splitTopLevel: splitTopLevel,
		layerUrl: layerUrl,
		swapLayer: swapLayer,
		designSelector: designSelector,
		designPath: designPath,
		addDecl: addDecl,
		removeDecl: removeDecl,
		rulesCss: rulesCss
	};
}( window.wp ) );
