/**
 * Inline style on core blocks — editor side.
 *
 * The converter keeps a mockup's `style` attribute on core/heading and
 * core/paragraph by storing it as an `inlineStyle` key in the block comment
 * (see inc/kerf-core-inline-style.php for why it cannot go on the tag).
 *
 * THIS FILE IS NOT OPTIONAL. Gutenberg discards any block-comment key the
 * CLIENT registration does not declare, and core blocks register themselves
 * client-side from their own bundled block.json — the server-side
 * `register_block_type_args` filter never reaches them. Without the filter
 * below, opening a converted page and pressing Update silently strips every
 * inline style the mockup had on a heading or a paragraph. Nothing errors, and
 * the damage is only visible on the front end afterwards.
 *
 * Three jobs: declare the attribute, show it in the sidebar, preview it on the
 * canvas (the front end applies it through render_block, so without a preview
 * the editor would disagree with the page).
 *
 * Deliberately no save() change — the attribute must NOT reach the saved markup
 * or core's block validation rejects the block as "unexpected content".
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var addFilter = wp.hooks.addFilter;
	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var TextareaControl = wp.components.TextareaControl;
	var createHigherOrderComponent = wp.compose.createHigherOrderComponent;

	var config = window.KerfCoreInlineStyle || {};
	var TARGETS = config.blocks || [ 'core/heading', 'core/paragraph' ];

	/**
	 * @param {string} name Block name.
	 * @return {boolean}
	 */
	function isTarget( name ) {
		return TARGETS.indexOf( name ) !== -1;
	}

	/**
	 * Parse a CSS declaration string into a React style object.
	 *
	 * Custom properties (`--brand`) keep their exact spelling; React passes those
	 * through untouched. Everything else is camelCased, because React rejects
	 * kebab-case keys silently and the preview would just not apply.
	 *
	 * @param {string} value
	 * @return {Object}
	 */
	function parseStyle( value ) {
		var out = {};

		if ( ! value ) {
			return out;
		}

		String( value ).split( ';' ).forEach( function ( part ) {
			part = part.trim();

			var colon = part.indexOf( ':' );
			if ( colon < 1 ) {
				return;
			}

			var key = part.substring( 0, colon ).trim();
			var val = part.substring( colon + 1 ).trim();

			if ( key.indexOf( '--' ) !== 0 ) {
				key = key.replace( /-([a-z])/g, function ( match, letter ) {
					return letter.toUpperCase();
				} );
			}

			out[ key ] = val;
		} );

		return out;
	}

	// 1. Declare the attribute so the editor round-trips it.
	addFilter( 'blocks.registerBlockType', 'kerf/core-inline-style-attribute', function ( settings, name ) {
		if ( ! isTarget( name ) ) {
			return settings;
		}

		// customAttributes too: the mockup's data-aos, data-wow-delay and the
		// rest, which the page puts back at render. Same rule, same reason — an
		// undeclared key is dropped on the next save.
		settings.attributes = Object.assign( {}, settings.attributes, {
			inlineStyle: { type: 'string', default: '' },
			customAttributes: { type: 'object', default: {} },
			// Where a top-level heading came from in the mockup: what an update
			// from a newer version of it finds it by (inc/kerf-sync.php).
			kerfSource: { type: 'object' }
		} );

		return settings;
	} );

	/**
	 * The data-/aria- attributes of a block, for the canvas preview. React
	 * passes these through as written; anything else it would warn about.
	 *
	 * @param {Object} custom
	 * @return {Object}
	 */
	function previewAttributes( custom ) {
		var out = {};
		Object.keys( custom || {} ).forEach( function ( key ) {
			if ( /^(data|aria)-/.test( key ) && 'string' === typeof custom[ key ] ) {
				out[ key ] = custom[ key ];
			}
		} );
		return out;
	}

	// Client mode (kerf-client-mode.js) locks a block to its content. Read from
	// the block's context: WordPress does not pass the mode to editor.BlockEdit
	// filters as a prop, and a gate reading props.blockEditingMode let every
	// panel through. A hook — call it first, unconditionally.
	function fullEditing() {
		return 'default' === ( wp.blockEditor.useBlockEditingMode ? wp.blockEditor.useBlockEditingMode() : 'default' );
	}

	// 2. Expose it in the sidebar, and 3. preview it on the canvas.
	addFilter( 'editor.BlockEdit', 'kerf/core-inline-style-control', createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			var full = fullEditing();
			if ( ! isTarget( props.name ) ) {
				return el( BlockEdit, props );
			}

			var value = props.attributes.inlineStyle || '';

			return el( Fragment, null,
				el( BlockEdit, Object.assign( {}, props, {
					// wrapperProps reaches the block's outer element in the
					// canvas, which is the same element render_block targets.
					wrapperProps: Object.assign( {}, props.wrapperProps, previewAttributes( props.attributes.customAttributes ), {
						style: Object.assign( {}, ( props.wrapperProps || {} ).style, parseStyle( value ) )
					} )
				} ) ),
				// Client mode (kerf-client-mode.js) keeps the words open, the CSS the design's.
				full && el( InspectorControls, null,
					el( PanelBody, { title: __( 'CSS', 'kerf-blocks' ), initialOpen: false },
						el( TextareaControl, {
							label: __( 'Inline style', 'kerf-blocks' ),
							value: value,
							onChange: function ( next ) {
								props.setAttributes( { inlineStyle: next } );
							},
							rows: 3,
							help: __( 'Carried over from your mockup\'s style attribute. Core blocks cannot hold one on the tag, so Kerf applies it when the page renders.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} )
					)
				)
			);
		};
	}, 'kerfCoreInlineStyle' ) );
}( window.wp ) );
