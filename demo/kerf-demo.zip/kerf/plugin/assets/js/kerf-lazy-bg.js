/**
 * Lazy background images.
 *
 * Elements carrying `.kerf-lazy-bg` hold their image URL in `data-bg` and get it
 * promoted to a real `background-image` when they approach the viewport. Inlined
 * only on pages that actually contain one, so a page without lazy backgrounds
 * ships none of this.
 *
 * @package kerf
 */

( function () {
	'use strict';

	var SELECTOR = '.kerf-lazy-bg[data-bg]';

	/**
	 * Apply an element's data-bg as its background image.
	 *
	 * @param {Element} node
	 */
	function reveal( node ) {
		var url = node.getAttribute( 'data-bg' );
		if ( ! url ) {
			return;
		}

		node.style.backgroundImage = 'url("' + url.replace( /"/g, '\\"' ) + '")';
		node.removeAttribute( 'data-bg' );
		node.classList.remove( 'kerf-lazy-bg' );
	}

	function init() {
		var nodes = document.querySelectorAll( SELECTOR );
		if ( ! nodes.length ) {
			return;
		}

		// No IntersectionObserver: show everything immediately. A missing
		// background is a broken design; an eagerly loaded one is only slower.
		if ( typeof window.IntersectionObserver !== 'function' ) {
			Array.prototype.forEach.call( nodes, reveal );
			return;
		}

		var observer = new window.IntersectionObserver( function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					reveal( entry.target );
					observer.unobserve( entry.target );
				}
			} );
		}, {
			// Start loading before the element is on screen, so the image has
			// landed by the time it scrolls into view. A background that visibly
			// pops in looks worse than one that was never deferred.
			rootMargin: '200px 0px'
		} );

		Array.prototype.forEach.call( nodes, function ( node ) {
			observer.observe( node );
		} );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
