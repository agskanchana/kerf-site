/**
 * The editor reads its design when the import's report never did.
 *
 * A design styled by a script (Tailwind's browser build) or with icons a
 * script draws gets that CSS in the editor from a reading of its page made
 * after the import (inc/kerf-capture.php, §5.37). An import that never showed
 * its report — the command line, REST, a tab closed too soon — left the
 * editor unstyled. Loaded only then (kerf_capture_editor_fallback()): the page
 * is read in a hidden frame, as the report reads it (kerf-design-read.js), the
 * result saved, and the CSS the save answers with is put in the canvas at
 * once — and kept there while the canvas is remounted, until the next load
 * of the editor brings it as one of its own styles.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var data = window.KerfCaptureEditor;
	// An attribute, not an id: kerf-canvas.js holds the hover rules of every
	// sheet without one, and Tailwind's `hover:` classes are this one's.
	var MARK = 'data-kerf-captured';
	var css = '';

	if ( ! data || ! data.url || ! window.kerfDesignRead || ! wp || ! wp.apiFetch ) {
		return;
	}

	function apply() {
		Array.prototype.forEach.call( document.querySelectorAll( 'iframe[name="editor-canvas"]' ), function ( frame ) {
			var doc;
			try {
				doc = frame.contentDocument;
			} catch ( error ) {
				return;
			}
			if ( ! doc || ! doc.body ) {
				return;
			}
			var style = doc.querySelector( 'style[' + MARK + ']' );
			if ( ! style ) {
				style = doc.createElement( 'style' );
				style.setAttribute( MARK, '' );
				// Last in the body, where the editor puts the design's own
				// sheets (scar 89): after them, as the script's CSS is on the page.
				doc.body.appendChild( style );
			}
			if ( style.textContent !== css ) {
				style.textContent = css;
			}
		} );
	}

	/**
	 * The page read from its HTML in a `srcdoc` frame.
	 *
	 * WordPress 7.1 isolates the editor's document (Document-Isolation-Policy,
	 * for its media processing, in Chromium 137 and later): a frame loading
	 * the page by its address is then another agent's, and reading it throws
	 * (kerfDesignRead.read() answers "could not be read"). A frame made from
	 * the page's own HTML belongs to the editor's document — the editor's own
	 * canvas is made that way — so the page is fetched, given its address as
	 * its `<base>`, and its scripts run there as on the page.
	 *
	 * @param {string} url
	 * @return {Promise<Object>} What kerfDesignRead.capture() answers.
	 */
	function readHtml( url ) {
		return window.fetch( url, { credentials: 'same-origin' } ).then( function ( response ) {
			if ( ! response.ok ) {
				throw new Error( 'The page could not be read.' );
			}
			return response.text();
		} ).then( function ( html ) {
			return new Promise( function ( resolve, reject ) {
				var frame = document.createElement( 'iframe' );
				var base = '<base href="' + String( url ).replace( /&/g, '&amp;' ).replace( /"/g, '&quot;' ) + '">';
				var timeout = window.setTimeout( function () {
					finish( reject, new Error( 'The page took too long to load.' ) );
				}, 30000 );

				function finish( fn, value ) {
					window.clearTimeout( timeout );
					if ( frame.parentNode ) {
						frame.parentNode.removeChild( frame );
					}
					fn( value );
				}

				frame.setAttribute( 'aria-hidden', 'true' );
				frame.tabIndex = -1;
				frame.style.cssText = 'position:fixed;left:-20000px;top:0;width:1440px;height:900px;border:0;opacity:0;pointer-events:none;';
				frame.addEventListener( 'load', function () {
					var doc = frame.contentDocument;
					var win = frame.contentWindow;
					if ( ! doc || ! doc.body ) {
						finish( reject, new Error( 'The page could not be read.' ) );
						return;
					}
					// As read() does: the fonts, then a moment for the scripts.
					var fonts = doc.fonts && doc.fonts.ready ? doc.fonts.ready : Promise.resolve();
					Promise.race( [ fonts, new Promise( function ( r ) {
						window.setTimeout( r, 6000 );
					} ) ] ).then( function () {
						window.setTimeout( function () {
							window.kerfDesignRead.capture( doc, win ).then( function ( captured ) {
								finish( resolve, { captured: captured } );
							}, function ( error ) {
								finish( reject, error );
							} );
						}, 800 );
					} );
				} );
				frame.srcdoc = /<head[^>]*>/i.test( html )
					? html.replace( /<head[^>]*>/i, function ( tag ) {
						return tag + base;
					} )
					: base + html;
				document.body.appendChild( frame );
			} );
		} );
	}

	function start() {
		window.kerfDesignRead.read( data.url ).catch( function () {
			return readHtml( data.url );
		} ).then( function ( result ) {
			var captured = result.captured || { css: '', icons: {} };
			captured.page = parseInt( data.page, 10 ) || 0;
			return wp.apiFetch( { path: '/kerf/v1/captured', method: 'POST', data: captured } );
		} ).then( function ( answer ) {
			css = answer && answer.css ? String( answer.css ) : '';
			if ( css ) {
				apply();
				window.setInterval( apply, 1500 );
			}
		} ).catch( function () {
			// Nothing saved: the next load of the editor tries again.
		} );
	}

	// After the editor has settled, so the reading does not compete with it.
	if ( 'complete' === document.readyState ) {
		window.setTimeout( start, 1500 );
	} else {
		window.addEventListener( 'load', function () {
			window.setTimeout( start, 1500 );
		} );
	}
}( window.wp ) );
