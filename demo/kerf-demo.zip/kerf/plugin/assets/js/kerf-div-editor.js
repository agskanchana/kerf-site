/**
 * kerf/div — the Element block.
 *
 * The editor preview renders the REAL tag with the REAL classes, because the
 * mockup's stylesheets are loaded into the canvas. Wrapping it in editor chrome
 * would break every layout rule the designer wrote — a `.grid > *` selector does
 * not survive an extra div, and the editor would show a stack where the page
 * shows three columns.
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var blockEditor = wp.blockEditor;
	var InspectorControls = blockEditor.InspectorControls;
	var useBlockProps = blockEditor.useBlockProps;
	var useInnerBlocksProps = blockEditor.useInnerBlocksProps;
	var InnerBlocks = blockEditor.InnerBlocks;
	var PanelBody = wp.components.PanelBody;
	var ToggleControl = wp.components.ToggleControl;
	var kerf = window.kerf;

	wp.blocks.registerBlockType( 'kerf/div', {
		edit: function ( props ) {
			var attributes = props.attributes;
			var setAttributes = props.setAttributes;
			var tag = ( attributes.tagName || 'div' ).toLowerCase();
			var voidTag = kerf.isVoid( tag );
			// A hook: called first, on every render.
			var full = kerf.fullEditing();

			// Deep: true, so selecting the paragraph four levels inside a closed
			// <details> counts. Called unconditionally — see the hook note below.
			var holdsSelection = wp.data.useSelect( function ( select ) {
				// The hook itself runs for every block, as the rules of hooks
				// require, but the walk does not. hasSelectedInnerBlock( …, true )
				// descends the whole subtree, and a converted page is routinely
				// 300+ of these — paying for it on all of them, on every store
				// change, is how an editor starts to feel slow.
				if ( 'details' !== tag ) {
					return false;
				}
				var store = select( 'core/block-editor' );
				return !! store && store.hasSelectedInnerBlock( props.clientId, true );
			}, [ props.clientId, tag ] );

			// A slot marked for the post's picture that a script paints
			// (`data-setbg`, §5.25): inside a loop, it shows the post's featured
			// image, as the page will. Called on every render (rules of hooks);
			// it returns early for every other element.
			var fields = ( attributes.kerfFields || '' ) + ' ' + ( ( attributes.customAttributes || {} )[ 'data-kerf-field' ] || '' );
			var postId = props.context && props.context.postId;
			var featured = wp.data.useSelect( function ( select ) {
				if ( ! postId || ! /(?:^|\s)image(?:\s|$)/.test( fields ) ) {
					return '';
				}
				var post = select( 'core' ).getEntityRecord( 'postType', props.context.postType || 'post', postId );
				var media = post && post.featured_media ? select( 'core' ).getEntityRecord( 'postType', 'attachment', post.featured_media ) : null;
				return media ? media.source_url : '';
			}, [ postId, fields ] );

			var preview = kerf.previewProps( attributes );

			if ( featured ) {
				Object.keys( preview ).forEach( function ( key ) {
					if ( /^data-/.test( key ) && /\.(?:jpe?g|png|gif|webp|avif|svg)(?:[?#].*)?$/i.test( String( preview[ key ] ) ) ) {
						preview[ key ] = featured;
					}
				} );
			}

			// A closed <details> is a dead end in the editor. Clicking its
			// <summary> selects the block instead of toggling it, the way it
			// would on the page, so there is no gesture that opens it — the
			// content is reachable from the List View and still invisible once
			// you get there. Opening it while anything inside is selected is the
			// missing gesture, and it closes again the moment you click away, so
			// an FAQ still reads as a stack of closed rows.
			//
			// The mockup's own `open` is honoured too: previewProps forwards only
			// data-/aria-, so `<details open>` was rendering closed.
			if ( 'details' === tag ) {
				var mockupOpen = attributes.customAttributes
					&& undefined !== attributes.customAttributes.open;

				if ( props.isSelected || holdsSelection || mockupOpen ) {
					preview.open = true;
				}
			}

			var blockProps = useBlockProps( preview );

			// Both hooks run on every render, unconditionally. tagName is editable,
			// so a block can go from <div> to <input> and back — branching before
			// the hook would change the hook count between renders, which React
			// treats as a fatal error and which would surface as the editor
			// blanking out the moment someone picks a void tag from the menu.
			//
			// The appender is shown ONLY for the selected block. A converted page
			// is a deep tree — a typical mockup produces 50+ nested elements — and
			// an unconditional ButtonBlockAppender puts a floating "+" over every
			// single one of them. The design becomes unreadable, which defeats the
			// entire point of loading the mockup's CSS into the canvas.
			var innerProps = useInnerBlocksProps( blockProps, {
				templateLock: false,
				renderAppender: props.isSelected ? InnerBlocks.ButtonBlockAppender : false
			} );

			// A void element takes no children. A form field is drawn as itself —
			// the designer's classes, type and placeholder, read-only — so a form
			// in the canvas looks like the form on the page; so is a rule. The
			// rest (a <br>, a <wbr>) would be invisible, and keep a marker to stay
			// selectable. A <textarea> is not void, but its children are its
			// VALUE: handed the inner-block list, React printed "[object Object]".
			var custom = attributes.customAttributes || {};
			var field = {
				placeholder: custom.placeholder || undefined,
				readOnly: true,
				tabIndex: -1
			};
			var preview;
			if ( 'input' === tag && ! /^(hidden|image|file)$/i.test( custom.type || '' ) ) {
				preview = el( 'input', Object.assign( {}, blockProps, field, {
					type: /^(text|email|url|search|tel|number|password|date|checkbox|radio|submit|button|reset)$/i.test( custom.type || '' ) ? custom.type : 'text',
					defaultValue: custom.value || undefined
				} ) );
			} else if ( 'hr' === tag ) {
				preview = el( 'hr', blockProps );
			} else if ( 'br' === tag || 'wbr' === tag ) {
				// A line break as itself: drawn as a "<br>" chip it split an
				// address's two lines with a box the page never shows (Murphy's
				// footer). Still in the List View, to select or remove.
				preview = el( tag, blockProps );
			} else if ( voidTag ) {
				preview = el( 'div', blockProps, el( 'span', { className: 'kerf-void-marker' }, '<' + tag + '>' ) );
			} else if ( 'textarea' === tag ) {
				preview = el( 'textarea', Object.assign( {}, blockProps, field, { defaultValue: '' } ) );
			} else {
				preview = el( tag, innerProps );
			}

			return el( Fragment, null,
				el( InspectorControls, null,
					// Client mode (kerf-client-mode.js) opens an element only for
					// its background picture: the tag and the form are the design's.
					full && el( PanelBody, { title: __( 'Element', 'kerf-blocks' ), initialOpen: true },
						el( kerf.TagControl, {
							value: tag,
							onChange: function ( next ) {
								setAttributes( { tagName: next || 'div' } );
							}
						} )
					),
					// An anchor with element children converts to this block, so
					// the link control belongs here too — otherwise a card that
					// is one big <a> has no way to be pointed at a page.
					'a' === tag && el( PanelBody, { title: __( 'Link', 'kerf-blocks' ), initialOpen: true },
						el( kerf.LinkTargetControl, {
							attributes: attributes,
							setAttributes: setAttributes,
							urlKey: 'href'
						} ),
					),
					// A search form searches the site (kerf_mc_is_search_form(),
					// or the designer's `search-form` marker): WordPress search,
					// never an email, so no switch — offering "Send this form
					// with Kerf" on it read as the search being a Kerf form.
					full && 'form' === tag && /(?:^|\s)search-form(?:\s|$)/.test( fields ) && el( PanelBody, { title: __( 'Form', 'kerf-blocks' ), initialOpen: true },
						el( 'p', { className: 'kerf-help' },
							__( 'A search form: it searches this site, as WordPress search does, and shows the results on the search page. Kerf never emails it.', 'kerf-blocks' )
						)
					),
					// A form Kerf sends (inc/kerf-forms.php): said, and switchable.
					full && 'form' === tag && ! /(?:^|\s)search-form(?:\s|$)/.test( fields ) && el( PanelBody, { title: __( 'Form', 'kerf-blocks' ), initialOpen: true },
						el( ToggleControl, {
							label: __( 'Send this form with Kerf', 'kerf-blocks' ),
							checked: !! attributes.kerfForm,
							onChange: function ( next ) {
								setAttributes( { kerfForm: next ? ( String( custom[ 'data-kerf-form' ] || '' ).replace( /[^a-z0-9_-]/gi, '' ) || 'contact' ) : '' } );
							},
							help: attributes.kerfForm
								? __( 'Each message is emailed to the address under Kerf → Settings. The thank-you message is the element marked data-kerf-form-success.', 'kerf-blocks' )
								: __( 'Off: the form posts wherever its action attribute says, as the design wrote it.', 'kerf-blocks' ),
							__nextHasNoMarginBottom: true
						} )
					),
					// The background picture has its own panel, for this block and
					// the text and link blocks (kerf-background-panel.js).
					el( kerf.StylePanel, {
						attributes: attributes,
						setAttributes: setAttributes
					} ),
					el( kerf.AttributesPanel, {
						value: attributes.customAttributes,
						onChange: function ( next ) {
							setAttributes( { customAttributes: next } );
						}
					} )
				),
				preview
			);
		},

		save: function () {
			// Dynamic block: PHP renders the wrapper, so only the children are
			// serialized. Returning markup here instead would mean the saved tag
			// and the rendered tag could disagree after a tagName change.
			return el( InnerBlocks.Content );
		}
	} );
}( window.wp ) );
