<?php
/**
 * Background pictures, changed without touching the design's files (§5.41).
 *
 * A design's background photos live in three places: the element's own
 * `style` (the block's Background panel always handled those), an attribute
 * a script reads (`data-setbg`), and — most often — its stylesheet, where
 * nothing in WordPress could reach them. The editor's Background picture panel
 * (assets/js/kerf-background-panel.js) reads what the browser actually draws
 * on the selected element and offers two ways to change it:
 *
 *   only here    the block carries the change: a `background-image` added to
 *                its own style, built from the designer's value with just the
 *                photo swapped (a darkening gradient stays), and `kerfBg`
 *                saying what it replaced. Part of the post, like any edit.
 *   everywhere   the rule carries it: stored here, apart from the stylesheet,
 *                and printed right after the design's own CSS with the same
 *                selector — what editing that one line of the file would do,
 *                except an update cannot erase it and a reset is one click.
 *
 * Making an "everywhere" change is Kerf Pro's (pro/inc/kerf-pro-backgrounds.php);
 * printing the ones made, and putting the design's picture back, is here — so
 * a change Pro made keeps showing without it, and can always be undone.
 *
 * An "everywhere" change can also be "each page's featured image" (`featured`):
 * the rule keeps the designer's value, and on a page or post with a featured
 * image it prints with that picture in the photo's place — an inner pages'
 * banner drawn by one rule (`.page-banner`) then shows every page's own
 * picture, its darkening gradient kept; a page with none shows the design's.
 * A banner the design marks `data-kerf-field="image"` whose picture is in the
 * stylesheet gets the same at render: the rules that draw it are found in the
 * design's stylesheets (kerf_bg_marked_rules()) and printed the same way.
 * Printed after the design's CSS with the designer's own selectors, a rule
 * reaches only what the design's rule reached.
 *
 * The stylesheet itself is never edited, so Update from mockup can replace it
 * and still tell what the owner changed (kerf_bg_update_*()). Until someone
 * changes a picture, nothing is added to the page.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_BG_RULES_OPTION = 'kerf_bg_rules';

/**
 * The "everywhere" changes for the design a page is dressed in: the site's,
 * or a page of its own's (kerf_assets_design()).
 *
 * @param int|null $post_id Null for this request's page.
 * @return array<string,array> Key => rule.
 */
function kerf_bg_rules( $post_id = null ) {
	$design = kerf_assets_design( $post_id );
	if ( $design['page'] ) {
		$sets  = kerf_asset_sets();
		$rules = isset( $sets[ $design['page'] ]['bg_rules'] ) ? $sets[ $design['page'] ]['bg_rules'] : array();
	} else {
		$rules = get_option( KERF_BG_RULES_OPTION, array() );
	}
	return is_array( $rules ) ? $rules : array();
}

/**
 * Store the "everywhere" changes for a page's design (a reset here; Kerf
 * Pro's changes and its update's check).
 *
 * @param int   $post_id
 * @param array $rules
 */
function kerf_bg_rules_save( $post_id, $rules ) {
	$design = kerf_assets_design( (int) $post_id );
	if ( $design['page'] ) {
		$sets = kerf_asset_sets();
		$set  = isset( $sets[ $design['page'] ] ) ? $sets[ $design['page'] ] : array();
		$set['bg_rules'] = $rules;
		kerf_asset_set_save( $design['page'], $set );
		return;
	}
	if ( $rules ) {
		update_option( KERF_BG_RULES_OPTION, $rules, false );
	} else {
		delete_option( KERF_BG_RULES_OPTION );
	}
}

/**
 * After a site import replaces the design's stylesheets, keep only the
 * "everywhere" changes made for this design: those whose own picture the new
 * design still has, at the same place in it (a newer version of the same
 * design — kerf-background-core.js's designPath()). A change made for another
 * design kept its selector and went on printing: the next design's
 * `.page-header` showed the last one's photograph (found by AI phase 3's lab
 * check, session 17). The import's recorder keeps the option, so undo brings
 * them back.
 *
 * @param array|null $staging The new design's staging; null for a paste.
 * @return int How many were dropped.
 */
function kerf_bg_rules_for_design( $staging ) {
	$rules = get_option( KERF_BG_RULES_OPTION, array() );
	if ( ! is_array( $rules ) || ! $rules ) {
		return 0;
	}
	$have = array();
	if ( is_array( $staging ) && ! empty( $staging['slug'] ) ) {
		// The staged folder is mockup-<time>/, or mockup-<time>/<the ZIP's one top folder>/.
		$slug = (string) $staging['slug'];
		$sub  = false !== strpos( $slug, '/' ) ? substr( $slug, strpos( $slug, '/' ) + 1 ) . '/' : '';
		foreach ( isset( $staging['zip_files'] ) ? (array) $staging['zip_files'] : array() as $file ) {
			$have[ $sub . $file ] = true;
		}
	}
	$kept = array();
	foreach ( $rules as $key => $rule ) {
		if ( is_array( $rule ) && ! empty( $rule['design'] ) && isset( $have[ $rule['design'] ] ) ) {
			$kept[ $key ] = $rule;
		}
	}
	if ( count( $kept ) !== count( $rules ) ) {
		if ( $kept ) {
			update_option( KERF_BG_RULES_OPTION, $kept, false );
		} else {
			delete_option( KERF_BG_RULES_OPTION );
		}
	}
	return count( $rules ) - count( $kept );
}

/**
 * One rule's key: its selector and the screen sizes it is for.
 *
 * @param string $selector
 * @param string $media
 * @return string
 */
function kerf_bg_key( $selector, $media ) {
	return md5( trim( (string) $selector ) . '|' . trim( (string) $media ) );
}

/**
 * Is this a background-image value Kerf may print: url()s to http(s) or the
 * site's own paths, gradients, `none` — and nothing that leaves the
 * declaration or runs?
 *
 * @param string $value
 * @return bool
 */
function kerf_bg_value_ok( $value ) {
	$value = (string) $value;
	if ( '' === trim( $value ) || strlen( $value ) > 4000 ) {
		return false;
	}
	if ( preg_match( '/[;{}<>@\\\\]|\/\*|expression\s*\(|javascript\s*:|vbscript\s*:|behaviou?r\s*:|-moz-binding/i', $value ) ) {
		return false;
	}
	if ( ! preg_match_all( '/url\(\s*(["\']?)(.*?)\1\s*\)/i', $value, $urls, PREG_SET_ORDER ) ) {
		return false;
	}
	foreach ( $urls as $url ) {
		$inside = $url[2];
		if ( preg_match( '/["\'()\s]/', $inside ) || ! preg_match( '#^(?:https?://|/(?!/))#i', $inside ) ) {
			return false;
		}
	}
	return true;
}

/**
 * A selector or a media condition Kerf may print inside its own rule: no
 * block delimiters, no at-rules, no markup.
 *
 * @param string $text
 * @param int    $max
 * @return bool
 */
function kerf_bg_part_ok( $text, $max ) {
	$text = (string) $text;
	return strlen( $text ) <= $max && ! preg_match( '/[{};<@]|\/\*|\*\//', $text );
}

/**
 * Clean an "everywhere" change as it arrives from the editor.
 *
 * @param array $raw { selector, media, value, important, layer, design, id, url, featured }.
 *                   `featured`: `value` is the designer's, and each page's
 *                   featured image takes layer `layer` as it prints.
 * @return array|null
 */
function kerf_bg_sanitize_rule( $raw ) {
	$raw      = is_array( $raw ) ? $raw : array();
	$selector = trim( (string) ( $raw['selector'] ?? '' ) );
	$media    = trim( (string) ( $raw['media'] ?? '' ) );
	$value    = trim( (string) ( $raw['value'] ?? '' ) );

	if ( '' === $selector || ! kerf_bg_part_ok( $selector, 600 ) || ! kerf_bg_part_ok( $media, 300 ) || ! kerf_bg_value_ok( $value ) ) {
		return null;
	}

	$featured = ! empty( $raw['featured'] );
	return array(
		'selector'  => $selector,
		'media'     => $media,
		'value'     => $value,
		'important' => ! empty( $raw['important'] ),
		'layer'     => max( 0, (int) ( $raw['layer'] ?? 0 ) ),
		'design'    => substr( sanitize_text_field( (string) ( $raw['design'] ?? '' ) ), 0, 300 ),
		'id'        => $featured ? 0 : max( 0, (int) ( $raw['id'] ?? 0 ) ),
		'url'       => $featured ? '' : esc_url_raw( (string) ( $raw['url'] ?? '' ) ),
		'featured'  => $featured,
		'at'        => time(),
	);
}

/**
 * The CSS for a design's "everywhere" changes: the designer's selector, the
 * new layers, inside the same media condition. Printed after the design's own
 * CSS, so it wins exactly where the rule it replaces did. A rule for each
 * page's featured image prints only where there is one, with it.
 *
 * @param array  $rules
 * @param string $featured This page's featured image (kerf_bg_featured_url()), or ''.
 * @return string
 */
function kerf_bg_rules_css( $rules, $featured = '' ) {
	$css = '';
	foreach ( (array) $rules as $rule ) {
		$rule = kerf_bg_sanitize_rule( $rule );
		if ( ! $rule ) {
			continue;
		}
		$value = $rule['value'];
		if ( $rule['featured'] ) {
			if ( '' === (string) $featured ) {
				continue;
			}
			$value = kerf_bg_swap_layer( $value, $rule['layer'], (string) $featured );
			if ( ! kerf_bg_value_ok( $value ) ) {
				continue;
			}
		}
		$block = $rule['selector'] . '{background-image:' . $value . ( $rule['important'] ? ' !important' : '' ) . '}';
		$css  .= '' !== $rule['media'] ? '@media ' . $rule['media'] . '{' . $block . '}' : $block;
	}
	return '' !== $css && function_exists( 'kerf_css_inert' ) ? kerf_css_inert( $css ) : $css;
}

/**
 * Split on commas outside parentheses and quotes: a background-image value
 * into its layers (kerf-background-core.js splitTopLevel()).
 *
 * @param string $value
 * @return string[]
 */
function kerf_bg_split_layers( $value ) {
	$value = (string) $value;
	$out   = array();
	$depth = 0;
	$quote = '';
	$start = 0;
	$len   = strlen( $value );
	for ( $i = 0; $i < $len; $i++ ) {
		$ch = $value[ $i ];
		if ( '' !== $quote ) {
			if ( $ch === $quote && ( 0 === $i || '\\' !== $value[ $i - 1 ] ) ) {
				$quote = '';
			}
			continue;
		}
		if ( '"' === $ch || "'" === $ch ) {
			$quote = $ch;
		} elseif ( '(' === $ch || '[' === $ch ) {
			$depth++;
		} elseif ( ')' === $ch || ']' === $ch ) {
			$depth--;
		} elseif ( ',' === $ch && 0 === $depth ) {
			$out[] = trim( substr( $value, $start, $i - $start ) );
			$start = $i + 1;
		}
	}
	$last = trim( substr( $value, $start ) );
	if ( '' !== $last ) {
		$out[] = $last;
	}
	return $out;
}

/**
 * A url() for CSS: quoted, with what could end it percent-encoded.
 *
 * @param string $url
 * @return string
 */
function kerf_bg_css_url( $url ) {
	return 'url("' . preg_replace_callback( '/["\'\\\\\s()]/', static function ( $m ) {
		return sprintf( '%%%02X', ord( $m[0] ) );
	}, (string) $url ) . '")';
}

/**
 * The value with layer `$index` showing `$url`, every other layer as the
 * designer wrote it (kerf-background-core.js swapLayer()).
 *
 * @param string $value
 * @param int    $index
 * @param string $url
 * @return string
 */
function kerf_bg_swap_layer( $value, $index, $url ) {
	$layers = kerf_bg_split_layers( $value );
	$index  = (int) $index;
	if ( ! isset( $layers[ $index ] ) ) {
		return (string) $value;
	}
	$layers[ $index ] = kerf_bg_css_url( $url );
	return implode( ', ', $layers );
}

/**
 * The address in a `url(…)` layer, or '' for a gradient or `none`.
 *
 * @param string $layer
 * @return string
 */
function kerf_bg_layer_url( $layer ) {
	return preg_match( '/^url\(\s*(["\']?)(.*?)\1\s*\)$/is', trim( (string) $layer ), $m ) ? $m[2] : '';
}

/**
 * A staged file's place in the design: `…/kerf-blocks/mockup-…/site/img/bg.jpg`
 * is `site/img/bg.jpg`, the same in every version (kerf-background-core.js
 * designPath()).
 *
 * @param string $url
 * @return string
 */
function kerf_bg_design_path( $url ) {
	$clean = (string) strtok( (string) $url, '?#' );
	$bases = implode( '|', array_map( 'preg_quote', array_keys( kerf_assets_base_folders() ) ) );
	return preg_match( '#/(?:' . $bases . ')/mockup-[^/]+/(.+)$#', $clean, $m ) ? rawurldecode( $m[1] ) : $clean;
}

/**
 * The picture a page's "featured image" backgrounds show: the featured image
 * of the page or post being shown, '' anywhere else (a blog list, an archive,
 * a page without one — which keep the design's picture).
 *
 * @param int|null $post_id Null for this request's.
 * @return string
 */
function kerf_bg_featured_url( $post_id = null ) {
	if ( null === $post_id ) {
		$post_id = is_singular() ? (int) get_queried_object_id() : 0;
	}
	$url = ( $post_id && has_post_thumbnail( $post_id ) )
		? (string) wp_get_attachment_image_url( (int) get_post_thumbnail_id( $post_id ), 'full' )
		: '';

	/**
	 * The picture a design's backgrounds marked for the featured image show on
	 * a page.
	 *
	 * @param string $url     The featured image, full size; '' for none.
	 * @param int    $post_id
	 */
	return (string) apply_filters( 'kerf_bg_featured_url', $url, (int) $post_id );
}

// ─────────────────────────────────────────────────────────────────────────────
// A banner the design marks for the featured image, its picture in the
// stylesheet
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Note a rendered element the design marked `data-kerf-field="image"` whose
 * picture is not on the element itself — the stylesheet draws it — so its
 * rules print with this page's featured image. Called by the Element renderer.
 * A picture in the element's style or in an attribute its script reads is
 * bound where it is (kerf_apply_bound_background(), kerf_apply_element_fields()).
 *
 * @param array         $attrs
 * @param WP_Block|null $block
 */
function kerf_bg_mark( $attrs, $block = null ) {
	if ( ! in_array( 'image', kerf_block_fields( $attrs ), true ) || ! empty( $attrs['backgroundImage'] ) ) {
		return;
	}
	foreach ( (array) ( $attrs['customAttributes'] ?? array() ) as $name => $value ) {
		if ( 0 === strpos( (string) $name, 'data-' ) && is_string( $value ) && preg_match( '/\.(?:jpe?g|png|gif|webp|avif|svg)(?:[?#].*)?$/i', trim( $value ) ) ) {
			return;
		}
	}
	// A card in a loop shows a post of its own, and one rule cannot.
	if ( kerf_bindings_in_loop() || '' === kerf_bg_featured_url() ) {
		return;
	}
	kerf_bg_marked( kerf_bg_marked_rules( $attrs ) );
}

/**
 * The rules this request's marked elements need: added to, and read.
 *
 * @param array[]|null $rules Rules to add.
 * @return array[]
 */
function kerf_bg_marked( $rules = null ) {
	static $collected = array();
	foreach ( (array) $rules as $rule ) {
		$collected[ kerf_bg_key( $rule['selector'], $rule['media'] ) . '|' . (int) $rule['layer'] ] = $rule;
	}
	return $collected;
}

/**
 * The design's rules that draw a picture on an element like this one — its
 * tag, id and classes — as "featured" rules. Kept a day per design version.
 *
 * Found by the selector's last part only (`.page-banner`, `section.hero`,
 * `#top::before`), its ancestors not looked at: printed with the designer's
 * own selector, a rule found so still reaches only what it reached in the
 * design. Remote stylesheets (a CDN) are not read.
 *
 * @param array $attrs Element attributes: tagName, anchor, className.
 * @return array[]
 */
function kerf_bg_marked_rules( $attrs ) {
	$tag     = strtolower( (string) ( $attrs['tagName'] ?? 'div' ) );
	$id      = trim( (string) ( $attrs['anchor'] ?? '' ) );
	$classes = preg_split( '/\s+/', trim( (string) ( $attrs['className'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY );
	if ( '' === $id && ! $classes ) {
		return array();
	}

	static $memo = array();
	$design = kerf_assets_design();
	$key    = 'kerf_bgm_' . md5( $design['page'] . '|' . $design['version'] . '|' . $tag . '#' . $id . '.' . implode( '.', $classes ) );
	if ( isset( $memo[ $key ] ) ) {
		return $memo[ $key ];
	}
	$cached = get_transient( $key );
	if ( is_array( $cached ) ) {
		$memo[ $key ] = $cached;
		return $cached;
	}

	$rules = array();
	foreach ( kerf_bg_design_sheets( $design ) as $sheet ) {
		$rules = array_merge( $rules, kerf_bg_rules_matching( $sheet['css'], $sheet['base'], $tag, $id, $classes ) );
	}
	set_transient( $key, $rules, DAY_IN_SECONDS );
	$memo[ $key ] = $rules;
	return $rules;
}

/**
 * A design's stylesheets as text, in order, each with the address its url()s
 * are relative to: its files (staged, read from disk) and its `<style>`s.
 *
 * @param array $design kerf_assets_design().
 * @return array[] Each: css, base.
 */
function kerf_bg_design_sheets( $design ) {
	$sheets = array();
	$base   = isset( $design['staging']['url'] ) ? (string) $design['staging']['url'] : '';
	foreach ( (array) $design['assets'] as $asset ) {
		if ( 'css' !== ( $asset['type'] ?? '' ) || ( function_exists( 'kerf_assets_applies_here' ) && ! kerf_assets_applies_here( $asset ) ) ) {
			continue;
		}
		if ( 'file' === ( $asset['kind'] ?? '' ) && ! empty( $asset['src'] ) ) {
			$css = kerf_assets_editor_css( (string) $asset['src'], false );
			if ( '' !== $css ) {
				$sheets[] = array( 'css' => $css, 'base' => (string) $asset['src'] );
			}
		} elseif ( 'inline' === ( $asset['kind'] ?? '' ) && '' !== (string) ( $asset['content'] ?? '' ) ) {
			$sheets[] = array( 'css' => (string) $asset['content'], 'base' => $base );
		}
	}
	return $sheets;
}

/**
 * The rules of one stylesheet that draw a picture on an element with this
 * tag, id and classes (or on its ::before / ::after), each as a "featured"
 * rule: its selector and media as written, its picture value with every
 * url() made absolute, the photo's layer (the last url()).
 *
 * @param string   $css
 * @param string   $base    What the sheet's url()s are relative to.
 * @param string   $tag
 * @param string   $id
 * @param string[] $classes
 * @return array[]
 */
function kerf_bg_rules_matching( $css, $base, $tag, $id, $classes ) {
	$found = array();
	kerf_css_walk( (string) $css, static function ( $rule ) use ( &$found, $base, $tag, $id, $classes ) {
		if ( null === $rule['body'] || '@' === substr( (string) $rule['selector'], 0, 1 ) ) {
			return;
		}
		$media = array();
		foreach ( (array) $rule['chain'] as $at ) {
			if ( preg_match( '/^@media\s+(.+)$/is', trim( (string) $at ), $m ) ) {
				$media[] = trim( $m[1] );
			} elseif ( ! preg_match( '/^@(?:supports|layer)\b/i', trim( (string) $at ) ) ) {
				// A container or scope query cannot be repeated outside it.
				return;
			}
		}
		if ( false === kerf_bg_selector_targets( (string) $rule['selector'], $tag, $id, $classes ) ) {
			return;
		}
		$image = kerf_bg_declared_image( (string) $rule['body'] );
		if ( ! $image ) {
			return;
		}
		$value  = kerf_bg_absolute_urls( $image['value'], $base );
		$layers = kerf_bg_split_layers( $value );
		$layer  = -1;
		foreach ( $layers as $index => $one ) {
			if ( '' !== kerf_bg_layer_url( $one ) ) {
				$layer = $index;
			}
		}
		if ( $layer < 0 || ! kerf_bg_value_ok( $value ) ) {
			return;
		}
		$found[] = array(
			'selector'  => trim( (string) $rule['selector'] ),
			'media'     => implode( ' and ', $media ),
			'value'     => $value,
			'important' => $image['important'],
			'layer'     => $layer,
			'design'    => kerf_bg_design_path( kerf_bg_layer_url( $layers[ $layer ] ) ),
			'featured'  => true,
		);
	} );
	return $found;
}

/**
 * Does a selector draw on an element with this tag, id and classes? Its last
 * compound decides (`.page-banner`, `section.hero`, `#top`); a state
 * (`:hover`) never does, and a selector naming neither id nor class is too
 * broad to take (`section`).
 *
 * @param string   $selector One selector.
 * @param string   $tag
 * @param string   $id
 * @param string[] $classes
 * @return string|false The layer it draws on — '', '::before', '::after' — or false.
 */
function kerf_bg_selector_targets( $selector, $tag, $id, $classes ) {
	$selector = trim( (string) $selector );
	if ( preg_match( '/:(?:hover|focus|focus-within|focus-visible|active|checked|target|visited)\b/i', $selector ) ) {
		return false;
	}
	$pseudo = '';
	if ( preg_match( '/::?(before|after)\s*$/i', $selector, $m ) ) {
		$pseudo   = '::' . strtolower( $m[1] );
		$selector = trim( (string) preg_replace( '/::?(?:before|after)\s*$/i', '', $selector ) );
	}
	if ( false !== strpos( $selector, '::' ) ) {
		return false;
	}

	// The last compound: after the last combinator outside brackets, quotes
	// and parentheses.
	$depth = 0;
	$quote = '';
	$from  = 0;
	$len   = strlen( $selector );
	for ( $i = 0; $i < $len; $i++ ) {
		$ch = $selector[ $i ];
		if ( '\\' === $ch ) {
			$i++;
			continue;
		}
		if ( '' !== $quote ) {
			$quote = $ch === $quote ? '' : $quote;
			continue;
		}
		if ( '"' === $ch || "'" === $ch ) {
			$quote = $ch;
		} elseif ( '(' === $ch || '[' === $ch ) {
			$depth++;
		} elseif ( ')' === $ch || ']' === $ch ) {
			$depth--;
		} elseif ( 0 === $depth && false !== strpos( " \t\n>+~", $ch ) ) {
			$from = $i + 1;
		}
	}
	$last = substr( $selector, $from );

	// Attribute selectors and pseudo-classes (:not(…), :first-child) left
	// out: the tag, the id and the classes decide.
	$plain = '';
	$depth = 0;
	$len   = strlen( $last );
	for ( $i = 0; $i < $len; $i++ ) {
		$ch = $last[ $i ];
		if ( '\\' === $ch && $i + 1 < $len ) {
			if ( 0 === $depth ) {
				$plain .= $ch . $last[ $i + 1 ];
			}
			$i++;
			continue;
		}
		if ( '[' === $ch || ( ':' === $ch && 0 === $depth ) ) {
			// Skip to the end of the attribute selector or the pseudo-class.
			if ( '[' === $ch ) {
				$end = strpos( $last, ']', $i );
				$i   = false === $end ? $len : $end;
				continue;
			}
			$j = $i + 1;
			while ( $j < $len && preg_match( '/[a-z0-9-]/i', $last[ $j ] ) ) {
				$j++;
			}
			if ( $j < $len && '(' === $last[ $j ] ) {
				$open = 1;
				for ( $j++; $j < $len && $open; $j++ ) {
					$open += '(' === $last[ $j ] ? 1 : ( ')' === $last[ $j ] ? -1 : 0 );
				}
			}
			$i = $j - 1;
			continue;
		}
		$plain .= $ch;
	}

	if ( ! preg_match( '/^(\*|[a-z][a-z0-9-]*)?((?:[#.](?:\\\\.|[^#.\\\\])+)*)$/i', $plain, $m ) ) {
		return false;
	}
	$want = strtolower( $m[1] );
	if ( '' !== $want && '*' !== $want && $want !== $tag ) {
		return false;
	}
	if ( ! preg_match_all( '/([#.])((?:\\\\.|[^#.\\\\])+)/', $m[2], $parts, PREG_SET_ORDER ) ) {
		return false;
	}
	foreach ( $parts as $part ) {
		$name = (string) preg_replace( '/\\\\(.)/s', '$1', $part[2] );
		if ( '#' === $part[1] ? $name !== $id : ! in_array( $name, $classes, true ) ) {
			return false;
		}
	}
	return $pseudo;
}

/**
 * The picture a rule's declarations give an element: `background-image`, or
 * the images of a `background` shorthand's layers (a gradient, a photo) —
 * whichever is written last, an `!important` one before one that is not.
 * Null when it shows no url() or leans on a custom property.
 *
 * @param string $body Declarations.
 * @return array{value:string,important:bool}|null
 */
function kerf_bg_declared_image( $body ) {
	$found = null;
	foreach ( kerf_bg_split_declarations( $body ) as $declaration ) {
		$colon = strpos( $declaration, ':' );
		if ( false === $colon ) {
			continue;
		}
		$property = strtolower( trim( substr( $declaration, 0, $colon ) ) );
		if ( 'background' !== $property && 'background-image' !== $property ) {
			continue;
		}
		$value     = trim( substr( $declaration, $colon + 1 ) );
		$important = (bool) preg_match( '/!\s*important\s*$/i', $value );
		$value     = trim( (string) preg_replace( '/!\s*important\s*$/i', '', $value ) );
		if ( 'background' === $property ) {
			$images = array();
			foreach ( kerf_bg_split_layers( $value ) as $layer ) {
				$images[] = kerf_bg_layer_image( $layer );
			}
			$value = implode( ', ', $images );
		}
		if ( $found && $found['important'] && ! $important ) {
			continue;
		}
		$found = array( 'value' => $value, 'important' => $important );
	}
	if ( ! $found || false === stripos( $found['value'], 'url(' ) || false !== stripos( $found['value'], 'var(' ) ) {
		return null;
	}
	return $found;
}

/**
 * A declaration block's declarations, split on semicolons outside quotes and
 * parentheses (a `data:` URL holds semicolons).
 *
 * @param string $body
 * @return string[]
 */
function kerf_bg_split_declarations( $body ) {
	$body  = (string) $body;
	$out   = array();
	$depth = 0;
	$quote = '';
	$start = 0;
	$len   = strlen( $body );
	for ( $i = 0; $i < $len; $i++ ) {
		$ch = $body[ $i ];
		if ( '' !== $quote ) {
			if ( $ch === $quote && '\\' !== $body[ $i - 1 ] ) {
				$quote = '';
			}
			continue;
		}
		if ( '"' === $ch || "'" === $ch ) {
			$quote = $ch;
		} elseif ( '(' === $ch ) {
			$depth++;
		} elseif ( ')' === $ch ) {
			$depth--;
		} elseif ( ';' === $ch && $depth <= 0 ) {
			$out[] = trim( substr( $body, $start, $i - $start ) );
			$start = $i + 1;
		}
	}
	$out[] = trim( substr( $body, $start ) );
	return array_values( array_filter( $out, 'strlen' ) );
}

/**
 * One `background` layer's image: its url() or gradient, else `none`.
 *
 * @param string $layer
 * @return string
 */
function kerf_bg_layer_image( $layer ) {
	$layer = (string) $layer;
	if ( ! preg_match( '/(?:url|(?:repeating-)?(?:linear|radial|conic)-gradient|(?:-webkit-)?image-set)\s*\(/i', $layer, $m, PREG_OFFSET_CAPTURE ) ) {
		return 'none';
	}
	$start = $m[0][1];
	$i     = $start + strlen( $m[0][0] );
	$depth = 1;
	$quote = '';
	$len   = strlen( $layer );
	for ( ; $i < $len && $depth > 0; $i++ ) {
		$ch = $layer[ $i ];
		if ( '' !== $quote ) {
			$quote = $ch === $quote ? '' : $quote;
			continue;
		}
		if ( '"' === $ch || "'" === $ch ) {
			$quote = $ch;
		} elseif ( '(' === $ch ) {
			$depth++;
		} elseif ( ')' === $ch ) {
			$depth--;
		}
	}
	return trim( substr( $layer, $start, $i - $start ) );
}

/**
 * Every url() in a value made absolute against the sheet's own address: the
 * rule prints in the page, not beside the file.
 *
 * @param string $value
 * @param string $base
 * @return string
 */
function kerf_bg_absolute_urls( $value, $base ) {
	return (string) preg_replace_callback( '/url\(\s*(["\']?)(.*?)\1\s*\)/is', static function ( $m ) use ( $base ) {
		$url = trim( $m[2] );
		if ( '' === $url || preg_match( '/^(?:data|blob):/i', $url ) || '' === (string) $base ) {
			return $m[0];
		}
		return kerf_bg_css_url( WP_Http::make_absolute_url( $url, $base ) );
	}, (string) $value );
}

/**
 * Print a design's "everywhere" changes after its last stylesheet, in a
 * `<style>` of their own: added to the design's own last block, an unclosed
 * brace there would swallow them (scar 101). Called by kerf_assets_enqueue()
 * with the handle it finished on — after the page's blocks have rendered, so
 * the rules a marked banner asked for (kerf_bg_mark()) are known.
 *
 * @param string $after_handle The last of the design's stylesheets, or ''.
 * @param array  $design       kerf_assets_design().
 */
function kerf_bg_enqueue( $after_handle, $design ) {
	$featured = kerf_bg_featured_url();
	$rules    = array_values( kerf_bg_rules( (int) $design['page'] ) );
	if ( '' !== $featured ) {
		$rules = array_merge( $rules, array_values( kerf_bg_marked() ) );
	}
	$css = kerf_bg_rules_css( $rules, $featured );
	if ( '' === $css ) {
		return;
	}
	wp_register_style( 'kerf-bg-rules', false, '' !== $after_handle ? array( $after_handle ) : array(), $design['version'] );
	wp_enqueue_style( 'kerf-bg-rules' );
	wp_add_inline_style( 'kerf-bg-rules', $css );
}

/**
 * REST: put the design's picture back where an "everywhere" change replaced
 * it. Free, with or without Kerf Pro (which makes such changes — POST on the
 * same route, pro/inc/kerf-pro-backgrounds.php): nothing it made is stuck.
 */
function kerf_bg_routes() {
	register_rest_route( 'kerf/v1', '/backgrounds', array(
		'methods'             => 'DELETE',
		'permission_callback' => static function () {
			return current_user_can( 'edit_theme_options' );
		},
		'callback'            => static function ( $request ) {
			$post  = (int) $request->get_param( 'post' );
			$rules = kerf_bg_rules( $post );
			unset( $rules[ (string) $request->get_param( 'key' ) ] );
			kerf_bg_rules_save( $post, $rules );
			return rest_ensure_response( array( 'rules' => $rules ) );
		},
	) );
}
add_action( 'rest_api_init', 'kerf_bg_routes' );

/**
 * The shared helpers (assets/js/kerf-background-core.js), registered once
 * for the editor panel and the update screen.
 */
function kerf_bg_register_core() {
	$rel = 'assets/js/kerf-background-core.js';
	if ( ! wp_script_is( 'kerf-background-core', 'registered' ) && file_exists( kerf_plugin_path( $rel ) ) ) {
		wp_register_script( 'kerf-background-core', kerf_plugin_url( $rel ), array(), filemtime( kerf_plugin_path( $rel ) ), true );
	}
}

/**
 * What the panel needs: the design's "everywhere" changes, and whether this
 * user may make them (a client may change a picture only where it is).
 */
function kerf_bg_editor_data() {
	$post = isset( $_GET['post'] ) ? (int) $_GET['post'] : 0; // phpcs:ignore WordPress.Security.NonceVerification -- read-only.
	wp_add_inline_script( 'kerf-background-panel', 'window.kerfBackgrounds = ' . wp_json_encode( array(
		'post'      => $post,
		'rules'     => (object) kerf_bg_rules( $post ),
		'canManage' => current_user_can( 'edit_theme_options' ),
	) ) . ';', 'before' );
}
