<?php
/**
 * Kerf → Import design: the import as three steps.
 *
 *   1. Upload — the ZIP dropped or chosen, or the HTML pasted.
 *   2. Check and choose — what the design holds and what will not work, read
 *      before anything is written (kerf_import_check(), kerf-preflight.php);
 *      where it goes; Kerf Pro's other pages (`kerf_import_check_sections`).
 *   3. Done — what was made, how closely it matches, what to do next, undo.
 *
 * The pipeline is inc/kerf-import.php; this only draws it. Every step is a
 * plain form that works without the screen's script (assets/js/kerf-admin.js),
 * which only adds the drop and a line saying the server is working.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The import, under the Kerf menu (its Dashboard is inc/kerf-dashboard.php).
 */
function kerf_import_menu() {
	add_submenu_page(
		'kerf',
		__( 'Import a design', 'kerf-blocks' ),
		__( 'Import design', 'kerf-blocks' ),
		'edit_theme_options',
		'kerf-import',
		'kerf_import_render_page'
	);
}
add_action( 'admin_menu', 'kerf_import_menu' );

/**
 * Is this the import's screen? (Kerf Pro measures the home page from its report.)
 *
 * @param string $hook The screen's hook suffix.
 * @return bool
 */
function kerf_import_is_screen( $hook ) {
	return false !== strpos( (string) $hook, 'kerf-import' );
}

/**
 * The page reader, on every Kerf screen for an add-on to build on; the import's
 * report reads the home page with it.
 *
 * @param string $hook Current admin page.
 */
function kerf_import_admin_assets( $hook ) {
	if ( ! kerf_ui_is_kerf_screen( $hook ) ) {
		return;
	}

	$reader = 'assets/js/kerf-design-read.js';
	if ( file_exists( kerf_plugin_path( $reader ) ) ) {
		wp_register_script( 'kerf-design-read', kerf_plugin_url( $reader ), array(), filemtime( kerf_plugin_path( $reader ) ), true );
	}
	$report = 'assets/js/kerf-import-report.js';
	if ( kerf_import_is_screen( $hook ) && file_exists( kerf_plugin_path( $report ) ) ) {
		wp_enqueue_script( 'kerf-import-report', kerf_plugin_url( $report ), array( 'kerf-design-read', 'wp-api-fetch' ), filemtime( kerf_plugin_path( $report ) ), true );
	}
}
add_action( 'admin_enqueue_scripts', 'kerf_import_admin_assets' );

/**
 * Say that importing needs the Kerf theme, with the button that gets there.
 *
 * Importing and updating a design write the Kerf theme's own template parts
 * and templates, so they wait for it (kerf_theme_active()). Since 1.1.0 the
 * blocks are the theme's (§5.49), so this is reached only where the engine is
 * loaded some other way — a test switching themes in its own request.
 */
function kerf_theme_required_notice() {
	$theme = wp_get_theme( 'kerf' );
	$link  = '';

	if ( $theme->exists() && current_user_can( 'switch_themes' ) ) {
		$link = sprintf(
			' <a class="button button-primary" href="%s">%s</a>',
			esc_url( wp_nonce_url( admin_url( 'themes.php?action=activate&stylesheet=kerf' ), 'switch-theme_kerf' ) ),
			esc_html__( 'Activate the Kerf theme', 'kerf-blocks' )
		);
	}

	printf(
		'<div class="notice notice-warning"><p>%s%s</p></div>',
		$theme->exists()
			? esc_html__( 'A design is imported into the Kerf theme’s page layouts, header and footer. Activate the Kerf theme first.', 'kerf-blocks' )
			: esc_html__( 'A design is imported into the Kerf theme’s page layouts, header and footer. Install the Kerf theme (Appearance → Themes → Add New), then activate it.', 'kerf-blocks' ),
		$link // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
	);
}

/**
 * Draw the import screen, at whichever step the last submit left it.
 */
function kerf_import_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to import a design.', 'kerf-blocks' ) );
	}

	if ( ! kerf_user_can_import() ) {
		kerf_ui_open( __( 'Import a design', 'kerf-blocks' ) );
		echo kerf_ui_note( kerf_import_permission_message(), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		kerf_ui_close();
		return;
	}

	// A design is imported into the Kerf theme's templates and parts.
	if ( ! kerf_theme_active() ) {
		kerf_ui_open( __( 'Import a design', 'kerf-blocks' ) );
		kerf_theme_required_notice();
		kerf_ui_close();
		return;
	}

	$result = kerf_import_handle_post();
	// Opened with a parked import's token — a design an add-on staged and
	// sent the owner to (kerf_import_check_url()): its check step.
	if ( null === $result && isset( $_GET['kerf_pending'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a read: the token is the owner's own, checked by kerf_import_pending_peek(); importing still needs the form's nonce.
		$result = kerf_import_check_pending( sanitize_key( wp_unslash( $_GET['kerf_pending'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- see above.
		if ( null === $result ) {
			$result = array( 'error' => __( 'That design has expired or was already imported. Make it again, or upload it.', 'kerf-blocks' ) );
		}
	}
	$step = 1;
	if ( $result && ! empty( $result['check'] ) ) {
		$step = 2;
	} elseif ( $result && empty( $result['error'] ) && empty( $result['cancelled'] ) ) {
		$step = 3;
	}

	kerf_ui_open( __( 'Import a design', 'kerf-blocks' ), array( 'class' => 'kerf-import' ) );
	kerf_import_render_steps( $step );

	if ( 2 === $step ) {
		kerf_import_render_check( $result );
	} elseif ( 3 === $step ) {
		kerf_import_render_report( $result );
		kerf_undo_render();
	} else {
		if ( $result && ! empty( $result['cancelled'] ) ) {
			echo kerf_ui_note( __( 'Import cancelled. Nothing was written, and the uploaded files were removed.', 'kerf-blocks' ), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		} elseif ( $result ) {
			kerf_import_render_report( $result );
		}
		kerf_import_render_form();
		// The last import, undoable — below the upload, not in its way.
		echo '<div class="kerf-gap-top">';
		kerf_undo_render();
		echo '</div>';
	}

	kerf_ui_working();
	kerf_ui_close();
}

/**
 * The three steps, and where this screen is among them.
 *
 * @param int $current 1, 2 or 3.
 */
function kerf_import_render_steps( $current ) {
	kerf_ui_steps( array( __( 'Upload', 'kerf-blocks' ), __( 'Check and choose', 'kerf-blocks' ), __( 'Done', 'kerf-blocks' ) ), $current, __( 'Importing a design', 'kerf-blocks' ) );
}

/**
 * Step one: the design, dropped, chosen or pasted.
 */
function kerf_import_render_form() {
	?>
	<div class="kerf-cols">
		<form method="post" enctype="multipart/form-data" class="kerf-panel" data-working="<?php esc_attr_e( 'Reading your design…', 'kerf-blocks' ); ?>">
			<?php wp_nonce_field( 'kerf_import', 'kerf_import_nonce' ); ?>
			<input type="hidden" name="kerf_action" value="check">
			<input type="hidden" name="kerf_source" value="zip">

			<div class="kerf-panel__head">
				<h2><?php esc_html_e( 'Bring in your design', 'kerf-blocks' ); ?></h2>
				<p><?php esc_html_e( 'The ZIP your AI tool or designer gave you: the folder with index.html and its styles, scripts and pictures. Nothing changes on the site until you have seen what Kerf found in it.', 'kerf-blocks' ); ?></p>
			</div>

			<div class="kerf-panel__body">
				<div class="kerf-source-switch" role="group" aria-label="<?php esc_attr_e( 'Where the design comes from', 'kerf-blocks' ); ?>">
					<button type="button" data-source="zip" aria-pressed="true" aria-controls="kerf-source-zip"><?php echo kerf_ui_icon( 'file' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'A ZIP file', 'kerf-blocks' ); ?></button>
					<button type="button" data-source="paste" aria-pressed="false" aria-controls="kerf-source-paste"><?php echo kerf_ui_icon( 'paste' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Pasted HTML', 'kerf-blocks' ); ?></button>
				</div>

				<div id="kerf-source-zip">
					<?php kerf_ui_drop( 'kerf_zip' ); ?>
				</div>

				<div id="kerf-source-paste" class="kerf-paste" hidden>
					<div class="kerf-field">
						<label class="kerf-label" for="kerf_html"><?php esc_html_e( 'The page\'s HTML', 'kerf-blocks' ); ?></label>
						<textarea name="kerf_html" id="kerf_html" rows="12" placeholder="&lt;!DOCTYPE html&gt;&#10;&lt;html&gt;…"></textarea>
						<p class="kerf-help"><?php esc_html_e( 'For one page whose styles and pictures load from the web. Files it names by a relative path cannot load without the folder — import the ZIP for those.', 'kerf-blocks' ); ?></p>
					</div>
					<div class="kerf-field">
						<label class="kerf-label" for="kerf_base_url"><?php esc_html_e( 'Where the page is online', 'kerf-blocks' ); ?> <span class="kerf-optional"><?php esc_html_e( '(optional)', 'kerf-blocks' ); ?></span></label>
						<input type="url" name="kerf_base_url" id="kerf_base_url" placeholder="https://preview.example.com/home.html">
						<p class="kerf-help"><?php esc_html_e( 'Its relative links and files are then loaded from there.', 'kerf-blocks' ); ?></p>
					</div>
				</div>
			</div>

			<div class="kerf-panel__foot">
				<button type="submit" class="kerf-btn kerf-btn--primary kerf-btn--lg" data-needs-source><?php esc_html_e( 'Check the design', 'kerf-blocks' ); ?></button>
				<p class="kerf-help"><?php esc_html_e( 'Next, you see what Kerf found and choose where the design goes.', 'kerf-blocks' ); ?></p>
			</div>
		</form>

		<aside class="kerf-stack">
			<?php
			/**
			 * Beside the upload: the brief for an AI tool (inc/kerf-brief.php).
			 */
			do_action( 'kerf_import_before_form' );
			?>
		</aside>
	</div>
	<?php
}

/**
 * Step two: what the design holds and what will not work, then where it goes.
 *
 * @param array $result From kerf_import_check().
 */
function kerf_import_render_check( $result ) {
	$findings = (array) $result['preflight'];
	$blocked  = kerf_preflight_blocks( $findings );
	$count    = (array) $result['inventory'];
	$scopes   = kerf_import_scopes();
	$pages    = get_pages( array( 'number' => 300, 'sort_column' => 'post_title' ) );

	// Into the page the last design went into, and the home page again if it
	// was; else a new page called Home, made the home page if the site has none.
	$previous = (int) get_option( 'kerf_mockup_page' );
	$previous = $previous && get_post( $previous ) && 'trash' !== get_post_status( $previous ) ? $previous : 0;
	$front    = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
	$is_front = ! $front || ( $previous && $front === $previous );

	$numbers = array(
		'pages'       => _n( 'page', 'pages', $count['pages'], 'kerf-blocks' ),
		'stylesheets' => _n( 'stylesheet', 'stylesheets', $count['stylesheets'], 'kerf-blocks' ),
		'scripts'     => _n( 'script', 'scripts', $count['scripts'], 'kerf-blocks' ),
		'pictures'    => _n( 'picture', 'pictures', $count['pictures'], 'kerf-blocks' ),
		'fonts'       => _n( 'font file', 'font files', $count['fonts'], 'kerf-blocks' ),
	);
	?>
	<form method="post" class="kerf-stack" data-working="<?php esc_attr_e( 'Importing your design…', 'kerf-blocks' ); ?>">
		<?php wp_nonce_field( 'kerf_import', 'kerf_import_nonce' ); ?>
		<input type="hidden" name="kerf_pending" value="<?php echo esc_attr( $result['token'] ); ?>">

		<section class="kerf-panel">
			<div class="kerf-panel__head">
				<h2>
					<?php
					/* translators: %s: the design's file name. */
					printf( esc_html__( 'What Kerf found in %s', 'kerf-blocks' ), esc_html( $result['name'] ) );
					?>
				</h2>
				<p>
					<?php
					echo '' !== $result['title']
						/* translators: %s: the page title the design has. */
						? sprintf( esc_html__( 'Its home page is titled “%s”. Nothing on the site has changed yet.', 'kerf-blocks' ), esc_html( $result['title'] ) )
						: esc_html__( 'Nothing on the site has changed yet.', 'kerf-blocks' );
					?>
				</p>
			</div>
			<div class="kerf-panel__body">
				<ul class="kerf-inventory-row">
					<?php foreach ( $numbers as $key => $label ) : ?>
						<li><b><?php echo (int) $count[ $key ]; ?></b><span><?php echo esc_html( $label ); ?></span></li>
					<?php endforeach; ?>
				</ul>
				<h3><?php esc_html_e( 'Checked before importing', 'kerf-blocks' ); ?></h3>
				<?php kerf_preflight_render( $findings ); ?>
				<?php if ( $blocked ) : ?>
					<label class="kerf-switch">
						<input type="checkbox" name="kerf_preflight_override" value="1">
						<span class="kerf-switch__text">
							<strong><?php esc_html_e( 'Import it anyway', 'kerf-blocks' ); ?></strong>
							<span><?php esc_html_e( 'The page will very likely come out empty. Undo puts the site back.', 'kerf-blocks' ); ?></span>
						</span>
					</label>
				<?php endif; ?>
			</div>
		</section>

		<section class="kerf-panel">
			<div class="kerf-panel__head">
				<h2><?php esc_html_e( 'Where it goes', 'kerf-blocks' ); ?></h2>
			</div>
			<div class="kerf-panel__body">
				<?php if ( count( $scopes ) > 1 ) : ?>
					<fieldset class="kerf-field">
						<legend class="kerf-label"><?php esc_html_e( 'This design is for', 'kerf-blocks' ); ?></legend>
						<div class="kerf-choices">
							<?php foreach ( $scopes as $value => $label ) : ?>
								<?php $parts = explode( ' — ', $label, 2 ); ?>
								<label class="kerf-choice">
									<input type="radio" name="kerf_scope" value="<?php echo esc_attr( $value ); ?>" <?php checked( 'site', $value ); ?>>
									<strong><?php echo esc_html( $parts[0] ); ?></strong>
									<?php if ( isset( $parts[1] ) ) : ?>
										<span><?php echo esc_html( ucfirst( $parts[1] ) ); ?></span>
									<?php endif; ?>
								</label>
							<?php endforeach; ?>
						</div>
					</fieldset>
				<?php endif; ?>

				<div class="kerf-field">
					<label class="kerf-label" for="kerf_target"><?php esc_html_e( 'The page it becomes', 'kerf-blocks' ); ?></label>
					<div class="kerf-row">
						<select name="kerf_target" id="kerf_target">
							<option value="new" <?php selected( 0, $previous ); ?>><?php esc_html_e( 'A new page', 'kerf-blocks' ); ?></option>
							<?php foreach ( $pages as $page ) : ?>
								<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( $previous, (int) $page->ID ); ?>>
									<?php
									echo esc_html( '' !== $page->post_title ? $page->post_title : __( '(no title)', 'kerf-blocks' ) );
									if ( (int) $page->ID === $previous ) {
										echo ' ' . esc_html__( '— the last design\'s page', 'kerf-blocks' );
									}
									?>
								</option>
							<?php endforeach; ?>
						</select>
						<input type="text" name="kerf_new_title" value="<?php esc_attr_e( 'Home', 'kerf-blocks' ); ?>" aria-label="<?php esc_attr_e( 'Title of the new page', 'kerf-blocks' ); ?>">
					</div>
					<p class="kerf-help"><?php esc_html_e( 'A new page takes the title beside it. An existing page keeps its title and address; what is on it now is replaced by the design.', 'kerf-blocks' ); ?></p>
				</div>

				<label class="kerf-switch">
					<input type="checkbox" name="kerf_set_front" value="1" <?php checked( $is_front ); ?>>
					<span class="kerf-switch__text">
						<strong><?php esc_html_e( 'Make it the site\'s home page', 'kerf-blocks' ); ?></strong>
						<span><?php esc_html_e( 'Visitors see it first. Your posts move to a page called Blog.', 'kerf-blocks' ); ?></span>
					</span>
				</label>
			</div>
		</section>

		<?php
		/**
		 * More of the check step, before its finer choices — Kerf Pro's: what
		 * each of the design's other pages becomes.
		 *
		 * @param array $result From kerf_import_check(): token, name, title,
		 *                      inventory, preflight, pages (file names), source.
		 */
		do_action( 'kerf_import_check_sections', $result );
		if ( $result['pages'] && ! has_action( 'kerf_import_check_sections' ) ) {
			echo kerf_ui_note( kerf_import_more_pages_note( $result['pages'] ), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		}
		?>

		<section class="kerf-panel">
			<div class="kerf-panel__body">
				<details class="kerf-more">
					<summary><?php echo kerf_ui_icon( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'What else it replaces', 'kerf-blocks' ); ?> <span><?php esc_html_e( 'Header, footer, styles, pictures', 'kerf-blocks' ); ?></span></summary>
					<div class="kerf-more__body">
						<div class="kerf-site-only">
							<?php
							kerf_import_switch( 'kerf_do_header', true, __( 'The site\'s header', 'kerf-blocks' ), __( 'Every page shows the design\'s header, menu included.', 'kerf-blocks' ) );
							kerf_import_switch( 'kerf_do_footer', true, __( 'The site\'s footer', 'kerf-blocks' ), __( 'Every page shows the design\'s footer.', 'kerf-blocks' ) );
							?>
						</div>
						<?php
						kerf_import_switch(
							'kerf_do_assets',
							true,
							__( 'The design\'s styles and scripts', 'kerf-blocks' ),
							__( 'Loaded in the order the design wrote them, exactly as written.', 'kerf-blocks' )
						);
						kerf_import_switch( 'kerf_do_media', true, __( 'Pictures into the media library', 'kerf-blocks' ), __( 'So each one can be swapped in the editor, and is served in the right size.', 'kerf-blocks' ) );
						/**
						 * More choices for an import, among these — each a switch
						 * (kerf_import_switch()).
						 */
						do_action( 'kerf_import_form_choices' );
						kerf_import_switch( 'kerf_create_pages', false, __( 'A draft page for every link that goes nowhere', 'kerf-blocks' ), __( 'Otherwise Kerf → Links lists them, to point at pages yourself.', 'kerf-blocks' ) );
						?>
					</div>
				</details>
			</div>
		</section>

		<div class="kerf-actionbar">
			<button type="submit" name="kerf_action" value="import" class="kerf-btn kerf-btn--primary kerf-btn--lg"><?php esc_html_e( 'Import the design', 'kerf-blocks' ); ?></button>
			<button type="submit" name="kerf_action" value="cancel" class="kerf-btn kerf-btn--quiet kerf-btn--lg" data-no-working formnovalidate><?php esc_html_e( 'Cancel', 'kerf-blocks' ); ?></button>
			<p class="kerf-help kerf-actionbar__end"><?php esc_html_e( 'You can undo the import afterwards: the site goes back to how it is now.', 'kerf-blocks' ); ?></p>
		</div>
	</form>
	<?php
}

/**
 * One of the import's yes-or-no choices, drawn as a switch.
 *
 * @param string $name    The field.
 * @param bool   $checked On by default.
 * @param string $label   What it does.
 * @param string $help    One line more.
 */
function kerf_import_switch( $name, $checked, $label, $help = '' ) {
	?>
	<label class="kerf-switch">
		<input type="checkbox" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $checked ); ?>>
		<span class="kerf-switch__text">
			<strong><?php echo esc_html( $label ); ?></strong>
			<?php if ( '' !== $help ) : ?>
				<span><?php echo esc_html( $help ); ?></span>
			<?php endif; ?>
		</span>
	</label>
	<?php
}

/**
 * Step three: the import done — or, from the command line, a dry run — or
 * why it stopped.
 *
 * @param array $result
 */
function kerf_import_render_report( $result ) {
	if ( ! empty( $result['error'] ) ) {
		echo kerf_ui_note( $result['error'], 'bad' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		if ( ! empty( $result['preflight'] ) ) {
			echo '<section class="kerf-panel kerf-gap-bottom"><div class="kerf-panel__head"><h2>' . esc_html__( 'What the check found', 'kerf-blocks' ) . '</h2></div><div class="kerf-panel__body">';
			kerf_preflight_render( $result['preflight'] );
			echo '</div></section>';
		}
		return;
	}

	$dry        = ! empty( $result['dry_run'] );
	$audit      = $result['audit'];
	$score      = (int) $audit['score'];
	$page       = ! empty( $result['page_id'] ) ? (int) $result['page_id'] : 0;
	$unresolved = ! empty( $result['unresolved'] ) ? count( (array) $result['unresolved'] ) : 0;
	$front      = $page && 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === $page;
	$tone       = $score >= 95 ? '' : ( $score >= 80 ? ' kerf-result__match--warn' : ' kerf-result__match--bad' );

	echo '<div class="kerf-report kerf-stack">';
	?>
	<section class="kerf-panel">
		<div class="kerf-result">
			<div class="kerf-result__match<?php echo esc_attr( $tone ); ?>" style="--kerf-match: <?php echo (int) $score; ?>" role="img" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: a percentage. */ __( '%d%% of the design\'s selectors match', 'kerf-blocks' ), $score ) ); ?>">
				<div><b><?php echo (int) $score; ?>%</b><span><?php esc_html_e( 'match', 'kerf-blocks' ); ?></span></div>
			</div>
			<div>
				<h2><?php echo $dry ? esc_html__( 'Nothing was written — this is what importing would do', 'kerf-blocks' ) : esc_html__( 'Your design is in', 'kerf-blocks' ); ?></h2>
				<p>
					<?php
					/* translators: %d: a percentage. */
					printf( esc_html__( '%d%% of the CSS selectors in your design still match its markup on the site.', 'kerf-blocks' ), (int) $score );
					if ( $page && ! $dry ) {
						echo ' ';
						echo $front
							/* translators: %s: page title. */
							? sprintf( esc_html__( 'It is the page “%s”, the site\'s home page.', 'kerf-blocks' ), esc_html( get_the_title( $page ) ) )
							/* translators: %s: page title. */
							: sprintf( esc_html__( 'It is the page “%s”.', 'kerf-blocks' ), esc_html( get_the_title( $page ) ) );
					}
					?>
				</p>
				<div class="kerf-actionbar">
					<?php if ( $page && ! $dry ) : ?>
						<a class="kerf-btn kerf-btn--primary" href="<?php echo esc_url( $front ? home_url( '/' ) : get_permalink( $page ) ); ?>" target="_blank" rel="noopener"><?php echo kerf_ui_icon( 'external' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'View it', 'kerf-blocks' ); ?></a>
						<a class="kerf-btn" href="<?php echo esc_url( get_edit_post_link( $page ) ); ?>"><?php esc_html_e( 'Edit it', 'kerf-blocks' ); ?></a>
					<?php endif; ?>
					<?php if ( $unresolved && ! $dry ) : ?>
						<a class="kerf-btn" href="<?php echo esc_url( admin_url( 'admin.php?page=kerf-links' ) ); ?>">
							<?php
							/* translators: %d: number of links. */
							echo esc_html( sprintf( _n( 'Point %d link at a page', 'Point %d links at pages', $unresolved, 'kerf-blocks' ), $unresolved ) );
							?>
						</a>
					<?php endif; ?>
					<a class="kerf-btn kerf-btn--quiet" href="<?php echo esc_url( admin_url( 'admin.php?page=kerf' ) ); ?>"><?php esc_html_e( 'Dashboard', 'kerf-blocks' ); ?></a>
				</div>
			</div>
		</div>
	</section>

	<section class="kerf-panel">
		<div class="kerf-panel__head"><h2><?php esc_html_e( 'What Kerf did', 'kerf-blocks' ); ?></h2></div>
		<div class="kerf-panel__body">
			<?php
			if ( ! empty( $result['actions'] ) ) {
				echo '<ul class="kerf-actions">';
				foreach ( $result['actions'] as $action ) {
					echo '<li>' . esc_html( $action ) . '</li>';
				}
				/**
				 * More lines at the end of an import's report — Kerf Pro reads a
				 * page of its own for its editor here. Each is an <li>.
				 *
				 * @param array $result The import's result (`scope`, `page_id`, `dry_run`…).
				 */
				do_action( 'kerf_import_report_items', $result );
				// What the design's scripts make (Tailwind's CSS, drawn icons)
				// only a browser can see: the home page is read for its editor
				// now, while the admin is here (assets/js/kerf-import-report.js,
				// inc/kerf-capture.php).
				if ( ! $dry && empty( $result['standalone'] ) ) {
					printf(
						'<li class="kerf-capture-after-import" data-url="%s" data-page="0" data-done="%s" data-failed="%s">%s</li>',
						esc_url( add_query_arg( 'kerf_measure', '1', home_url( '/' ) ) ),
						esc_attr__( 'Read the home page for its editor: what its scripts draw shows there too.', 'kerf-blocks' ),
						esc_attr__( 'Could not read the home page for its editor; a design styled by a script may look unstyled there until it is imported again.', 'kerf-blocks' ),
						esc_html__( 'Reading the home page for its editor…', 'kerf-blocks' )
					);
					// Without Kerf Pro the blog and the other pages keep the theme's look.
					if ( ! has_action( 'kerf_import_report_items' ) ) {
						echo '<li>' . esc_html__( 'Your blog, posts and search results use the theme\'s plain look. Kerf Pro gives them your design\'s fonts and colours.', 'kerf-blocks' ) . '</li>';
					}
				}
				echo '</ul>';
			}

			kerf_import_render_details( $result );
			?>
		</div>
	</section>
	<?php
	/**
	 * After an import's report — Kerf Pro explains it in plain words here.
	 *
	 * @param array $result The import's result (`audit`, `report`, `actions`, `dry_run`…).
	 */
	do_action( 'kerf_import_report_after', $result );
	echo '</div>';
}

/**
 * The report's details, folded: what was lost, what was moved, the blocks.
 *
 * @param array $result
 */
function kerf_import_render_details( $result ) {
	$audit = $result['audit'];

	// The persuasive part: exactly which selectors stopped matching.
	if ( ! empty( $audit['missing'] ) ) {
		echo '<details class="kerf-details" open><summary>'
			. sprintf(
				/* translators: %d: number of CSS selectors. */
				esc_html__( '%d selectors are no longer in the markup — CSS rules targeting these will not match', 'kerf-blocks' ),
				count( $audit['missing'] )
			)
			. '</summary><p class="kerf-inventory">';
		foreach ( $audit['missing'] as $name ) {
			echo '<code class="kerf-chip kerf-chip--fail">' . esc_html( $name ) . '</code>';
		}
		echo '</p></details>';
	}

	// Notes, by kind.
	$by_category = array();
	foreach ( (array) $result['report'] as $entry ) {
		$by_category[ $entry['category'] ][] = $entry['message'];
	}

	$labels = array(
		'preflight' => __( 'Checked before importing', 'kerf-blocks' ),
		'limit'     => __( 'Limits hit — the page is incomplete', 'kerf-blocks' ),
		'dropped'   => __( 'Left out', 'kerf-blocks' ),
		'media'     => __( 'Pictures not found', 'kerf-blocks' ),
		'asset'     => __( 'Moved to the design\'s styles and scripts', 'kerf-blocks' ),
		'converted' => __( 'Converted', 'kerf-blocks' ),
		'general'   => __( 'Notes', 'kerf-blocks' ),
	);

	foreach ( $labels as $category => $label ) {
		if ( empty( $by_category[ $category ] ) ) {
			continue;
		}
		$messages = array_unique( $by_category[ $category ] );
		printf(
			'<details class="kerf-details kerf-details--%s"><summary>%s (%d)</summary><ul>',
			esc_attr( $category ),
			esc_html( $label ),
			count( $messages )
		);
		foreach ( $messages as $message ) {
			echo '<li>' . esc_html( $message ) . '</li>';
		}
		echo '</ul></details>';
	}

	// Block inventory — "how much of this is actually editable".
	if ( ! empty( $audit['blocks'] ) ) {
		echo '<details class="kerf-details"><summary>' . esc_html__( 'Blocks made', 'kerf-blocks' ) . '</summary><p class="kerf-inventory">';
		foreach ( $audit['blocks'] as $name => $count ) {
			printf( '<span class="kerf-chip">%s <b>%d</b></span>', esc_html( $name ), (int) $count );
		}
		echo '</p></details>';
	}
}
