<?php
/**
 * Forms that send (§5.35).
 *
 * A contact form in an AI-made design posts nowhere: `action="#"`, no action
 * at all, or a Netlify form that only works on Netlify. The converter marks the
 * ones Kerf sends (`kerfForm`, kerf_mc_form_to_send()) and names their unnamed
 * fields; here the designer's own form is pointed at Kerf's handler, each
 * message is emailed, and the designer's thank-you and error messages
 * (`data-kerf-form-success`, `data-kerf-form-error`) are shown. Nothing is
 * added to the form: its address changes, and that is all — but for a form
 * with a file field, which gets the encoding that carries files. Each message
 * is also announced (`kerf_form_received`): Kerf Pro keeps it under Kerf →
 * Form entries (pro/inc/kerf-pro-forms.php).
 *
 * Without JavaScript the form posts and the page comes back with
 * `?kerf_form=sent`; with it (assets/js/kerf-forms.js) it sends in place.
 *
 * Spam: the form's address carries a signed timestamp, so a bot has to load the
 * page first; one address may send five messages in ten minutes; a message full
 * of links is spam and not emailed (Kerf Pro keeps it, marked). `kerf_form_is_spam`
 * adds checks (Akismet, a CAPTCHA plugin).
 *
 * Nothing is lost without a word. A message WordPress could not email — a host
 * that sends no mail is common — was answered "thank you" and gone: the
 * visitor is now told it did not go (unless something kept it, as Kerf Pro
 * does), and the owner sees why on the Dashboard and Settings, which can send
 * a test. Files chosen in a form were dropped as they arrived: they now go
 * with the email as attachments, within limits the visitor is told.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_FORMS_TO_OPTION   = 'kerf_forms_to';
const KERF_FORMS_MAIL_OPTION = 'kerf_forms_mail';

/**
 * Where the messages go.
 *
 * @return string
 */
function kerf_forms_recipient() {
	$to = sanitize_email( (string) get_option( KERF_FORMS_TO_OPTION, '' ) );
	return is_email( $to ) ? $to : (string) get_option( 'admin_email' );
}

// ─────────────────────────────────────────────────────────────────────────────
// The page
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Point a form Kerf sends at the handler, and show its result where the
 * designer put the message for it. Called by the Element and text renderers.
 *
 * @param array  $attrs   Block attributes.
 * @param string $content The element's rendered content (a form's fields).
 * @return array
 */
function kerf_forms_apply( $attrs, $content = '' ) {
	$custom = isset( $attrs['customAttributes'] ) && is_array( $attrs['customAttributes'] ) ? $attrs['customAttributes'] : array();

	if ( ! empty( $attrs['kerfForm'] ) && 'form' === strtolower( isset( $attrs['tagName'] ) ? (string) $attrs['tagName'] : '' ) ) {
		$custom['action'] = kerf_forms_action_url( (string) $attrs['kerfForm'] );
		$custom['method'] = 'post';
		unset( $custom['onsubmit'] );
		// A browser sends a file only as multipart/form-data, and AI-written
		// forms leave that out: the file arrived as its name.
		if ( kerf_forms_has_file_field( $content ) ) {
			$custom['enctype'] = 'multipart/form-data';
		}
		$attrs['customAttributes'] = $custom;
		if ( function_exists( 'kerf_enqueue_front_script' ) ) {
			kerf_enqueue_front_script( 'kerf-forms' );
		}
		return $attrs;
	}

	// After a send without JavaScript: the designer's message, shown.
	$state = isset( $_GET['kerf_form'] ) ? sanitize_key( wp_unslash( $_GET['kerf_form'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification -- a display state.
	if ( '' !== $state && ( array_key_exists( 'data-kerf-form-success', $custom ) || array_key_exists( 'data-kerf-form-error', $custom ) ) ) {
		$shows = array_key_exists( 'sent' === $state ? 'data-kerf-form-success' : 'data-kerf-form-error', $custom );
		if ( $shows ) {
			unset( $custom['hidden'] );
			$attrs['customAttributes'] = $custom;
		}
	}

	return $attrs;
}

/**
 * Does this markup hold a file field?
 *
 * @param string $html
 * @return bool
 */
function kerf_forms_has_file_field( $html ) {
	if ( '' === (string) $html || false === stripos( (string) $html, 'file' ) ) {
		return false;
	}
	$tags = new WP_HTML_Tag_Processor( (string) $html );
	while ( $tags->next_tag( 'INPUT' ) ) {
		if ( 'file' === strtolower( trim( (string) $tags->get_attribute( 'type' ) ) ) ) {
			return true;
		}
	}
	return false;
}

/**
 * The address a form sends to: admin-post, with which form, which page, and a
 * signed time — so a bot must load the page to send anything.
 *
 * @param string $form Form name.
 * @return string
 */
function kerf_forms_action_url( $form ) {
	$page = (int) get_queried_object_id();
	$time = time();
	return add_query_arg(
		array(
			'action'    => 'kerf_form',
			'kerf_form' => rawurlencode( $form ),
			'kerf_page' => $page,
			'kerf_t'    => $time,
			'kerf_s'    => kerf_forms_sign( $form, $page, $time ),
		),
		admin_url( 'admin-post.php' )
	);
}

/**
 * @param string $form
 * @param int    $page
 * @param int    $time
 * @return string
 */
function kerf_forms_sign( $form, $page, $time ) {
	return substr( hash_hmac( 'sha256', $form . '|' . (int) $page . '|' . (int) $time, wp_salt( 'nonce' ) ), 0, 20 );
}

// ─────────────────────────────────────────────────────────────────────────────
// Sending
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Receive a message: check, announce, email, answer.
 */
function kerf_forms_handle() {
	// A request larger than PHP accepts arrives with nothing in it, the fields
	// included: say the files were too big, not that the form was empty.
	$length = isset( $_SERVER['CONTENT_LENGTH'] ) ? (int) $_SERVER['CONTENT_LENGTH'] : 0;
	$limit  = wp_convert_hr_to_bytes( (string) ini_get( 'post_max_size' ) );
	if ( $length > 0 && $limit > 0 && $length > $limit && empty( $_POST ) && empty( $_FILES ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- only counted.
		$result = array(
			'ok'      => false,
			/* translators: %s: a size, e.g. "8 MB". */
			'message' => sprintf( __( 'The files are too large to send: everything together may be up to %s.', 'kerf-blocks' ), size_format( $limit ) ),
			'reason'  => true,
		);
	} else {
		$result = kerf_forms_receive( wp_unslash( $_GET ), wp_unslash( $_POST ), kerf_forms_uploads( $_FILES ) ); // phpcs:ignore WordPress.Security.NonceVerification -- signed address (kerf_forms_sign()); a public form takes no nonce, which page caching would break. $_FILES is never slashed.
	}

	$wants_json = isset( $_POST['kerf_js'] ) || false !== strpos( isset( $_SERVER['HTTP_ACCEPT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT'] ) ) : '', 'application/json' ); // phpcs:ignore WordPress.Security.NonceVerification
	if ( $wants_json ) {
		wp_send_json( array( 'ok' => $result['ok'], 'message' => $result['message'], 'reason' => ! empty( $result['reason'] ) ), $result['ok'] ? 200 : 400 );
	}

	$back = wp_get_referer();
	$back = $back ? $back : home_url( '/' );
	wp_safe_redirect( add_query_arg( 'kerf_form', $result['ok'] ? 'sent' : 'error', remove_query_arg( 'kerf_form', $back ) ) );
	exit;
}
add_action( 'admin_post_kerf_form', 'kerf_forms_handle' );
add_action( 'admin_post_nopriv_kerf_form', 'kerf_forms_handle' );

/**
 * The checks and the work, apart from the request so they can be tested.
 *
 * @param array $query   The address's parameters.
 * @param array $post    The fields sent.
 * @param array $uploads The files sent (kerf_forms_uploads()): real uploads only.
 * @return array{ok:bool,message:string,spam:bool,mailed:bool,reason:bool}
 */
function kerf_forms_receive( $query, $post, $uploads = array() ) {
	$fail = static function ( $message, $reason = false ) {
		return array( 'ok' => false, 'message' => $message, 'spam' => false, 'mailed' => false, 'reason' => $reason );
	};

	$form = isset( $query['kerf_form'] ) ? sanitize_key( (string) $query['kerf_form'] ) : '';
	$page = isset( $query['kerf_page'] ) ? (int) $query['kerf_page'] : 0;
	$time = isset( $query['kerf_t'] ) ? (int) $query['kerf_t'] : 0;
	$sign = isset( $query['kerf_s'] ) ? (string) $query['kerf_s'] : '';

	if ( '' === $form || ! hash_equals( kerf_forms_sign( $form, $page, $time ), $sign ) ) {
		return $fail( __( 'This form could not be sent. Reload the page and try again.', 'kerf-blocks' ) );
	}
	// A cached page keeps its address for a while; a month is plenty.
	if ( $time > time() + 60 || $time < time() - 30 * DAY_IN_SECONDS ) {
		return $fail( __( 'This page is too old to send from. Reload it and try again.', 'kerf-blocks' ) );
	}

	if ( ! kerf_forms_rate_ok() ) {
		return $fail( __( 'Too many messages from here in a short time. Please wait a few minutes.', 'kerf-blocks' ) );
	}

	$fields = kerf_forms_fields( $post );

	// The files: checked, then listed among the fields by the name of the field
	// they were chosen in, so the email, and a kept entry, say what came.
	$attach = kerf_forms_files( $uploads );
	if ( ! $attach['ok'] ) {
		return $fail( $attach['message'], true );
	}
	$listed = array();
	foreach ( $attach['files'] as $file ) {
		$key = '' !== $file['field'] ? $file['field'] : 'file';
		if ( isset( $fields[ $key ] ) && ! isset( $listed[ $key ] ) ) {
			$key .= '-file';
		}
		$line           = $file['name'] . ' (' . size_format( $file['size'] ) . ')';
		$fields[ $key ] = isset( $listed[ $key ] ) ? $fields[ $key ] . ', ' . $line : $line;
		$listed[ $key ] = true;
	}

	if ( ! array_filter( $fields, 'strlen' ) ) {
		return $fail( __( 'The form was empty.', 'kerf-blocks' ) );
	}
	foreach ( $fields as $name => $value ) {
		if ( preg_match( '/(?:^|[-_])e-?mail$/', $name ) && '' !== $value && ! is_email( $value ) ) {
			return $fail( __( 'That email address does not look right.', 'kerf-blocks' ) );
		}
	}

	$text  = implode( "\n", $fields );
	$links = preg_match_all( '#https?://#i', $text );
	/**
	 * Is this message spam? Spam is not emailed (Kerf Pro keeps it, marked).
	 *
	 * @param bool   $spam   Kerf's own guess: more than three links.
	 * @param array  $fields Field name => value.
	 * @param string $form   The form's name.
	 */
	$spam = (bool) apply_filters( 'kerf_form_is_spam', $links > 3, $fields, $form );

	/**
	 * A message has arrived and passed the checks. Kerf Pro keeps it under
	 * Kerf → Form entries, spam marked as such. Fired before the email, so a
	 * kept copy does not depend on the mail going out.
	 *
	 * @param string   $form   The form's name.
	 * @param int      $page   The page it was sent from (0: unknown).
	 * @param array    $fields Field name => value, plain text (a file: its name and size).
	 * @param bool     $spam   Taken for spam (and so not emailed).
	 * @param string[] $files  The names of the files sent with it, attached to the email.
	 */
	do_action( 'kerf_form_received', $form, $page, $fields, $spam, wp_list_pluck( $attach['files'], 'name' ) );

	$mailed = true;
	if ( ! $spam ) {
		$mail   = kerf_forms_email( $form, $page, $fields, $attach['files'] );
		$mailed = $mail['sent'];
		kerf_forms_mail_note( $mail['sent'], $mail['error'] );

		/**
		 * The message's email went out, or did not (and why).
		 *
		 * @param bool   $sent
		 * @param string $error WordPress's reason, when it did not.
		 * @param string $form
		 * @param int    $page
		 */
		do_action( 'kerf_form_mailed', $mail['sent'], $mail['error'], $form, $page );
	}

	if ( ! $mailed ) {
		/**
		 * Was this message kept somewhere the owner will read it — Kerf Pro's
		 * Form entries? Then the visitor is thanked although the email did not
		 * go; otherwise they are told, rather than thanked for nothing.
		 *
		 * @param bool   $kept
		 * @param string $form
		 * @param int    $page
		 * @param array  $fields
		 */
		$kept = (bool) apply_filters( 'kerf_form_kept', false, $form, $page, $fields );
		// The files went only with the email.
		if ( ! $kept || $attach['files'] ) {
			return $fail( __( 'Sorry — your message could not be sent. Please try again later, or reach us another way.', 'kerf-blocks' ) );
		}
	}

	return array( 'ok' => true, 'message' => __( 'Thank you — your message was sent.', 'kerf-blocks' ), 'spam' => $spam, 'mailed' => $mailed, 'reason' => false );
}

/**
 * The fields a visitor filled in: named, plain text, bounded.
 *
 * @param array $post
 * @return array<string,string>
 */
function kerf_forms_fields( $post ) {
	$fields = array();
	foreach ( (array) $post as $name => $value ) {
		$name = kerf_forms_field_name( $name );
		if ( '' === $name || 0 === strpos( $name, 'kerf_' ) || 0 === strpos( $name, '_' ) || in_array( $name, array( 'action', 'bot-field', 'form-name' ), true ) ) {
			continue;
		}
		if ( is_array( $value ) ) {
			$value = implode( ', ', array_map( 'strval', array_filter( $value, 'is_scalar' ) ) );
		}
		$fields[ $name ] = mb_substr( sanitize_textarea_field( (string) $value ), 0, 5000 );
		if ( count( $fields ) >= 40 ) {
			break;
		}
	}
	return $fields;
}

/**
 * A field's name as kept: letters, digits, - and _, lower case, 60 at most.
 *
 * @param string $name
 * @return string
 */
function kerf_forms_field_name( $name ) {
	return strtolower( substr( (string) preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $name ), 0, 60 ) );
}

/**
 * The files of a request, one entry per file: `name="cv"` and
 * `name="photos[]"` alike. A file that did not arrive keeps its error, so the
 * visitor hears why; one that did must be a real upload — anything else in
 * `$_FILES` is no file this request received.
 *
 * @param array $raw $_FILES.
 * @return array[] Each: field, name, tmp, size, error.
 */
function kerf_forms_uploads( $raw ) {
	$out = array();
	foreach ( (array) $raw as $field => $info ) {
		if ( ! is_array( $info ) || ! isset( $info['name'], $info['tmp_name'], $info['error'], $info['size'] ) ) {
			continue;
		}
		$names = (array) $info['name'];
		foreach ( array_keys( $names ) as $i ) {
			$name  = is_array( $info['name'] ) ? ( $info['name'][ $i ] ?? '' ) : $info['name'];
			$tmp   = is_array( $info['tmp_name'] ) ? ( $info['tmp_name'][ $i ] ?? '' ) : $info['tmp_name'];
			$error = is_array( $info['error'] ) ? ( $info['error'][ $i ] ?? UPLOAD_ERR_NO_FILE ) : $info['error'];
			$size  = is_array( $info['size'] ) ? ( $info['size'][ $i ] ?? 0 ) : $info['size'];
			// Deeper nesting (`a[b][c]`) is no field a design writes.
			if ( ! is_scalar( $name ) || ! is_scalar( $tmp ) || ! is_scalar( $error ) || ! is_scalar( $size ) ) {
				continue;
			}
			if ( UPLOAD_ERR_OK === (int) $error && ! is_uploaded_file( (string) $tmp ) ) {
				continue;
			}
			$out[] = array(
				'field' => kerf_forms_field_name( $field ),
				'name'  => (string) $name,
				'tmp'   => (string) $tmp,
				'size'  => (int) $size,
				'error' => (int) $error,
			);
		}
	}
	return $out;
}

/**
 * What a form may send: how many files, how large, of which kinds — the
 * documents and pictures a business asks for (a CV, a quote's drawings, a
 * photo of the problem), as WordPress names their types.
 *
 * @return array{count:int,size:int,total:int,types:array<string,string>}
 */
function kerf_forms_file_limits() {
	$want  = array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'heic', 'heif', 'pdf', 'doc', 'docx', 'odt', 'rtf', 'txt', 'csv', 'xls', 'xlsx', 'ods', 'ppt', 'pptx', 'odp' );
	$types = array();
	foreach ( wp_get_mime_types() as $exts => $mime ) {
		if ( array_intersect( explode( '|', $exts ), $want ) ) {
			$types[ $exts ] = $mime;
		}
	}

	/**
	 * What a design's forms may send by email. Most mail services refuse a
	 * message over 25 MB, attachments included.
	 *
	 * @param array $limits { count, size (bytes a file), total (bytes together), types (WordPress's ext pattern => MIME type) }.
	 */
	$limits = (array) apply_filters( 'kerf_form_file_limits', array(
		'count' => 5,
		'size'  => (int) min( wp_max_upload_size(), 10 * MB_IN_BYTES ),
		'total' => 20 * MB_IN_BYTES,
		'types' => $types,
	) );

	return array(
		'count' => max( 0, (int) ( $limits['count'] ?? 5 ) ),
		'size'  => max( 0, (int) ( $limits['size'] ?? 0 ) ),
		'total' => max( 0, (int) ( $limits['total'] ?? 0 ) ),
		'types' => isset( $limits['types'] ) && is_array( $limits['types'] ) ? $limits['types'] : $types,
	);
}

/**
 * Check the files a visitor sent. Their contents are checked against their
 * names (wp_check_filetype_and_ext()), so a script renamed `cv.pdf` is not
 * passed on.
 *
 * @param array[] $uploads From kerf_forms_uploads().
 * @return array{ok:bool,message:string,files:array[]} Each file: field, name, path, size.
 */
function kerf_forms_files( $uploads ) {
	$limits = kerf_forms_file_limits();
	$fail   = static function ( $message ) {
		return array( 'ok' => false, 'message' => $message, 'files' => array() );
	};
	$files  = array();
	$total  = 0;
	$names  = array();

	foreach ( (array) $uploads as $upload ) {
		$upload = wp_parse_args( (array) $upload, array( 'field' => '', 'name' => '', 'tmp' => '', 'size' => 0, 'error' => UPLOAD_ERR_NO_FILE ) );
		// A file field left empty.
		if ( UPLOAD_ERR_NO_FILE === (int) $upload['error'] || ( '' === (string) $upload['name'] && '' === (string) $upload['tmp'] ) ) {
			continue;
		}
		$label = sanitize_file_name( wp_basename( (string) $upload['name'] ) );
		$label = '' !== $label ? $label : __( 'A file', 'kerf-blocks' );

		if ( in_array( (int) $upload['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) || (int) $upload['size'] > $limits['size'] ) {
			/* translators: 1: a file name, 2: a size, e.g. "10 MB". */
			return $fail( sprintf( __( '%1$s is too large to send: a file may be up to %2$s.', 'kerf-blocks' ), $label, size_format( $limits['size'] ) ) );
		}
		if ( UPLOAD_ERR_OK !== (int) $upload['error'] || '' === (string) $upload['tmp'] || ! is_file( (string) $upload['tmp'] ) ) {
			/* translators: %s: a file name. */
			return $fail( sprintf( __( '%s did not arrive. Please try again.', 'kerf-blocks' ), $label ) );
		}
		if ( count( $files ) >= $limits['count'] ) {
			/* translators: %d: how many files. */
			return $fail( sprintf( _n( 'Please send at most %d file.', 'Please send at most %d files.', $limits['count'], 'kerf-blocks' ), $limits['count'] ) );
		}
		$check = wp_check_filetype_and_ext( (string) $upload['tmp'], wp_basename( (string) $upload['name'] ), $limits['types'] );
		if ( empty( $check['ext'] ) || empty( $check['type'] ) ) {
			/* translators: %s: a file name. */
			return $fail( sprintf( __( '%s cannot be sent: only pictures, PDF, Word, Excel, PowerPoint and text files can.', 'kerf-blocks' ), $label ) );
		}
		$total += (int) $upload['size'];
		if ( $total > $limits['total'] ) {
			/* translators: %s: a size, e.g. "20 MB". */
			return $fail( sprintf( __( 'The files are too large to send together: up to %s in all.', 'kerf-blocks' ), size_format( $limits['total'] ) ) );
		}

		// The name it arrives under: its own, with the extension its contents
		// have, never two alike in one email.
		$name = sanitize_file_name( wp_basename( ! empty( $check['proper_filename'] ) ? (string) $check['proper_filename'] : (string) $upload['name'] ) );
		$name = '' !== $name ? $name : 'file.' . $check['ext'];
		for ( $n = 2, $base = $name; isset( $names[ strtolower( $name ) ] ); $n++ ) {
			$name = $n . '-' . $base;
		}
		$names[ strtolower( $name ) ] = true;

		$files[] = array(
			'field' => (string) $upload['field'],
			'name'  => $name,
			'path'  => (string) $upload['tmp'],
			'size'  => (int) $upload['size'],
		);
	}

	return array( 'ok' => true, 'message' => '', 'files' => $files );
}

/**
 * At most five messages from one address in ten minutes. The address is kept
 * hashed, and only for those ten minutes.
 *
 * @return bool
 */
function kerf_forms_rate_ok() {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'kerf_form_' . substr( md5( $ip . wp_salt( 'nonce' ) ), 0, 16 );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		return false;
	}
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );
	return true;
}

/**
 * The fields as plain text, one per line.
 *
 * @param array $fields
 * @return string
 */
function kerf_forms_text( $fields ) {
	$lines = array();
	foreach ( $fields as $name => $value ) {
		$lines[] = ucfirst( str_replace( array( '-', '_' ), ' ', $name ) ) . ': ' . $value;
	}
	return implode( "\n", $lines );
}

/**
 * Email the message. Plain text; the visitor's address as Reply-To, never as
 * the sender (that is the site's, or the mail would be refused as spoofed);
 * the files attached under their own names.
 *
 * @param string  $form
 * @param int     $page
 * @param array   $fields
 * @param array[] $files From kerf_forms_files().
 * @return array{sent:bool,error:string}
 */
function kerf_forms_email( $form, $page, $fields, $files = array() ) {
	$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	/* translators: 1: site name, 2: form name. */
	$subject = sprintf( __( '[%1$s] New %2$s message', 'kerf-blocks' ), $site, $form );
	$body    = kerf_forms_text( $fields ) . "\n\n— "
		/* translators: %s: page address. */
		. sprintf( __( 'Sent from %s', 'kerf-blocks' ), $page ? get_permalink( $page ) : home_url( '/' ) );

	$headers = array();
	foreach ( $fields as $name => $value ) {
		if ( preg_match( '/(?:^|[-_])e-?mail$/', $name ) && is_email( $value ) ) {
			$headers[] = 'Reply-To: ' . sanitize_email( $value );
			break;
		}
	}

	$attachments = array();
	foreach ( (array) $files as $file ) {
		$attachments[ $file['name'] ] = $file['path'];
	}

	return kerf_forms_mail( kerf_forms_recipient(), $subject, $body, $headers, $attachments );
}

/**
 * wp_mail(), and why it failed when it did: WordPress answers only false, and
 * gives the reason — no mail server, a refused login — to `wp_mail_failed`.
 *
 * @param string $to
 * @param string $subject
 * @param string $body
 * @param array  $headers
 * @param array  $attachments Name => path.
 * @return array{sent:bool,error:string}
 */
function kerf_forms_mail( $to, $subject, $body, $headers = array(), $attachments = array() ) {
	$error = '';
	$catch = static function ( $wp_error ) use ( &$error ) {
		if ( is_wp_error( $wp_error ) ) {
			$error = $wp_error->get_error_message();
		}
	};
	add_action( 'wp_mail_failed', $catch );
	$sent = (bool) wp_mail( $to, $subject, $body, $headers, $attachments );
	remove_action( 'wp_mail_failed', $catch );

	if ( $sent ) {
		return array( 'sent' => true, 'error' => '' );
	}
	$error = trim( wp_strip_all_tags( (string) $error ) );
	return array( 'sent' => false, 'error' => '' !== $error ? mb_substr( $error, 0, 300 ) : __( 'WordPress could not send it, and did not say why.', 'kerf-blocks' ) );
}

// ─────────────────────────────────────────────────────────────────────────────
// Whether email goes out
// ─────────────────────────────────────────────────────────────────────────────

/**
 * When an email last went out and when one last could not, why, and which
 * came last.
 *
 * @return array{sent:int,failed:int,error:string,last:string}
 */
function kerf_forms_mail_status() {
	$status = get_option( KERF_FORMS_MAIL_OPTION, array() );
	$status = is_array( $status ) ? $status : array();
	return array(
		'sent'   => (int) ( $status['sent'] ?? 0 ),
		'failed' => (int) ( $status['failed'] ?? 0 ),
		'error'  => (string) ( $status['error'] ?? '' ),
		'last'   => (string) ( $status['last'] ?? '' ),
	);
}

/**
 * Note an email that went out, or one that could not.
 *
 * @param bool   $sent
 * @param string $error
 */
function kerf_forms_mail_note( $sent, $error = '' ) {
	$status = kerf_forms_mail_status();
	if ( $sent ) {
		$status['sent'] = time();
	} else {
		$status['failed'] = time();
		$status['error']  = mb_substr( (string) $error, 0, 300 );
	}
	// Which came last: two in the same second have the same time.
	$status['last'] = $sent ? 'sent' : 'failed';
	update_option( KERF_FORMS_MAIL_OPTION, $status, false );
}

/**
 * The last email could not be sent, and none has gone out since: the status,
 * or null when all is well.
 *
 * @return array|null
 */
function kerf_forms_mail_failing() {
	$status = kerf_forms_mail_status();
	if ( '' !== $status['last'] ) {
		return 'failed' === $status['last'] && $status['failed'] ? $status : null;
	}
	return $status['failed'] && $status['failed'] > $status['sent'] ? $status : null;
}

/**
 * "Send a test email", from Kerf → Settings: to the address messages go to.
 * Handled once per request; the forms' row shows what happened.
 *
 * @return array{sent?:bool,error?:string,to?:string} Empty when no test was asked for.
 */
function kerf_forms_test_result() {
	static $result = null;
	if ( null !== $result ) {
		return $result;
	}
	$result = array();

	if ( empty( $_POST['kerf_mail_test'] ) || ! current_user_can( 'edit_theme_options' ) ) {
		return $result;
	}
	if ( ! isset( $_POST['kerf_mail_test_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_mail_test_nonce'] ) ), 'kerf_mail_test' ) ) {
		return $result;
	}

	$to   = kerf_forms_recipient();
	$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$mail = kerf_forms_mail(
		$to,
		/* translators: %s: site name. */
		sprintf( __( '[%s] A test email from Kerf', 'kerf-blocks' ), $site ),
		/* translators: %s: the site's address. */
		sprintf( __( "This is a test email from Kerf, sent from %s.\n\nIt arrived, so messages from your design's forms reach this address too.", 'kerf-blocks' ), home_url( '/' ) )
	);
	kerf_forms_mail_note( $mail['sent'], $mail['error'] );

	$result = array( 'sent' => $mail['sent'], 'error' => $mail['error'], 'to' => $to );
	return $result;
}

/**
 * The test's own form, after the settings form: its button sits in the forms'
 * row (`form="kerf-mail-test"`), outside the settings form, so pressing Enter
 * in a setting still saves and sends nothing.
 */
function kerf_forms_test_form() {
	?>
	<form id="kerf-mail-test" method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=kerf-settings' ) . '#kerf-forms' ); ?>" hidden>
		<input type="hidden" name="kerf_mail_test" value="1">
		<?php wp_nonce_field( 'kerf_mail_test', 'kerf_mail_test_nonce', false ); ?>
	</form>
	<?php
}
add_action( 'kerf_settings_after_form', 'kerf_forms_test_form' );

/**
 * Where messages go, on Kerf → Settings.
 */
function kerf_forms_settings_register() {
	register_setting( 'kerf_settings', KERF_FORMS_TO_OPTION, array(
		'type'              => 'string',
		'default'           => '',
		'sanitize_callback' => static function ( $value ) {
			$value = sanitize_email( (string) $value );
			return is_email( $value ) ? $value : '';
		},
	) );
}
add_action( 'admin_init', 'kerf_forms_settings_register' );

/**
 * The field, inside the settings form: where messages go, whether they went,
 * and a test.
 */
function kerf_forms_settings_section() {
	$test    = kerf_forms_test_result();
	$failing = kerf_forms_mail_failing();
	$keeps   = (bool) has_action( 'kerf_form_received' );
	/**
	 * Filter whether something keeps each message that arrives now — Kerf
	 * Pro's Form entries, while its licence lets it. Something listening to
	 * `kerf_form_received` is not enough: a lapsed licence listens and keeps
	 * nothing, and "every message waits under Form entries" would be a promise
	 * that loses them.
	 *
	 * @param bool $kept
	 */
	$kept = (bool) apply_filters( 'kerf_forms_keeps', false );

	kerf_ui_setting_open(
		__( 'Form messages go to', 'kerf-blocks' ),
		// Whoever keeps the messages says so on their own screen.
		$keeps
			? __( 'Your design\'s contact and booking forms send through Kerf: each message is emailed here, with any files sent in it attached.', 'kerf-blocks' )
			: __( 'Your design\'s contact and booking forms send through Kerf: each message is emailed here, with any files sent in it attached. Kerf Pro also keeps every message under Form entries, spam set apart.', 'kerf-blocks' )
	);
	?>
	<div class="kerf-field" id="kerf-forms">
		<?php
		// kerf_ui_note() escapes what it is given.
		if ( $test && $test['sent'] ) {
			/* translators: %s: an email address. */
			$note = kerf_ui_note( sprintf( __( 'A test email was sent to %s. If it has not arrived in a few minutes, look in the spam folder: a message that lands there needs the mail setup below.', 'kerf-blocks' ), $test['to'] ), 'ok' );
		} elseif ( $test ) {
			/* translators: %s: WordPress's reason. */
			$note = kerf_ui_note( sprintf( __( 'The test email could not be sent: %s', 'kerf-blocks' ), $test['error'] ), 'bad' );
		} elseif ( $failing ) {
			/* translators: 1: how long ago, e.g. "2 hours", 2: WordPress's reason. */
			$note = kerf_ui_note( sprintf( __( 'The last message, %1$s ago, could not be emailed: %2$s', 'kerf-blocks' ), human_time_diff( $failing['failed'] ), $failing['error'] ), 'bad' );
		} else {
			$note = '';
		}
		echo $note; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kerf_ui_note() escapes.
		?>
		<label class="screen-reader-text" for="kerf_forms_to"><?php esc_html_e( 'Email address', 'kerf-blocks' ); ?></label>
		<input type="email" name="<?php echo esc_attr( KERF_FORMS_TO_OPTION ); ?>" id="kerf_forms_to"
			value="<?php echo esc_attr( (string) get_option( KERF_FORMS_TO_OPTION, '' ) ); ?>" placeholder="<?php echo esc_attr( (string) get_option( 'admin_email' ) ); ?>">
		<p class="kerf-help"><?php esc_html_e( 'Left empty, the site\'s admin email address.', 'kerf-blocks' ); ?></p>
		<?php if ( $failing || ( $test && ! $test['sent'] ) ) : ?>
			<p class="kerf-help">
				<?php
				echo esc_html( $kept
					? __( 'Many hosts send no email from WordPress until it is set up: a mail plugin such as WP Mail SMTP or FluentSMTP does that. Then send a test. Meanwhile every message waits under Form entries.', 'kerf-blocks' )
					: __( 'Many hosts send no email from WordPress until it is set up: a mail plugin such as WP Mail SMTP or FluentSMTP does that. Then send a test. Until then, visitors are told their message could not be sent.', 'kerf-blocks' ) );
				?>
			</p>
		<?php endif; ?>
		<p>
			<button type="submit" form="kerf-mail-test" class="kerf-btn">
				<?php
				/* translators: %s: an email address. */
				echo esc_html( sprintf( __( 'Send a test email to %s', 'kerf-blocks' ), kerf_forms_recipient() ) );
				?>
			</button>
		</p>
	</div>
	<?php
	kerf_ui_setting_close();
}
add_action( 'kerf_settings_sections', 'kerf_forms_settings_section' );
