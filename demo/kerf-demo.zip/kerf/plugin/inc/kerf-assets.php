<?php
/**
 * The mockup's own stylesheets and scripts.
 *
 * THE MODEL: the mockup's assets ARE the site's assets. Kerf ships no icon font,
 * no grid system, no component CSS and no behaviour — it takes what the designer
 * linked in their `<head>`, keeps it in the order they wrote it, and enqueues it
 * properly.
 *
 * That single decision is what lets the converter promise to change nothing.
 * Icons are the clearest case: the reference implementation bundled Font Awesome
 * and rewrote `ri-home-line` into `fa-house` on the way through, so every glyph
 * outside its mapping table silently became a blank square and the designer's
 * own icon stylesheet — sitting right there in the mockup — went unused. Import
 * the stylesheet instead and the rewrite is unnecessary: the classes pass
 * through untouched and the glyph renders because the CSS that draws it is on
 * the page.
 *
 * ORDER IS THE WHOLE GAME. CSS is a cascade and a mockup's `<head>` is an
 * ordered document: a reset before a framework before the theme sheet, with an
 * inline `<style>` wedged between two of them. Re-emitting those as an unordered
 * set produces a page that is subtly, unfixably wrong. So every asset is
 * registered with the previous one as its dependency, and inline blocks attach
 * to the file they followed — WordPress' own dependency graph then guarantees
 * the original sequence.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option holding the ordered asset list.
 */
const KERF_ASSETS_OPTION = 'kerf_assets';

/**
 * Option holding the mockup's `<body>` class, id and other attributes.
 */
const KERF_BODY_OPTION = 'kerf_body_attributes';

/**
 * Option: the pages with a design of their own — kerf_asset_sets().
 */
const KERF_ASSET_SETS_OPTION = 'kerf_asset_sets';

/**
 * Option controlling how much of WordPress' own CSS is allowed onto the page.
 */
const KERF_CORE_CSS_OPTION = 'kerf_core_css';

/**
 * Subdirectory of uploads/ for new imports. Older files stay where they were.
 */
const KERF_ASSETS_DIR = 'kerf-blocks';

// ═══════════════════════════════════════════════════════════════════════════════
// EXTRACTION
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Pull every stylesheet, script and head hint out of a mockup document.
 *
 * Returns one flat, ordered list rather than separate css/js arrays, because the
 * order between them is sometimes load-bearing — an inline `<script>` that sets
 * a theme class before the stylesheet paints, for instance.
 *
 * @param string $html     Full mockup document.
 * @param string $base_url Absolute URL the mockup came from, for relative paths.
 * @return array[] Each: { type, kind, src, content, position, media, attrs }.
 */
function kerf_assets_extract( $html, $base_url = '' ) {
	$html = (string) $html;
	$out  = array();

	// Split head from body so each asset is remembered with the position it was
	// written in. A script at the end of <body> expects the DOM to exist; moving
	// it into <head> breaks it, and that failure is invisible until a widget
	// silently stops initialising.
	$head = '';
	if ( preg_match( '#<head\b[^>]*>(.*?)</head>#is', $html, $m ) ) {
		$head = $m[1];
	}
	$body = $html;
	if ( preg_match( '#<body\b[^>]*>(.*?)</body>#is', $html, $m ) ) {
		$body = $m[1];
	}

	foreach ( array( 'head' => $head, 'footer' => $body ) as $position => $chunk ) {
		if ( '' === trim( $chunk ) ) {
			continue;
		}
		foreach ( kerf_assets_scan( $chunk, $position, $base_url ) as $asset ) {
			$out[] = $asset;
		}
	}

	return $out;
}

/**
 * Scan one region of a document for assets, in source order.
 *
 * @param string $chunk    Markup to scan.
 * @param string $position 'head' or 'footer'.
 * @param string $base_url Absolute URL for resolving relative paths.
 * @return array[]
 */
function kerf_assets_scan( $chunk, $position, $base_url ) {
	$out = array();

	// An inline <svg> may legitimately contain its own <script>, and that script
	// belongs to the graphic, not to the page. Capturing it here would re-enqueue
	// as a first-class site script exactly the code kerf_sanitize_svg_markup()
	// exists to strip — the sanitizer would keep doing its job on the block while
	// the same bytes ran from a <script> tag in the footer.
	//
	// <template> and <noscript> are stripped for the same reason: their contents
	// are inert markup that something else decides what to do with, and a
	// <noscript> fallback stylesheet must stay inside its <noscript>.
	$chunk = preg_replace( '#<(svg|template|noscript)\b[^>]*>.*?</\1\s*>#is', '', (string) $chunk );

	// Opening tags only, matched in one pass so the relative order of links,
	// styles and scripts survives — a separate regex per type would return three
	// correctly-ordered lists that cannot be merged back into the one order that
	// mattered.
	//
	// Matching the OPEN tag rather than open-plus-close is what makes <link>
	// work: it is a void element, so it has neither a closing tag nor (usually) a
	// self-closing slash, and a pattern requiring either one silently skipped
	// every stylesheet in the document.
	//
	// What a comment holds is not on the page: an old Internet Explorer's
	// `<!--[if lt IE 9]><script src="html5shiv.js">` and a stylesheet a
	// designer commented out were imported and loaded on every page — the
	// shiv from a CDN long gone, in <head>, holding the page up (scar 114). Nor is what
	// a script or a style holds: a `'<link …>'` written in a script's string
	// is the script's. So the tags are found one after the other, skipping
	// each comment and each container's content. (A comment ends at `-->`,
	// `--!>`, or at once as `<!-->` and `<!--->`, as a browser ends it.)
	$pattern = '#<!--(?:>|->|.*?(?:--!?>|\z))|<(link|style|script)\b((?:"[^"]*"|\'[^\']*\'|[^>])*)>#is';

	$matches = array();
	$offset  = 0;
	while ( preg_match( $pattern, $chunk, $found, PREG_OFFSET_CAPTURE, $offset ) ) {
		$offset = $found[0][1] + strlen( $found[0][0] );
		if ( 0 === strpos( $found[0][0], '<!--' ) ) {
			continue;
		}
		$name = strtolower( $found[1][0] );
		if ( 'link' !== $name && '/' !== substr( rtrim( $found[2][0] ), -1 ) && preg_match( '#</' . $name . '\s*>#i', $chunk, $close, PREG_OFFSET_CAPTURE, $offset ) ) {
			$offset = $close[0][1] + strlen( $close[0][0] );
		}
		$matches[] = $found;
	}
	if ( ! $matches ) {
		return $out;
	}

	foreach ( $matches as $match ) {
		$tag   = strtolower( $match[1][0] );
		$attrs = kerf_assets_parse_attributes( $match[2][0] );

		// For the container elements, take everything up to the matching close.
		$content = '';
		if ( 'link' !== $tag && '/' !== substr( rtrim( $match[2][0] ), -1 ) ) {
			$body_start = $match[0][1] + strlen( $match[0][0] );
			if ( preg_match( '#</' . $tag . '\s*>#i', $chunk, $close, PREG_OFFSET_CAPTURE, $body_start ) ) {
				$content = substr( $chunk, $body_start, $close[0][1] - $body_start );
			}
		}

		if ( 'link' === $tag ) {
			$rel = isset( $attrs['rel'] ) ? strtolower( $attrs['rel'] ) : '';
			$href = isset( $attrs['href'] ) ? trim( $attrs['href'] ) : '';

			if ( '' === $href ) {
				continue;
			}

			if ( 'stylesheet' === $rel ) {
				$out[] = array(
					'type'     => 'css',
					'kind'     => 'file',
					'src'      => kerf_assets_absolutize( $href, $base_url ),
					'content'  => '',
					'position' => $position,
					'media'    => isset( $attrs['media'] ) ? $attrs['media'] : 'all',
					'attrs'    => array(),
				);
				continue;
			}

			// Resource hints and the favicon are cheap to keep and visibly wrong
			// to lose — a missing preconnect costs a round trip on the font CDN,
			// a missing icon shows a blank browser tab.
			if ( in_array( $rel, array( 'preconnect', 'dns-prefetch', 'preload', 'icon', 'shortcut icon', 'apple-touch-icon', 'manifest' ), true ) ) {
				$out[] = array(
					'type'     => 'hint',
					'kind'     => 'file',
					'src'      => kerf_assets_absolutize( $href, $base_url ),
					'content'  => '',
					'position' => 'head',
					'media'    => '',
					'attrs'    => $attrs,
				);
			}
			continue;
		}

		if ( 'style' === $tag ) {
			if ( '' === trim( $content ) ) {
				continue;
			}
			// `<style type="text/tailwindcss">` is not CSS the browser applies:
			// it is what Tailwind's script reads — `@theme`, `@apply`. Printed as
			// an ordinary stylesheet it did nothing, Tailwind never saw it, and a
			// design's buttons, colours and fonts were gone (a SaaS page measured
			// 8% identical). Kept with its type, printed by kerf_assets_print_typed_styles().
			$style_type = isset( $attrs['type'] ) ? strtolower( trim( $attrs['type'] ) ) : '';
			$typed      = '' !== $style_type && 'text/css' !== $style_type && preg_match( '#^text/[a-z0-9.+-]+$#', $style_type );
			$out[] = array(
				'type'     => $typed ? 'typed-style' : 'css',
				'kind'     => 'inline',
				'src'      => '',
				'content'  => $content,
				'position' => $typed ? 'head' : $position,
				'media'    => isset( $attrs['media'] ) ? $attrs['media'] : 'all',
				'attrs'    => $typed ? array( 'type' => $style_type ) : array(),
			);
			continue;
		}

		// <script>.
		$type = isset( $attrs['type'] ) ? strtolower( trim( $attrs['type'] ) ) : '';
		$src  = isset( $attrs['src'] ) ? trim( $attrs['src'] ) : '';
		$tag  = kerf_assets_script_tag_attributes( $attrs );

		// An import map says where a module's `import 'three'` comes from: lost,
		// every module importing by name threw ("Failed to resolve module
		// specifier"), as a design built on Three.js's examples does (scar
		// 112). Printed before the modules (kerf_assets_print_import_map()).
		if ( 'importmap' === $type ) {
			if ( '' === $src && '' !== trim( $content ) ) {
				$out[] = array(
					'type'     => 'importmap',
					'kind'     => 'inline',
					'src'      => '',
					'content'  => $content,
					'position' => 'head',
					'media'    => '',
					'attrs'    => array(),
				);
			}
			continue;
		}

		// A type that is not JavaScript is data a script reads — a JSON block,
		// a template, a shader — inert, and kept where it was written, with its
		// id: the converter puts a kerf/script block there (a head's are
		// printed in the head, kerf_assets_print_data_scripts()). Dropped, the
		// script reading it stopped at `null`. JSON-LD alone is not kept: it
		// describes the mockup's sample business, and on WordPress an SEO
		// plugin writes it (kerf_mc_data_script_message()).
		if ( ! kerf_mc_is_js_type( $type ) ) {
			if ( kerf_mc_is_kept_data_script( $type ) && '' === $src && '' !== trim( $content ) ) {
				$out[] = array(
					'type'     => 'data',
					'kind'     => 'inline',
					'src'      => '',
					'content'  => $content,
					'position' => 'footer' === $position ? 'inplace' : 'head',
					'media'    => '',
					'attrs'    => array( 'ref' => kerf_mc_script_ref( $content ), 'type' => $type, 'tag' => $tag ),
				);
			}
			continue;
		}

		// A body script that writes into the page is not a footer script: the
		// converter puts a kerf/script block where it was written, and that
		// block prints this record. See kerf_mc_is_inplace_script().
		if ( '' === $src && 'footer' === $position && 'module' !== $type && kerf_mc_is_inplace_script( $content ) ) {
			$out[] = array(
				'type'     => 'js',
				'kind'     => 'inline',
				'src'      => '',
				'content'  => $content,
				'position' => 'inplace',
				'media'    => '',
				'attrs'    => array( 'ref' => kerf_mc_script_ref( $content ), 'tag' => $tag ),
			);
			continue;
		}

		$out[] = array(
			'type'     => 'js',
			'kind'     => ( '' !== $src ) ? 'file' : 'inline',
			'src'      => ( '' !== $src ) ? kerf_assets_absolutize( $src, $base_url ) : '',
			'content'  => ( '' === $src ) ? $content : '',
			'position' => $position,
			'media'    => '',
			'attrs'    => array(
				'defer'  => isset( $attrs['defer'] ),
				'async'  => isset( $attrs['async'] ),
				'module' => ( 'module' === $type ),
				'tag'    => $tag,
			),
		);
	}

	return $out;
}

/**
 * A `<script>`'s own attributes beyond those the asset records itself (src,
 * type, defer, async): its `id`, `data-*`, `nomodule`, `crossorigin` and the
 * like, printed back on the tag (kerf_assets_tag_attributes()). A widget that
 * reads its settings off its own tag — `document.currentScript.dataset`, or
 * `getElementById( 'its-id' )` — found nothing; an old browser's `nomodule`
 * fallback ran in every new browser beside the module it stands in for.
 * Names are held to the converter's shape rule; values are printed escaped.
 *
 * @param array<string,string> $attrs From kerf_assets_parse_attributes().
 * @return array<string,string|true> Name ⇒ value, true for a valueless one.
 */
function kerf_assets_script_tag_attributes( $attrs ) {
	$out = array();
	foreach ( (array) $attrs as $name => $value ) {
		$name = strtolower( (string) $name );
		if ( in_array( $name, array( 'src', 'type', 'defer', 'async', 'language', 'nonce' ), true ) || ! kerf_mc_attribute_name_ok( $name ) ) {
			continue;
		}
		$out[ $name ] = ( '' === $value && in_array( $name, array( 'nomodule', 'crossorigin', 'blocking' ), true ) ) ? true : (string) $value;
	}
	return $out;
}

/**
 * Report entries for the `<head>`'s scripts that are not JavaScript, which are
 * not imported. The body's are reported by the converter, which meets them
 * where they stand; the head never reaches it — and the head is where JSON-LD
 * usually is.
 *
 * @param string $html Full mockup document.
 * @return array[]
 */
function kerf_assets_data_script_report( $html ) {
	$types = array();
	if ( preg_match( '#<head\b[^>]*>(.*?)</head>#is', (string) $html, $m )
		&& preg_match_all( '#<script\b((?:"[^"]*"|\'[^\']*\'|[^>])*)>#i', (string) preg_replace( array( '#<!--.*?(?:-->|\z)#s', '#<(svg|template|noscript)\b[^>]*>.*?</\1\s*>#is' ), '', $m[1] ), $tags ) ) {
		foreach ( $tags[1] as $attr_string ) {
			$attrs = kerf_assets_parse_attributes( $attr_string );
			$type  = isset( $attrs['type'] ) ? strtolower( trim( $attrs['type'] ) ) : '';
			// An import map and a data block are kept, as scripts are
			// (kerf_assets_scan()); the report names what is not.
			if ( ! kerf_mc_is_js_type( $type ) && 'importmap' !== $type && ! kerf_mc_is_kept_data_script( $type ) ) {
				$types[] = $type;
			}
		}
	}

	$report = array();
	foreach ( array_count_values( $types ) as $type => $count ) {
		$report[] = array( 'category' => 'dropped', 'message' => kerf_mc_data_script_message( $type ) . ( $count > 1 ? " (×$count)" : '' ) );
	}
	return $report;
}

/**
 * Parse an HTML tag's attribute string into a map.
 *
 * Valueless attributes (`defer`, `async`) map to ''. Presence is what matters
 * for those, so callers test with isset().
 *
 * @param string $attr_string
 * @return array<string,string>
 */
function kerf_assets_parse_attributes( $attr_string ) {
	$out = array();

	if ( preg_match_all(
		'/([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+)))?/',
		(string) $attr_string,
		$m,
		PREG_SET_ORDER
	) ) {
		foreach ( $m as $pair ) {
			$name = strtolower( $pair[1] );
			if ( isset( $pair[2] ) && '' !== $pair[2] ) {
				$out[ $name ] = $pair[2];
			} elseif ( isset( $pair[3] ) && '' !== $pair[3] ) {
				$out[ $name ] = $pair[3];
			} elseif ( isset( $pair[4] ) && '' !== $pair[4] ) {
				$out[ $name ] = $pair[4];
			} else {
				$out[ $name ] = '';
			}
		}
	}

	return $out;
}

/**
 * Resolve a possibly-relative asset URL against the mockup's source URL.
 *
 * With no base URL the value is returned untouched — the import pipeline then
 * matches it against the uploaded ZIP by path, which is the normal case.
 *
 * @param string $url
 * @param string $base_url
 * @return string
 */
function kerf_assets_absolutize( $url, $base_url ) {
	$url = trim( (string) $url );

	if ( '' === $url || '' === (string) $base_url ) {
		return $url;
	}
	if ( preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//)#i', $url ) ) {
		return $url;
	}

	$parts = wp_parse_url( $base_url );
	if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return $url;
	}

	$origin = $parts['scheme'] . '://' . $parts['host'] . ( empty( $parts['port'] ) ? '' : ':' . $parts['port'] );

	if ( 0 === strpos( $url, '/' ) ) {
		return $origin . $url;
	}

	$dir = isset( $parts['path'] ) ? preg_replace( '#/[^/]*$#', '/', $parts['path'] ) : '/';

	return $origin . $dir . $url;
}

// ═══════════════════════════════════════════════════════════════════════════════
// STORAGE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The stored asset list.
 *
 * @return array[]
 */
function kerf_assets_get() {
	$assets = get_option( KERF_ASSETS_OPTION, array() );
	return is_array( $assets ) ? $assets : array();
}

/**
 * Replace the stored asset list.
 *
 * @param array[] $assets
 * @return bool
 */
function kerf_assets_save( $assets ) {
	return update_option( KERF_ASSETS_OPTION, array_values( (array) $assets ), false );
}

/**
 * What was added to one page in WordPress — a pasted section's styles (Kerf
 * Pro's Convert HTML), the CSS AI wrote for a page — carried into a new asset
 * list: it is that page's, not the design's, and a design imported or updated
 * would otherwise take it from a page it does not touch. Marked `added` by
 * whoever added it; only what loads on pages is carried (a template or the
 * header is written again by an import), and not onto a page the import
 * writes over: what was added to it goes with what it held.
 *
 * @param array[] $assets  The new list.
 * @param int[]   $written Pages the import writes.
 * @return array[]
 */
function kerf_assets_carry_added( $assets, $written = array() ) {
	$written = array_map( 'intval', (array) $written );
	$assets  = array_values( (array) $assets );
	foreach ( kerf_assets_get() as $asset ) {
		if ( empty( $asset['added'] ) || empty( $asset['only']['pages'] ) ) {
			continue;
		}
		$pages = array_values( array_diff( array_map( 'intval', (array) $asset['only']['pages'] ), $written ) );
		if ( ! $pages ) {
			continue;
		}
		$asset['only']['pages'] = $pages;
		$assets[]               = $asset;
	}
	return $assets;
}

/**
 * The pages with a design of their own (§5.39): page ID => their set — the
 * assets, the `<html>`/`<body>` attributes, where the files were staged, what
 * the editor needs drawn (inc/kerf-capture.php).
 *
 * A design imported as "a page of its own" — a landing page from another AI
 * tool, a campaign — used to replace the site's one asset list, and every
 * other page lost its styles to it. Its set loads on its page alone, and the
 * site's on every other.
 *
 * @return array[]
 */
function kerf_asset_sets() {
	$sets = get_option( KERF_ASSET_SETS_OPTION, array() );
	return is_array( $sets ) ? $sets : array();
}

/**
 * Keep a page's own design, or drop it (null).
 *
 * @param int        $page_id
 * @param array|null $set
 */
function kerf_asset_set_save( $page_id, $set ) {
	$sets = kerf_asset_sets();
	if ( null === $set ) {
		if ( ! isset( $sets[ (int) $page_id ] ) ) {
			return;
		}
		unset( $sets[ (int) $page_id ] );
	} else {
		$sets[ (int) $page_id ] = $set;
	}
	update_option( KERF_ASSET_SETS_OPTION, $sets, false );
}

/**
 * The design a page is dressed in: its own set, or the site's.
 *
 * Everything that prints a design's assets or attributes asks this — the
 * enqueue, the hints, the typed styles, `<html>` and `<body>`, kerf/script,
 * the editor's styles — never the site's options directly.
 *
 * @param int|null $post_id The page; null for this request's.
 * @return array{page:int,assets:array[],body:array,html:array,version:string,staging:array,captured:?array}
 */
function kerf_assets_design( $post_id = null ) {
	if ( null === $post_id ) {
		$post_id = is_singular() ? (int) get_queried_object_id() : 0;
	}

	$sets = $post_id ? kerf_asset_sets() : array();
	if ( isset( $sets[ (int) $post_id ] ) && is_array( $sets[ (int) $post_id ] ) ) {
		$set = $sets[ (int) $post_id ];
		return array(
			'page'     => (int) $post_id,
			'assets'   => isset( $set['assets'] ) && is_array( $set['assets'] ) ? $set['assets'] : array(),
			'body'     => isset( $set['body'] ) && is_array( $set['body'] ) ? $set['body'] : array(),
			'html'     => isset( $set['html'] ) && is_array( $set['html'] ) ? $set['html'] : array(),
			'version'  => isset( $set['version'] ) ? (string) $set['version'] : '1',
			'staging'  => isset( $set['staging'] ) && is_array( $set['staging'] ) ? $set['staging'] : array(),
			'captured' => isset( $set['captured'] ) && is_array( $set['captured'] ) ? $set['captured'] : array(),
		);
	}

	$body = get_option( KERF_BODY_OPTION, array() );
	$html = get_option( KERF_HTML_OPTION, array() );
	$last = get_option( 'kerf_last_staging', array() );
	return array(
		'page'     => 0,
		'assets'   => kerf_assets_get(),
		'body'     => is_array( $body ) ? $body : array(),
		'html'     => is_array( $html ) ? $html : array(),
		'version'  => (string) get_option( 'kerf_assets_version', '1' ),
		'staging'  => is_array( $last ) ? $last : array(),
		// The site's is its own option (KERF_CAPTURE_OPTION); null says so.
		'captured' => null,
	);
}

/**
 * A page deleted for good takes its design with it. (Trashed, it keeps it: a
 * page can come back.)
 *
 * @param int $post_id
 */
function kerf_asset_set_forget( $post_id ) {
	kerf_asset_set_save( (int) $post_id, null );
}
add_action( 'deleted_post', 'kerf_asset_set_forget' );

/**
 * May the current user put scripts on the site?
 *
 * A mockup's scripts run in every visitor's browser — a super admin's too,
 * where they can do anything that super admin can. WordPress's rule for adding
 * code like that is `unfiltered_html`: on a network only a super admin has it,
 * and on a site that defines DISALLOW_UNFILTERED_HTML nobody does. Kerf's
 * import, its update and its staged files keep to the same rule (§5.32);
 * `edit_theme_options`, which a network's site admins have, is not enough.
 *
 * @return bool
 */
function kerf_user_can_add_scripts() {
	return current_user_can( 'unfiltered_html' );
}

/**
 * May the current user import a design, including its stylesheets and scripts?
 *
 * Additional CSS and the Custom HTML block let only a user with unfiltered_html
 * add this code; core's media library lets only that user upload .js files
 * (get_allowed_mime_types()). Import follows the same rule, alongside permission
 * to change the site's design. DISALLOW_UNFILTERED_HTML therefore switches
 * import off, and on a network only a super admin may import (§5.32).
 *
 * @return bool
 */
function kerf_user_can_import() {
	return current_user_can( 'edit_theme_options' ) && current_user_can( 'unfiltered_html' );
}

/**
 * Why an administrator WordPress does not trust with code cannot import.
 *
 * Shared by the import screen, its refusal and the Dashboard, so the menu can
 * stay visible to a network's site administrator and explain what is needed.
 *
 * @return string
 */
function kerf_import_permission_message() {
	return __( 'Importing a design adds its stylesheets and scripts to your site. WordPress lets only users who may add code do this. On a network, that is the network\'s super admin. If your host has turned off adding code, nobody can import a design.', 'kerf-blocks' );
}

/**
 * Is this asset a script: a file, an inline block, or one printed where it was
 * written? (A `raw-head` entry from before session 8 is data nothing prints.)
 *
 * @param array $asset
 * @return bool
 */
function kerf_assets_is_script( $asset ) {
	// An import map decides where modules come from, and a data block feeds a
	// script: both are a script's, and follow its rule.
	return in_array( isset( $asset['type'] ) ? $asset['type'] : '', array( 'js', 'importmap', 'data' ), true );
}

/**
 * The asset list the current user may save, from a new one.
 *
 * Someone who can add scripts saves the new list as it is. Anyone else saves
 * the new stylesheets and hints with the site's CURRENT scripts, untouched —
 * whoever put those there could. Import and Update design now require
 * kerf_user_can_import(); this still protects a list handed here another way,
 * so nothing that runs is added or changed by someone who may not add it.
 * The scripts left out are counted, for the report.
 *
 * @param array[]      $assets  The new list.
 * @param array[]|null $current The list it replaces: the site's (null), or a
 *                              page's own design (kerf_asset_sets()).
 * @return array{assets:array[],withheld:int,kept:int}
 */
function kerf_assets_for_user( $assets, $current = null ) {
	$assets = array_values( (array) $assets );

	if ( kerf_user_can_add_scripts() ) {
		return array( 'assets' => $assets, 'withheld' => 0, 'kept' => 0 );
	}

	$styles = array_values( array_filter( $assets, static function ( $asset ) {
		return ! kerf_assets_is_script( $asset );
	} ) );
	$kept = array_values( array_filter( null === $current ? kerf_assets_get() : (array) $current, 'kerf_assets_is_script' ) );

	return array(
		'assets'   => array_merge( $styles, $kept ),
		'withheld' => count( $assets ) - count( $styles ),
		'kept'     => count( $kept ),
	);
}

/**
 * The report line for scripts kerf_assets_for_user() left out; '' when none were.
 *
 * @param array $gate kerf_assets_for_user()'s result.
 * @return string
 */
function kerf_assets_withheld_message( $gate ) {
	if ( empty( $gate['withheld'] ) ) {
		return '';
	}

	return sprintf(
		/* translators: 1: number of scripts in the mockup, 2: number the site already had. */
		_n(
			'This mockup\'s %1$d script was not added: on this site only a user who may add unfiltered HTML (on a network, a super admin) can add scripts. The site keeps the %2$d it had. Someone who can may bring the new one in with Kerf → Update from mockup.',
			'This mockup\'s %1$d scripts were not added: on this site only a user who may add unfiltered HTML (on a network, a super admin) can add scripts. The site keeps the %2$d it had. Someone who can may bring the new ones in with Kerf → Update from mockup.',
			(int) $gate['withheld'],
			'kerf-blocks'
		),
		(int) $gate['withheld'],
		(int) $gate['kept']
	);
}

/**
 * Every staged mockup folder, and what still uses it.
 *
 * Each import and each update stages a new `mockup-<time>` folder, and none
 * is removed on its own, because something may still point into an older one:
 * a script the site kept (§5.32), a background the converter resolved to a
 * staged file, an import not finished yet. A folder is IN USE when its path
 * appears in any option (the asset list, the frame, the pending reviews, the
 * measured hero picture…) or in the content of any post, page, part or
 * template — revisions aside, or no folder would ever be free again.
 *
 * @return array[] Newest first. Each: slug, path, bytes, files, time, used (string[]).
 */
function kerf_assets_staged_folders() {
	global $wpdb;

	$storages = kerf_assets_base_folders();
	if ( ! $storages ) {
		return array();
	}

	$folders = array();
	foreach ( $storages as $base => $storage ) {
		foreach ( (array) glob( $storage['dir'] . 'mockup-*', GLOB_ONLYDIR ) as $path ) {
			$slug  = basename( $path );
			$bytes = 0;
			$files = 0;
			foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $path, FilesystemIterator::SKIP_DOTS ) ) as $file ) {
				$bytes += (int) $file->getSize();
				$files++;
			}
			// Named for when it was staged, in UTC (kerf_import_unzip()).
			$date = preg_match( '/^mockup-(\d{8}-\d{6})/', $slug, $m ) ? DateTime::createFromFormat( 'Ymd-His', $m[1], new DateTimeZone( 'UTC' ) ) : false;
			$time = $date ? $date->getTimestamp() : filemtime( $path );

			// Two imports may have the same timestamp in different base folders.
			$folders[ $base . '/' . $slug ] = array( 'slug' => $base . '/' . $slug, 'path' => $path, 'bytes' => $bytes, 'files' => $files, 'time' => (int) $time, 'used' => array() );
		}
	}
	if ( ! $folders ) {
		return array();
	}

	// A path in a block attribute may be JSON with its slashes escaped.
	$pattern = '#(' . implode( '|', array_map( 'preg_quote', array_keys( $storages ) ) ) . ')/(mockup-\d{8}-\d{6}(?:-\d+)?)\b#';
	$likes   = array_map( static function ( $base ) use ( $wpdb ) {
		return '%' . $wpdb->esc_like( $base ) . '%';
	}, array_keys( $storages ) );

	$labels = array(
		KERF_ASSETS_OPTION     => __( 'the stylesheets and scripts', 'kerf-blocks' ),
		KERF_ASSET_SETS_OPTION => __( 'a page with a design of its own', 'kerf-blocks' ),
		'kerf_last_staging'    => __( 'sections pasted in the editor', 'kerf-blocks' ),
		'kerf_import_pending'  => __( 'an import or update not finished yet', 'kerf-blocks' ),
		'kerf_frame'           => __( 'the page frame', 'kerf-blocks' ),
		'kerf_shell_measured'  => __( 'the default style', 'kerf-blocks' ),
		'kerf_shell_tokens'    => __( 'the default style', 'kerf-blocks' ),
		KERF_BODY_OPTION       => __( 'the page\'s own attributes', 'kerf-blocks' ),
		'kerf_html_attributes' => __( 'the page\'s own attributes', 'kerf-blocks' ),
	);
	// Which options and posts name a staged folder: no API searches option
	// values or post content, and this runs on Kerf → Settings only. The two
	// bases, new and old (kerf_assets_base_folders() gives both or none).
	list( $like_new, $like_old ) = $likes;
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_value LIKE %s OR option_value LIKE %s", $like_new, $like_old ) ) as $row ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- see above.
		if ( preg_match_all( $pattern, str_replace( '\\/', '/', $row->option_value ), $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$slug = $match[1] . '/' . $match[2];
				if ( isset( $folders[ $slug ] ) ) {
					$folders[ $slug ]['used'][] = isset( $labels[ $row->option_name ] ) ? $labels[ $row->option_name ] : $row->option_name;
				}
			}
		}
	}

	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_type, post_status, post_title, post_name FROM {$wpdb->posts} WHERE post_type <> 'revision' AND ( post_content LIKE %s OR post_content LIKE %s )", $like_new, $like_old ) ) as $row ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- see above.
		$content = (string) get_post_field( 'post_content', (int) $row->ID, 'raw' );
		if ( ! preg_match_all( $pattern, str_replace( '\\/', '/', $content ), $matches, PREG_SET_ORDER ) ) {
			continue;
		}
		$type  = get_post_type_object( $row->post_type );
		$label = sprintf(
			/* translators: 1: post type, e.g. "Page", 2: its title. */
			__( '%1$s “%2$s”', 'kerf-blocks' ),
			$type ? $type->labels->singular_name : $row->post_type,
			'' !== $row->post_title ? $row->post_title : $row->post_name
		) . ( 'trash' === $row->post_status ? ' ' . __( '(in the trash)', 'kerf-blocks' ) : '' );
		foreach ( $matches as $match ) {
			$slug = $match[1] . '/' . $match[2];
			if ( isset( $folders[ $slug ] ) ) {
				$folders[ $slug ]['used'][] = $label;
			}
		}
	}

	foreach ( $folders as $slug => $folder ) {
		$folders[ $slug ]['used'] = array_values( array_unique( $folder['used'] ) );
	}

	uasort( $folders, static function ( $a, $b ) {
		return $b['time'] - $a['time'];
	} );

	return array_values( $folders );
}

/**
 * Absolute path to the imported-assets directory, created on demand.
 *
 * Assets live in uploads/ rather than inside the theme so they survive a theme
 * update, and so a site whose theme directory is read-only (which is the
 * recommended production posture) can still import.
 *
 * @return array{dir:string,url:string}|null Null when uploads is unwritable.
 */
function kerf_assets_storage() {
	$folders = kerf_assets_base_folders();
	$storage = isset( $folders[ KERF_ASSETS_DIR ] ) ? $folders[ KERF_ASSETS_DIR ] : null;
	if ( ! $storage || ( ! is_dir( $storage['dir'] ) && ! wp_mkdir_p( $storage['dir'] ) ) ) {
		return null;
	}
	return $storage;
}

/**
 * Both places staged designs may live, without creating either folder.
 *
 * New files belong under the plugin's slug. Existing designs keep their files
 * and stored URLs under kerf-assets; readers must accept both (§5.12, §5.39).
 *
 * @return array<string,array{dir:string,url:string}> Base folder => paths.
 */
function kerf_assets_base_folders() {
	$uploads = wp_upload_dir( null, false );

	if ( ! empty( $uploads['error'] ) ) {
		return array();
	}

	$folders = array();
	foreach ( array( KERF_ASSETS_DIR, 'kerf-assets' ) as $base ) {
		$folders[ $base ] = array(
			'dir' => trailingslashit( $uploads['basedir'] ) . $base . '/',
			'url' => trailingslashit( $uploads['baseurl'] ) . $base . '/',
		);
	}
	return $folders;
}

/**
 * The staged base a stored URL belongs to; null for another place.
 *
 * @param string $url A design's folder or file URL.
 * @return array{dir:string,url:string}|null
 */
function kerf_assets_storage_for_url( $url ) {
	foreach ( kerf_assets_base_folders() as $storage ) {
		if ( 0 === strpos( (string) $url, $storage['url'] ) ) {
			return $storage;
		}
	}
	return null;
}

/**
 * Send a request for one of the design's files, made by a path relative to a
 * WordPress page, to the file.
 *
 * A path in an attribute or a stylesheet is resolved at import; a path a
 * design's SCRIPT builds — `img.src = 'assets/before-and-after-' + n +
 * '.jpg'`, `fetch( 'data/team.json' )` — resolves in the browser against the
 * page's address, which on WordPress is not the design's folder: the
 * Manhattan design's before-and-after gallery showed four broken pictures
 * (scar 109). Such a request finds no page, so before WordPress answers it
 * "not found", the design's folder is asked for the path — whole, then without
 * its first folders, as a page under `/about/` asks for `about/assets/x.jpg` —
 * and a file there is where the browser is sent. The design is the page's the
 * request came from (a page with a design of its own, §5.39), else the site's.
 * Only files a design may have (kerf_import_servable()), only inside its
 * folder; a server that answers missing pictures itself, without WordPress,
 * never asks.
 */
function kerf_assets_relative_redirect() {
	if ( ! is_404() || ! kerf_theme_active() ) {
		return;
	}
	$path    = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH );
	$referer = wp_get_referer();
	$design  = kerf_assets_design( $referer ? url_to_postid( $referer ) : 0 );
	$to      = kerf_assets_relative_file( $path, $design['staging'] );
	if ( '' !== $to ) {
		wp_safe_redirect( $to, 302, 'Kerf' );
		exit;
	}
}
add_action( 'template_redirect', 'kerf_assets_relative_redirect', 1 );

/**
 * The design's file a path below the site's address names
 * (kerf_assets_relative_redirect()): the whole path below the home address,
 * then without its first folders, looked for in the design's staged folder.
 *
 * @param string $path    A request's path (`/site/about/assets/x.jpg`).
 * @param array  $staging A design's staging: `url` of the document's folder.
 * @return string The file's URL, or ''.
 */
function kerf_assets_relative_file( $path, $staging ) {
	$path    = (string) $path;
	$home    = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	$storage = kerf_assets_storage_for_url( isset( $staging['url'] ) ? $staging['url'] : '' );
	if ( '' === $path || 0 !== strpos( $path, $home ) || ! preg_match( '/\.(?:' . KERF_IMPORT_ASSET_EXT . ')$/i', $path )
		|| empty( $staging['url'] ) || ! $storage || 0 !== strpos( (string) $staging['url'], $storage['url'] ) ) {
		return '';
	}
	$dir  = $storage['dir'] . substr( (string) $staging['url'], strlen( $storage['url'] ) );
	$root = realpath( $dir );
	if ( false === $root ) {
		return '';
	}
	$root = trailingslashit( wp_normalize_path( $root ) );

	$segments = array_values( array_filter( explode( '/', rawurldecode( substr( $path, strlen( $home ) ) ) ), 'strlen' ) );
	$count    = count( $segments );
	for ( $i = 0; $i < $count; $i++ ) {
		$suffix = array_slice( $segments, $i );
		if ( in_array( '..', $suffix, true ) || ! kerf_import_servable( (string) end( $suffix ) ) ) {
			continue;
		}
		$file = realpath( $dir . implode( '/', $suffix ) );
		if ( false !== $file && is_file( $file ) && 0 === strpos( wp_normalize_path( $file ), $root ) ) {
			return $staging['url'] . implode( '/', array_map( 'rawurlencode', $suffix ) );
		}
	}
	return '';
}

// ═══════════════════════════════════════════════════════════════════════════════
// ENQUEUE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Does an asset load on this request?
 *
 * Everything from the entry document does. An asset only one of the mockup's
 * other pages brought (Kerf Pro's kerf_import_pages_merge_assets()) carries `only`: the
 * pages and templates it belongs to.
 *
 * @param array $asset
 * @return bool
 */
function kerf_assets_applies_here( $asset ) {
	if ( empty( $asset['only'] ) || ! is_array( $asset['only'] ) ) {
		return true;
	}

	$only = $asset['only'];

	// Pages by id — and a post's own (a section's styles pasted on it, Kerf
	// Pro's page assets), which is_page() would never match.
	if ( ! empty( $only['pages'] ) && is_singular() && in_array( (int) get_queried_object_id(), array_map( 'intval', (array) $only['pages'] ), true ) ) {
		return true;
	}

	if ( ! empty( $only['templates'] ) ) {
		// Set by core when it resolved the block template for this request:
		// "kerf//single".
		$current = isset( $GLOBALS['_wp_current_template_id'] ) ? (string) $GLOBALS['_wp_current_template_id'] : '';
		$slug    = false !== strpos( $current, '//' ) ? substr( $current, strpos( $current, '//' ) + 2 ) : $current;
		if ( '' !== $slug && in_array( $slug, (array) $only['templates'], true ) ) {
			return true;
		}
	}

	return false;
}

/**
 * Does the design belong on this request — its stylesheets, scripts, hints and
 * body classes?
 *
 * Under the Kerf theme every page is the design's. Under another theme only a
 * page whose content is Kerf blocks is: the rest are that theme's, and the
 * design's stylesheet would restyle them.
 *
 * @return bool
 */
function kerf_assets_here() {
	if ( kerf_theme_active() ) {
		return true;
	}

	$post = is_singular() ? get_queried_object() : null;

	return $post instanceof WP_Post && false !== strpos( (string) $post->post_content, '<!-- wp:kerf/' );
}

/**
 * Register and enqueue every imported asset, in the mockup's original order.
 *
 * Every asset is a handle of its own that depends on the one before it, so
 * WordPress' dependency resolution reproduces the source order exactly. An
 * inline block is a handle with no source — WordPress prints no tag of its own
 * for it, only the block, as one element where the mockup wrote it (scar 101).
 *
 * An asset carrying `only` came from one of the mockup's other pages and loads
 * only where that page renders: gymlife's main.html is a launch page whose
 * `<style>` sets `img { margin: 20% auto 0; display: block }` — site-wide, it
 * pushed every picture on every page down by a fifth (scar 45).
 */
function kerf_assets_enqueue() {
	if ( ! kerf_assets_here() ) {
		return;
	}

	// The site's design, or this page's own (kerf_assets_design()).
	$design = kerf_assets_design();
	$assets = $design['assets'];
	if ( empty( $assets ) ) {
		return;
	}

	// First in the queue, so its listener prints before the design's first
	// script: a script of the design's that dies is noticed (§5.50).
	kerf_reveal_enqueue( $assets );
	// Whatever search the design has — a form, a box with no form, an icon
	// with no box — reaches WordPress search (assets/js/kerf-search.js, scar 136).
	if ( ! is_admin() && function_exists( 'kerf_enqueue_front_script' ) ) {
		kerf_enqueue_front_script( 'kerf-search' );
	}

	$version  = $design['version'];
	$previous = array( 'css' => '', 'js' => '' );
	$index    = 0;
	// Scripts are chained in source order, as stylesheets are — but a script
	// that blocks the page never waits on one that does not (`defer`, `async`,
	// a module): a browser runs it first. Chained to a deferred script before
	// it, a plain one made WordPress drop that script's `defer` (a dependent
	// that blocks), and it ran in <head> before the page it reads existed
	// (scar 112). A deferred script or a module follows the script before it,
	// whatever it is; an async one waits on nothing deferred and nothing waits
	// on it.
	$blocking = '';

	foreach ( $assets as $asset ) {
		$type = isset( $asset['type'] ) ? $asset['type'] : '';
		if ( 'css' !== $type && 'js' !== $type ) {
			continue;
		}

		// Printed by the kerf/script block where the mockup wrote it.
		if ( 'inplace' === ( isset( $asset['position'] ) ? $asset['position'] : '' ) ) {
			continue;
		}

		// What only one of the mockup's other pages loads, loads only there.
		if ( ! kerf_assets_applies_here( $asset ) ) {
			continue;
		}

		$index++;
		$handle   = 'kerf-' . $type . '-' . $index;
		$in_footer = ( 'footer' === ( isset( $asset['position'] ) ? $asset['position'] : 'head' ) );
		$deps      = ( '' !== $previous[ $type ] ) ? array( $previous[ $type ] ) : array();
		$flags     = isset( $asset['attrs'] ) && is_array( $asset['attrs'] ) ? $asset['attrs'] : array();
		$file      = 'file' === $asset['kind'];
		$delayed   = 'js' === $type && ( ! empty( $flags['module'] ) || ( $file && ( ! empty( $flags['defer'] ) || ! empty( $flags['async'] ) ) ) );
		if ( 'js' === $type && ( ! $delayed || ! $file || ! empty( $flags['async'] ) ) ) {
			// Blocking, an inline module (its inline code keeps WordPress from
			// delaying anything it waits on), or async: after the blocking ones.
			$deps = '' !== $blocking ? array( $blocking ) : array();
		}

		if ( $file ) {
			$src = isset( $asset['src'] ) ? $asset['src'] : '';
			if ( '' === $src ) {
				continue;
			}

			if ( 'css' === $type ) {
				wp_enqueue_style( $handle, $src, $deps, $version, isset( $asset['media'] ) ? $asset['media'] : 'all' );
			} else {
				wp_enqueue_script( $handle, $src, $deps, $version, $in_footer );
				kerf_assets_apply_script_flags( $handle, $asset );
			}

			if ( 'css' === $type || empty( $flags['async'] ) ) {
				$previous[ $type ] = $handle;
			}
			if ( 'js' === $type && ! $delayed ) {
				$blocking = $handle;
			}
			continue;
		}

		// Inline block: an element of its own, in its own place, as written.
		// Attached to the file before it, as it was, WordPress joined every
		// block after that file into ONE element, printed where the file was
		// (scar 101). Two <script>s are two programs: a Tailwind design's
		// `tailwind.config = {…}`, with no semicolon, and the menu script
		// after it, `(function () {…})()`, became one statement that called
		// the object — the config never set, every brand colour and both fonts
		// gone — and that menu script, from the end of <body>, ran in <head>
		// before the elements it looks for existed. A <style> beginning with
		// @import stops importing once it follows other rules.
		$content = isset( $asset['content'] ) ? (string) $asset['content'] : '';
		if ( '' === trim( $content ) ) {
			continue;
		}

		if ( 'css' === $type ) {
			wp_register_style( $handle, false, $deps, $version );
			wp_enqueue_style( $handle );
			// The mockup's CSS stays CSS: a `</style` in it would end the
			// element core prints it in (kerf_css_inert()).
			wp_add_inline_style( $handle, kerf_css_inert( $content ) );
		} else {
			wp_register_script( $handle, false, $deps, $version, $in_footer );
			wp_enqueue_script( $handle );
			wp_add_inline_script( $handle, $content );
			kerf_assets_inline_attributes( $handle, $asset );
		}

		// An inline module runs after the page, as a deferred file does: a
		// plain script after it does not wait on it.
		if ( 'css' === $type || empty( $flags['module'] ) ) {
			$previous[ $type ] = $handle;
			if ( 'js' === $type ) {
				$blocking = $handle;
			}
		}
	}

	// Background pictures the owner changed "everywhere", right after the
	// design's own CSS (inc/kerf-backgrounds.php).
	if ( function_exists( 'kerf_bg_enqueue' ) ) {
		kerf_bg_enqueue( $previous['css'], $design );
	}
}
add_action( 'wp_enqueue_scripts', 'kerf_assets_enqueue', 20 );

/**
 * Print the mockup's typed style blocks — `<style type="text/tailwindcss">` —
 * as written, for the script that reads them (kerf_assets_scan()). Tailwind's
 * script finds them wherever they are in the document, so they go out before
 * the enqueued assets. Their text is made inert like any stored CSS: it cannot
 * close the element it is printed in (kerf_css_inert()).
 */
function kerf_assets_print_typed_styles() {
	if ( ! kerf_assets_here() ) {
		return;
	}

	foreach ( kerf_assets_design()['assets'] as $asset ) {
		if ( 'typed-style' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) || ! kerf_assets_applies_here( $asset ) ) {
			continue;
		}
		$type = isset( $asset['attrs']['type'] ) ? (string) $asset['attrs']['type'] : '';
		if ( ! preg_match( '#^text/[a-z0-9.+-]+$#', $type ) || 'text/css' === $type ) {
			continue;
		}
		printf( "<style type=\"%s\">%s</style>\n", esc_attr( $type ), kerf_css_inert( (string) $asset['content'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kerf_css_inert() is the escape for CSS text.
	}
}
add_action( 'wp_head', 'kerf_assets_print_typed_styles', 7 );

/**
 * Print the design's import map, before any module (core prints the head's
 * scripts at `wp_head` 9). Only the map's own parts go out — `imports`,
 * `scopes`, `integrity` — and only addresses (http, https, the site's own
 * paths; a relative one was made the design folder's at import,
 * kerf_import_localize_assets()), as JSON that cannot end its element.
 */
function kerf_assets_print_import_map() {
	if ( ! kerf_assets_here() ) {
		return;
	}
	foreach ( kerf_assets_design()['assets'] as $asset ) {
		if ( 'importmap' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) || ! kerf_assets_applies_here( $asset ) ) {
			continue;
		}
		$map = kerf_assets_clean_import_map( json_decode( (string) $asset['content'], true ) );
		if ( $map ) {
			echo wp_get_inline_script_tag( (string) wp_json_encode( $map, JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP ), array( 'type' => 'importmap' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core's tag builder; the JSON cannot close it (JSON_HEX_TAG).
		}
		// A document takes one map in older browsers: the design's first.
		return;
	}
}
add_action( 'wp_head', 'kerf_assets_print_import_map', 7 );

/**
 * An import map, keeping only what one holds: `imports` and `integrity`
 * (name ⇒ string), `scopes` (address ⇒ imports), each address http(s) or a
 * path on this site.
 *
 * @param mixed $map Decoded JSON.
 * @return array The map, or an empty array.
 */
function kerf_assets_clean_import_map( $map ) {
	if ( ! is_array( $map ) ) {
		return array();
	}
	$address = static function ( $url ) {
		return is_string( $url ) && preg_match( '#^(?:https?://|/(?!/))#i', trim( $url ) ) && ! preg_match( '/[\x00-\x1F\x7F]/', $url );
	};
	$imports = static function ( $list ) use ( $address ) {
		$out = array();
		foreach ( is_array( $list ) ? $list : array() as $name => $url ) {
			if ( is_string( $name ) && '' !== $name && $address( $url ) ) {
				$out[ $name ] = trim( $url );
			}
		}
		return $out;
	};
	$out = array();
	if ( isset( $map['imports'] ) && $imports( $map['imports'] ) ) {
		$out['imports'] = $imports( $map['imports'] );
	}
	foreach ( isset( $map['scopes'] ) && is_array( $map['scopes'] ) ? $map['scopes'] : array() as $scope => $list ) {
		if ( is_string( $scope ) && $address( $scope ) && $imports( $list ) ) {
			$out['scopes'][ trim( $scope ) ] = $imports( $list );
		}
	}
	foreach ( isset( $map['integrity'] ) && is_array( $map['integrity'] ) ? $map['integrity'] : array() as $url => $hash ) {
		if ( is_string( $url ) && $address( $url ) && is_string( $hash ) && preg_match( '/^sha(?:256|384|512)-[A-Za-z0-9+\/=]+$/', $hash ) ) {
			$out['integrity'][ trim( $url ) ] = $hash;
		}
	}
	return $out;
}

/**
 * Print the data blocks the design's `<head>` holds — a JSON block, a
 * template — with their type and id, for the scripts that read them. (The
 * body's stay where they were written, kerf_render_script_block().)
 */
function kerf_assets_print_data_scripts() {
	if ( ! kerf_assets_here() ) {
		return;
	}
	foreach ( kerf_assets_design()['assets'] as $asset ) {
		if ( 'data' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) || 'head' !== ( isset( $asset['position'] ) ? $asset['position'] : '' ) || ! kerf_assets_applies_here( $asset ) ) {
			continue;
		}
		$type = isset( $asset['attrs']['type'] ) ? (string) $asset['attrs']['type'] : '';
		if ( kerf_mc_is_kept_data_script( $type ) ) {
			echo wp_get_inline_script_tag( (string) $asset['content'], array( 'type' => $type ) + kerf_assets_tag_attributes( $asset ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- core's tag builder, which refuses what cannot be embedded.
		}
	}
}
add_action( 'wp_head', 'kerf_assets_print_data_scripts', 7 );

/**
 * Re-apply a script tag's `defer`/`async`/`type=module`.
 *
 * These are not cosmetic. A library written as a module and loaded as a classic
 * script throws on its first `import`; a `defer`ed script that starts running
 * before the DOM exists throws on its first `querySelector`. Both look like
 * "the mockup's JS doesn't work in WordPress".
 *
 * @param string $handle
 * @param array  $asset
 */
function kerf_assets_apply_script_flags( $handle, $asset ) {
	$flags = isset( $asset['attrs'] ) && is_array( $asset['attrs'] ) ? $asset['attrs'] : array();

	// A module runs after the page as a deferred script does, and says so to
	// WordPress, so a deferred script before it keeps its `defer` (a dependent
	// with no strategy makes WordPress print it blocking). On a module `defer`
	// changes nothing.
	if ( ! empty( $flags['async'] ) ) {
		wp_script_add_data( $handle, 'strategy', 'async' );
	} elseif ( ! empty( $flags['defer'] ) || ! empty( $flags['module'] ) ) {
		wp_script_add_data( $handle, 'strategy', 'defer' );
	}

	// wp_script_add_data() with 'type' is not honoured by core's loader: the
	// type, and the tag's own attributes, go on as core builds the tag.
	$extra = kerf_assets_tag_attributes( $asset );
	if ( ! empty( $flags['module'] ) ) {
		$extra = array( 'type' => 'module' ) + $extra;
	}
	if ( $extra ) {
		add_filter( 'wp_script_attributes', static function ( $attributes ) use ( $handle, $extra ) {
			return isset( $attributes['id'] ) && $handle . '-js' === $attributes['id'] ? array_merge( $attributes, $extra ) : $attributes;
		} );
	}
}

/**
 * An inline script's type and own attributes, as core prints its block with
 * `wp_get_inline_script_tag()`, never through `script_loader_tag`: an inline
 * `<script type="module">` printed as a classic script threw on its first
 * `import`. (`defer` and `async` do nothing on an inline script, in the
 * mockup or here.)
 *
 * @param string $handle
 * @param array  $asset
 */
function kerf_assets_inline_attributes( $handle, $asset ) {
	$extra = kerf_assets_tag_attributes( $asset );
	if ( ! empty( $asset['attrs']['module'] ) ) {
		$extra = array( 'type' => 'module' ) + $extra;
	}
	if ( ! $extra ) {
		return;
	}
	add_filter( 'wp_inline_script_attributes', static function ( $attributes ) use ( $handle, $extra ) {
		return isset( $attributes['id'] ) && $handle . '-js-after' === $attributes['id'] ? array_merge( $attributes, $extra ) : $attributes;
	} );
}

/**
 * The design's own attributes for a script's tag (kerf_assets_script_tag_attributes()),
 * as core's tag builders take them: its `id` in place of core's, `data-*`,
 * `nomodule`, `crossorigin`… Names are checked again — the list is stored in
 * an option, and printed on every page.
 *
 * @param array $asset
 * @return array<string,string|true>
 */
function kerf_assets_tag_attributes( $asset ) {
	$tag = isset( $asset['attrs']['tag'] ) && is_array( $asset['attrs']['tag'] ) ? $asset['attrs']['tag'] : array();
	$out = array();
	foreach ( $tag as $name => $value ) {
		$name = strtolower( (string) $name );
		if ( in_array( $name, array( 'src', 'type', 'defer', 'async', 'nonce' ), true ) || ! kerf_mc_attribute_name_ok( $name ) || ( ! is_string( $value ) && true !== $value ) ) {
			continue;
		}
		$out[ $name ] = $value;
	}
	return $out;
}

/**
 * Print the mockup's resource hints and favicon links in <head>.
 *
 * These have no WordPress enqueue equivalent, so they are printed directly —
 * early, because a preconnect that lands after the request it was meant to warm
 * up has done nothing.
 */
function kerf_assets_print_hints() {
	if ( ! kerf_assets_here() ) {
		return;
	}

	foreach ( kerf_assets_design()['assets'] as $asset ) {
		if ( 'hint' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) || ! kerf_assets_applies_here( $asset ) ) {
			continue;
		}

		$href = esc_url( isset( $asset['src'] ) ? $asset['src'] : '' );
		if ( '' === $href ) {
			continue;
		}

		$attrs = isset( $asset['attrs'] ) && is_array( $asset['attrs'] ) ? $asset['attrs'] : array();
		$out   = '<link href="' . $href . '"';

		foreach ( array( 'rel', 'as', 'type', 'sizes', 'crossorigin', 'media', 'imagesrcset' ) as $name ) {
			if ( isset( $attrs[ $name ] ) && '' !== $attrs[ $name ] ) {
				$out .= ' ' . $name . '="' . esc_attr( $attrs[ $name ] ) . '"';
			} elseif ( 'crossorigin' === $name && isset( $attrs[ $name ] ) ) {
				$out .= ' crossorigin';
			}
		}

		echo $out . ">\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- assembled from escaped parts above.
	}
}
add_action( 'wp_head', 'kerf_assets_print_hints', 2 );

/**
 * Apply the mockup's `<body>` classes to the rendered page.
 *
 * Mockups routinely hang page-level styling off the body — `class="home
 * dark-theme"` selects an entire colour scheme — and dropping it loses the
 * design with nothing visible to explain why.
 *
 * The body's `id` and its other attributes have no filter; they are printed by
 * Kerf's own template canvas instead — see kerf_document_attributes().
 *
 * @param string[] $classes
 * @return string[]
 */
function kerf_assets_body_class( $classes ) {
	if ( ! kerf_assets_here() ) {
		return $classes;
	}

	$body = kerf_assets_design()['body'];

	if ( empty( $body['class'] ) ) {
		return $classes;
	}

	foreach ( preg_split( '/\s+/', (string) $body['class'], -1, PREG_SPLIT_NO_EMPTY ) as $class ) {
		$classes[] = sanitize_html_class( $class );
	}

	return array_values( array_unique( array_filter( $classes ) ) );
}
add_filter( 'body_class', 'kerf_assets_body_class' );

// ═══════════════════════════════════════════════════════════════════════════════
// WORDPRESS' OWN CSS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Hold back WordPress' default styles so the mockup's cascade starts clean.
 *
 * Core injects several hundred lines of `global-styles-inline-css` derived from
 * theme.json — body typography, link colour, block margins — at a specificity
 * the designer never anticipated and in a `<style>` tag that lands AFTER the
 * enqueued stylesheets. A mockup that sets `body { font-family: Satoshi }` in
 * its own sheet loses to it, and the only fix available to the designer is
 * `!important`, applied by trial and error.
 *
 * Three levels, because the right answer depends on how much of the page is the
 * mockup's:
 *
 *   full     leave WordPress alone. Correct before an import, and the escape
 *            hatch when a site mixes converted pages with core-block pages.
 *   minimal  (default) drop the derived global styles and the classic-theme
 *            shims; keep wp-block-library, which is what makes core/table,
 *            core/embed and the query blocks look like anything at all.
 *   none     drop wp-block-library too. The mockup owns every pixel.
 *
 * Nothing is removed in the editor — the block canvas needs core's CSS to be
 * usable, and an editor that does not resemble the front end is a fair trade
 * against an editor that cannot be operated.
 */
function kerf_assets_filter_core_css() {
	$level = get_option( KERF_CORE_CSS_OPTION, 'minimal' );

	if ( 'full' === $level || is_admin() || ! kerf_theme_active() ) {
		return;
	}

	wp_dequeue_style( 'classic-theme-styles' );
	wp_dequeue_style( 'global-styles' );
	wp_dequeue_style( 'wp-block-library-theme' );

	if ( 'none' === $level ) {
		wp_dequeue_style( 'wp-block-library' );
	}
}
add_action( 'wp_enqueue_scripts', 'kerf_assets_filter_core_css', 100 );

/**
 * Stop core emitting the theme.json-derived global stylesheet at all.
 *
 * Dequeuing `global-styles` is not enough on its own — core also prints layout
 * and block-support CSS through a separate path (`wp_enqueue_global_styles`,
 * and per-block styles rendered inline next to each block). This closes that
 * second door at the same setting.
 */
function kerf_assets_suppress_global_styles() {
	$level = get_option( KERF_CORE_CSS_OPTION, 'minimal' );

	if ( 'full' === $level || is_admin() || ! kerf_theme_active() ) {
		return;
	}

	// Core registers these on init; removing the actions is the supported way to
	// opt a theme out.
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
	remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
	remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
}
add_action( 'init', 'kerf_assets_suppress_global_styles', 20 );

// ═══════════════════════════════════════════════════════════════════════════════
// EDITOR
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Load the mockup's stylesheets into the block editor canvas.
 *
 * Without this the editor shows unstyled markup and every converted page looks
 * broken while you edit it — which reads as a failed conversion even when the
 * front end is perfect.
 *
 * Every stylesheet is handed to the editor as CSS plus its own URL as
 * `baseURL`, in the mockup's order, inline blocks included. The editor rebases a
 * relative `url()` against `baseURL`.
 *
 * This used to be add_editor_style() with each file's URL, and for a URL core
 * fetches the CSS and inlines it with NO base URL — so every relative `url()`
 * resolved against the admin screen and 404'd. The icon font of every CDN icon
 * set failed (`remixicon: error`; every icon an empty box, in the editor only),
 * and so would any `url(../images/hero.jpg)` background. Inline blocks were
 * also appended after all the files instead of where the mockup put them.
 *
 * A page with a design of its own gets that design's stylesheets; the Site
 * Editor and every other page, the site's.
 *
 * A stylesheet only some pages or templates load (§5.26) is drawn where one of
 * them is edited. The owner's dental design brought its inner page's
 * `inner-page.css` — the banner's grid, the breadcrumb's row, the article
 * beside its sidebar — and its editor showed that page as a column of bare
 * markup, a numbered breadcrumb and a photo the width of the screen, while the
 * page itself was right: every page-only sheet was kept out of the editor. A
 * post's editor knows its post, and the template it renders through
 * (kerf_assets_editor_template()), so those sheets are given in their place
 * among the design's. The Site Editor shows one template, part or page after
 * another without loading again: there each is given to the canvas apart
 * (`kerfScope`, with what it belongs to), which draws it while one of those is
 * open (kerf-canvas.js, applyScoped()).
 *
 * @param array                        $settings Block editor settings.
 * @param WP_Block_Editor_Context|null $context  Where the editor is.
 * @return array
 */
function kerf_assets_editor_styles( $settings, $context = null ) {
	$styles   = isset( $settings['styles'] ) && is_array( $settings['styles'] ) ? $settings['styles'] : array();
	$post     = isset( $context->post ) && $context->post instanceof WP_Post ? (int) $context->post->ID : 0;
	$template = $post ? kerf_assets_editor_template( $context->post ) : '';
	$site     = isset( $context->name ) && 'core/edit-site' === $context->name;

	// Kerf's own editor affordances (a void element's marker, where a post's
	// body goes), ahead of the design's CSS — where the theme's add_editor_style()
	// put them while the blocks were the theme's.
	$affordances = kerf_plugin_path( 'assets/css/kerf-editor.css' );
	if ( is_readable( $affordances ) ) {
		$styles[] = array(
			'css'            => (string) file_get_contents( $affordances ),
			'baseURL'        => kerf_plugin_url( 'assets/css/kerf-editor.css' ),
			'__unstableType' => 'theme',
			'isGlobalStyles' => false,
		);
	}

	// Under another theme the design belongs only in an editor whose content is
	// Kerf blocks (kerf_assets_here()); that theme's other posts and its Site
	// Editor keep its own look.
	if ( ! kerf_theme_active() && ( ! $post || false === strpos( (string) $context->post->post_content, '<!-- wp:kerf/' ) ) ) {
		$settings['styles'] = $styles;
		return $settings;
	}

	foreach ( kerf_assets_design( $post )['assets'] as $asset ) {
		if ( 'css' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) ) {
			continue;
		}
		$scoped = ! empty( $asset['only'] ) && is_array( $asset['only'] );
		if ( $scoped && ! $site && ! kerf_assets_editor_applies( $asset, $post, $template ) ) {
			continue;
		}

		$entry = kerf_assets_editor_entry( $asset );
		if ( ! $entry ) {
			continue;
		}

		if ( $scoped && $site ) {
			// Kept apart for the canvas: an entry with no `css` draws nothing
			// in the editor's own styles.
			$styles[] = array(
				'css'       => '',
				'kerfCss'   => $entry['css'],
				'baseURL'   => isset( $entry['baseURL'] ) ? $entry['baseURL'] : '',
				'kerfScope' => array(
					'pages'     => array_values( array_map( 'intval', isset( $asset['only']['pages'] ) ? (array) $asset['only']['pages'] : array() ) ),
					'templates' => array_values( array_map( 'strval', isset( $asset['only']['templates'] ) ? (array) $asset['only']['templates'] : array() ) ),
				),
			);
			continue;
		}

		$styles[] = $entry;
	}

	$settings['styles'] = $styles;

	return $settings;
}
add_filter( 'block_editor_settings_all', 'kerf_assets_editor_styles', 10, 2 );

/**
 * One of the design's stylesheets as the editor takes it: its CSS (a file's
 * read from disk, or fetched once from elsewhere), its own address for its
 * relative `url()`s, its `media` kept.
 *
 * @param array $asset A `css` asset.
 * @return array|null An entry of the editor's `styles`; null when it holds nothing.
 */
function kerf_assets_editor_entry( $asset ) {
	$media = isset( $asset['media'] ) ? trim( (string) $asset['media'] ) : '';
	// `kerfDesign`: the canvas puts a sheet the editor could not read in
	// as written (kerf-canvas.js, applyUnparsed()).
	$entry = array( '__unstableType' => 'theme', 'isGlobalStyles' => false, 'kerfDesign' => true );

	if ( 'inline' === $asset['kind'] ) {
		$css = isset( $asset['content'] ) ? (string) $asset['content'] : '';
	} elseif ( 'file' === $asset['kind'] && ! empty( $asset['src'] ) ) {
		$css              = kerf_assets_editor_css( $asset['src'] );
		$entry['baseURL'] = $asset['src'];
	} else {
		return null;
	}

	if ( '' === trim( $css ) ) {
		return null;
	}

	// A `media` on the <link> is part of the rule set; `print` CSS must not
	// restyle the canvas.
	if ( '' !== $media && ! in_array( strtolower( $media ), array( 'all', 'screen' ), true ) ) {
		$css = '@media ' . $media . '{' . $css . '}';
	}

	$entry['css'] = $css;
	return $entry;
}

/**
 * Does a stylesheet only some pages or templates load (§5.26) belong in this
 * post's editor: the post is one of its pages, or renders through one of its
 * templates?
 *
 * @param array  $asset
 * @param int    $post_id
 * @param string $template The template the post renders through (kerf_assets_editor_template()).
 * @return bool
 */
function kerf_assets_editor_applies( $asset, $post_id, $template ) {
	$only = isset( $asset['only'] ) && is_array( $asset['only'] ) ? $asset['only'] : array();
	if ( $post_id && ! empty( $only['pages'] ) && in_array( (int) $post_id, array_map( 'intval', (array) $only['pages'] ), true ) ) {
		return true;
	}
	return '' !== $template && ! empty( $only['templates'] ) && in_array( $template, array_map( 'strval', (array) $only['templates'] ), true );
}

/**
 * The template a post renders through, as its editor's "Show template" draws
 * it: one chosen for it; `kerf-mockup` for content made of Kerf blocks (the
 * routing, kerf_shell_route_singular()); else the first of the hierarchy's
 * the theme has — `single` for a blog post, which a designer's own post page
 * is (Kerf Pro's marked templates), `page` for a page written in WordPress.
 *
 * @param WP_Post $post
 * @return string A template's slug, or '' when none is the theme's.
 */
function kerf_assets_editor_template( $post ) {
	if ( ! $post instanceof WP_Post ) {
		return '';
	}
	$chosen = (string) get_page_template_slug( $post );
	if ( '' !== $chosen ) {
		return $chosen;
	}
	if ( false !== strpos( (string) $post->post_content, '<!-- wp:kerf/' ) ) {
		return 'kerf-mockup';
	}

	$type       = (string) $post->post_type;
	$name       = (string) $post->post_name;
	$candidates = 'page' === $type
		? array( 'page-' . $name, 'page-' . $post->ID, 'page' )
		: array( 'single-' . $type . '-' . $name, 'single-' . $type, 'single' );
	$candidates = array_merge( $candidates, array( 'singular', 'index' ) );

	foreach ( $candidates as $slug ) {
		// A draft not yet named has no `page-<name>`.
		if ( '-' === substr( $slug, -1 ) ) {
			continue;
		}
		if ( get_block_template( get_stylesheet() . '//' . $slug, 'wp_template' ) ) {
			return $slug;
		}
	}
	return '';
}

/**
 * The text of a mockup stylesheet, for the editor.
 *
 * A staged file is read from disk. A remote one (a CDN icon font) is fetched
 * once and cached until the next import — core fetched it on every editor load.
 *
 * @param string $url
 * @param bool   $remote Fetch one from another server. Not while a visitor's
 *                       page renders (kerf_bg_design_sheets()): never a network
 *                       call there.
 * @return string CSS, or '' when it cannot be read.
 */
function kerf_assets_editor_css( $url, $remote = true ) {
	$uploads = wp_upload_dir();
	$base    = trailingslashit( $uploads['baseurl'] );

	if ( 0 === strpos( $url, $base ) ) {
		$path = trailingslashit( $uploads['basedir'] ) . rawurldecode( substr( strtok( $url, '?#' ), strlen( $base ) ) );
		$real = realpath( $path );

		// Stay inside uploads, whatever the URL said.
		if ( $real && 0 === strpos( wp_normalize_path( $real ), wp_normalize_path( realpath( $uploads['basedir'] ) ) ) ) {
			return (string) file_get_contents( $real );
		}
		return '';
	}

	if ( ! $remote || ! preg_match( '#^(?:https?:)?//#i', $url ) ) {
		return '';
	}

	$key    = 'kerf_css_' . md5( $url . '|' . get_option( 'kerf_assets_version', '1' ) );
	$cached = get_transient( $key );
	if ( false !== $cached ) {
		return (string) $cached;
	}

	$response = wp_remote_get( 0 === strpos( $url, '//' ) ? 'https:' . $url : $url, array( 'timeout' => 10 ) );
	$css      = ( ! is_wp_error( $response ) && 200 === wp_remote_retrieve_response_code( $response ) )
		? wp_remote_retrieve_body( $response )
		: '';

	// A failure is cached briefly, so a CDN outage does not stall every load.
	set_transient( $key, $css, '' === $css ? 5 * MINUTE_IN_SECONDS : WEEK_IN_SECONDS );

	return $css;
}
