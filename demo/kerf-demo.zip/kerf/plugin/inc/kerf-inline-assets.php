<?php
/**
 * Enqueue Kerf's own front-end scripts where their blocks render.
 *
 * The design's styles and scripts belong to the asset pipeline. These shims
 * read the markup their blocks already print, so no page data needs injecting.
 * Core dedupes their handles and prints the files in the footer. A final pass
 * catches blocks rendered after core's usual footer pass.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_FRONT_SCRIPT_HANDLES = array( 'kerf-search', 'kerf-lazy-bg', 'kerf-forms' );

/**
 * Register on demand so a script follows its block under any theme.
 *
 * Admin renders need no front-end behaviour, and must not give these scripts
 * to the editor's canvas.
 *
 * @param string $handle One of Kerf's own front-end script handles.
 */
function kerf_enqueue_front_script( $handle ) {
	if ( is_admin() || ! in_array( $handle, KERF_FRONT_SCRIPT_HANDLES, true ) ) {
		return;
	}

	if ( ! wp_script_is( $handle, 'registered' ) ) {
		wp_register_script(
			$handle,
			kerf_plugin_url( 'assets/js/' . $handle . '.js' ),
			array(),
			KERF_VERSION,
			array( 'in_footer' => true )
		);
		// A search box with no form, or a search icon with no box, has no
		// address of WordPress search in its markup to read (scar 136).
		if ( 'kerf-search' === $handle ) {
			wp_add_inline_script( $handle, 'window.kerfSearchHome = ' . wp_json_encode( home_url( '/' ) ) . ';', 'before' );
		}
	}
	wp_enqueue_script( $handle );
}

/**
 * A footer callback can render blocks after core printed its script queue.
 *
 * Print only Kerf handles still waiting: core's done list keeps an earlier
 * script from running twice, and another plugin's queue is left to that plugin.
 */
function kerf_print_late_front_scripts() {
	if ( is_admin() ) {
		return;
	}

	$pending = array();
	foreach ( KERF_FRONT_SCRIPT_HANDLES as $handle ) {
		if ( wp_script_is( $handle, 'enqueued' ) && ! wp_script_is( $handle, 'done' ) ) {
			$pending[] = $handle;
		}
	}
	if ( $pending ) {
		wp_print_scripts( $pending );
	}
}
add_action( 'wp_footer', 'kerf_print_late_front_scripts', PHP_INT_MAX );
