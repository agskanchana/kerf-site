<?php
/**
 * Fidelity audit — which of the mockup's selectors survived conversion.
 *
 * The audit is the honest half of the product. Every converter can show you
 * output; this one tells you what it cost. It walks the source markup, collects
 * every class and id the designer wrote, and reports the ones that do not appear
 * anywhere in the converted blocks — which is exactly the set of CSS rules that
 * will silently stop matching on the live site.
 *
 * In Kerf this list should almost always be empty, and that is the point. There
 * are no dynamic blocks swapping canonical markup in for the designer's, so
 * there is no legitimate reason for a class to vanish. A non-empty result is a
 * converter bug or genuinely unconvertible input, not an expected cost of doing
 * business — which is what makes the number worth publishing.
 *
 * Zero WordPress dependencies, so the same file backs the CLI tool, the editor
 * panel, and anything hosted later.
 *
 * @package kerf
 */

// Without WordPress the engine is loaded by tools/kerf-convert.php and
// tests/bin/golden.php, which define ABSPATH as WordPress does.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Compare a mockup against its conversion.
 *
 * @param string $html   Source mockup HTML.
 * @param string $markup Converted block markup.
 * @return array{
 *     total:int, kept:int, missing:string[], score:int,
 *     blocks:array<string,int>
 * }
 */
function kerf_mc_audit( $html, $markup ) {
	$selectors = kerf_mc_source_selectors( $html );
	$missing   = array();

	// Block attributes serialize a double hyphen as `--`, because an
	// unescaped `--` inside an HTML comment can terminate it early. WordPress
	// decodes it again when it parses the block, so the class is intact on the
	// page — but a naive substring search over the raw markup reports every BEM
	// name (`card--featured`, `btn--primary`) as lost. Undo the escape before
	// searching; the alternative is an audit that cries wolf on the single most
	// common class-naming convention in circulation.
	$haystack = str_replace( array( '\\u002d', '\\u002D' ), '-', (string) $markup );

	foreach ( $selectors as $name ) {
		// A bare substring test is deliberate: a class counts as kept whether it
		// appears in a block's `className`, inside a heading's saved markup, or
		// in an inline style. Parsing the block tree to be precise would report
		// false losses for every one of those, and a false loss is worse than a
		// missed one — it trains people to ignore the report.
		$needle = ( '#' === $name[0] ) ? substr( $name, 1 ) : $name;
		if ( false === strpos( $haystack, $needle ) ) {
			$missing[] = $name;
		}
	}

	$total = count( $selectors );
	$kept  = $total - count( $missing );

	return array(
		'total'   => $total,
		'kept'    => $kept,
		'missing' => $missing,
		'score'   => ( 0 === $total ) ? 100 : (int) round( $kept / $total * 100 ),
		'blocks'  => kerf_mc_block_inventory( $markup ),
	);
}

/**
 * Every class and id written in the source markup.
 *
 * ids are prefixed with `#` so the report can tell `.header` from `#header`;
 * both matter, because a mockup hangs scroll handlers and skip links off ids and
 * a dropped one fails just as quietly as a dropped class.
 *
 * @param string $html
 * @return string[] Unique selector names, in source order.
 */
function kerf_mc_source_selectors( $html ) {
	if ( '' === trim( (string) $html ) ) {
		return array();
	}

	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML(
		'<?xml encoding="utf-8"?><div data-kerf-audit-root="1">' . kerf_mc_extract_body( $html ) . '</div>',
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
	);
	libxml_clear_errors();

	$root = $doc->documentElement;
	if ( ! $root ) {
		return array();
	}

	$found   = array();
	$skip    = kerf_mc_dropped_tags();
	$walk    = function ( $node ) use ( &$walk, &$found, $skip ) {
		foreach ( $node->childNodes as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}

			// A <script>/<style> subtree is never converted, so its selectors are
			// not a loss — counting them would put a permanent floor under the
			// score that no mockup could ever clear.
			if ( in_array( strtolower( $child->nodeName ), $skip, true ) ) {
				continue;
			}

			foreach ( preg_split( '/\s+/', $child->getAttribute( 'class' ), -1, PREG_SPLIT_NO_EMPTY ) as $class ) {
				// wp-block-* is WordPress' own vocabulary, not the designer's.
				if ( 0 === strpos( $class, 'wp-block-' ) ) {
					continue;
				}
				$found[ $class ] = true;
			}

			$id = trim( $child->getAttribute( 'id' ) );
			if ( '' !== $id ) {
				$found[ '#' . $id ] = true;
			}

			$walk( $child );
		}
	};
	$walk( $root );

	return array_keys( $found );
}

/**
 * Count the blocks in converted markup, by name.
 *
 * Surfaced in the report so "how much of this is actually editable" has a
 * number. A conversion that is mostly kerf/div is healthy; one carrying a pile
 * of core/html would not be, which is why Kerf has no raw-HTML fallback path
 * for this to find.
 *
 * @param string $markup
 * @return array<string,int> block name => count, most frequent first.
 */
function kerf_mc_block_inventory( $markup ) {
	if ( ! preg_match_all( '/<!--\s+wp:([a-z0-9-]+\/[a-z0-9-]+|[a-z0-9-]+)\s/i', (string) $markup, $m ) ) {
		return array();
	}

	$counts = array_count_values( $m[1] );
	arsort( $counts );

	// Core blocks serialize without the `core/` prefix; spell it out so the
	// report reads the same as the block inserter.
	$out = array();
	foreach ( $counts as $name => $count ) {
		$out[ false === strpos( $name, '/' ) ? 'core/' . $name : $name ] = $count;
	}

	return $out;
}
