<?php
/**
 * Attributes that run code: who may add them (§5.32).
 *
 * Alpine, htmx, Vue and their kind read code out of attributes — `x-init="…"`
 * runs like an `onload`, `hx-get` puts a server's answer into the page,
 * scripts included (kerf_mc_is_directive_attribute() has the list). With such
 * a library on the page — imported from a mockup, which only someone who may
 * add scripts can do — an attribute an Author typed into a block's HTML
 * attributes panel ran for every visitor: KSES does not recognize code in
 * block attributes or `data-*` names.
 *
 * So these follow the rule scripts follow. The converter keeps them only from
 * an import by someone who may add scripts; and on every save by anyone else,
 * an attribute that runs code survives only if the post already had it — the
 * same name with the same value. Moving what an administrator imported is
 * allowed; writing new code is not.
 *
 * Inline styles in block attributes need core's rule too: KSES filters a
 * style on an HTML tag with safecss_filter_attr(), but cannot see inlineStyle
 * or customAttributes.style. New or changed values go through that filter;
 * the exact style a trusted importer put in the post survives, like a directive.
 *
 * The renderer cannot tell an imported attribute from an injected one, so the
 * save is the gate: every write of post content passes wp_insert_post_data —
 * the editor, REST, XML-RPC, the Site Editor's templates and parts, revisions.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Remove attributes that run code which someone who may not add scripts has
 * added or changed, and filter their new or changed inline styles as core does.
 *
 * @param array $data    Slashed post data about to be written.
 * @param array $postarr The post as submitted (ID, post_type, post_parent).
 * @return array
 */
function kerf_directives_guard_post_data( $data, $postarr ) {
	if ( current_user_can( 'unfiltered_html' ) || empty( $data['post_content'] ) ) {
		return $data;
	}

	$content = wp_unslash( (string) $data['post_content'] );
	$allowed = kerf_directives_in( kerf_directives_baseline( $postarr ) );
	$guarded = kerf_directives_strip( $content, $allowed );

	if ( $guarded['removed'] ) {
		$data['post_content'] = wp_slash( $guarded['content'] );
	}

	return $data;
}
add_filter( 'wp_insert_post_data', 'kerf_directives_guard_post_data', 99, 2 );

/**
 * What the post held before this save: its stored content, and for a revision
 * or an autosave, its parent's — restoring one must not lose what the
 * administrator put there.
 *
 * @param array $postarr
 * @return string
 */
function kerf_directives_baseline( $postarr ) {
	$ids = array();
	if ( ! empty( $postarr['ID'] ) ) {
		$ids[] = (int) $postarr['ID'];
	}
	if ( ! empty( $postarr['post_parent'] ) && isset( $postarr['post_type'] ) && 'revision' === $postarr['post_type'] ) {
		$ids[] = (int) $postarr['post_parent'];
	}

	$baseline = '';
	foreach ( array_unique( $ids ) as $id ) {
		$baseline .= (string) get_post_field( 'post_content', $id, 'raw' );
	}
	return $baseline;
}

/**
 * Every attribute that runs code, and every block-held inline style, as
 * `name=json(value)` keys:
 * in Kerf and core blocks' `customAttributes`, and on the HTML elements of rich
 * text, Custom HTML and classic content.
 *
 * @param string $content
 * @return array<string,true>
 */
function kerf_directives_in( $content ) {
	$found = array();
	if ( '' === trim( (string) $content ) ) {
		return $found;
	}

	$walk = static function ( $blocks ) use ( &$walk, &$found ) {
		foreach ( $blocks as $block ) {
			if ( isset( $block['attrs']['inlineStyle'] ) ) {
				$found[ kerf_directives_key( 'inlineStyle', $block['attrs']['inlineStyle'] ) ] = true;
			}
			if ( ! empty( $block['attrs']['customAttributes'] ) && is_array( $block['attrs']['customAttributes'] ) ) {
				foreach ( $block['attrs']['customAttributes'] as $name => $value ) {
					$name = strtolower( (string) $name );
					if ( 'style' === $name || kerf_mc_is_directive_attribute( $name ) ) {
						$found[ kerf_directives_key( $name, $value ) ] = true;
					}
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$walk( $block['innerBlocks'] );
			}
		}
	};
	$walk( parse_blocks( $content ) );

	$tags = new WP_HTML_Tag_Processor( $content );
	while ( $tags->next_tag() ) {
		foreach ( (array) $tags->get_attribute_names_with_prefix( '' ) as $name ) {
			if ( kerf_mc_is_directive_attribute( $name ) ) {
				$found[ kerf_directives_key( $name, $tags->get_attribute( $name ) ) ] = true;
			}
		}
	}

	return $found;
}

/**
 * @param string $name
 * @param mixed  $value
 * @return string
 */
function kerf_directives_key( $name, $value ) {
	// A valueless attribute is '' in a block and true in HTML: one key.
	if ( true === $value ) {
		$value = '';
	}
	return strtolower( (string) $name ) . '=' . wp_json_encode( is_scalar( $value ) ? (string) $value : $value );
}

/**
 * Take out every attribute that runs code and is not in `$allowed`, and hold
 * new or changed block-held styles to safecss_filter_attr().
 *
 * The HTML pass edits tags in place (block comments are not tags); the block
 * pass re-serializes only when it removes or filters a value. A save that
 * changes nothing here leaves the content byte for byte as the editor sent it.
 *
 * @param string            $content
 * @param array<string,true> $allowed From kerf_directives_in().
 * @return array{content:string,removed:int}
 */
function kerf_directives_strip( $content, $allowed ) {
	$removed = 0;

	$tags = new WP_HTML_Tag_Processor( $content );
	while ( $tags->next_tag() ) {
		foreach ( (array) $tags->get_attribute_names_with_prefix( '' ) as $name ) {
			if ( kerf_mc_is_directive_attribute( $name ) && ! isset( $allowed[ kerf_directives_key( $name, $tags->get_attribute( $name ) ) ] ) ) {
				$tags->remove_attribute( $name );
				$removed++;
			}
		}
	}
	if ( $removed ) {
		$content = $tags->get_updated_html();
	}

	$in_blocks = 0;
	$walk      = static function ( $blocks ) use ( &$walk, &$in_blocks, $allowed ) {
		foreach ( $blocks as $i => $block ) {
			if ( isset( $block['attrs']['inlineStyle'] ) ) {
				$value = $block['attrs']['inlineStyle'];
				$style = kerf_directives_filter_style( 'inlineStyle', $value, $allowed );
				if ( $style !== $value ) {
					$blocks[ $i ]['attrs']['inlineStyle'] = $style;
					$in_blocks++;
				}
			}
			if ( ! empty( $block['attrs']['customAttributes'] ) && is_array( $block['attrs']['customAttributes'] ) ) {
				foreach ( $block['attrs']['customAttributes'] as $name => $value ) {
					$lower = strtolower( (string) $name );
					if ( 'style' === $lower ) {
						$style = kerf_directives_filter_style( 'style', $value, $allowed );
						if ( $style !== $value ) {
							$blocks[ $i ]['attrs']['customAttributes'][ $name ] = $style;
							$in_blocks++;
						}
					} elseif ( kerf_mc_is_directive_attribute( $lower ) && ! isset( $allowed[ kerf_directives_key( $lower, $value ) ] ) ) {
						unset( $blocks[ $i ]['attrs']['customAttributes'][ $name ] );
						$in_blocks++;
					}
				}
				// An emptied map would be written as `[]`, not an object.
				if ( empty( $blocks[ $i ]['attrs']['customAttributes'] ) ) {
					unset( $blocks[ $i ]['attrs']['customAttributes'] );
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$blocks[ $i ]['innerBlocks'] = $walk( $block['innerBlocks'] );
			}
		}
		return $blocks;
	};

	if ( false !== strpos( $content, '"customAttributes"' ) || false !== strpos( $content, '"inlineStyle"' ) ) {
		$blocks = $walk( parse_blocks( $content ) );
		if ( $in_blocks ) {
			$content = serialize_blocks( $blocks );
			$removed += $in_blocks;
		}
	}

	return array( 'content' => $content, 'removed' => $removed );
}

/**
 * Keep an imported style exactly; a newly written value gets core's filter.
 *
 * Like directives, a style is compared by its attribute name and exact value
 * anywhere in the baseline, so moving an imported block does not alter it.
 *
 * @param string            $name inlineStyle or style.
 * @param mixed             $value
 * @param array<string,true> $allowed From kerf_directives_in().
 * @return mixed
 */
function kerf_directives_filter_style( $name, $value, $allowed ) {
	if ( isset( $allowed[ kerf_directives_key( $name, $value ) ] ) ) {
		return $value;
	}
	return safecss_filter_attr( is_string( $value ) ? $value : '' );
}

/**
 * The mockup's `<body>`/`<html>` attributes, as an import keeps them: those
 * that run code only for someone who may add scripts (§5.32), the rest named
 * in `$dropped`.
 *
 * @param array<string,string> $attrs
 * @param string[]             $dropped Names left out, appended.
 * @return array<string,string>
 */
function kerf_directives_document_attributes( $attrs, &$dropped ) {
	if ( function_exists( 'kerf_user_can_add_scripts' ) && kerf_user_can_add_scripts() ) {
		return $attrs;
	}
	foreach ( $attrs as $name => $value ) {
		if ( kerf_mc_is_directive_attribute( (string) $name ) ) {
			unset( $attrs[ $name ] );
			$dropped[] = (string) $name;
		}
	}
	return $attrs;
}
