<?php
/**
 * The pages the mockup did not draw.
 *
 * A mockup is a home page. A WordPress site is also a blog, its posts, pages
 * written after the import, category and tag archives, search results and a
 * 404. Those render through the theme's own templates — the SHELL: the
 * imported header and footer around `main.kerf-shell`, which holds a title band
 * and WordPress content in core blocks.
 *
 * The shell is theme-authored, like §5.11's blog templates always were, so it
 * may have a stylesheet of its own (assets/css/kerf-shell.css). That stylesheet
 * reads nothing but `--kerf-*` custom properties, and their values come from
 * the home page: measured in the browser after an import (Kerf Pro's
 * kerf-design-measure.js → kerf_shell_save_measurement()), turned into tokens
 * here, overridden by whatever the owner set under Kerf → Inner pages (Kerf
 * Pro's too), and printed as one small rule on `.kerf-shell` — never on
 * anything the mockup owns. Without a measurement the tokens are empty and
 * the theme's own look shows; a measurement keeps applying without Pro.
 *
 * Pages that ARE the mockup keep rendering bare: a page whose content holds
 * Kerf blocks is routed to `kerf-mockup.html` (header, content, footer, nothing
 * else), whichever template WordPress would otherwise have chosen.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What the home page measured like: the raw result of kerf-design-read.js.
 */
const KERF_SHELL_MEASURED_OPTION = 'kerf_shell_measured';

/**
 * The owner's overrides, token => value. Empty values fall back to the measure.
 */
const KERF_SHELL_TOKENS_OPTION = 'kerf_shell_tokens';

/**
 * The layout switches: blog layout, which meta to show, the title band.
 */
const KERF_SHELL_LAYOUT_OPTION = 'kerf_shell_layout';

// ═══════════════════════════════════════════════════════════════════════════════
// TOKENS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Every token the shell stylesheet reads, and what kind of value it takes.
 *
 * An empty token is not printed, and the stylesheet's own fallback applies —
 * mostly `inherit`, so an unmeasured site already takes the mockup's body
 * font and text colour from the mockup's own CSS.
 *
 * @return array<string,string>
 */
function kerf_shell_token_schema() {
	return array(
		'font-heading'   => 'font',
		'font-body'      => 'font',
		'bg'             => 'color',
		'surface'        => 'color',
		'text'           => 'color',
		'heading'        => 'color',
		'muted'          => 'color',
		'accent'         => 'color',
		'accent-text'    => 'color',
		'border'         => 'color',
		'band-bg'        => 'color',
		'band-text'      => 'color',
		'band-image'     => 'url',
		'container'      => 'length',
		'radius'         => 'length',
		'button-radius'  => 'length',
		'header-overlap' => 'length',
	);
}

/**
 * Sanitize one token. Everything printed goes into a `<style>` element, so a
 * value is either one of a few recognizable shapes or nothing.
 *
 * @param string $type  'color', 'font', 'length' or 'url'.
 * @param mixed  $value
 * @return string
 */
function kerf_shell_sanitize_token( $type, $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}

	switch ( $type ) {
		case 'color':
			if ( preg_match( '/^#[0-9a-f]{3,8}$/i', $value ) ) {
				return strtolower( $value );
			}
			if ( preg_match( '/^(?:rgba?|hsla?)\(\s*[0-9.%\s,\/-]+\)$/i', $value ) ) {
				return $value;
			}
			if ( preg_match( '/^[a-z]{3,20}$/i', $value ) ) {
				return strtolower( $value );
			}
			return '';

		case 'font':
			// Family names and generic families: letters, digits, spaces,
			// quotes, commas, hyphens, dots. Nothing that can end a declaration.
			$value = preg_replace( '/[^\p{L}\p{N}\s,"\'\-.]/u', '', $value );
			return trim( substr( (string) $value, 0, 240 ) );

		case 'length':
			if ( preg_match( '/^0+(?:\.0+)?$/', $value ) ) {
				return '0px';
			}
			return preg_match( '/^\d{1,4}(?:\.\d{1,3})?(?:px|rem|em|%|vw)$/', $value ) ? $value : '';

		case 'url':
			return (string) esc_url_raw( $value, array( 'http', 'https' ) );
	}

	return '';
}

/**
 * The tokens in effect: the owner's override, else the measured value, else
 * nothing (the stylesheet's fallback).
 *
 * @return array<string,string>
 */
function kerf_shell_tokens() {
	$measured  = kerf_shell_tokens_from_measurement( get_option( KERF_SHELL_MEASURED_OPTION, array() ) );
	$overrides = get_option( KERF_SHELL_TOKENS_OPTION, array() );
	$overrides = is_array( $overrides ) ? $overrides : array();
	$tokens    = array();

	foreach ( kerf_shell_token_schema() as $key => $type ) {
		$value = ( isset( $overrides[ $key ] ) && '' !== trim( (string) $overrides[ $key ] ) )
			? $overrides[ $key ]
			: ( isset( $measured[ $key ] ) ? $measured[ $key ] : '' );

		$tokens[ $key ] = kerf_shell_sanitize_token( $type, $value );
	}

	// An accent the owner chose, with no text for it and none measured: the
	// stylesheet's fallback for the text is the text around the button, which
	// suits only no accent at all (the theme's kerf-shell.css, `--_fill-text`).
	// Whichever of white or near-black reads on it, as a measured accent gets.
	if ( '' !== $tokens['accent'] && '' === $tokens['accent-text'] ) {
		$tokens['accent-text'] = kerf_shell_luminance( $tokens['accent'] ) > 0.45 ? '#111111' : '#ffffff';
	}

	return $tokens;
}

/**
 * Turn what the home page measured like into tokens.
 *
 * Mostly a copy. The decisions are the title band's: a header that floats over
 * the page (absolute or fixed) was designed over the home page's hero. The band
 * it floats over on every other page has to be tall enough to clear it, and,
 * when its links are light, dark too — or the menu is white on white, which is
 * what gymlife looked like before this existed.
 *
 * @param mixed $m Measurement, as saved.
 * @return array<string,string>
 */
function kerf_shell_tokens_from_measurement( $m ) {
	if ( ! is_array( $m ) || empty( $m ) ) {
		return array();
	}

	$get = function ( $path ) use ( $m ) {
		$value = $m;
		foreach ( explode( '.', $path ) as $step ) {
			if ( ! is_array( $value ) || ! isset( $value[ $step ] ) ) {
				return '';
			}
			$value = $value[ $step ];
		}
		return is_scalar( $value ) ? (string) $value : '';
	};

	$t = array(
		'font-body'    => $get( 'fontBody' ),
		'font-heading' => $get( 'fontHeading' ),
		'text'         => $get( 'text' ),
		'heading'      => $get( 'heading' ),
		'accent'       => $get( 'accent' ),
		'band-image'   => $get( 'heroImage' ),
	);

	// The page colour behind most of the text; an image there says nothing
	// about colour, so the body's own background stands in.
	$bg = $get( 'surface' );
	if ( '' === $bg || 'image' === $bg ) {
		$bg = $get( 'bodyBg' );
	}
	$t['bg'] = $bg;

	// Text on the accent: the designer's own button text when their primary
	// button is the accent colour, otherwise whichever of white or near-black
	// reads on it.
	$button_bg = $get( 'button.bg' );
	if ( '' !== $button_bg && '' !== $t['accent'] && kerf_shell_same_color( $button_bg, $t['accent'] ) && '' !== $get( 'button.color' ) ) {
		$t['accent-text'] = $get( 'button.color' );
	} elseif ( '' !== $t['accent'] ) {
		$t['accent-text'] = kerf_shell_luminance( $t['accent'] ) > 0.45 ? '#111111' : '#ffffff';
	}

	$radius = $get( 'button.radius' );
	if ( preg_match( '/^(\d+(?:\.\d+)?)px/', $radius, $r ) ) {
		$t['button-radius'] = $r[1] . 'px';
		// Pill buttons do not make pill cards.
		$t['radius'] = min( (float) $r[1], 12 ) . 'px';
	}

	$container = (int) $get( 'container' );
	if ( $container >= 480 && $container <= 2400 ) {
		$t['container'] = $container . 'px';
	}

	// How far the header floats over the page: measured as `overlap` — only
	// the floating part, since cozastore keeps a top bar in the flow and fixes
	// its menu under it — or, in a measurement saved before that was read,
	// the whole height of a header that floats.
	$overlap = $get( 'header.overlap' );
	if ( '' === $overlap ) {
		$overlap = in_array( $get( 'header.position' ), array( 'absolute', 'fixed' ), true ) ? $get( 'header.height' ) : '0';
	}
	$overlap = (int) $overlap;

	if ( $overlap > 0 && $overlap < 400 ) {
		$t['header-overlap'] = $overlap . 'px';

		// Transparent and light-linked: designed over a dark hero, so the band
		// it floats over has to be dark. Dark links (cozastore's, over a pale
		// slider) read on the page's own surface, which is the band's default.
		$link  = $get( 'header.link' );
		$light = '' === $link || kerf_shell_luminance( $link ) > 0.55;

		if ( $light && kerf_shell_is_transparent( $get( 'header.bg' ) ) ) {
			$footer = $get( 'footer.bg' );
			if ( '' !== $footer && 'image' !== $footer && kerf_shell_luminance( $footer ) < 0.25 ) {
				$t['band-bg'] = $footer;
			} elseif ( '' !== $bg && 'image' !== $bg && kerf_shell_luminance( $bg ) < 0.25 ) {
				$t['band-bg'] = $bg;
			} else {
				$t['band-bg'] = '#111111';
			}

			$t['band-text'] = '' !== $link ? $link : '#ffffff';
		}
	}

	return array_filter( $t, 'strlen' );
}

/**
 * Parse a CSS colour into [r, g, b, a], 0–255 and 0–1. Hex and rgb()/rgba();
 * anything else is null.
 *
 * @param string $color
 * @return float[]|null
 */
function kerf_shell_rgba( $color ) {
	$color = strtolower( trim( (string) $color ) );

	if ( preg_match( '/^#([0-9a-f]{3,8})$/', $color, $m ) ) {
		$hex = $m[1];
		if ( 3 === strlen( $hex ) || 4 === strlen( $hex ) ) {
			$hex = preg_replace( '/(.)/', '$1$1', $hex );
		}
		if ( 6 !== strlen( $hex ) && 8 !== strlen( $hex ) ) {
			return null;
		}
		return array(
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
			8 === strlen( $hex ) ? hexdec( substr( $hex, 6, 2 ) ) / 255 : 1,
		);
	}

	if ( preg_match( '/^rgba?\(([^)]*)\)$/', $color, $m ) ) {
		$parts = preg_split( '/[\s,\/]+/', trim( $m[1] ) );
		if ( count( $parts ) < 3 ) {
			return null;
		}
		$alpha = isset( $parts[3] ) ? ( '%' === substr( $parts[3], -1 ) ? (float) $parts[3] / 100 : (float) $parts[3] ) : 1;
		return array( (float) $parts[0], (float) $parts[1], (float) $parts[2], $alpha );
	}

	if ( 'transparent' === $color ) {
		return array( 0, 0, 0, 0 );
	}

	return null;
}

/**
 * Relative luminance, 0 (black) to 1 (white). Unknown colours count as mid-grey.
 *
 * @param string $color
 * @return float
 */
function kerf_shell_luminance( $color ) {
	$rgba = kerf_shell_rgba( $color );
	if ( ! $rgba ) {
		return 0.5;
	}

	$channel = function ( $v ) {
		$v /= 255;
		return $v <= 0.03928 ? $v / 12.92 : pow( ( $v + 0.055 ) / 1.055, 2.4 );
	};

	return 0.2126 * $channel( $rgba[0] ) + 0.7152 * $channel( $rgba[1] ) + 0.0722 * $channel( $rgba[2] );
}

/**
 * @param string $color
 * @return bool
 */
function kerf_shell_is_transparent( $color ) {
	if ( '' === trim( (string) $color ) ) {
		return true;
	}
	$rgba = kerf_shell_rgba( $color );
	return $rgba && $rgba[3] < 0.1;
}

/**
 * Are two colours the same to the eye (each channel within 8)?
 *
 * @param string $a
 * @param string $b
 * @return bool
 */
function kerf_shell_same_color( $a, $b ) {
	$x = kerf_shell_rgba( $a );
	$y = kerf_shell_rgba( $b );
	if ( ! $x || ! $y ) {
		return false;
	}
	return abs( $x[0] - $y[0] ) <= 8 && abs( $x[1] - $y[1] ) <= 8 && abs( $x[2] - $y[2] ) <= 8;
}

/**
 * The token rule printed on shell pages.
 *
 * @return string CSS, or '' when nothing is set.
 */
function kerf_shell_tokens_css() {
	$decls = array();

	foreach ( kerf_shell_tokens() as $key => $value ) {
		if ( '' === $value ) {
			continue;
		}
		if ( 'band-image' === $key ) {
			$value = 'url("' . esc_url( $value ) . '")';
		}
		$decls[] = '--kerf-' . $key . ':' . $value;
	}

	// The shell, and a designer's own content and comments areas
	// (assets/css/kerf-prose.css): the same home-page colours for both.
	return $decls ? '.kerf-shell,[data-kerf-field~="content"],[data-kerf-field~="comments"]{' . implode( ';', $decls ) . '}' : '';
}

/**
 * The safety net for WordPress content inside a designer's page (see the
 * header of assets/css/kerf-prose.css), with the home page's tokens. Called by
 * kerf/post-content and by a comments area as they render.
 */
function kerf_shell_enqueue_prose() {
	static $done = false;
	if ( $done || is_admin() ) {
		return;
	}
	$done = true;

	$css = 'assets/css/kerf-prose.css';
	if ( ! file_exists( kerf_plugin_path( $css ) ) ) {
		return;
	}
	wp_enqueue_style( 'kerf-prose', kerf_plugin_url( $css ), array(), filemtime( kerf_plugin_path( $css ) ) );

	// The shell prints the tokens itself; a designer's template needs them here.
	if ( ! kerf_shell_rendered() ) {
		$tokens = kerf_shell_tokens_css();
		if ( '' !== $tokens ) {
			wp_add_inline_style( 'kerf-prose', $tokens );
		}
	}
}

// ═══════════════════════════════════════════════════════════════════════════════
// LAYOUT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The layout switches: type, default, and for enums the allowed values or for
 * integers the range.
 *
 * @return array<string,array>
 */
function kerf_shell_layout_schema() {
	return array(
		'blog'     => array( 'enum', 'grid-3', array( 'grid-3', 'grid-2', 'list' ) ),
		'image'    => array( 'bool', 1 ),
		'category' => array( 'bool', 1 ),
		'date'     => array( 'bool', 1 ),
		'author'   => array( 'bool', 0 ),
		'excerpt'  => array( 'int', 24, 0, 80 ),
		'band'     => array( 'enum', 'color', array( 'color', 'image', 'none' ) ),
	);
}

/**
 * The layout in effect, sanitized against the schema.
 *
 * @param array|null $raw Values to sanitize; the saved option when null.
 * @return array<string,string|int>
 */
function kerf_shell_layout( $raw = null ) {
	if ( null === $raw ) {
		$raw = get_option( KERF_SHELL_LAYOUT_OPTION, array() );
	}
	$raw    = is_array( $raw ) ? $raw : array();
	$layout = array();

	foreach ( kerf_shell_layout_schema() as $key => $spec ) {
		$value = array_key_exists( $key, $raw ) ? $raw[ $key ] : $spec[1];

		switch ( $spec[0] ) {
			case 'enum':
				$layout[ $key ] = in_array( (string) $value, $spec[2], true ) ? (string) $value : $spec[1];
				break;
			case 'bool':
				$layout[ $key ] = $value ? 1 : 0;
				break;
			case 'int':
				$layout[ $key ] = max( $spec[2], min( $spec[3], (int) $value ) );
				break;
		}
	}

	return $layout;
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Is this post the mockup — content made of Kerf blocks?
 *
 * @param mixed $post
 * @return bool
 */
function kerf_shell_is_mockup_post( $post ) {
	return $post instanceof WP_Post && false !== strpos( (string) $post->post_content, '<!-- wp:kerf/' );
}

/**
 * Keep imported pages bare.
 *
 * `page.html` and `single.html` are the shell now; a page whose content is the
 * mockup must not render inside it. It goes to `kerf-mockup.html` instead —
 * unless someone chose a template for it on purpose, which wins.
 *
 * The editor asks the same question through the REST API (the template it
 * shows with "Show template", and names in the sidebar), where nothing is
 * queried: there the post is the one the first candidate names
 * (`page-about`, `single-post-hello`) — so the editor and the page agree.
 *
 * @param string[] $templates Candidate templates, most specific first.
 * @return string[]
 */
function kerf_shell_route_singular( $templates ) {
	// `kerf-mockup` is the Kerf theme's template; another theme routes its own.
	if ( ! kerf_theme_active() ) {
		return $templates;
	}

	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		$post = kerf_shell_post_from_hierarchy( $templates );
	}

	if ( ! kerf_shell_is_mockup_post( $post ) || '' !== (string) get_page_template_slug( $post ) ) {
		return $templates;
	}

	array_unshift( $templates, 'kerf-mockup.php' );

	return $templates;
}
add_filter( 'page_template_hierarchy', 'kerf_shell_route_singular' );
add_filter( 'single_template_hierarchy', 'kerf_shell_route_singular' );

/**
 * The post a template hierarchy was built for, read from its first candidate —
 * for the editor's template lookup, which carries no post, only the
 * hierarchy core built from its slug.
 *
 * @param string[] $templates
 * @return WP_Post|null
 */
function kerf_shell_post_from_hierarchy( $templates ) {
	foreach ( (array) $templates as $template ) {
		$slug = preg_replace( '/\.php$/', '', (string) $template );

		// Post types are named without dashes; post names may hold them.
		if ( preg_match( '/^page-(.+)$/', $slug, $m ) ) {
			$type = 'page';
			$name = $m[1];
		} elseif ( preg_match( '/^single-([a-z0-9_]+)-(.+)$/', $slug, $m ) ) {
			$type = $m[1];
			$name = $m[2];
		} else {
			continue;
		}

		// An array of types, never a string: a string also matches
		// attachments (scar 47).
		$post = get_page_by_path( $name, OBJECT, array( $type ) );
		if ( $post instanceof WP_Post ) {
			return $post;
		}
	}

	return null;
}

/**
 * A front page that is the mockup renders bare, through `kerf-mockup.html`.
 *
 * The theme has no front-page template of its own (§8.14): without this
 * plugin a front page takes the shell, as the blog and every page do. With it,
 * an imported home page goes to the bare template — right for the mockup, and
 * wrong for a front page written in WordPress or one that shows the latest
 * posts, which fall through to the shell's page or blog template. A template
 * chosen for the page on purpose wins here too: a page with a design of its
 * own is Blank, its header and footer in its content (§5.39).
 *
 * @param string[] $templates
 * @return string[]
 */
function kerf_shell_route_front( $templates ) {
	if ( ! kerf_theme_active() ) {
		return $templates;
	}

	if ( 'page' !== get_option( 'show_on_front' ) ) {
		return array();
	}

	$front = get_post( (int) get_option( 'page_on_front' ) );

	return kerf_shell_is_mockup_post( $front ) && '' === (string) get_page_template_slug( $front ) ? array( 'kerf-mockup.php' ) : array();
}
add_filter( 'frontpage_template_hierarchy', 'kerf_shell_route_front' );

// ═══════════════════════════════════════════════════════════════════════════════
// RENDERING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Has a shell been rendered on this request? Set by kerf_shell_render().
 *
 * @param bool|null $set
 * @return bool
 */
function kerf_shell_rendered( $set = null ) {
	static $rendered = false;
	if ( null !== $set ) {
		$rendered = (bool) $set;
	}
	return $rendered;
}

/**
 * Recognise the shell's `<main>` as it renders: stamp the layout switches on
 * it, and load what the shell needs.
 *
 * Block templates render before `<head>`, so what is enqueued here is printed
 * in the head of the same page. Keyed on the class rather than on the template
 * that is showing, so a template the owner rebuilt in the Site Editor keeps its
 * style as long as it keeps the shell.
 *
 * @param string $block_content
 * @param array  $block
 * @return string
 */
function kerf_shell_render( $block_content, $block ) {
	// The theme's templates are core groups since the theme stood on its own
	// (§8.14); a template customized before that keeps its kerf/div.
	$name = isset( $block['blockName'] ) ? $block['blockName'] : '';
	if ( is_admin() || ! kerf_theme_active() || ( 'core/group' !== $name && 'kerf/div' !== $name ) ) {
		return $block_content;
	}

	$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( ! preg_match( '/(?:^|\s)kerf-shell(?:\s|$)/', $class ) ) {
		return $block_content;
	}

	kerf_shell_enqueue();

	$tokens    = kerf_shell_tokens();
	$processor = new WP_HTML_Tag_Processor( $block_content );

	if ( $processor->next_tag() ) {
		$layout = kerf_shell_layout();
		foreach ( $layout as $key => $value ) {
			$processor->set_attribute( 'data-kerf-' . $key, (string) $value );
		}
		// A title band with a picture shows the page's or post's own featured
		// image where it has one (else the home page's), and the article below
		// does not show it a second time.
		$featured = 'image' === $layout['band'] && function_exists( 'kerf_bg_featured_url' ) ? kerf_bg_featured_url() : '';
		if ( '' !== $featured ) {
			$processor->set_attribute( 'style', '--kerf-band-image:' . kerf_bg_css_url( $featured ) );
			$processor->set_attribute( 'data-kerf-band-featured', '' );
			static $hidden = false;
			if ( ! $hidden && wp_style_is( 'kerf-shell', 'enqueued' ) ) {
				$hidden = true;
				wp_add_inline_style( 'kerf-shell', '.kerf-shell[data-kerf-band-featured] .kerf-shell__featured{display:none}' );
			}
		}
		// Known before any script runs, so the band under a light floating
		// header is dark on the first paint; kerf-shell.js re-measures after
		// it. A floating header with dark links only needs the clearance,
		// which the overlap token gives without this.
		$floats = '' !== $tokens['header-overlap'] && '0px' !== $tokens['header-overlap'];
		if ( $floats && '' !== $tokens['band-bg'] && kerf_shell_luminance( $tokens['band-bg'] ) < 0.4 ) {
			$processor->set_attribute( 'data-kerf-overlap', '' );
		}
	}

	return $processor->get_updated_html();
}
add_filter( 'render_block', 'kerf_shell_render', 10, 2 );

/**
 * The shell's stylesheet, its tokens, its header-clearance script, and the
 * core CSS its WordPress content needs.
 */
function kerf_shell_enqueue() {
	if ( kerf_shell_rendered() ) {
		return;
	}
	kerf_shell_rendered( true );

	// The sheet and the header-clearance script are the theme's
	// (assets/css/kerf-shell.css, assets/js/kerf-shell.js), registered by it
	// before any template renders; the tokens are this plugin's.
	if ( wp_style_is( 'kerf-shell', 'registered' ) ) {
		wp_enqueue_style( 'kerf-shell' );
		$tokens = kerf_shell_tokens_css();
		if ( '' !== $tokens ) {
			wp_add_inline_style( 'kerf-shell', $tokens );
		}
	}
	if ( wp_script_is( 'kerf-shell', 'registered' ) ) {
		wp_enqueue_script( 'kerf-shell' );
	}

	// The content of these pages is WordPress content — core blocks written in
	// the editor — so it gets WordPress' block CSS whatever the core-CSS level
	// says. That level exists for the mockup's pages (kerf_assets_filter_core_css()).
	wp_enqueue_style( 'wp-block-library' );
	add_action( 'wp_enqueue_scripts', 'kerf_shell_enqueue_global_styles', 101 );
}

/**
 * Put core's layout and block-support CSS back on a shell page, after
 * kerf_assets_filter_core_css() took it off (priority 100).
 */
function kerf_shell_enqueue_global_styles() {
	if ( function_exists( 'wp_enqueue_global_styles' ) ) {
		wp_enqueue_global_styles();
	}
	wp_enqueue_style( 'wp-block-library' );
}

/**
 * Card excerpts at the length chosen under Kerf → Inner pages.
 *
 * @param array $parsed_block
 * @return array
 */
function kerf_shell_excerpt_length( $parsed_block ) {
	if ( isset( $parsed_block['blockName'] ) && 'core/post-excerpt' === $parsed_block['blockName']
		&& isset( $parsed_block['attrs']['className'] ) && false !== strpos( $parsed_block['attrs']['className'], 'kerf-card__excerpt' ) ) {
		$layout = kerf_shell_layout();
		if ( $layout['excerpt'] > 0 ) {
			$parsed_block['attrs']['excerptLength'] = $layout['excerpt'];
		}
	}
	return $parsed_block;
}
add_filter( 'render_block_data', 'kerf_shell_excerpt_length' );

/**
 * The theme's own base look (its assets/css/kerf-base.css) is for a site with
 * no design: once one is imported, the design's CSS owns every pixel, and the
 * pages it did not draw take its look through the shell's tokens.
 *
 * @param bool $load
 * @return bool
 */
function kerf_shell_theme_base_styles( $load ) {
	return $load && empty( kerf_assets_get() );
}
add_filter( 'kerf_theme_base_styles', 'kerf_shell_theme_base_styles' );

/**
 * Pages loaded into Kerf's own frames — the measurement and the preview — have
 * no admin bar: it is a fixed element at the top of the page, which is exactly
 * what the header measurement looks for.
 */
function kerf_shell_quiet_frames() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- presentation only.
	if ( isset( $_GET['kerf_measure'] ) || isset( $_GET['kerf_preview'] ) ) {
		add_filter( 'show_admin_bar', '__return_false' );
	}
}
add_action( 'init', 'kerf_shell_quiet_frames' );
