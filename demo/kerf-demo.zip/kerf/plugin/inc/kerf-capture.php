<?php
/**
 * What a design's scripts make, for the editor (§5.37).
 *
 * The editor gets a mockup's stylesheets, never its scripts (§5.16). A design
 * styled by Tailwind's browser build — which AI tools write constantly — has
 * no stylesheet to give: in the editor it was Times New Roman and no layout,
 * while the page was perfect. Icons drawn by Lucide or Feather were blank.
 *
 * After an import, while Kerf reads the home page in the admin's browser
 * (kerf-design-read.js), it also copies what those scripts made: Tailwind's
 * CSS, generated for every class the design may use, and each icon's SVG.
 * The editor gets the CSS as one more stylesheet, and each icon as a CSS mask
 * on the design's own element, coloured like its text — the editor's markup
 * is not touched. The page itself is unchanged: there the scripts run.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_CAPTURE_OPTION = 'kerf_captured';

/**
 * REST: save what was captured.
 */
function kerf_capture_routes() {
	register_rest_route( 'kerf/v1', '/captured', array(
		'methods'             => 'POST',
		'permission_callback' => static function () {
			return kerf_user_can_import();
		},
		'callback'            => static function ( $request ) {
			$data  = (array) $request->get_json_params();
			$saved = kerf_capture_save( $data );
			// The editor that read it applies it at once (kerf-capture-editor.js).
			return rest_ensure_response( array(
				'saved' => $saved,
				'css'   => $saved ? kerf_capture_editor_css( isset( $data['page'] ) ? (int) $data['page'] : 0 ) : '',
			) );
		},
	) );
}
add_action( 'rest_api_init', 'kerf_capture_routes' );

/**
 * Does a design's editor still wait for what its scripts make?
 *
 * The capture is made after an import, by the report in the admin's browser
 * (kerf-import-report.js). An import that never showed it — from the command
 * line, over REST, a tab closed before the report read the page — left a
 * Tailwind design unstyled in the editor for good: the owner's Wellness test
 * site was Times New Roman there and right on the page. True when the
 * design's own files load Tailwind's browser build, Lucide or Feather, or
 * hold a style Tailwind reads, and nothing has been captured for it since it
 * was imported (a site import clears the copy, scar 85).
 *
 * @param int $post_id The page being edited; 0 for the site's design.
 * @return bool
 */
function kerf_capture_pending( $post_id = 0 ) {
	$design   = kerf_assets_design( (int) $post_id );
	$captured = null !== $design['captured'] ? $design['captured'] : get_option( KERF_CAPTURE_OPTION, array() );
	if ( is_array( $captured ) && ! empty( $captured['at'] ) ) {
		return false;
	}

	foreach ( $design['assets'] as $asset ) {
		$type = isset( $asset['type'] ) ? (string) $asset['type'] : '';
		$src  = isset( $asset['src'] ) ? (string) $asset['src'] : '';
		if ( 'typed-style' === $type && false !== stripos( isset( $asset['attrs']['type'] ) ? (string) $asset['attrs']['type'] : '', 'tailwind' ) ) {
			return true;
		}
		if ( 'js' === $type && '' !== $src && preg_match( '#cdn\.tailwindcss\.com|@tailwindcss/browser|lucide|feather-icons|/feather(?:\.min)?\.js#i', $src ) ) {
			return true;
		}
	}
	return false;
}

/**
 * The page a design is read on for its editor: the page with a design of its
 * own, else the site's design page (the front page, as the import's report
 * reads it).
 *
 * @param int $post_id The page being edited.
 * @return array{page:int,url:string}
 */
function kerf_capture_source( $post_id = 0 ) {
	$design = kerf_assets_design( (int) $post_id );
	if ( $design['page'] ) {
		return array( 'page' => (int) $design['page'], 'url' => add_query_arg( 'kerf_measure', '1', get_permalink( $design['page'] ) ) );
	}

	$page = (int) get_option( 'kerf_mockup_page', 0 );
	$url  = $page && (int) get_option( 'page_on_front' ) !== $page && 'publish' === get_post_status( $page )
		? get_permalink( $page )
		: home_url( '/' );
	return array( 'page' => 0, 'url' => add_query_arg( 'kerf_measure', '1', $url ) );
}

/**
 * Read the design in the editor when its capture is missing: the same reading
 * the import's report does (kerf-design-read.js), started by the editor for
 * someone who may save it, and applied to the canvas as soon as it is saved
 * (kerf-capture-editor.js) — every later load of the editor has it as one of
 * its styles, as after an import seen through the screen.
 */
function kerf_capture_editor_fallback() {
	if ( ! kerf_user_can_import() ) {
		return;
	}
	$post    = get_post();
	$post_id = $post instanceof WP_Post ? (int) $post->ID : 0;
	if ( ! kerf_theme_active() && ( ! $post || false === strpos( (string) $post->post_content, '<!-- wp:kerf/' ) ) ) {
		return;
	}
	if ( ! kerf_capture_pending( $post_id ) ) {
		return;
	}

	$reader = 'assets/js/kerf-design-read.js';
	$script = 'assets/js/kerf-capture-editor.js';
	wp_register_script( 'kerf-design-read', kerf_plugin_url( $reader ), array(), filemtime( kerf_plugin_path( $reader ) ), true );
	wp_enqueue_script( 'kerf-capture-editor', kerf_plugin_url( $script ), array( 'kerf-design-read', 'wp-api-fetch' ), filemtime( kerf_plugin_path( $script ) ), true );
	wp_localize_script( 'kerf-capture-editor', 'KerfCaptureEditor', kerf_capture_source( $post_id ) );
}
add_action( 'enqueue_block_editor_assets', 'kerf_capture_editor_fallback' );

/**
 * Keep what the browser copied: CSS as text, each icon through the SVG
 * sanitizer — the browser is the admin's, but what it read was the mockup.
 * A page with a design of its own keeps its copy in its set
 * (kerf_asset_sets()); the site's is an option.
 *
 * @param array $data { css, icons, page }.
 * @return bool
 */
function kerf_capture_save( $data ) {
	if ( ! kerf_user_can_import() ) {
		return false;
	}
	$css = isset( $data['css'] ) ? (string) $data['css'] : '';
	if ( strlen( $css ) > 3 * MB_IN_BYTES ) {
		$css = '';
	}

	$icons = array();
	foreach ( isset( $data['icons'] ) && is_array( $data['icons'] ) ? $data['icons'] : array() as $key => $svg ) {
		if ( ! preg_match( '/^(lucide|feather):[a-z0-9-]{1,60}$/', (string) $key ) || count( $icons ) >= 400 ) {
			continue;
		}
		$clean = kerf_sanitize_svg_markup( (string) $svg, 'file' );
		if ( '' !== $clean ) {
			$icons[ $key ] = $clean;
		}
	}

	$captured = array( 'css' => $css, 'icons' => $icons, 'at' => time() );

	$page = isset( $data['page'] ) ? (int) $data['page'] : 0;
	if ( $page ) {
		$sets = kerf_asset_sets();
		if ( ! isset( $sets[ $page ] ) ) {
			return false;
		}
		$sets[ $page ]['captured'] = $captured;
		kerf_asset_set_save( $page, $sets[ $page ] );
		return true;
	}

	return update_option( KERF_CAPTURE_OPTION, $captured, false ) || true;
}

/**
 * The editor's stylesheet: the generated CSS, then a rule per icon.
 *
 * @param int $post_id The page being edited: its own design's copy, if it
 *                     has one (kerf_assets_design()); else the site's.
 * @return string
 */
function kerf_capture_editor_css( $post_id = 0 ) {
	$design   = kerf_assets_design( (int) $post_id );
	$captured = null !== $design['captured'] ? $design['captured'] : get_option( KERF_CAPTURE_OPTION, array() );
	if ( ! is_array( $captured ) ) {
		return '';
	}

	$css = isset( $captured['css'] ) ? (string) $captured['css'] : '';
	if ( ! empty( $captured['icons'] ) && is_array( $captured['icons'] ) ) {
		foreach ( $captured['icons'] as $key => $svg ) {
			list( $set, $name ) = array_pad( explode( ':', (string) $key, 2 ), 2, '' );
			$attribute = 'lucide' === $set ? 'data-lucide' : 'data-feather';
			$name      = preg_replace( '/[^a-z0-9-]/', '', $name );
			$url       = 'data:image/svg+xml,' . rawurlencode( (string) $svg );
			$css      .= '[' . $attribute . '="' . $name . '"]{display:inline-block;background-color:currentColor;'
				. '-webkit-mask:url("' . $url . '") center/contain no-repeat;mask:url("' . $url . '") center/contain no-repeat}';
		}
		// An icon with no size of its own is drawn at the scripts' default.
		$css .= '[data-lucide]:not([class*="w-"]):not([class*="size-"]),[data-feather]:not([class*="w-"]):not([class*="size-"]){width:24px;height:24px}';
	}

	return kerf_css_inert( $css );
}

/**
 * Hand it to the editor, after the mockup's own stylesheets — where the
 * scripts put it on the page.
 *
 * @param array                        $settings
 * @param WP_Block_Editor_Context|null $context
 * @return array
 */
function kerf_capture_editor_styles( $settings, $context = null ) {
	$post = isset( $context->post ) && $context->post instanceof WP_Post ? $context->post : null;

	// As the design's own stylesheets: under another theme, only where the
	// content is Kerf blocks (kerf_assets_editor_styles()).
	if ( ! kerf_theme_active() && ( ! $post || false === strpos( (string) $post->post_content, '<!-- wp:kerf/' ) ) ) {
		return $settings;
	}

	$css = kerf_capture_editor_css( $post ? (int) $post->ID : 0 );
	if ( '' !== $css ) {
		$settings['styles']   = isset( $settings['styles'] ) && is_array( $settings['styles'] ) ? $settings['styles'] : array();
		$settings['styles'][] = array( 'css' => $css, '__unstableType' => 'theme', 'isGlobalStyles' => false, 'kerfDesign' => true );
	}
	return $settings;
}
add_filter( 'block_editor_settings_all', 'kerf_capture_editor_styles', 20, 2 );
