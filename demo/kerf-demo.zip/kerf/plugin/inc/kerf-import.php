<?php
/**
 * One-shot mockup import: a folder of HTML becomes a working site.
 *
 * The reference implementation converted section by section — paste a header
 * into the header part, paste a hero into the page, repeat. That works, and it
 * is roughly twenty manual steps in which the operator is responsible for
 * remembering which part each chunk belongs in, importing the images first so
 * the manifest resolves, and pasting the stylesheet somewhere sensible at the
 * end. Every one of those steps is a place to get it wrong.
 *
 * This does the whole document in one pass:
 *
 *   1. read the mockup (a pasted page, or a ZIP of the designer's folder)
 *   2. stage css/js/fonts/images into uploads, KEEPING THE FOLDER STRUCTURE
 *   3. import content images into the media library
 *   4. lift stylesheets, styles and scripts out and register them as real assets
 *   5. split <header> / <main> / <footer>
 *   6. convert all three at once
 *   7. write the header and footer template parts, create the page
 *   8. report what changed and what was lost
 *
 * WHY THE FOLDER STRUCTURE IS KEPT (step 2): a mockup's stylesheet is full of
 * relative references — `url(../images/hero.jpg)`, `src: url(fonts/icons.woff2)`.
 * Flattening the files into one directory means rewriting every one of those,
 * correctly, in CSS the converter never parses. Mirroring the tree instead
 * makes all of them resolve unchanged, and rewriting nothing is always more
 * faithful than rewriting well.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Largest ZIP accepted, in bytes.
 *
 * Generous for a mockup (they are mostly images) and far below the point where
 * extraction threatens the disk.
 */
const KERF_IMPORT_MAX_ZIP = 67108864; // 64 MB.

/**
 * Largest number of files accepted from one ZIP.
 */
const KERF_IMPORT_MAX_FILES = 2000;

/**
 * Attachment meta holding the MD5 of the file an image was imported from.
 */
const KERF_IMPORT_HASH_META = '_kerf_source_md5';

/**
 * Asset file extensions staged into uploads as-is.
 */
const KERF_IMPORT_ASSET_EXT = 'css|js|mjs|woff|woff2|ttf|otf|eot|svg|png|jpg|jpeg|gif|webp|avif|bmp|ico|mp4|webm|ogv|ogg|mp3|wav|m4a|oga|vtt|pdf|json|map|txt|webmanifest';

/**
 * Extensions a server may run a file by, wherever they stand in its name
 * (kerf_import_servable()).
 */
const KERF_IMPORT_EXEC_EXT = 'php\d*|phtml|phar|pht|phps|pl|py|cgi|asp|aspx|jsp|shtml?';

// ═══════════════════════════════════════════════════════════════════════════════
// WHAT AN IMPORT IS ASKED (its screen is inc/kerf-import-screen.php)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The converter's options for an import — and for an update or a pasted
 * section, which must convert as the import did (scar 71).
 *
 * What the design is converted with beyond its files: `site_details` (the
 * business's details found and bound, §5.36) and `dynamic` (posts, comments
 * and their details filled in where the design marks them, §5.25) are off
 * here; Kerf Pro switches them on.
 *
 * @param array $options Where the design's files are, whether the importer may
 *                       add scripts.
 * @return array
 */
function kerf_import_converter_options( $options ) {
	/**
	 * Filter the converter's options for an import, an update or a pasted
	 * section. Kerf Pro sets `site_details` and `dynamic`.
	 *
	 * @param array $options
	 */
	return (array) apply_filters( 'kerf_import_converter_options', $options + array( 'site_details' => false, 'dynamic' => false ) );
}

/**
 * What a design may be imported for: the whole site, and whatever an add-on
 * offers — Kerf Pro's "one page of its own" (§5.39). scope => label.
 *
 * @return array<string,string>
 */
function kerf_import_scopes() {
	$site = array( 'site' => __( 'The whole site — its header, footer and styles become the site\'s', 'kerf-blocks' ) );
	/**
	 * Filter what a design may be imported for. The whole site is always first.
	 *
	 * @param array<string,string> $scopes
	 */
	return $site + (array) apply_filters( 'kerf_import_scopes', $site );
}

/**
 * The scope this import was asked for, if one on offer; else the whole site.
 *
 * @return string
 */
function kerf_import_scope() {
	$scope = isset( $_POST['kerf_scope'] ) ? sanitize_key( wp_unslash( $_POST['kerf_scope'] ) ) : 'site'; // phpcs:ignore WordPress.Security.NonceVerification -- read inside the checked import.
	return isset( kerf_import_scopes()[ $scope ] ) ? $scope : 'site';
}

/**
 * What an import without Kerf Pro says about the design's other pages.
 *
 * @param string[] $files Their file names.
 * @return string
 */
function kerf_import_more_pages_note( $files ) {
	return sprintf(
		/* translators: 1: number of pages, 2: list of file names. */
		_n(
			'Your design has %1$d more page: %2$s. Kerf Pro imports it too, linked from the home page.',
			'Your design has %1$d more pages: %2$s. Kerf Pro imports them too, each linked where the design links it.',
			count( $files ),
			'kerf-blocks'
		),
		count( $files ),
		implode( ', ', $files )
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE PIPELINE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Handle a submitted import, if there is one — recorded, so it can be undone
 * (inc/kerf-undo.php). The check before an import, a cancel, a dry run and a
 * refused import write nothing, and leave the previous import undoable.
 *
 * @return array|null Result payload, or null when nothing was submitted.
 */
function kerf_import_handle_post() {
	$recording = kerf_user_can_import() && ! empty( $_POST['kerf_action'] ) && 'import' === $_POST['kerf_action']; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput -- compared, only to know whether to record; kerf_import_run_post() checks the nonce before anything is done.
	if ( $recording ) {
		kerf_undo_begin();
	}
	$result = kerf_import_run_post();
	if ( $recording ) {
		kerf_undo_finish( ! empty( $result['page_id'] )
			/* translators: %s: page title. */
			? sprintf( __( 'Import into “%s”', 'kerf-blocks' ), get_the_title( (int) $result['page_id'] ) )
			: __( 'An import', 'kerf-blocks' ) );
	}
	return $result;
}

/**
 * The import itself: read, check, convert, write.
 *
 * @return array|null
 */
function kerf_import_run_post() {
	if ( empty( $_POST['kerf_action'] ) ) {
		return null;
	}
	if ( ! kerf_user_can_import() ) {
		return array( 'error' => kerf_import_permission_message() );
	}
	if ( ! isset( $_POST['kerf_import_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_import_nonce'] ) ), 'kerf_import' ) ) {
		return array( 'error' => __( 'Security check failed. Reload the page and try again.', 'kerf-blocks' ) );
	}

	$action = sanitize_key( wp_unslash( $_POST['kerf_action'] ) );
	$token  = isset( $_POST['kerf_pending'] ) ? sanitize_key( wp_unslash( $_POST['kerf_pending'] ) ) : '';

	// Cancelled after the check: the upload goes; nothing was written.
	if ( 'cancel' === $action ) {
		$pending = '' !== $token ? kerf_import_pending_take( $token ) : null;
		if ( $pending ) {
			kerf_import_discard( isset( $pending['staging'] ) ? $pending['staging'] : null );
		}
		return array( 'cancelled' => true );
	}

	// The screen's first step: the design read, staged and checked — nothing
	// written until the owner has seen what was found.
	if ( 'check' === $action ) {
		return kerf_import_check();
	}

	$dry_run = ( 'dry-run' === $action );
	// What the design is for: the whole site, or less — an add-on's scope
	// (Kerf Pro's page of its own, §5.39). Anything but the whole site writes
	// nothing site-wide: its parts, styles and attributes are its own.
	$scope      = kerf_import_scope();
	$standalone = 'site' !== $scope;
	$base_url   = isset( $_POST['kerf_base_url'] ) ? esc_url_raw( wp_unslash( $_POST['kerf_base_url'] ) ) : '';

	// ── 1. Get the document, and the staged asset folder if a ZIP came with it:
	// what the check parked (the screen's second step), or — in one go, from
	// the command line — the upload.
	$choices = array();
	if ( '' !== $token ) {
		$pending = kerf_import_pending_take( $token );
		if ( ! $pending ) {
			return array( 'error' => __( 'That import has expired or was already finished. Upload the ZIP again.', 'kerf-blocks' ) );
		}
		$source    = array(
			'html'    => $pending['staging'] ? (string) $pending['staging']['html'] : (string) $pending['html'],
			'staging' => $pending['staging'],
			'actions' => (array) $pending['actions'],
		);
		$preflight = (array) $pending['preflight'];
		$base_url  = (string) $pending['base_url'];
		$design    = array( 'title' => (string) $pending['title'], 'file' => (string) $pending['name'] );
		// What each of the design's other pages becomes, as the check step
		// asked (Kerf Pro's); cleaned where it is used, kerf_import_pages_apply_choices().
		$choices = isset( $_POST['kerf_page'] ) && is_array( $_POST['kerf_page'] ) ? wp_unslash( $_POST['kerf_page'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- see above.
	} else {
		$source = kerf_import_read_source();
		if ( ! empty( $source['error'] ) ) {
			return array( 'error' => $source['error'] );
		}
		$preflight = kerf_preflight( $source['html'], $source['staging'] );
		$design    = array( 'title' => kerf_import_document_title( $source['html'] ), 'file' => kerf_import_source_name( $source ) );
	}

	// What will not work on the site, before anything is written. An app whose
	// page is empty until JavaScript draws it would import as a blank page:
	// that stops here unless the owner said to go on (kerf-preflight.php).
	if ( kerf_preflight_blocks( $preflight ) && empty( $_POST['kerf_preflight_override'] ) ) {
		kerf_import_discard( $source['staging'] );
		return array(
			'error'     => __( 'This design cannot be imported as it is — see below. Nothing was written.', 'kerf-blocks' ),
			'preflight' => $preflight,
		);
	}

	$html    = $source['html'];
	$staging = $source['staging']; // null for a paste.
	$actions = $source['actions'];

	// The business's details the owner confirmed for this design (Kerf Pro's
	// build screen puts them in its staging): the site's, before anything is
	// converted. A template's samples never replace what the site keeps
	// (kerf_site_remember()); these are the owner's words.
	if ( ! $dry_run && $staging && ! empty( $staging['site_details'] ) && is_array( $staging['site_details'] ) ) {
		$confirmed = kerf_site_confirm( $staging['site_details'] );
		if ( $confirmed ) {
			$actions[] = sprintf(
				/* translators: %s: list of details, as "Phone, Email". */
				__( 'Kept the business details you confirmed as the site\'s: %s.', 'kerf-blocks' ),
				implode( ', ', array_map( 'kerf_site_label', $confirmed ) )
			);
		}
	}

	// ── 2. Media library, so the converter's cascade can resolve image paths.
	$manifest = null;
	if ( $staging && ! empty( $_POST['kerf_do_media'] ) && ! $dry_run ) {
		$media     = kerf_import_media( $staging['dir'] );
		$manifest  = array( 'media' => $media['items'] );
		$actions[] = $media['reused']
			? sprintf(
				/* translators: 1: number of new images, 2: number of images already in the library. */
				__( 'Imported %1$d new images into the media library, and reused %2$d that were already there.', 'kerf-blocks' ),
				$media['count'],
				$media['reused']
			)
			: sprintf(
				/* translators: %d: number of images. */
				_n( 'Imported %d image into the media library.', 'Imported %d images into the media library.', $media['count'], 'kerf-blocks' ),
				$media['count']
			);
	}

	// ── 3. Assets. Lifted out before conversion so the converter never sees them.
	$assets = kerf_assets_extract( $html, $base_url );
	if ( $staging ) {
		$assets = kerf_import_localize_assets( $assets, $staging );
	}

	// ── 4. Split and convert. One pass over the whole document.
	$body  = kerf_mc_extract_body( $html );
	$split = array( 'parts' => kerf_import_split( $body ), 'actions' => array() );
	if ( $standalone ) {
		/**
		 * The regions of a design not for the whole site — Kerf Pro's page of
		 * its own is its body whole (kerf_import_whole_page()) — and what the
		 * report says about it.
		 *
		 * @param array      $split   { parts: kerf_import_split()'s shape, actions: string[] }.
		 * @param string     $body
		 * @param string     $scope
		 * @param array|null $staging
		 */
		$split = (array) apply_filters( 'kerf_import_parts', $split, $body, $scope, $staging );
	}
	$parts   = $split['parts'];
	$actions = array_merge( $actions, (array) $split['actions'] );

	if ( ! empty( $parts['folded'] ) ) {
		$actions[] = sprintf(
			/* translators: %s: list of elements. */
			__( 'Site-wide markup outside the header and footer was folded into the nearest template part, so it appears on every page: %s', 'kerf-blocks' ),
			implode( ', ', $parts['folded'] )
		);
	}
	if ( ! empty( $parts['front_only'] ) ) {
		$actions[] = sprintf(
			/* translators: %s: list of elements. */
			__( 'Kept in the header but shown on the home page only, because it carries the home page\'s headline: %s. Change it under the block\'s Visibility settings.', 'kerf-blocks' ),
			implode( ', ', $parts['front_only'] )
		);
	}

	$converter_options = kerf_import_converter_options( array(
		'base_url'    => $base_url,
		'staging_url' => $staging ? $staging['base_url'] : '',
		'base_rel'    => $staging ? $staging['base_rel'] : '',
		// Attributes that run code (Alpine, htmx…) are scripts (§5.32).
		'directives'  => kerf_user_can_add_scripts(),
	) );

	// The page frame: the element(s) wrapping header, content and footer, kept
	// as kerf/div attributes so kerf/frame can re-emit them around every page.
	$frame = array();
	foreach ( $parts['frame'] as $shell ) {
		$shell_result = kerf_mc_convert_html( $shell, $manifest, $converter_options );
		$blocks       = parse_blocks( $shell_result['markup'] );
		$block        = isset( $blocks[0]['blockName'] ) && 'kerf/div' === $blocks[0]['blockName'] ? $blocks[0] : null;
		if ( $block ) {
			$frame[] = $block['attrs'];
		}
	}
	if ( $frame ) {
		$actions[] = sprintf(
			/* translators: %s: element description, e.g. <div> #wrapper. */
			__( 'The whole page sits inside %s, so it wraps the header, the content and the footer on every page.', 'kerf-blocks' ),
			implode( ' › ', array_map( 'kerf_import_describe_frame', $frame ) )
		);
	}

	$converted = array();
	$report    = array_merge( kerf_preflight_report( $preflight ), kerf_import_disarm_report( $staging ), kerf_assets_data_script_report( $html ) );
	$markup    = implode( '', array_map( function ( $attrs ) {
		return '<!-- wp:kerf/div ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' /-->';
	}, $frame ) );

	$site_known  = array(); // This import's details so far (kerf_site_run_known()).
	$live_marked = 0;       // Places marked for live posts that kept the samples.
	foreach ( array( 'before', 'header', 'main', 'footer', 'after' ) as $region ) {
		if ( '' === trim( $parts[ $region ] ) ) {
			$converted[ $region ] = '';
			continue;
		}

		// The mockup's own <header>/<footer> is kept as-is. Kerf's templates
		// reference their template parts WITHOUT a tagName, so the part renders
		// its content with no wrapper at all — which means the designer's
		// `<header class="site-header">` is the page's one and only banner
		// landmark, and a selector written as `header.site-header` still matches.
		//
		// Demoting it to a <div> (which the reference implementation had to do,
		// because its header part hard-coded a <header> wrapper) traded a correct
		// selector for a duplicate landmark. Not wrapping is strictly better, and
		// kerf_mc_demote_root_landmark() stays available for the REST endpoint,
		// where the caller may well be pasting into a part that does wrap.
		// Stamped: each top-level section carries where it came from, so a
		// newer version of the mockup can be applied section by section
		// (inc/kerf-sync.php).
		$result = kerf_mc_convert_html( $parts[ $region ], $manifest, $converter_options + array(
			'eager_images' => ( 'header' === $region ),
			'stamp'        => true,
			// What the regions before this one found, so a phone in the header
			// and the same phone in the footer are one detail (inc/kerf-site.php).
			'site_known'   => $site_known,
		) );

		$converted[ $region ] = $result['markup'];
		$report               = array_merge( $report, $result['report'] );
		$markup              .= $result['markup'];
		$site_known           = $result['site'];
		$live_marked         += (int) $result['live_marked'];
	}
	if ( $live_marked ) {
		$actions[] = __( 'Your design marks where your posts go; they show its sample posts for now. Kerf Pro fills them with your real posts.', 'kerf-blocks' );
	}

	// The business's details, kept in one place (inc/kerf-site.php): only keys
	// not set yet, so the owner's own changes outlive a newer design. The
	// other pages match against what the home page found.
	kerf_site_run_known( $site_known );
	if ( ! $dry_run ) {
		$site_added = kerf_site_remember( $site_known );
		if ( $site_added ) {
			$actions[] = sprintf(
				/* translators: %s: list of details, e.g. "Phone, Email, Facebook". */
				__( 'Your business details are now changed in one place, Kerf → Site details: %s.', 'kerf-blocks' ),
				implode( ', ', array_map( 'kerf_site_label', $site_added ) )
			);
		}
	}

	// The stamps are bookkeeping, not markup: a hash must not pass for a class.
	$audit = kerf_mc_audit( $body, kerf_sync_strip_stamps( $markup ) );

	// The other pages in the ZIP. Decided now, and the ordinary ones created
	// now, so that binding the home page's links below already finds /about/
	// for about.html.
	/**
	 * The design's other pages — Kerf Pro imports them: what each becomes,
	 * and the ordinary ones made now so the home page's links find them. The
	 * plan is the add-on's own; it comes back to `kerf_import_other_pages_assets`
	 * and `kerf_import_other_pages_written`.
	 *
	 * @param array $planned { plan: array, actions: string[] }.
	 * @param array $context { staging, parts, choices, dry_run, standalone }.
	 */
	$planned = (array) apply_filters( 'kerf_import_other_pages', array( 'plan' => array(), 'actions' => array() ), array(
		'staging'    => $staging,
		'parts'      => $parts,
		'choices'    => $choices,
		'dry_run'    => $dry_run,
		'standalone' => $standalone,
	) );
	$plan    = isset( $planned['plan'] ) ? (array) $planned['plan'] : array();
	$actions = array_merge( $actions, isset( $planned['actions'] ) ? (array) $planned['actions'] : array() );
	// Without the add-on, what it would have imported.
	if ( $staging && ! empty( $staging['pages'] ) && ! $standalone && ! has_filter( 'kerf_import_other_pages' ) ) {
		$actions[] = kerf_import_more_pages_note( array_keys( $staging['pages'] ) );
	}

	// The blog's page, before links are bound, so a menu's "Blog" finds it.
	if ( ! $dry_run && ! empty( $_POST['kerf_set_front'] ) ) {
		$blog = kerf_import_blog_page();
		if ( '' !== $blog ) {
			$actions[] = $blog;
		}
	}

	// The file the design's home page came from means the home page to every
	// link of the design, whatever it is called (`index-1.html`, scar 134), and
	// to every binding after this one; a page of its own leaves the site's be.
	if ( ! $standalone ) {
		kerf_links_home_file( $staging ? (string) $staging['entry_name'] : '' );
		if ( ! $dry_run ) {
			update_option( KERF_LINKS_HOME_FILE_OPTION, kerf_links_home_file(), true );
		}
	}

	// Bind internal links to real pages. A separate pass over the converter's
	// output, not part of the converter, because resolving a permalink needs
	// WordPress and the engine must keep running without it.
	$unresolved = array();
	$bound      = 0;
	$created    = 0;

	foreach ( $converted as $region => $region_markup ) {
		if ( '' === trim( $region_markup ) ) {
			continue;
		}

		$links = kerf_links_bind( $region_markup, array(
			'create_missing' => ! $dry_run && ! empty( $_POST['kerf_create_pages'] ),
			// The site header's logo goes to the home page (scar 135).
			'logo'           => 'header' === $region && ! $standalone,
		) );
		if ( isset( $links['logo'] ) ) {
			$actions[] = '' === $links['logo']
				? __( 'The logo in your header was a link to nowhere; it now goes to the home page, from every page.', 'kerf-blocks' )
				: sprintf(
					/* translators: %s: the address the design's logo pointed at, e.g. "#top". */
					__( 'The logo in your header pointed at %s; it now goes to the home page, from every page.', 'kerf-blocks' ),
					$links['logo']
				);
		}
		if ( ! empty( $links['logo_added'] ) ) {
			$actions[] = __( 'The logo in your header had no link; it now goes to the home page, from every page.', 'kerf-blocks' );
		}

		// And each section records what was written, bindings included, so an
		// update can tell a section edited in WordPress from one left alone.
		$converted[ $region ] = kerf_sync_stamp_out( $links['markup'] );
		$bound               += $links['bound'];
		$created             += $links['created'];

		foreach ( $links['unresolved'] as $href => $count ) {
			$unresolved[ $href ] = ( $unresolved[ $href ] ?? 0 ) + $count;
		}
	}

	if ( $bound ) {
		$actions[] = sprintf(
			/* translators: %d: number of links. */
			_n( 'Bound %d link to a page on this site — it will follow that page if its slug changes.', 'Bound %d links to pages on this site — they will follow those pages if their slugs change.', $bound, 'kerf-blocks' ),
			$bound
		);
	}
	if ( $created ) {
		$actions[] = sprintf(
			/* translators: %d: number of pages. */
			_n( 'Created %d draft page to hold a link the mockup pointed at.', 'Created %d draft pages to hold links the mockup pointed at.', $created, 'kerf-blocks' ),
			$created
		);
	}
	if ( $unresolved ) {
		$actions[] = sprintf(
			/* translators: %d: number of links. */
			_n( '%d internal link has no destination yet — fix it under Kerf → Links.', '%d internal links have no destination yet — fix them under Kerf → Links.', count( $unresolved ), 'kerf-blocks' ),
			count( $unresolved )
		);
	}

	if ( $dry_run ) {
		if ( $staging ) {
			kerf_import_discard( $staging );
			$actions[] = __( 'Dry run: the staged files were removed again.', 'kerf-blocks' );
		}
		return array(
			'dry_run'    => true,
			'audit'      => $audit,
			'report'     => $report,
			'actions'    => $actions,
			'unresolved' => $unresolved,
		);
	}

	kerf_links_save_report( $unresolved );

	$report = array_merge( $report, kerf_import_svg_loss(
		implode( '', $converted ),
		$staging ? $staging['entry_name'] : __( 'The pasted HTML', 'kerf-blocks' )
	) );

	$alts = kerf_import_fill_alts( implode( '', $converted ) );
	if ( $alts ) {
		$actions[] = sprintf(
			/* translators: %d: number of pictures. */
			_n( 'Gave %d picture in the media library the design\'s description (alt text).', 'Gave %d pictures in the media library the design\'s descriptions (alt text).', $alts, 'kerf-blocks' ),
			$alts
		);
	}

	// What the other pages link to that the home page does not — the brief asks
	// for extra CSS in one css/pages.css — is loaded after the home page's own.
	if ( $plan ) {
		/**
		 * The other pages' own stylesheets and scripts, after the home page's
		 * and marked with where they load (`only`, §5.26).
		 *
		 * @param array  $merged   { assets: array[], added: string[] }.
		 * @param array  $plan     From `kerf_import_other_pages`.
		 * @param string $base_url
		 * @param array  $staging
		 */
		$merged = (array) apply_filters( 'kerf_import_other_pages_assets', array( 'assets' => $assets, 'added' => array() ), $plan, $base_url, $staging );
		$assets = $merged['assets'];
		if ( $merged['added'] ) {
			$actions[] = sprintf(
				/* translators: %s: list of files. */
				__( 'Loaded only on the pages that use them: %s.', 'kerf-blocks' ),
				implode( ', ', $merged['added'] )
			);
		}
	}

	// ── 5. Write everything. A design not for the whole site keeps its assets
	// and its <html>/<body> attributes where its scope says, once the page
	// exists (`kerf_import_scope_written`).
	if ( ! empty( $_POST['kerf_do_assets'] ) && ! empty( $assets ) ) {
		// The entry gate requires permission to add code (§5.32). Keep the
		// script guard too, for a list reaching here through another caller:
		// it preserves the scripts of the site's (null) or scope's own list.
		$replaced = null;
		if ( $standalone ) {
			/**
			 * The stylesheets and scripts a design not for the whole site
			 * replaces — Kerf Pro's page of its own: the page's own.
			 *
			 * @param array  $replaced
			 * @param string $scope
			 * @param int    $target The chosen page, or 0 for a new one.
			 */
			$replaced = (array) apply_filters( 'kerf_import_replaced_assets', array(), $scope, kerf_import_target_id() );
		}
		$gate   = kerf_assets_for_user( $assets, $replaced );
		$assets = $gate['assets'];
		if ( ! $standalone ) {
			// What was added to other pages in WordPress stays theirs.
			$written = array_merge( array( kerf_import_target_id() ), $plan ? array_map( 'intval', wp_list_pluck( $plan, 'page_id' ) ) : array() );
			$assets  = kerf_assets_carry_added( $assets, $written );
			kerf_assets_save( $assets );
			update_option( 'kerf_assets_version', (string) time(), false );
			// What the last design's scripts made belongs to that design: the
			// editor drew the previous design's Tailwind and icons over this
			// one until the home page was read again (the report reads it).
			delete_option( KERF_CAPTURE_OPTION );
			// So do the background pictures changed "everywhere" for it (§5.41).
			$dropped = $dry_run ? 0 : kerf_bg_rules_for_design( $staging );
			if ( $dropped ) {
				$actions[] = sprintf(
					/* translators: %d: how many background pictures. */
					_n( 'Left out %d background picture you had changed everywhere for the previous design: it was for that design\'s styles. Undo brings it back.', 'Left out %d background pictures you had changed everywhere for the previous design: they were for that design\'s styles. Undo brings them back.', $dropped, 'kerf-blocks' ),
					$dropped
				);
			}
		}

		if ( $gate['withheld'] ) {
			$report[] = array( 'category' => 'dropped', 'message' => kerf_assets_withheld_message( $gate ) );
		}

		$counts    = array_count_values( wp_list_pluck( $assets, 'type' ) );
		$actions[] = sprintf(
			/* translators: 1: stylesheet count, 2: script count. */
			__( 'Enqueued %1$d stylesheets and %2$d scripts, in the mockup\'s original order.', 'kerf-blocks' ),
			isset( $counts['css'] ) ? $counts['css'] : 0,
			isset( $counts['js'] ) ? $counts['js'] : 0
		);
	}

	$body_attrs               = kerf_mc_extract_body_attributes( $html );
	$doc_dropped              = array();
	$body_attrs['attributes'] = kerf_directives_document_attributes( $body_attrs['attributes'], $doc_dropped );
	$html_attrs               = kerf_directives_document_attributes( kerf_mc_extract_html_attributes( $html ), $doc_dropped );
	if ( ! $standalone ) {
		update_option( KERF_BODY_OPTION, $body_attrs, false );
		update_option( KERF_HTML_OPTION, $html_attrs, false );
	}
	if ( $doc_dropped ) {
		$report[] = array(
			'category' => 'dropped',
			'message'  => sprintf(
				/* translators: %s: attribute names. */
				__( 'Left out of the page\'s <html> and <body>, because they run code and only someone who may add scripts can import them: %s.', 'kerf-blocks' ),
				implode( ', ', $doc_dropped )
			),
		);
	}

	if ( '' !== $body_attrs['class'] ) {
		$actions[] = sprintf(
			/* translators: %s: class list. */
			__( 'Applied the mockup\'s body classes: %s', 'kerf-blocks' ),
			$body_attrs['class']
		);
	}
	if ( '' !== $body_attrs['id'] || ! empty( $body_attrs['attributes'] ) ) {
		$actions[] = sprintf(
			/* translators: %s: list of attribute names. */
			__( 'Applied the mockup\'s other <body> attributes: %s', 'kerf-blocks' ),
			implode( ', ', array_merge(
				'' !== $body_attrs['id'] ? array( 'id' ) : array(),
				array_keys( $body_attrs['attributes'] )
			) )
		);
	}

	// A mockup with no top-level <header> or <footer> still gets that part
	// REPLACED — with nothing. Skipping the write left whatever was there before
	// rendering on every page: the theme's placeholder footer (`© 2026`, an
	// element the designer never wrote) under a fresh install, or the PREVIOUS
	// mockup's entire header above a new one whose navigation is a bare <nav>.
	// Its markup is not lost: with no landmark to split on, it is in the page.
	foreach ( array( 'header' => __( 'Header', 'kerf-blocks' ), 'footer' => __( 'Footer', 'kerf-blocks' ) ) as $part => $label ) {
		// A page of its own carries its header and footer in its content.
		if ( $standalone || empty( $_POST[ 'kerf_do_' . $part ] ) ) {
			continue;
		}

		$content = trim( $converted[ $part ] );
		kerf_import_write_template_part( $part, $part, $label, $converted[ $part ] );

		$node = 'header' === $part ? $parts['chrome'] : $parts['footer_node'];

		$actions[] = '' !== $content
			? ( '' !== $node
				? sprintf(
					/* translators: 1: template part name, e.g. "header", 2: element, e.g. <nav> #mainNav. */
					__( 'Replaced the %1$s template part. The site %1$s is %2$s, and every page shows it.', 'kerf-blocks' ),
					$part,
					$node
				)
				: sprintf(
					/* translators: %s: template part name, e.g. "header". */
					__( 'Replaced the %s template part.', 'kerf-blocks' ),
					$part
				) )
			: sprintf(
				/* translators: %s: template part name, e.g. "header". */
				__( 'The mockup has no site %1$s Kerf could find, so the %1$s template part was emptied rather than left showing the previous one. Everything is in the page.', 'kerf-blocks' ),
				$part
			);
	}

	// The frame and what sits beside it belong to the header: written together,
	// so a mockup without a frame also clears the previous mockup's.
	if ( ! $standalone && ! empty( $_POST['kerf_do_header'] ) ) {
		update_option( KERF_FRAME_OPTION, $frame, false );
		kerf_import_write_template_part( 'page-start', WP_TEMPLATE_PART_AREA_UNCATEGORIZED, __( 'Page start', 'kerf-blocks' ), $converted['before'] );
		kerf_import_write_template_part( 'page-end', WP_TEMPLATE_PART_AREA_UNCATEGORIZED, __( 'Page end', 'kerf-blocks' ), $converted['after'] );
	}

	// Where the mockup's files are, for a section pasted later in the editor:
	// its `img/…` and `url(…)` resolve against the same folder (Kerf Pro's
	// Convert HTML, kerf_rest_convert(), and a new version pasted into Update
	// design). A pasted design has no folder: the one an earlier design left
	// is not this design's, and its files would be taken for this one's.
	if ( $staging && ! $standalone ) {
		update_option( 'kerf_last_staging', array( 'url' => $staging['base_url'], 'rel' => $staging['base_rel'] ), false );
	} elseif ( ! $standalone ) {
		delete_option( 'kerf_last_staging' );
	}

	$page_id = kerf_import_write_page( $converted['main'] );
	if ( $page_id && $standalone ) {
		/**
		 * Where a design not for the whole site keeps its stylesheets,
		 * scripts, <html>/<body> attributes and files — Kerf Pro's page of its
		 * own: on the page (kerf_asset_sets, §5.39), which the free plugin
		 * then dresses wherever it renders. Returns lines for the report.
		 *
		 * @param string[] $actions
		 * @param string   $scope
		 * @param int      $page_id
		 * @param array    $design  { assets (null: not imported this time), body, html, staging, source }.
		 */
		$actions = array_merge( $actions, (array) apply_filters( 'kerf_import_scope_written', array(), $scope, $page_id, array(
			'assets'  => ! empty( $_POST['kerf_do_assets'] ) ? $assets : null,
			'body'    => $body_attrs,
			'html'    => $html_attrs,
			'staging' => $staging ? array( 'url' => $staging['base_url'], 'rel' => $staging['base_rel'] ) : array(),
			'source'  => $staging ? $staging['entry_name'] : '',
		) ) );
	} elseif ( $page_id ) {
		// A page that had a design of its own is the site's again.
		if ( kerf_assets_design( $page_id )['page'] ) {
			kerf_asset_set_save( $page_id, null );
			if ( 'blank' === get_page_template_slug( $page_id ) ) {
				delete_post_meta( $page_id, '_wp_page_template' );
			}
			$actions[] = __( 'This page had a design of its own; it now has the site\'s header, footer and styles.', 'kerf-blocks' );
		}
		// The page the header's home-only intro belongs to (see kerf_block_is_home()).
		update_option( 'kerf_mockup_page', $page_id, false );
		// What the Dashboard says the site's design is (inc/kerf-dashboard.php).
		kerf_dashboard_remember( $design + array( 'page' => $page_id, 'match' => (int) $audit['score'] ) );
	}
	if ( $page_id ) {

		$actions[] = sprintf(
			/* translators: %s: page title. */
			__( 'Wrote the page content to "%s".', 'kerf-blocks' ),
			get_the_title( $page_id )
		);

		if ( ! empty( $_POST['kerf_set_front'] ) ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $page_id );
			$actions[] = __( 'Set as the site\'s front page.', 'kerf-blocks' );
		}

		$actions[] = sprintf(
			/* translators: %s: URL. */
			__( 'View it: %s', 'kerf-blocks' ),
			get_permalink( $page_id )
		);
	}

	if ( $plan ) {
		/**
		 * Write the other pages — pages and templates — once the home page is.
		 *
		 * @param array $written { actions: string[], report: array[], unresolved: array }.
		 * @param array $plan    From `kerf_import_other_pages`.
		 * @param array $context { manifest, options (the converter's), create_missing }.
		 */
		$written = (array) apply_filters( 'kerf_import_other_pages_written', array( 'actions' => array(), 'report' => array(), 'unresolved' => array() ), $plan, array(
			'manifest'       => $manifest,
			'options'        => $converter_options,
			'create_missing' => ! empty( $_POST['kerf_create_pages'] ),
		) );
		$actions = array_merge( $actions, $written['actions'] );
		$report  = array_merge( $report, $written['report'] );

		foreach ( $written['unresolved'] as $href => $count ) {
			$unresolved[ $href ] = ( isset( $unresolved[ $href ] ) ? $unresolved[ $href ] : 0 ) + $count;
		}
		kerf_links_save_report( $unresolved );
	}

	return array(
		'dry_run'    => false,
		'audit'      => $audit,
		'report'     => $report,
		'actions'    => $actions,
		'page_id'    => $page_id,
		'scope'      => $scope,
		'standalone' => $standalone,
		'unresolved' => $unresolved,
	);
}

/**
 * Clean a pasted design before it can wait in the pending-import option.
 *
 * The REST converter's 4 MB byte ceiling applies before and after UTF-8
 * cleanup (CLAUDE.md §6.5): core can replace one bad byte with several.
 * Keep scripts, styles and handlers intact: kerf_user_can_import() admits only
 * users WordPress trusts with code. The asset guard, converter's directives
 * option and staged-file disarming still protect other callers (§5.32).
 *
 * @param string $html Unslashed design HTML.
 * @return string|WP_Error Clean HTML, or an error when the page is too large.
 */
function kerf_import_sanitize_design_html( $html ) {
	if ( ! is_string( $html ) ) {
		return '';
	}
	if ( strlen( $html ) <= 4 * MB_IN_BYTES ) {
		$html = wp_check_invalid_utf8( $html, true );
		$html = (string) preg_replace( '/[\x00-\x08\x0b\x0c\x0e-\x1f]/', '', $html );
		$html = 0 === strpos( $html, "\xEF\xBB\xBF" ) ? substr( $html, 3 ) : $html;
	}
	if ( strlen( $html ) > 4 * MB_IN_BYTES ) {
		return new WP_Error( 'kerf_import_html_too_large', __( 'That HTML is larger than 4 MB. Paste a smaller page.', 'kerf-blocks' ) );
	}
	return $html;
}

/**
 * Read the submitted mockup — from a ZIP upload or a paste.
 *
 * @return array{html:string,staging:?array,actions:string[],error?:string}
 */
function kerf_import_read_source() {
	$actions = array();

	// Paste path: no ZIP sent, or "Pasted HTML" chosen on the screen — a ZIP
	// picked before switching is still in its (hidden) field, and was taken
	// over the HTML the owner then pasted.
	// The nonce was checked by kerf_import_run_post() (or Kerf Pro's update), which reads this.
	$pasted = isset( $_POST['kerf_source'] ) && 'paste' === sanitize_key( wp_unslash( $_POST['kerf_source'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
	if ( $pasted || empty( $_FILES['kerf_zip']['tmp_name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- see above.
		$html = isset( $_POST['kerf_html'] ) ? kerf_import_sanitize_design_html( wp_unslash( $_POST['kerf_html'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized by kerf_import_sanitize_design_html(); the nonce was checked above.
		if ( is_wp_error( $html ) ) {
			return array(
				'html'    => '',
				'staging' => null,
				'actions' => array(),
				'error'   => $html->get_error_message(),
			);
		}
		if ( '' === trim( $html ) ) {
			return array(
				'html'    => '',
				'staging' => null,
				'actions' => array(),
				'error'   => __( 'Upload a ZIP or paste some HTML.', 'kerf-blocks' ),
			);
		}
		return array( 'html' => $html, 'staging' => null, 'actions' => $actions );
	}

	$upload = $_FILES['kerf_zip']; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- checked below (error, size, a ZIP) and extracted privately (§5.32).

	if ( ! empty( $upload['error'] ) ) {
		return array( 'html' => '', 'staging' => null, 'actions' => array(), 'error' => __( 'The upload failed. Check the file size limit on this server.', 'kerf-blocks' ) );
	}
	if ( $upload['size'] > KERF_IMPORT_MAX_ZIP ) {
		return array( 'html' => '', 'staging' => null, 'actions' => array(), 'error' => __( 'That ZIP is larger than 64 MB.', 'kerf-blocks' ) );
	}

	$staging = kerf_import_unzip( $upload['tmp_name'] );
	if ( ! empty( $staging['error'] ) ) {
		return array( 'html' => '', 'staging' => null, 'actions' => array(), 'error' => $staging['error'] );
	}

	$actions[] = sprintf(
		/* translators: %s: file name. */
		__( 'Read %s from the ZIP.', 'kerf-blocks' ),
		$staging['entry_name']
	);
	$actions[] = sprintf(
		/* translators: %d: number of files. */
		__( 'Staged %d asset files, keeping the folder structure so relative CSS paths still resolve.', 'kerf-blocks' ),
		$staging['files']
	);

	return array(
		'html'    => $staging['html'],
		'staging' => $staging,
		'actions' => $actions,
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE CHECK, AND THE PAUSE BEFORE WRITING
// ═══════════════════════════════════════════════════════════════════════════════
//
// The screen checks a design before it writes anything: the upload is staged
// and read, and what it holds waits under a one-time token while the owner
// sees what was found and chooses where it goes (the HTML must not sit in
// uploads/ — scar 10). Kerf Pro's Update design parks its comparison the
// same way. It was Kerf Pro's alone, for its review of a design's other
// pages; every import pauses now. The store: inc/kerf-import-pending.php.

/**
 * The screen's first step: read the design, stage its files and check it —
 * and write nothing.
 *
 * @return array { check, token, name, title, inventory, preflight, pages, source }, or { error }.
 */
function kerf_import_check() {
	if ( ! kerf_user_can_import() ) {
		return array( 'error' => kerf_import_permission_message() );
	}
	$source = kerf_import_read_source();
	if ( ! empty( $source['error'] ) ) {
		return array( 'error' => $source['error'] );
	}

	$base_url  = isset( $_POST['kerf_base_url'] ) ? esc_url_raw( wp_unslash( $_POST['kerf_base_url'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- kerf_import_run_post() checked it.
	$preflight = kerf_preflight( $source['html'], $source['staging'] );
	$name      = kerf_import_source_name( $source );
	$title     = kerf_import_document_title( $source['html'] );

	return array(
		'check'     => true,
		'token'     => kerf_import_pending_save( $source['staging'], $source['actions'], 'import', array(
			// A ZIP's documents are in its staging; a paste has only this.
			'html'      => $source['staging'] ? '' : $source['html'],
			'preflight' => $preflight,
			'base_url'  => $base_url,
			'name'      => $name,
			'title'     => $title,
		) ),
		'name'      => $name,
		'title'     => $title,
		'inventory' => kerf_import_inventory( $source, $base_url ),
		'preflight' => $preflight,
		'pages'     => $source['staging'] && ! empty( $source['staging']['pages'] ) ? array_keys( (array) $source['staging']['pages'] ) : array(),
		'source'    => $source,
	);
}

/**
 * Park a design an add-on staged (kerf_import_stage_files()) for the check
 * step, as an upload is parked: checked before importing (kerf_preflight()),
 * and waiting under a token for the owner who staged it.
 *
 * @param array    $staging From kerf_import_stage_files().
 * @param string   $name    What the check step calls the design.
 * @param string[] $actions What was done so far, for the report.
 * @return string Token: the check step opens at kerf_import_check_url().
 */
function kerf_import_check_staged( $staging, $name, $actions = array() ) {
	if ( ! kerf_user_can_import() ) {
		return '';
	}
	return kerf_import_pending_save( $staging, (array) $actions, 'import', array(
		'preflight' => kerf_preflight( (string) $staging['html'], $staging ),
		'name'      => (string) $name,
		'title'     => kerf_import_document_title( (string) $staging['html'] ),
	) );
}

/**
 * Where the check step of a parked import opens.
 *
 * @param string $token
 * @return string
 */
function kerf_import_check_url( $token ) {
	return add_query_arg( array( 'page' => 'kerf-import', 'kerf_pending' => rawurlencode( $token ) ), admin_url( 'admin.php' ) );
}

/**
 * The check step of a parked import, drawn from what waits — for its owner
 * only, as the pause is (kerf_import_pending_peek()).
 *
 * @param string $token
 * @return array|null As kerf_import_check(), or null.
 */
function kerf_import_check_pending( $token ) {
	if ( ! kerf_user_can_import() ) {
		return null;
	}
	// A Kerf Pro from before session 16 keeps the pause, without peek().
	$pending = function_exists( 'kerf_import_pending_peek' ) ? kerf_import_pending_peek( $token ) : null;
	if ( ! $pending || empty( $pending['staging'] ) || ! is_array( $pending['staging'] ) ) {
		return null;
	}
	$source = array(
		'html'    => (string) $pending['staging']['html'],
		'staging' => $pending['staging'],
		'actions' => (array) $pending['actions'],
	);
	return array(
		'check'     => true,
		'token'     => $token,
		'name'      => (string) $pending['name'],
		'title'     => (string) $pending['title'],
		'inventory' => kerf_import_inventory( $source, (string) $pending['base_url'] ),
		'preflight' => (array) $pending['preflight'],
		'pages'     => ! empty( $pending['staging']['pages'] ) ? array_keys( (array) $pending['staging']['pages'] ) : array(),
		'source'    => $source,
	);
}

/**
 * What the design is called where it came from: the ZIP's name, else its
 * entry page, else "the pasted HTML".
 *
 * @param array $source From kerf_import_read_source().
 * @return string
 */
function kerf_import_source_name( $source ) {
	if ( empty( $source['staging'] ) ) {
		return __( 'the pasted HTML', 'kerf-blocks' );
	}
	$file = isset( $_FILES['kerf_zip']['name'] ) ? sanitize_file_name( wp_unslash( $_FILES['kerf_zip']['name'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- read inside the checked import.
	return '' !== $file ? $file : (string) $source['staging']['entry_name'];
}

/**
 * A document's `<title>`, as text.
 *
 * @param string $html
 * @return string
 */
function kerf_import_document_title( $html ) {
	if ( ! preg_match( '#<title\b[^>]*>(.*?)</title>#is', (string) $html, $found ) ) {
		return '';
	}
	$title = html_entity_decode( wp_strip_all_tags( $found[1] ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	return trim( mb_substr( (string) preg_replace( '/\s+/u', ' ', $title ), 0, 120 ) );
}

/**
 * What the design holds, counted for the check: its pages, the home page's
 * stylesheets and scripts, the pictures and fonts in the ZIP.
 *
 * @param array  $source   From kerf_import_read_source().
 * @param string $base_url
 * @return array{pages:int,stylesheets:int,scripts:int,pictures:int,fonts:int}
 */
function kerf_import_inventory( $source, $base_url ) {
	$types = array_count_values( wp_list_pluck( kerf_assets_extract( $source['html'], $base_url ), 'type' ) );
	$files = ! empty( $source['staging']['zip_files'] ) ? (array) $source['staging']['zip_files'] : array();
	$count = array( 'pictures' => 0, 'fonts' => 0 );

	foreach ( $files as $file ) {
		$ext = strtolower( pathinfo( (string) $file, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'svg' ), true ) ) {
			$count['pictures']++;
		} elseif ( in_array( $ext, array( 'woff', 'woff2', 'ttf', 'otf', 'eot' ), true ) ) {
			$count['fonts']++;
		}
	}

	return array(
		'pages'       => 1 + ( ! empty( $source['staging']['pages'] ) ? count( (array) $source['staging']['pages'] ) : 0 ),
		'stylesheets' => isset( $types['css'] ) ? (int) $types['css'] : 0,
		'scripts'     => isset( $types['js'] ) ? (int) $types['js'] : 0,
		'pictures'    => $count['pictures'],
		'fonts'       => $count['fonts'],
	);
}

/**
 * Extract a mockup ZIP, and stage what may be served under uploads.
 *
 * The ZIP is extracted and pruned in a private folder (the system's temp
 * directory), and only what survives the pruning is moved under uploads. It
 * used to be extracted straight into `uploads/kerf-assets/mockup-<time>/` and
 * pruned there — so for the length of the extraction every file in it,
 * a `shell.php` or an `.htaccess` included, sat at a URL anyone could guess
 * to the second, on a server that may well run PHP in uploads. The mockup is
 * the attacker (§6); that was a window onto the server.
 *
 * The entry HTML and the pages beside it are read into memory before pruning
 * deletes them: the documents belong in the database, never in a folder the
 * web server serves.
 *
 * @param string $tmp_path Uploaded temp file.
 * @return array{dir:string,url:string,slug:string,files:int,html:string,entry_name:string,disarmed?:array,error?:string}
 */
function kerf_import_unzip( $tmp_path ) {
	$private = kerf_import_staging_start();
	if ( is_array( $private ) ) {
		return $private;
	}

	// unzip_file() is used rather than ZipArchive directly because it already
	// refuses absolute and `../` member paths — the zip-slip class of bug, where
	// a crafted archive writes outside the target directory.
	// Core uses its global filesystem. Lend it the direct instance only for
	// extraction, then put back the transport another caller had set up.
	$filesystem_present = array_key_exists( 'wp_filesystem', $GLOBALS );
	$filesystem_was     = $filesystem_present ? $GLOBALS['wp_filesystem'] : null;
	try {
		$GLOBALS['wp_filesystem'] = kerf_import_fs();
		$unzipped = unzip_file( $tmp_path, $private );
	} finally {
		if ( $filesystem_present ) {
			$GLOBALS['wp_filesystem'] = $filesystem_was;
		} else {
			unset( $GLOBALS['wp_filesystem'] );
		}
	}

	if ( is_wp_error( $unzipped ) ) {
		kerf_import_remove_private( $private );
		return kerf_import_staging_failed( $unzipped->get_error_message() );
	}

	return kerf_import_stage_private( $private );
}

/**
 * Stage a design given as files — path ⇒ content — exactly as an uploaded
 * ZIP is staged (kerf_import_unzip()): written into a private folder, its
 * documents read, the rest pruned and disarmed, and only then moved under
 * uploads. A design an add-on made (Kerf Pro's AI) reaches the check step
 * this way, with the same scrutiny as a stranger's ZIP: what it holds is
 * untrusted until the converter has read it (§6).
 *
 * The paths are a ZIP's member names, held to what unzip_file() holds a ZIP
 * to and more (kerf_import_safe_path()); the limits are a ZIP's.
 *
 * @param array<string,string> $files Relative path ⇒ the file's bytes.
 * @return array As kerf_import_unzip(): the staging, or { error }.
 */
function kerf_import_stage_files( $files ) {
	if ( ! is_array( $files ) || ! $files ) {
		return kerf_import_staging_failed( __( 'There are no files to stage.', 'kerf-blocks' ) );
	}
	if ( count( $files ) > KERF_IMPORT_MAX_FILES ) {
		/* translators: %d: file limit. */
		return kerf_import_staging_failed( sprintf( __( 'A design of more than %d files cannot be staged.', 'kerf-blocks' ), KERF_IMPORT_MAX_FILES ) );
	}
	$total = 0;
	foreach ( $files as $path => $content ) {
		if ( ! is_string( $content ) || ! kerf_import_safe_path( (string) $path ) ) {
			/* translators: %s: a file's path. */
			return kerf_import_staging_failed( sprintf( __( 'Kerf cannot stage a file called %s.', 'kerf-blocks' ), sanitize_text_field( (string) $path ) ) );
		}
		$total += strlen( $content );
	}
	if ( $total > KERF_IMPORT_MAX_ZIP ) {
		return kerf_import_staging_failed( __( 'That design is larger than 64 MB.', 'kerf-blocks' ) );
	}

	$private = kerf_import_staging_start();
	if ( is_array( $private ) ) {
		return $private;
	}
	foreach ( $files as $path => $content ) {
		$target = $private . '/' . $path;
		// Two paths differing only in capitals are one file on Windows: the
		// second would quietly replace the first.
		if ( file_exists( $target ) || ! wp_mkdir_p( dirname( $target ) ) || false === kerf_import_fs()->put_contents( $target, $content ) ) {
			kerf_import_remove_private( $private );
			/* translators: %s: a file's path. */
			return kerf_import_staging_failed( sprintf( __( 'Could not write %s to stage it.', 'kerf-blocks' ), sanitize_text_field( (string) $path ) ) );
		}
	}

	return kerf_import_stage_private( $private );
}

/**
 * May a file of a design given as files be written under this name? A
 * relative path of plain names — no drive, no leading or back slash, no `.`
 * or `..`, no name that starts with a dot (`.htaccess`, `.user.ini`) or holds
 * a colon (a Windows stream: `x.jpg:y.php`) — at most eight folders deep.
 *
 * @param string $path
 * @return bool
 */
function kerf_import_safe_path( $path ) {
	if ( '' === $path || strlen( $path ) > 240 || preg_match( '#[\\\\:\x00-\x1f]|^/|//#', $path ) ) {
		return false;
	}
	$segments = explode( '/', $path );
	if ( count( $segments ) > 9 ) {
		return false;
	}
	foreach ( $segments as $segment ) {
		// A name ending in a dot or a space is written without it on Windows:
		// `x.php.` lands as `x.php`.
		if ( ! preg_match( '/^[A-Za-z0-9_\-][A-Za-z0-9_\-. ()]*$/', $segment ) || $segment !== rtrim( $segment, '. ' ) ) {
			return false;
		}
	}
	return true;
}

/**
 * A staging that failed, in the shape a staging has.
 *
 * @param string $message
 * @return array
 */
function kerf_import_staging_failed( $message ) {
	return array(
		'dir'        => '', 'url' => '', 'slug' => '', 'files' => 0,
		'html'       => '', 'entry_name' => '',
		'error'      => $message,
	);
}

/**
 * Before anything is staged: the uploads folder, direct file access, and a
 * private folder to work in.
 *
 * @return string|array The private folder, or a failed staging.
 */
function kerf_import_staging_start() {
	if ( ! kerf_user_can_import() ) {
		return kerf_import_staging_failed( kerf_import_permission_message() );
	}
	$storage = kerf_assets_storage();
	if ( ! $storage ) {
		return kerf_import_staging_failed( __( 'The uploads directory is not writable.', 'kerf-blocks' ) );
	}

	// Staging walks local folders and reads them through PHP, so it needs
	// direct file access. Through FTP, unzip_file() would write files
	// PHP may not be able to delete — refused, rather than half-pruned.
	require_once ABSPATH . 'wp-admin/includes/file.php';
	if ( 'direct' !== get_filesystem_method( array(), $storage['dir'] ) ) {
		return kerf_import_staging_failed( __( 'Kerf needs direct access to the files on this server to stage a mockup, and WordPress is set to use FTP or SSH. Ask your host to give PHP write access to wp-content/uploads, or define FS_METHOD as \'direct\' in wp-config.php.', 'kerf-blocks' ) );
	}

	$private = kerf_import_private_dir();
	if ( '' === $private ) {
		return kerf_import_staging_failed( __( 'Could not create a temporary folder to extract the ZIP into.', 'kerf-blocks' ) );
	}
	return $private;
}

/**
 * Stage what sits in a private folder: read the documents, list the files,
 * prune and disarm, and move what may be served under uploads.
 *
 * @param string $private From kerf_import_private_dir(), filled.
 * @return array The staging, or a failed one.
 */
function kerf_import_stage_private( $private ) {
	$fail    = 'kerf_import_staging_failed';
	$storage = kerf_assets_storage();

	// Designers zip the containing folder as often as its contents. When
	// everything landed in a single subdirectory, treat that as the root — the
	// alternative is every asset path being off by one segment.
	$dir     = $private;
	$sub     = '';
	$entries = array_values( array_diff( scandir( $dir ), array( '.', '..', '__MACOSX' ) ) );
	if ( 1 === count( $entries ) && is_dir( $dir . '/' . $entries[0] ) ) {
		$sub = $entries[0];
		$dir = $dir . '/' . $sub;
	}

	// Read the document before pruning removes it.
	$entry = kerf_import_find_entry_html( $dir );
	if ( '' === $entry ) {
		kerf_import_remove_private( $private );
		return $fail( __( 'No HTML file found in that ZIP.', 'kerf-blocks' ) );
	}

	$html       = (string) file_get_contents( $entry );
	$entry_name = basename( $entry );

	// Where the document sits inside the staged folder. Its relative paths
	// resolve against THIS folder, exactly as the browser resolved them — not
	// against the ZIP root. A repository ZIP keeps its page in `dist/`, and a
	// Bootstrap example sits in `cover/` beside a shared `assets/`: resolved from
	// the root, `cover.css` and every image were simply not found.
	$base_rel = trim( str_replace(
		'\\',
		'/',
		substr( wp_normalize_path( dirname( $entry ) ), strlen( wp_normalize_path( $dir ) ) )
	), '/' );

	// The other pages beside it — about.html, blog.html, 404.html — read now for
	// the same reason: pruning deletes them. Only the entry's own folder: that is
	// where a mockup's pages live, and a repository ZIP's other folders are
	// source files and examples, not pages of this site.
	$pages = array();
	$names = scandir( dirname( $entry ) );
	sort( $names );
	foreach ( (array) $names as $name ) {
		$file = dirname( $entry ) . '/' . $name;
		if ( ! preg_match( '/\.x?html?$/i', $name ) || ! is_file( $file )
			|| wp_normalize_path( $file ) === wp_normalize_path( $entry ) || filesize( $file ) > 2 * MB_IN_BYTES ) {
			continue;
		}
		$pages[ $name ] = (string) file_get_contents( $file );
		if ( count( $pages ) >= 60 ) {
			break;
		}
	}

	// A file whose name hides a program's extension — `all.css.php.css`, what
	// a browser's "Save page as" makes of a stylesheet a PHP script served —
	// is given a name no server runs (`all.css-php.css`) rather than pruned,
	// and the design's references follow it. Pruned, a design built on such a
	// template lost its whole stylesheet and its jQuery without a word (scar 113).
	$renamed = kerf_import_rename_unservable( $dir );
	if ( $renamed ) {
		$html = kerf_import_follow_renames( $html, $renamed );
		foreach ( $pages as $name => $page ) {
			$pages[ $name ] = kerf_import_follow_renames( $page, $renamed );
		}
	}

	// Every file in the ZIP, before pruning: what the check before importing
	// (kerf_preflight()) compares the design's references with, and how it
	// knows a React project — its package.json and src/ are never staged.
	$zip_files = array();
	$walk      = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $walk as $file ) {
		if ( $file->isFile() && count( $zip_files ) < 5000 ) {
			$zip_files[] = ltrim( str_replace( '\\', '/', substr( wp_normalize_path( $file->getPathname() ), strlen( wp_normalize_path( $dir ) ) ) ), '/' );
		}
	}

	$kept = kerf_import_prune( $dir );

	if ( $kept > KERF_IMPORT_MAX_FILES ) {
		kerf_import_remove_private( $private );
		return $fail( sprintf(
			/* translators: %d: file limit. */
			__( 'That ZIP contains more than %d files.', 'kerf-blocks' ),
			KERF_IMPORT_MAX_FILES
		) );
	}

	// The import gate admits only someone who may add code. Still disarm a
	// private folder handed here by another caller without that permission.
	$disarmed = kerf_user_can_add_scripts() ? array() : kerf_import_disarm( $dir );
	if ( $disarmed ) {
		$kept -= $disarmed['removed'];
	}

	// Only now does anything reach a folder the web server serves. A second
	// import in the same second gets its own folder rather than merging into
	// the first one's.
	$slug = 'mockup-' . gmdate( 'Ymd-His' );
	for ( $n = 2; file_exists( $storage['dir'] . $slug ); $n++ ) {
		$slug = 'mockup-' . gmdate( 'Ymd-His' ) . '-' . $n;
	}
	if ( '' !== $sub ) {
		$slug .= '/' . $sub;
	}

	$moved = kerf_import_move_tree( $dir, $storage['dir'] . $slug );
	kerf_import_remove_private( $private );
	if ( ! $moved ) {
		kerf_import_cleanup( $storage['dir'] . strtok( $slug, '/' ) );
		return $fail( __( 'Could not move the mockup\'s files into the uploads folder.', 'kerf-blocks' ) );
	}

	$url = trailingslashit( $storage['url'] . $slug );

	return array(
		'dir'        => trailingslashit( $storage['dir'] . $slug ),
		'url'        => $url,
		'base_rel'   => $base_rel,
		'base_url'   => '' === $base_rel ? $url : $url . $base_rel . '/',
		'slug'       => $slug,
		'files'      => $kept,
		'html'       => $html,
		'entry_name' => '' === $base_rel ? $entry_name : $base_rel . '/' . $entry_name,
		'pages'      => $pages,
		'disarmed'   => $disarmed,
		'renamed'    => $renamed,
		'zip_files'  => $zip_files,
	);
}

/**
 * Give the media library the design's description of a picture, where the
 * library has none.
 *
 * The converter keeps each `<img alt>` on its block, but the picture's
 * library entry stayed without one: used again — as a featured image, in
 * another block, in an SEO plugin's image sitemap — it had no description.
 * The first description the design gives a picture is copied to it; one the
 * owner wrote is never replaced.
 *
 * @param string $markup Converted block markup.
 * @return int How many pictures got a description.
 */
function kerf_import_fill_alts( $markup ) {
	if ( false === strpos( (string) $markup, '"mediaId"' ) ) {
		return 0;
	}
	$filled = 0;
	$walk   = static function ( $blocks ) use ( &$walk, &$filled ) {
		foreach ( $blocks as $block ) {
			$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
			$alt   = isset( $attrs['alt'] ) ? trim( (string) $attrs['alt'] ) : '';
			if ( 'kerf/image' === ( $block['blockName'] ?? '' ) && ! empty( $attrs['mediaId'] ) && '' !== $alt ) {
				$id = (int) $attrs['mediaId'];
				if ( 'attachment' === get_post_type( $id ) && '' === (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) {
					// update_post_meta() unslashes what it is given.
					update_post_meta( $id, '_wp_attachment_image_alt', wp_slash( sanitize_text_field( $alt ) ) );
					$filled++;
				}
			}
			if ( ! empty( $block['innerBlocks'] ) ) {
				$walk( $block['innerBlocks'] );
			}
		}
	};
	$walk( parse_blocks( (string) $markup ) );
	return $filled;
}

/**
 * The report entry for inline SVGs that cannot be stored by the current user.
 *
 * WordPress runs KSES on everything saved by someone without unfiltered_html
 * (on a network, anyone but a super admin), and KSES keeps no `<svg>`: a
 * kerf/svg block's markup is emptied on its way into the database and the
 * graphic renders as nothing. Everything else Kerf writes comes through —
 * measured on gymlife, 564 of 564 elements identical (§5.32). Imports now need
 * permission to add code; this still reports what another caller would lose.
 * The editor warns before a save does the same (kerf-editor-ux.js).
 *
 * @param string $markup Block markup about to be written.
 * @param string $where  What it is, for the message: "Home page", "about.html".
 * @return array[] Report entries; none when nothing is lost.
 */
function kerf_import_svg_loss( $markup, $where ) {
	$count = substr_count( (string) $markup, '<!-- wp:kerf/svg ' );
	if ( ! $count || current_user_can( 'unfiltered_html' ) ) {
		return array();
	}

	return array( array(
		'category' => 'dropped',
		'message'  => sprintf(
			/* translators: 1: page or part, 2: number of graphics. */
			_n(
				'%1$s: %2$d inline SVG graphic could not be kept. WordPress removes <svg> from whatever is saved by a user who may not add unfiltered HTML (on a network, anyone but a super admin); ask one to run this import.',
				'%1$s: %2$d inline SVG graphics could not be kept. WordPress removes <svg> from whatever is saved by a user who may not add unfiltered HTML (on a network, anyone but a super admin); ask one to run this import.',
				$count,
				'kerf-blocks'
			),
			$where,
			$count
		),
	) );
}

/**
 * What kerf_import_disarm() took out of the staged files, as report entries.
 *
 * @param array|null $staging
 * @return array[]
 */
function kerf_import_disarm_report( $staging ) {
	$disarmed = is_array( $staging ) && ! empty( $staging['disarmed'] ) ? $staging['disarmed'] : array();
	$report   = array();

	$renamed = is_array( $staging ) && ! empty( $staging['renamed'] ) ? (array) $staging['renamed'] : array();
	if ( $renamed ) {
		$pairs = array();
		foreach ( array_slice( $renamed, 0, 8, true ) as $old => $new ) {
			$pairs[] = $old . ' → ' . $new;
		}
		$report[] = array(
			'category' => 'converted',
			'message'  => sprintf(
				/* translators: 1: number of files, 2: list of "old name → new name". */
				_n(
					'%1$d file was given a new name, because a name with ".php" (or another program\'s extension) inside it could run as a program on some servers; the design\'s links to it were changed to match: %2$s.',
					'%1$d files were given new names, because a name with ".php" (or another program\'s extension) inside it could run as a program on some servers; the design\'s links to them were changed to match: %2$s.',
					count( $renamed ),
					'kerf-blocks'
				),
				count( $renamed ),
				implode( ', ', $pairs ) . ( count( $renamed ) > 8 ? ', …' : '' )
			),
		);
	}

	if ( ! empty( $disarmed['removed'] ) ) {
		$report[] = array(
			'category' => 'dropped',
			'message'  => sprintf(
				/* translators: 1: number of files, 2: list of files. */
				_n(
					'%1$d file was not staged because it could run on this site, and only a user who may add unfiltered HTML can add anything that runs: %2$s.',
					'%1$d files were not staged because they could run on this site, and only a user who may add unfiltered HTML can add anything that runs: %2$s.',
					(int) $disarmed['removed'],
					'kerf-blocks'
				),
				(int) $disarmed['removed'],
				implode( ', ', array_slice( $disarmed['files'], 0, 12 ) ) . ( count( $disarmed['files'] ) > 12 ? ', …' : '' )
			),
		);
	}
	if ( ! empty( $disarmed['cleaned'] ) ) {
		$report[] = array(
			'category' => 'converted',
			'message'  => sprintf(
				/* translators: %d: number of SVG files. */
				_n(
					'%d SVG image was rewritten through an allowlist that keeps drawings, styles and pictures and takes out anything that could run (scripts, event handlers, links): only a user who may add unfiltered HTML can add those.',
					'%d SVG images were rewritten through an allowlist that keeps drawings, styles and pictures and takes out anything that could run (scripts, event handlers, links): only a user who may add unfiltered HTML can add those.',
					(int) $disarmed['cleaned'],
					'kerf-blocks'
				),
				(int) $disarmed['cleaned']
			),
		);
	}

	return $report;
}

/**
 * A new, empty folder outside the web root to extract a ZIP into.
 *
 * `get_temp_dir()` is the system's temp directory wherever PHP can write to
 * it; only on a host where it cannot does it fall back to wp-content, and the
 * random name is then what keeps the folder from being found.
 *
 * @return string Absolute path with no trailing slash, or '' on failure.
 */
function kerf_import_private_dir() {
	$dir = trailingslashit( get_temp_dir() ) . 'kerf-import-' . wp_generate_password( 16, false, false );

	return wp_mkdir_p( $dir ) ? untrailingslashit( wp_normalize_path( $dir ) ) : '';
}

/**
 * Remove a folder made by kerf_import_private_dir(), and nothing else.
 *
 * @param string $dir
 */
function kerf_import_remove_private( $dir ) {
	$dir  = untrailingslashit( wp_normalize_path( (string) $dir ) );
	$temp = wp_normalize_path( trailingslashit( get_temp_dir() ) ) . 'kerf-import-';

	// Refuse anything that is not one of ours, whatever was passed in.
	if ( 0 !== strpos( $dir, $temp ) || strlen( $dir ) <= strlen( $temp ) || false !== strpos( substr( $dir, strlen( $temp ) ), '/' ) || ! is_dir( $dir ) ) {
		return;
	}

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);
	foreach ( $iterator as $file ) {
		if ( $file->isDir() && ! $file->isLink() ) {
			kerf_import_fs()->rmdir( $file->getPathname() );
		} else {
			wp_delete_file( $file->getPathname() );
		}
	}
	kerf_import_fs()->rmdir( $dir );
}

/**
 * The filesystem staging uses: core's when it is direct, otherwise an instance
 * of our own.
 *
 * Staging works on local paths — the system temp dir, then uploads — and
 * refuses without direct access (get_filesystem_method(), §5.32). Core's
 * global can still be another transport (an FTP FS_METHOD, credentials for
 * another folder), whose paths are the server's, not PHP's: then a direct
 * instance of our own, and the global left as it is for whoever set it up.
 * The permission constants every write reads (FS_CHMOD_FILE, FS_CHMOD_DIR —
 * unzip_file() passes them too) are core's to define: WP_Filesystem() does,
 * asked about the uploads folder as staging's own check was. Never recursive
 * here: each caller walks its folder itself, links left alone.
 *
 * @return WP_Filesystem_Direct
 */
function kerf_import_fs() {
	global $wp_filesystem;
	static $direct = null;
	if ( ! defined( 'FS_CHMOD_FILE' ) || ! defined( 'FS_CHMOD_DIR' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
		$kept    = $wp_filesystem;
		$uploads = wp_upload_dir( null, false );
		WP_Filesystem( false, empty( $uploads['error'] ) ? $uploads['basedir'] : false );
		if ( $kept ) {
			$wp_filesystem = $kept;
		}
	}
	if ( $wp_filesystem instanceof WP_Filesystem_Direct ) {
		return $wp_filesystem;
	}
	if ( null === $direct ) {
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
		$direct = new WP_Filesystem_Direct( null );
	}
	return $direct;
}

/**
 * Move a folder's contents to a new folder.
 *
 * One rename when both are on the same volume. Across volumes — the system
 * temp on another disk, a tmpfs /tmp — a folder cannot be renamed, so its
 * files are copied one by one. Either way only what may be served arrives
 * (kerf_import_servable()): the prune deleted the rest, and a file it could
 * not delete stays behind here rather than landing in uploads.
 *
 * @param string $from Existing folder.
 * @param string $to   Folder to create; must not exist.
 * @return bool
 */
function kerf_import_move_tree( $from, $to ) {
	$from = untrailingslashit( wp_normalize_path( $from ) );
	$to   = untrailingslashit( wp_normalize_path( $to ) );

	if ( ! wp_mkdir_p( dirname( $to ) ) ) {
		return false;
	}

	$clean = true;
	foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $from, FilesystemIterator::SKIP_DOTS ) ) as $file ) {
		if ( $file->isLink() || ! kerf_import_servable( $file->getFilename() ) ) {
			$clean = false;
			break;
		}
	}
	if ( $clean && ! file_exists( $to ) && kerf_import_fs()->move( $from, $to ) ) {
		return true;
	}
	if ( ! wp_mkdir_p( $to ) ) {
		return false;
	}

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $from, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::SELF_FIRST
	);
	foreach ( $iterator as $file ) {
		$target = $to . substr( wp_normalize_path( $file->getPathname() ), strlen( $from ) );
		if ( $file->isLink() ) {
			continue; // Never followed: a link out of the folder is not the mockup's.
		}
		if ( $file->isDir() ) {
			if ( ! wp_mkdir_p( $target ) ) {
				return false;
			}
		} elseif ( ! kerf_import_servable( $file->getFilename() ) ) {
			continue;
		} elseif ( ! kerf_import_fs()->copy( $file->getPathname(), $target, true ) ) {
			return false;
		}
	}

	return true;
}

/**
 * Take out of a staged folder whatever could run, for a user who may not add
 * scripts (§5.32). Import now requires that permission; a private folder may
 * still reach this guard through another caller.
 *
 * Their scripts are not enqueued, but a script FILE in uploads would still be
 * one linked script away from running — and an SVG is a document that runs
 * its own scripts and `onload` when opened, at the site's origin. Script
 * files are removed; SVGs are cut down to the allowlist the inline-SVG block
 * uses, and removed when nothing is left.
 *
 * @param string $dir
 * @return array{removed:int,cleaned:int,files:string[]}
 */
function kerf_import_disarm( $dir ) {
	$out = array( 'removed' => 0, 'cleaned' => 0, 'files' => array() );

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::LEAVES_ONLY
	);
	foreach ( $iterator as $file ) {
		$name = $file->getFilename();
		$path = $file->getPathname();
		$rel  = ltrim( substr( wp_normalize_path( $path ), strlen( wp_normalize_path( $dir ) ) ), '/' );

		if ( preg_match( '/\.m?js$/i', $name ) ) {
			wp_delete_file( $path );
			$out['removed']++;
			$out['files'][] = $rel;
			continue;
		}

		if ( preg_match( '/\.svg$/i', $name ) ) {
			$raw   = (string) file_get_contents( $path );
			$clean = kerf_sanitize_svg_markup( $raw, 'file' );
			if ( '' === $clean ) {
				wp_delete_file( $path );
				$out['removed']++;
				$out['files'][] = $rel;
			} elseif ( $clean !== $raw ) {
				kerf_import_fs()->put_contents( $path, $clean );
				$out['cleaned']++;
			}
		}
	}

	return $out;
}

/**
 * Resolve a reference from the entry document to a path inside the staged
 * folder, the way a browser resolves it against the document's URL.
 *
 * @param string $base_rel Entry document's folder, relative to the staged root.
 * @param string $ref      The reference as the mockup wrote it.
 * @return string Path relative to the staged root, or '' when it is not a
 *                local path or climbs out of the staged folder.
 */
function kerf_import_join_path( $base_rel, $ref ) {
	return kerf_mc_join_path( $base_rel, $ref );
}

/**
 * The staged file a resolved reference names: itself, or — for a name that
 * hides a program's extension — the name it was staged under
 * (kerf_import_rename_unservable()). A page pasted later still writes the
 * old name.
 *
 * @param array  $staging
 * @param string $relative From kerf_import_join_path().
 * @return string The path that exists, relative to the staged root, or ''.
 */
function kerf_import_staged_path( $staging, $relative ) {
	$relative = (string) $relative;
	if ( '' === $relative || empty( $staging['dir'] ) ) {
		return '';
	}
	$path = strtok( $relative, '?#' );
	if ( false === $path || '' === $path ) {
		return '';
	}
	if ( file_exists( $staging['dir'] . $path ) ) {
		return $relative;
	}
	$safe = kerf_import_servable_name( basename( $path ) );
	if ( '' === $safe ) {
		return '';
	}
	$dir = dirname( $path );
	$alt = ( '.' === $dir ? '' : $dir . '/' ) . $safe;
	return file_exists( $staging['dir'] . $alt ) ? $alt . substr( $relative, strlen( $path ) ) : '';
}

/**
 * Make every relative `url()` and `@import` in a block of CSS absolute.
 *
 * A stylesheet FILE resolves its own relative URLs against its own location,
 * which after staging is still right. An inline style block does not: it
 * becomes an inline style on a WordPress page, and its relative URLs then
 * resolve against the page — `/about/images/hero.jpg`, which does not exist.
 *
 * @param string $css
 * @param array  $staging
 * @return string
 */
function kerf_import_absolutize_css( $css, $staging ) {
	$resolve = static function ( $ref ) use ( $staging ) {
		$path = kerf_import_staged_path( $staging, kerf_import_join_path( $staging['base_rel'], $ref ) );
		if ( '' === $path ) {
			return null;
		}
		// Keep a query or fragment: icon fonts rely on `?#iefix` and cache busters.
		$suffix = preg_match( '/[?#].*$/', $ref, $m ) ? $m[0] : '';
		return $staging['url'] . implode( '/', array_map( 'rawurlencode', explode( '/', $path ) ) ) . $suffix;
	};

	$css = preg_replace_callback(
		'/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i',
		static function ( $m ) use ( $resolve ) {
			$url = $resolve( $m[2] );
			return null === $url ? $m[0] : 'url(' . $m[1] . $url . $m[1] . ')';
		},
		(string) $css
	);

	return preg_replace_callback(
		'/@import\s+([\'"])([^\'"]+)\1/i',
		static function ( $m ) use ( $resolve ) {
			$url = $resolve( $m[2] );
			return null === $url ? $m[0] : '@import ' . $m[1] . $url . $m[1];
		},
		$css
	);
}

/**
 * Delete anything from the staging folder that is not a recognised asset.
 *
 * A mockup ZIP routinely carries .psd, .sketch, .DS_Store, and occasionally a
 * .php or .htaccess that a designer's boilerplate dragged along. Serving an
 * unexpected executable out of uploads is how a staging folder becomes an
 * incident, so the extension list is an allowlist and everything else goes —
 * including the HTML, which is read into the database and never served.
 *
 * @param string $dir
 * @return int Files kept.
 */
function kerf_import_prune( $dir ) {
	$kept = 0;

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iterator as $file ) {
		if ( $file->isDir() ) {
			// Prune empty directories on the way back up.
			kerf_import_fs()->rmdir( $file->getPathname() );
			continue;
		}

		if ( kerf_import_servable( $file->getFilename() ) ) {
			$kept++;
			continue;
		}

		wp_delete_file( $file->getPathname() );
	}

	return $kept;
}

/**
 * May a staged file with this name be served from uploads?
 *
 * The extension allowlist — and no executable extension anywhere in the name:
 * `shell.php.jpg` ends in an allowed one, and a server that maps handlers by
 * ANY extension in a name (Apache's AddHandler) runs it as PHP. Core renames
 * an upload like that (sanitize_file_name()); a staged file keeps the
 * designer's name, so it goes instead. Asked by the prune, and again by the
 * move into uploads, so a file the prune could not delete is still not served.
 *
 * @param string $name File name.
 * @return bool
 */
function kerf_import_servable( $name ) {
	return (bool) preg_match( '/\.(?:' . KERF_IMPORT_ASSET_EXT . ')$/i', $name )
		&& ! preg_match( '/\.(?:' . KERF_IMPORT_EXEC_EXT . ')\./i', $name );
}

/**
 * The name a file whose name hides a program's extension is staged under:
 * each such extension inside the name loses its dot — `all.css.php.css`
 * becomes `all.css-php.css`, `bootstrap-datepicker.pl.min.js`
 * `bootstrap-datepicker-pl.min.js` — so no server maps it to a handler, as
 * core renames an upload like it (sanitize_file_name()). '' when renaming
 * would not make it servable (its last extension is not a design's).
 *
 * @param string $name File name.
 * @return string
 */
function kerf_import_servable_name( $name ) {
	$safe = (string) preg_replace( '/\.(' . KERF_IMPORT_EXEC_EXT . ')(?=\.)/i', '-$1', (string) $name );
	return $safe !== $name && kerf_import_servable( $safe ) ? $safe : '';
}

/**
 * Rename every file in a private staging folder that only its name keeps
 * from being served (kerf_import_servable_name()), before the prune would
 * delete it. A name already taken gets `-2`, `-3` before its extension.
 *
 * @param string $dir The private folder (kerf_import_private_dir()).
 * @return array<string,string> Old file name ⇒ new, for the references to follow.
 */
function kerf_import_rename_unservable( $dir ) {
	$paths = array();
	$walk  = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
	foreach ( $walk as $file ) {
		if ( $file->isFile() && ! $file->isLink() && ! kerf_import_servable( $file->getFilename() ) && '' !== kerf_import_servable_name( $file->getFilename() ) ) {
			$paths[] = $file->getPathname();
		}
	}

	$renamed = array();
	foreach ( $paths as $path ) {
		$name   = basename( $path );
		$safe   = kerf_import_servable_name( $name );
		$dot    = strrpos( $safe, '.' );
		$target = dirname( $path ) . '/' . $safe;
		for ( $n = 2; file_exists( $target ) && $n < 100; $n++ ) {
			$target = dirname( $path ) . '/' . substr( $safe, 0, $dot ) . '-' . $n . substr( $safe, $dot );
		}
		if ( file_exists( $target ) || ! kerf_import_fs()->move( $path, $target ) ) {
			continue;
		}
		// The same name in two folders becomes the same new name: the first
		// says what the references become.
		if ( ! isset( $renamed[ $name ] ) ) {
			$renamed[ $name ] = basename( $target );
		}
	}

	if ( $renamed ) {
		// What the stylesheets and scripts staged beside them call them.
		$walk = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) );
		foreach ( $walk as $file ) {
			if ( $file->isFile() && ! $file->isLink() && preg_match( '/\.(?:css|m?js)$/i', $file->getFilename() ) && $file->getSize() < 4 * MB_IN_BYTES ) {
				$text = (string) file_get_contents( $file->getPathname() );
				$new  = kerf_import_follow_renames( $text, $renamed );
				if ( $new !== $text ) {
					kerf_import_fs()->put_contents( $file->getPathname(), $new );
				}
			}
		}
	}

	return $renamed;
}

/**
 * Point a document's (or a stylesheet's) references to renamed files at
 * their new names: the old name where a path ends — after a slash, a quote,
 * `(`, `=`, a comma or a space, and before a quote, `?`, `#`, `)`, a comma
 * or a space. A name hiding `.php` is distinctive enough that nothing else
 * matches it.
 *
 * @param string                $text
 * @param array<string,string> $renamed Old file name ⇒ new.
 * @return string
 */
function kerf_import_follow_renames( $text, $renamed ) {
	foreach ( (array) $renamed as $old => $new ) {
		$text = (string) preg_replace( '#(?<=^|[\s"\'(=/,])' . preg_quote( (string) $old, '#' ) . '(?=$|[\s"\'?\#),])#', (string) $new, (string) $text );
	}
	return $text;
}

/**
 * Remove what an import staged, whole: its mockup-<time> folder. `dir` is a
 * subfolder of it when the ZIP had one top folder (the files keep their
 * place), and removing only that left an empty mockup-<time> behind every
 * cancelled review, dry run and empty update.
 *
 * @param array|null $staging From kerf_import_unzip(), or a pending import's.
 */
function kerf_import_discard( $staging ) {
	$storage = kerf_assets_storage_for_url( isset( $staging['url'] ) ? $staging['url'] : '' );
	if ( ! $storage || empty( $staging['slug'] ) ) {
		return;
	}
	kerf_import_cleanup( $storage['dir'] . strtok( (string) $staging['slug'], '/' ) );
}

/**
 * Remove a staging folder and everything under it.
 *
 * @param string $dir
 */
function kerf_import_cleanup( $dir ) {
	if ( '' === $dir || ! is_dir( $dir ) ) {
		return;
	}

	$root   = realpath( $dir );
	$inside = false;
	foreach ( kerf_assets_base_folders() as $storage ) {
		$base = realpath( $storage['dir'] );
		if ( false !== $root && false !== $base && 0 === strpos( wp_normalize_path( $root ), trailingslashit( wp_normalize_path( $base ) ) ) ) {
			$inside = true;
			break;
		}
	}
	if ( ! $inside ) {
		// Refuse to recurse outside either staged base, including a path with ..
		return;
	}

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
		RecursiveIteratorIterator::CHILD_FIRST
	);

	foreach ( $iterator as $file ) {
		if ( $file->isDir() && ! $file->isLink() ) {
			kerf_import_fs()->rmdir( $file->getPathname() );
		} else {
			wp_delete_file( $file->getPathname() );
		}
	}

	kerf_import_fs()->rmdir( $dir );
}

/**
 * Find the mockup's entry HTML file.
 *
 * index.html wins; otherwise the shallowest, then largest, HTML file — a
 * mockup's home page is almost always both.
 *
 * @param string $dir
 * @return string Absolute path, or ''.
 */
function kerf_import_find_entry_html( $dir ) {
	$candidates = array();

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS )
	);

	foreach ( $iterator as $file ) {
		if ( $file->isDir() || ! preg_match( '/\.x?html?$/i', $file->getFilename() ) ) {
			continue;
		}
		$path = $file->getPathname();
		if ( 0 === strcasecmp( $file->getFilename(), 'index.html' ) ) {
			return $path;
		}
		$candidates[ $path ] = array(
			'depth' => substr_count( wp_normalize_path( $path ), '/' ),
			'size'  => $file->getSize(),
		);
	}

	if ( empty( $candidates ) ) {
		return '';
	}

	uasort( $candidates, function ( $a, $b ) {
		return ( $a['depth'] <=> $b['depth'] ) ?: ( $b['size'] <=> $a['size'] );
	} );

	return (string) array_key_first( $candidates );
}

/**
 * Point asset records at their staged copies.
 *
 * The mockup says `href="css/style.css"`; after staging, that file lives at
 * uploads/kerf-blocks/mockup-…/css/style.css. Remote URLs are left exactly as
 * written — a CDN link is a deliberate choice by the designer, and quietly
 * localising it changes both caching and licensing.
 *
 * @param array[] $assets
 * @param array   $staging
 * @return array[]
 */
function kerf_import_localize_assets( $assets, $staging ) {
	$base_rel = isset( $staging['base_rel'] ) ? $staging['base_rel'] : '';

	foreach ( $assets as $i => $asset ) {
		// Inline CSS carries its own relative URLs; see kerf_import_absolutize_css().
		if ( 'css' === $asset['type'] && 'inline' === $asset['kind'] && ! empty( $asset['content'] ) ) {
			$assets[ $i ]['content'] = kerf_import_absolutize_css( $asset['content'], $staging + array( 'base_rel' => $base_rel ) );
			continue;
		}

		// So does an import map: `"./js/lib/"` resolves against the page, on
		// WordPress not the design's folder. Each relative address, and each
		// scope, becomes the staged one; a prefix keeps its closing slash.
		if ( 'importmap' === $asset['type'] ) {
			$map = json_decode( (string) $asset['content'], true );
			if ( is_array( $map ) ) {
				$resolve = static function ( $url ) use ( $staging, $base_rel ) {
					if ( ! is_string( $url ) || preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//)#i', $url ) ) {
						return $url;
					}
					$staged = kerf_import_staged_path( $staging, kerf_import_join_path( $base_rel, $url ) );
					return '' === $staged ? $url : $staging['url'] . implode( '/', array_map( 'rawurlencode', explode( '/', $staged ) ) ) . ( '/' === substr( $url, -1 ) ? '/' : '' );
				};
				foreach ( array( 'imports', 'integrity' ) as $part ) {
					foreach ( isset( $map[ $part ] ) && is_array( $map[ $part ] ) ? $map[ $part ] : array() as $key => $value ) {
						if ( 'imports' === $part ) {
							$map['imports'][ $key ] = $resolve( $value );
						} else {
							unset( $map['integrity'][ $key ] );
							$map['integrity'][ $resolve( $key ) ] = $value;
						}
					}
				}
				foreach ( isset( $map['scopes'] ) && is_array( $map['scopes'] ) ? $map['scopes'] : array() as $scope => $list ) {
					unset( $map['scopes'][ $scope ] );
					$map['scopes'][ $resolve( $scope ) ] = is_array( $list ) ? array_map( $resolve, $list ) : $list;
				}
				$assets[ $i ]['content'] = (string) wp_json_encode( $map, JSON_UNESCAPED_SLASHES );
			}
			continue;
		}

		if ( 'file' !== $asset['kind'] || empty( $asset['src'] ) ) {
			continue;
		}

		// Resolved like the browser resolves it: against the document's folder,
		// `../` included. The previous `ltrim( $src, './' )` stripped `../` as a
		// run of characters, so it only worked when the document sat at the root.
		$relative = kerf_import_join_path( $base_rel, $asset['src'] );
		$staged   = kerf_import_staged_path( $staging, $relative );

		if ( '' !== $staged ) {
			$assets[ $i ]['src'] = $staging['url'] . implode( '/', array_map( 'rawurlencode', explode( '/', $staged ) ) );
		} elseif ( '' !== $relative ) {
			// A file the ZIP does not have: enqueued, it was a 404 on every
			// page view, at an address WordPress mangled (`/sitecss/x.css`).
			// The check before importing names it (kerf_preflight()).
			unset( $assets[ $i ] );
		}
	}

	return array_values( $assets );
}

/**
 * Import every image in the staging folder into the media library.
 *
 * Images exist twice after an import, on purpose. The staged copy is what the
 * mockup's CSS resolves `url(../images/hero.jpg)` against, and moving it would
 * mean rewriting stylesheets. The library copy is what the CONTENT points at, so
 * an editor can swap a photograph without touching files, and so WordPress can
 * generate sizes and srcset for it. Neither copy can do the other's job.
 *
 * @param string $dir Staging directory.
 * @return array{items:array[],count:int}
 */
function kerf_import_media( $dir ) {
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$items  = array();
	$count  = 0;
	$reused = 0;

	$iterator = new RecursiveIteratorIterator(
		new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS )
	);

	$root = wp_normalize_path( trailingslashit( $dir ) );

	foreach ( $iterator as $file ) {
		if ( $file->isDir() || ! preg_match( '/\.(?:png|jpe?g|gif|webp|avif|svg)$/i', $file->getFilename() ) ) {
			continue;
		}

		$name = $file->getFilename();

		// Where the image sits in the mockup, so the converter can resolve a
		// reference to it by path. `thumbs/01.jpg` and `fulls/01.jpg` are two
		// images with one name, and a lightbox gallery uses both on every item.
		$path = ltrim( substr( wp_normalize_path( $file->getPathname() ), strlen( $root ) ), '/' );

		// Already in the library — the SAME image, not just the same name?
		// Reuse it rather than filling the library with hero-1.jpg, hero-2.jpg.
		// Matching by name alone reused the previous template's `team-1.jpg`
		// for this one's, and the page showed the wrong people.
		$hash     = md5_file( $file->getPathname() );
		$existing = $hash ? kerf_import_find_attachment_by_hash( $hash ) : null;
		if ( $existing ) {
			$reused++;
			$items[] = array(
				'filename' => $name,
				'path'     => $path,
				'id'       => $existing['id'],
				'url'      => $existing['url'],
				'alt'      => $existing['alt'],
				'width'    => $existing['width'],
				'height'   => $existing['height'],
			);
			continue;
		}

		// Copy first: wp_handle_sideload() MOVES the file it is given, and the
		// staged original has to stay where the CSS expects it.
		$tmp = wp_tempnam( $name );
		if ( ! $tmp || ! kerf_import_fs()->copy( $file->getPathname(), $tmp, true ) ) {
			continue;
		}

		// wp_handle_sideload() takes its first argument by reference, so it has to
		// be a variable — an array literal is a fatal, not a notice.
		$upload     = array( 'name' => $name, 'tmp_name' => $tmp, 'error' => 0, 'size' => $file->getSize() );
		$sideloaded = wp_handle_sideload( $upload, array( 'test_form' => false ) );

		if ( ! empty( $sideloaded['error'] ) ) {
			wp_delete_file( $tmp );
			continue;
		}

		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $sideloaded['type'],
				'post_title'     => sanitize_text_field( pathinfo( $name, PATHINFO_FILENAME ) ),
				// The slug keeps the extension: `about-us-jpg`, not `about-us`.
				// WordPress reserves attachment slugs against pages, and
				// templates name pictures after pages — about-us.jpg beside
				// about-us.html — so without it the About page lost its address
				// to its own photograph and became /about-us-2/.
				'post_name'      => sanitize_title( $name ),
				'post_status'    => 'inherit',
			),
			$sideloaded['file']
		);

		if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
			continue;
		}

		$meta = wp_generate_attachment_metadata( $attachment_id, $sideloaded['file'] );
		wp_update_attachment_metadata( $attachment_id, $meta );

		if ( $hash ) {
			update_post_meta( $attachment_id, KERF_IMPORT_HASH_META, $hash );
		}

		$items[] = array(
			'filename' => $name,
			'path'     => $path,
			'id'       => (int) $attachment_id,
			'url'      => wp_get_attachment_url( $attachment_id ),
			'alt'      => '',
			'width'    => isset( $meta['width'] ) ? (int) $meta['width'] : 0,
			'height'   => isset( $meta['height'] ) ? (int) $meta['height'] : 0,
		);
		$count++;
	}

	return array( 'items' => $items, 'count' => $count, 'reused' => $reused );
}

/**
 * An attachment Kerf imported from a file with exactly these bytes.
 *
 * @param string $hash MD5 of the source file.
 * @return array|null { id, url, alt, width, height } or null.
 */
function kerf_import_find_attachment_by_hash( $hash ) {
	$ids = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'meta_key'       => KERF_IMPORT_HASH_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one picture by its content's hash, once per imported file.
		'meta_value'     => $hash, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- as above.
	) );

	if ( ! $ids ) {
		return null;
	}

	$id  = (int) $ids[0];
	$url = wp_get_attachment_url( $id );
	if ( ! $url ) {
		return null;
	}

	$meta = wp_get_attachment_metadata( $id );

	return array(
		'id'     => $id,
		'url'    => $url,
		'alt'    => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
		'width'  => isset( $meta['width'] ) ? (int) $meta['width'] : 0,
		'height' => isset( $meta['height'] ) ? (int) $meta['height'] : 0,
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// SPLITTING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Split a document body into the regions a WordPress page is assembled from.
 *
 * Partitions by POSITION, never by extraction:
 *
 *   header  everything up to and including the site CHROME — the element that
 *           holds the primary navigation
 *   footer  the site footer and everything after it
 *   main    everything in between
 *
 * An earlier version picked out the landmarks and, when it found a top-level
 * `<main>`, used that alone as the page — which silently deleted every other
 * top-level sibling. Real mockups are full of them: a back-to-top button, a
 * cookie banner, a search overlay, a mobile drawer, all parked after
 * `</footer>`. Partitioning by position cannot drop anything: every node lands
 * in exactly one region, in document order.
 *
 * WHAT COUNTS AS CHROME was, through session 5, "the first top-level `<header>`",
 * and on real templates that was wrong more often than right — invisible on
 * the home page, which renders every region anyway, and fatal on every other
 * page, which renders only the parts:
 *
 *   - Start Bootstrap puts `<nav>` first and makes `<header class="masthead">`
 *     the HERO: the hero became the header and repeated on every page.
 *   - Colorlib's clark and plumberz have no `<header>` at all — the chrome is a
 *     top-level `<nav>`, or a `<div>` holding one — so the header part was
 *     emptied and inner pages had no navigation.
 *   - HTML5 UP's Massively and Bootstrap's cover example wrap the WHOLE page in
 *     one element (`div#wrapper`, `.cover-container`), so nothing was at the
 *     top level to split on: no header or footer on any other page.
 *   - gymlife's footer is `<section class="footer-section">`; plumberz's is a
 *     `<div class="… footer">`. No `<footer>`, no footer part.
 *
 * So the rules, in order:
 *
 *   1. A FRAME — one element that holds the navigation AND a `<footer>` or
 *      `<main>` — is descended into, and recorded: it is re-emitted around the
 *      header, the content and the footer on every page by `kerf/frame`, so the
 *      home page keeps its exact DOM. Whatever sits beside it goes to the
 *      `page-start` / `page-end` parts, which render outside it.
 *   2. The chrome is the first `<header>` holding a navigation; else the first
 *      navigation element (a `<nav>`, `role="navigation"`, or anything holding
 *      one) that is not an off-canvas drawer; else the first `<header>` at all.
 *      A navigation directly after it, a slide-out panel (cart, drawer,
 *      modal, overlay), and a dialog (`role="dialog"`, `<dialog>`) whatever
 *      it holds, are chrome too.
 *   3. The footer is the last `<footer>` after the chrome; else the last node
 *      whose class or id names it a footer.
 *   4. Before the chrome, a node carrying the page's HEADLINE — an `<h1>` or
 *      `<h2>` with text that is not a logo link — is the home page's intro, not
 *      site chrome (Massively's `#intro`). It stays where it is, so the home
 *      page is unchanged, and is marked to render on the home page only.
 *
 * A mockup with no navigation at all converts entirely into the page: better
 * one long page the author can cut up than a guess that puts the hero in the
 * header.
 *
 * @param string $body Body HTML, as kerf_mc_extract_body() gives it — its
 *                     elements closed where a browser closes them (scar 102).
 * @return array{header:string,main:string,footer:string,before:string,after:string,frame:string[],folded:string[],front_only:string[],chrome:string,footer_node:string}
 */
function kerf_import_split( $body ) {
	$out = array(
		'header'      => '',
		'main'        => '',
		'footer'      => '',
		'before'      => '',
		'after'       => '',
		'frame'       => array(),
		'folded'      => array(),
		'front_only'  => array(),
		// What was taken as the site header and footer, named for the report:
		// the one decision every inner page inherits (§5.23).
		'chrome'      => '',
		'footer_node' => '',
	);

	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML(
		'<?xml encoding="utf-8"?><div data-kerf-split-root="1">' . $body . '</div>',
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
	);
	libxml_clear_errors();

	$root = $doc->documentElement;
	if ( ! $root ) {
		$out['main'] = $body;
		return $out;
	}

	$xpath = new DOMXPath( $doc );
	$level = kerf_import_split_nodes( $root );

	// ── 1. Descend through the page frame, if there is one.
	$chrome = kerf_import_split_find_chrome( $level, $xpath );
	while ( null !== $chrome && kerf_import_split_is_frame( $level[ $chrome ], $xpath ) ) {
		$frame = $level[ $chrome ];

		// Nested frames are followed only when nothing sits beside the inner
		// one: content between two frames would need a slot of its own.
		if ( ! empty( $out['frame'] ) && count( kerf_import_split_significant( $level ) ) > 1 ) {
			break;
		}

		if ( empty( $out['frame'] ) ) {
			foreach ( array_slice( $level, 0, $chrome ) as $node ) {
				$out['before'] .= $doc->saveHTML( $node );
				kerf_import_split_label( $out, $node, 'page start' );
			}
			foreach ( array_slice( $level, $chrome + 1 ) as $node ) {
				$out['after'] .= $doc->saveHTML( $node );
				kerf_import_split_label( $out, $node, 'page end' );
			}
		}

		$out['frame'][] = $doc->saveHTML( $frame->cloneNode( false ) );
		$level          = kerf_import_split_nodes( $frame );
		$chrome         = kerf_import_split_find_chrome( $level, $xpath );
	}

	// A frame that could not be descended is not chrome either: it holds the
	// footer and the content, and putting it in the header part would put the
	// whole page there.
	if ( null !== $chrome && kerf_import_split_is_frame( $level[ $chrome ], $xpath ) ) {
		$chrome = null;
	}

	// ── 2. Where the chrome ends.
	$header_end = null;
	if ( null !== $chrome ) {
		$header_end = $chrome;
		$count      = count( $level );
		for ( $i = $chrome + 1; $i < $count; $i++ ) {
			$node = $level[ $i ];
			if ( XML_ELEMENT_NODE !== $node->nodeType ) {
				break;
			}
			if ( in_array( strtolower( $node->nodeName ), kerf_mc_dropped_tags(), true ) ) {
				continue; // A script element between the header and its drawer.
			}
			// A dialog the header opens — a search overlay, a booking pop-up —
			// is chrome whatever it is named and whatever it holds: its heading
			// is its own title, never the page's. Left in the home page, every
			// other page lacked it, and the header's button that opens it
			// opened nothing there (scar 132).
			if ( kerf_import_split_is_dialog( $node ) ) {
				$header_end = $i;
				continue;
			}
			// A block carrying the page's headline is the page, whatever
			// navigation it holds: a title banner, not more of the menu.
			if ( kerf_import_split_has_headline( $node, $xpath ) ) {
				break;
			}
			if ( kerf_import_split_is_navigation( $node, $xpath ) || kerf_import_split_is_panel( $node ) ) {
				$header_end = $i;
				continue;
			}
			break;
		}
	}

	// ── 3. Where the footer starts.
	$footer_at = null;
	$from      = null === $header_end ? 0 : $header_end + 1;
	for ( $i = count( $level ) - 1; $i >= $from; $i-- ) {
		// Last one wins: a mockup sometimes has a <footer> inside an <article>
		// hoisted to the top level by the parser, before the real site footer.
		if ( XML_ELEMENT_NODE === $level[ $i ]->nodeType && 'footer' === strtolower( $level[ $i ]->nodeName ) ) {
			$footer_at = $i;
			break;
		}
	}
	if ( null === $footer_at ) {
		for ( $i = count( $level ) - 1; $i >= $from; $i-- ) {
			if ( XML_ELEMENT_NODE === $level[ $i ]->nodeType
				&& kerf_import_split_named( $level[ $i ], '(?:site-?)?footer' ) ) {
				$footer_at = $i;
				break;
			}
		}
	}

	if ( null !== $chrome && XML_ELEMENT_NODE === $level[ $chrome ]->nodeType ) {
		$out['chrome'] = kerf_import_split_describe( $level[ $chrome ] );
	}
	if ( null !== $footer_at ) {
		$out['footer_node'] = kerf_import_split_describe( $level[ $footer_at ] );
	}

	// ── 4. Place every node.
	foreach ( $level as $index => $node ) {
		if ( null !== $header_end && $index <= $header_end ) {
			$region = 'header';
		} elseif ( null !== $footer_at && $index >= $footer_at ) {
			$region = 'footer';
		} else {
			$region = 'main';
		}

		if ( 'header' === $region && $index < $chrome && XML_ELEMENT_NODE === $node->nodeType
			&& kerf_import_split_has_headline( $node, $xpath ) ) {
			$node->setAttribute( 'data-kerf-only', 'front' );
			$out['front_only'][] = kerf_import_split_describe( $node );
		}

		$out[ $region ] .= $doc->saveHTML( $node );

		if ( 'main' !== $region ) {
			kerf_import_split_label( $out, $node, $region );
		}
	}

	return $out;
}

/**
 * `<div> #wrapper`, for the import report, from a frame element's attributes.
 *
 * @param array $attrs kerf/div attributes.
 * @return string
 */
function kerf_import_describe_frame( $attrs ) {
	$label = '<' . ( isset( $attrs['tagName'] ) ? $attrs['tagName'] : 'div' ) . '>';
	if ( ! empty( $attrs['anchor'] ) ) {
		return $label . ' #' . $attrs['anchor'];
	}
	if ( ! empty( $attrs['className'] ) ) {
		return $label . ' .' . strtok( $attrs['className'], ' ' );
	}
	return $label;
}

/**
 * The nodes of one level worth placing: elements, and text that is not
 * whitespace, in document order.
 *
 * @param DOMNode $parent
 * @return DOMNode[]
 */
function kerf_import_split_nodes( $parent ) {
	$nodes = array();
	foreach ( $parent->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			$nodes[] = $child;
		} elseif ( XML_TEXT_NODE === $child->nodeType && '' !== trim( $child->textContent ) ) {
			$nodes[] = $child;
		}
	}
	return $nodes;
}

/**
 * The nodes of a level that render something: not scripts, styles or text.
 *
 * @param DOMNode[] $level
 * @return DOMNode[]
 */
function kerf_import_split_significant( $level ) {
	return array_values( array_filter( $level, function ( $node ) {
		return XML_ELEMENT_NODE === $node->nodeType
			&& ! in_array( strtolower( $node->nodeName ), kerf_mc_dropped_tags(), true );
	} ) );
}

/**
 * Index of the site chrome on one level, or null. See kerf_import_split(),
 * rule 2.
 *
 * @param DOMNode[] $level
 * @param DOMXPath  $xpath
 * @return int|null
 */
function kerf_import_split_find_chrome( $level, $xpath ) {
	$first_header = null;
	$first_nav    = null;

	foreach ( $level as $index => $node ) {
		if ( XML_ELEMENT_NODE !== $node->nodeType ) {
			continue;
		}
		$tag = strtolower( $node->nodeName );
		$nav = kerf_import_split_is_navigation( $node, $xpath );

		if ( 'header' === $tag ) {
			if ( $nav ) {
				return $index;
			}
			if ( null === $first_header ) {
				$first_header = $index;
			}
		} elseif ( $nav && null === $first_nav && ! kerf_import_split_is_panel( $node ) ) {
			$first_nav = $index;
		}
	}

	return null !== $first_nav ? $first_nav : $first_header;
}

/**
 * Is this element navigation, or does it hold some?
 *
 * @param DOMElement $node
 * @param DOMXPath   $xpath
 * @return bool
 */
function kerf_import_split_is_navigation( $node, $xpath ) {
	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return false;
	}
	foreach ( $xpath->query( './descendant-or-self::nav | ./descendant-or-self::*[@role="navigation"]', $node ) as $nav ) {
		if ( ! kerf_import_split_is_breadcrumb( $nav, $xpath ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Is this navigation a breadcrumb trail? Written as a `<nav>`, but it says
 * where the page is, not how to get around the site: page content.
 *
 * Every plumberz inner page opens with a banner — the page's title and
 * `<nav aria-label="breadcrumb">` — straight after the menu. Holding a nav,
 * the banner was taken as more of the site's navigation, joined the header,
 * and was lost on every inner page, which renders the home page's header.
 *
 * @param DOMElement $nav
 * @param DOMXPath   $xpath
 * @return bool
 */
function kerf_import_split_is_breadcrumb( $nav, $xpath ) {
	$names = $nav->getAttribute( 'aria-label' ) . ' ' . $nav->getAttribute( 'class' ) . ' ' . $nav->getAttribute( 'id' );
	if ( preg_match( '/bread-?crumb/i', $names ) ) {
		return true;
	}
	return $xpath->query( './/*[contains(translate(@class, "BREADCUM", "breadcum"), "breadcrumb") or contains(@itemtype, "BreadcrumbList")]', $nav )->length > 0;
}

/**
 * Is this element a page frame — the navigation AND the rest of the page?
 *
 * @param DOMElement $node
 * @param DOMXPath   $xpath
 * @return bool
 */
function kerf_import_split_is_frame( $node, $xpath ) {
	$tag = strtolower( $node->nodeName );
	if ( in_array( $tag, array( 'header', 'nav', 'footer', 'main' ), true ) ) {
		return false;
	}
	if ( $xpath->query( './/footer | .//main', $node )->length > 0 ) {
		return true;
	}

	// The page in a box with the footer outside it: a single-file page as an
	// AI writes one wraps the navigation and every section in `<div
	// class="wrap">`, and taken as the chrome the whole page went into the
	// header part — the page itself came out empty. Two or more sections after
	// the navigation make it a frame. A hero wrapper (the navigation and one
	// intro block) does not: wrapped around every page, its background would be
	// behind everything.
	$after_nav = false;
	$sections  = 0;
	foreach ( kerf_import_split_nodes( $node ) as $child ) {
		if ( XML_ELEMENT_NODE !== $child->nodeType ) {
			continue;
		}
		if ( ! $after_nav ) {
			$after_nav = kerf_import_split_is_navigation( $child, $xpath );
			continue;
		}
		if ( in_array( strtolower( $child->nodeName ), array( 'section', 'article' ), true ) || $xpath->query( './/h2', $child )->length > 0 ) {
			$sections++;
		}
	}
	return $sections >= 2;
}

/**
 * Is this a slide-out panel that belongs to the chrome — an off-canvas menu,
 * a cart drawer, a modal, a search overlay? Named, because a panel is hidden
 * until its script opens it and there is nothing else to measure.
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_import_split_is_panel( $node ) {
	return XML_ELEMENT_NODE === $node->nodeType
		&& kerf_import_split_named( $node, '(?:off-?canvas|cart|drawer|modal|overlay|popup|side-?panel|mobile-?menu|search-?(?:model|modal|overlay|popup))' );
}

/**
 * Does the element say it is a dialog — `<dialog>`, `role="dialog"` or
 * `"alertdialog"`, `aria-modal="true"`?
 *
 * The names above miss what a designer calls their own overlay (`searchlayer`,
 * `slayer` — the Murphy designs, scar 132); the markup that makes it a dialog
 * for a screen reader says what it is, and a page's banner never says it.
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_import_split_is_dialog( $node ) {
	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return false;
	}
	if ( 'dialog' === strtolower( $node->nodeName ) || 'true' === strtolower( trim( $node->getAttribute( 'aria-modal' ) ) ) ) {
		return true;
	}
	return (bool) preg_match( '/(?:^|\s)(?:alert)?dialog(?:\s|$)/i', $node->getAttribute( 'role' ) );
}

/**
 * Does the element's class list or id contain this name as a whole word?
 * Hyphens and underscores separate words: `footer-section` names a footer,
 * `prefooter` does not.
 *
 * @param DOMElement $node
 * @param string     $pattern Regex fragment, no delimiters.
 * @return bool
 */
function kerf_import_split_named( $node, $pattern ) {
	$names = $node->getAttribute( 'class' ) . ' ' . $node->getAttribute( 'id' );
	return (bool) preg_match( '/(?:^|[\s_-])' . $pattern . '(?:$|[\s_-])/i', $names );
}

/**
 * Does the element carry a headline — an h1 or h2 with text of its own, not
 * only a logo link?
 *
 * Logos come both ways round — `<h1><a>Brand</a></h1>` and plumberz's
 * `<a><h1>Brand</h1></a>` in its top bar — and neither is a headline.
 *
 * @param DOMElement $node
 * @param DOMXPath   $xpath
 * @return bool
 */
function kerf_import_split_has_headline( $node, $xpath ) {
	$headings = $xpath->query( './descendant-or-self::*[self::h1 or self::h2][not(ancestor::a)]', $node );
	foreach ( $headings as $heading ) {
		$text = $heading->textContent;
		foreach ( $xpath->query( './/a', $heading ) as $link ) {
			$text = str_replace( $link->textContent, '', $text );
		}
		if ( '' !== trim( $text ) ) {
			return true;
		}
	}
	return false;
}

/**
 * `<tag> #id` or `<tag> .first-class`, for the import report.
 *
 * @param DOMElement $node
 * @return string
 */
function kerf_import_split_describe( $node ) {
	$tag   = strtolower( $node->nodeName );
	$class = trim( $node->getAttribute( 'class' ) );
	$id    = trim( $node->getAttribute( 'id' ) );
	$label = '<' . $tag . '>';
	if ( '' !== $id ) {
		$label .= ' #' . $id;
	} elseif ( '' !== $class ) {
		$label .= ' .' . strtok( $class, " \t\n" );
	}
	return $label;
}

/**
 * Name a node that was moved into a template part because of where it sat,
 * rather than because of what it is. Silently relocating a modal into the
 * footer is fine; doing it without saying so is not.
 *
 * A script or style element is not "folded markup" — the asset pipeline takes it
 * and reports it there. Listing it twice trains people to skim the report.
 *
 * @param array   $out    Split result, by reference.
 * @param DOMNode $node
 * @param string  $region Where it went.
 */
function kerf_import_split_label( &$out, $node, $region ) {
	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return;
	}
	$skip = array_merge( kerf_mc_dropped_tags(), array( 'header', 'footer', 'nav' ) );
	if ( in_array( strtolower( $node->nodeName ), $skip, true ) ) {
		return;
	}
	$out['folded'][] = kerf_import_split_describe( $node ) . ' → ' . $region;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WRITING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Create or replace a template part.
 *
 * Written as a `wp_template_part` post rather than a file in the theme, because
 * a file is read-only from the Site Editor: the whole point of converting a
 * header into blocks is being able to edit it afterwards.
 *
 * @param string $slug    Part slug, e.g. 'header'.
 * @param string $area    Template part area.
 * @param string $title   Human title.
 * @param string $content Block markup.
 * @return int Post ID, or 0 on failure.
 */
function kerf_import_write_template_part( $slug, $area, $title, $content ) {
	$theme = get_stylesheet();

	$existing = get_posts( array(
		'post_type'      => 'wp_template_part',
		'post_status'    => array( 'publish', 'draft', 'auto-draft' ),
		'name'           => $slug,
		'posts_per_page' => 1,
		'no_found_rows'  => true,
		'tax_query'      => array( array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a template part is its theme's: how core finds one too.
			'taxonomy' => 'wp_theme',
			'field'    => 'name',
			'terms'    => $theme,
		) ),
	) );

	$postarr = array(
		'post_type'    => 'wp_template_part',
		'post_status'  => 'publish',
		'post_name'    => $slug,
		'post_title'   => $title,
		// wp_slash() is mandatory, not defensive. wp_insert_post() unslashes
		// whatever it is given, and block attributes are serialized with `--`
		// escaped as `--` (an unescaped double hyphen can terminate the
		// HTML comment the block lives in). Unslashing eats those backslashes, so
		// `btn--primary` reaches the database as `btnu002du002dprimary` — every
		// BEM class in the mockup silently mangled, with the block markup still
		// parsing cleanly so nothing errors.
		'post_content' => wp_slash( $content ),
	);

	if ( ! empty( $existing ) ) {
		$postarr['ID'] = $existing[0]->ID;
		$post_id       = wp_update_post( $postarr, true );
	} else {
		$post_id = wp_insert_post( $postarr, true );
	}

	if ( is_wp_error( $post_id ) || ! $post_id ) {
		return 0;
	}

	// Both terms are required: wp_theme scopes the part to this theme, and
	// wp_template_part_area is what makes the Site Editor file it under Header
	// rather than in a flat "general" list.
	wp_set_object_terms( $post_id, $theme, 'wp_theme' );
	wp_set_object_terms( $post_id, $area, 'wp_template_part_area' );

	// Template parts are cached aggressively; without this the Site Editor and
	// the front end keep serving the previous markup until something else
	// happens to bust it.
	clean_post_cache( $post_id );
	wp_cache_delete( 'wp_template_part_' . $theme . '_' . $slug, 'posts' );

	return (int) $post_id;
}

/**
 * A page for the blog, when the design becomes the front page and the site
 * has none.
 *
 * WordPress lists posts on the "Posts page" chosen under Settings → Reading.
 * With the design as the front page and no posts page, the blog had no
 * address: its menu link went nowhere, and so did every post's way back.
 * An empty page called "blog" — a draft Kerf made for a link, say — is used
 * and published; one with content of its own is never taken over.
 *
 * @return string A line for the report, or ''.
 */
function kerf_import_blog_page() {
	// A posts page that was deleted still has its number in the setting.
	$current = (int) get_option( 'page_for_posts' );
	if ( $current && in_array( get_post_status( $current ), array( 'publish', 'private' ), true ) ) {
		return '';
	}

	$page = get_page_by_path( 'blog', OBJECT, array( 'page' ) ); // An array: a string adds 'attachment'.
	if ( $page && '' !== trim( wp_strip_all_tags( (string) $page->post_content ) ) ) {
		return __( 'Your site has no blog page, and the page called "blog" has content of its own, so Kerf left it alone: choose the blog\'s page under Settings → Reading.', 'kerf-blocks' );
	}

	if ( $page ) {
		$id = (int) $page->ID;
		if ( 'publish' !== $page->post_status ) {
			wp_update_post( array( 'ID' => $id, 'post_status' => 'publish' ) );
		}
	} else {
		$id = wp_insert_post( array(
			'post_type'   => 'page',
			'post_status' => 'publish',
			'post_title'  => __( 'Blog', 'kerf-blocks' ),
			'post_name'   => 'blog',
		), true );
		if ( is_wp_error( $id ) || ! $id ) {
			return '';
		}
	}

	update_option( 'page_for_posts', (int) $id );

	return sprintf(
		/* translators: 1: page title, 2: its address. */
		__( 'Made "%1$s" the blog\'s page, at %2$s: your posts are listed there.', 'kerf-blocks' ),
		get_the_title( $id ),
		get_permalink( $id )
	);
}

/**
 * The page chosen on the form: its ID, or 0 for a new one.
 *
 * @return int
 */
function kerf_import_target_id() {
	$target = isset( $_POST['kerf_target'] ) ? sanitize_text_field( wp_unslash( $_POST['kerf_target'] ) ) : 'new'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in kerf_import_run_post().
	return 'new' === $target ? 0 : (int) $target;
}

/**
 * Create or update the target page.
 *
 * @param string $content Block markup.
 * @return int Page ID, or 0.
 */
function kerf_import_write_page( $content ) {
	if ( '' === trim( $content ) ) {
		return 0;
	}

	$target = isset( $_POST['kerf_target'] ) ? sanitize_text_field( wp_unslash( $_POST['kerf_target'] ) ) : 'new'; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in kerf_import_run_post().

	// @see kerf_import_write_template_part() for why wp_slash() is required here.
	$content = wp_slash( $content );

	if ( 'new' !== $target ) {
		$page_id = (int) $target;
		if ( ! get_post( $page_id ) ) {
			return 0;
		}
		$updated = wp_update_post( array( 'ID' => $page_id, 'post_content' => $content ), true );
		return is_wp_error( $updated ) ? 0 : $page_id;
	}

	$title = isset( $_POST['kerf_new_title'] ) ? sanitize_text_field( wp_unslash( $_POST['kerf_new_title'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in kerf_import_run_post().
	if ( '' === $title ) {
		$title = __( 'Imported mockup', 'kerf-blocks' );
	}

	$page_id = wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'publish',
		'post_title'   => $title,
		'post_content' => $content,
	), true );

	return is_wp_error( $page_id ) ? 0 : (int) $page_id;
}
