<?php
/**
 * Bind converted links to real WordPress content.
 *
 * THE PROBLEM. A mockup's navigation is `<a href="about.html">About</a>` or
 * `<a href="/about">About</a>`. Converted literally — which is what fidelity
 * demands — it renders exactly that, and exactly that 404s on a WordPress site
 * whose About page lives at `/about-us/`. So the menu looks perfect and works
 * nowhere.
 *
 * THE USUAL FIX IS WRONG HERE. Every other tool solves this by replacing the
 * `<nav>` with `wp_nav_menu()`, which throws away the designer's markup and with
 * it every selector, every animation and every mega-menu the CSS was written
 * against. Kerf does not do that (see CLAUDE.md §5.2).
 *
 * WHAT THIS DOES INSTEAD. The markup stays byte-for-byte as written; only the
 * *destination* is bound. A link carries two extra attributes — `linkType` and
 * `linkId` — and when they are set the renderer resolves the href through
 * `get_permalink()` at render time. The result:
 *
 *   - the DOM is still the designer's DOM, class for class
 *   - the link follows the page. Rename the slug, move it under a parent,
 *     switch permalink structure — the menu keeps working, which is the thing
 *     people actually mean by "it works like a menu"
 *   - nothing is lost if the binding is removed: `url` still holds what the
 *     mockup said, and the renderer falls back to it
 *
 * Anything that cannot be bound is REPORTED rather than guessed at. An
 * unresolved internal link is a real, listed problem with a one-click fix, not
 * a silent 404 discovered after launch.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option holding the unresolved-link report from the last import.
 */
const KERF_LINKS_OPTION = 'kerf_unresolved_links';

/**
 * The design's home page file, as an address reads it (kerf_links_home_file()).
 */
const KERF_LINKS_HOME_FILE_OPTION = 'kerf_links_home_file';

/**
 * Block attributes that can carry a bound destination.
 *
 * kerf/link keeps its href in `url`; kerf/div (which is what an anchor with
 * element children becomes) keeps it in `customAttributes['href']`. Both get the
 * same two binding attributes so the behaviour does not depend on which shape
 * the converter happened to pick.
 *
 * @return string[]
 */
function kerf_links_bindable_blocks() {
	return array( 'kerf/link', 'kerf/div', 'kerf/image' );
}

// ═══════════════════════════════════════════════════════════════════════════════
// NORMALIZING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Reduce an href to something that can be looked up, or null when it is not a
 * candidate for binding at all.
 *
 * Returns the sentinel 'home' for anything that means the front page.
 *
 * Deliberately NOT bound: fragments (`#services` scrolls within the page),
 * `mailto:`/`tel:`/`sms:` (not pages), and absolute URLs on another host (the
 * designer meant that exact destination). Binding any of those would be the tool
 * overruling the author.
 *
 * @param string $href
 * @return string|null Normalized path, 'home', or null.
 */
function kerf_links_normalize( $href ) {
	$href = trim( (string) $href );

	if ( '' === $href || '#' === $href ) {
		return null;
	}

	// In-page anchor, or a non-navigational scheme.
	if ( 0 === strpos( $href, '#' ) ) {
		return null;
	}
	if ( preg_match( '#^(?:mailto|tel|sms|callto|javascript|vbscript|data|ftp):#i', $href ) ) {
		return null;
	}

	// Absolute URL: only a candidate when it is on this site.
	if ( preg_match( '#^(?:https?:)?//#i', $href ) ) {
		$host = wp_parse_url( $href, PHP_URL_HOST );
		$home = wp_parse_url( home_url(), PHP_URL_HOST );

		if ( ! $host || ! $home || 0 !== strcasecmp(
			preg_replace( '/^www\./i', '', $host ),
			preg_replace( '/^www\./i', '', $home )
		) ) {
			return null;
		}

		$href = (string) wp_parse_url( $href, PHP_URL_PATH );
	}

	// Drop the query and the fragment — neither identifies a different page.
	$href = preg_replace( '/[?#].*$/', '', $href );

	// On a site in a folder of its own — a subdirectory network's
	// `/kerf-test/pleasanthilldental/` — an address on this site starts with
	// that folder, which is the home page; what follows it is the page. Read
	// whole, the home page's own address was a page named
	// `kerf-test/pleasanthilldental`, listed as going nowhere (scar 134).
	$site_path = trailingslashit( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ) );
	if ( '/' !== $site_path && 0 === strpos( trailingslashit( (string) $href ), $site_path ) ) {
		$href = '/' . substr( (string) $href, strlen( $site_path ) );
	}

	// `./about.html` and `../about.html` are `about.html`. Only `../` was ever
	// stripped (below the index check, too late for `./index.html`), and
	// designers write the `./` out of habit: gymlife's whole menu is
	// `./about-us.html`, `./index.html` — none of it was bound, on any import
	// (scar 53). A mockup zipped from a subfolder carries the `../`.
	$href = preg_replace( '#^(?:\.{1,2}/)+#', '', trim( (string) $href ) );

	if ( '' === $href || '/' === $href ) {
		return 'home';
	}

	// A FILE is not a page. `img/gallery-1.jpg` behind a lightbox link, a PDF, a
	// video: looked up as slugs they were listed as unresolved links, and with
	// "create missing pages" on each one became an empty draft page. Only a
	// page-like extension, or none at all, is a candidate. An extension starts
	// with a letter, so a slug like `release-v1.2` is still a page.
	if ( preg_match( '/\.([a-z][a-z0-9]{0,4})$/i', $href, $ext ) && ! preg_match( '/^(?:html?|php|aspx?)$/i', $ext[1] ) ) {
		return null;
	}

	// A mockup is a folder of files, so its links carry extensions.
	$href = preg_replace( '/\.(?:html?|php|aspx?)$/i', '', $href );
	$href = trim( (string) $href, '/' );
	$href = strtolower( $href );

	if ( '' === $href || in_array( $href, array( 'index', 'home', 'default' ), true ) ) {
		return 'home';
	}

	// The file the design's home page was imported from, whatever it was
	// called: a ZIP of design variants names it `index-1.html`, and every
	// "home" link of that design — the logo, the menu's first item, the inner
	// page's way back — was left literal and led to "Page not found" (scar 134).
	$home_file = kerf_links_home_file();
	if ( '' !== $home_file && $href === $home_file ) {
		return 'home';
	}

	return $href;
}

/**
 * The name the design gave its home page's file, read as kerf_links_normalize()
 * reads an address (`index-1` for index-1.html) — '' when it was index.html,
 * which means the home page already. A site import names it before it binds a
 * link (kerf_import_handle_post()) and keeps it, so every later binding — Update
 * design, Kerf → Links' check, a page Kerf AI makes — reads it the same way.
 *
 * @param string|null $file The entry file of the import running now.
 * @return string
 */
function kerf_links_home_file( $file = null ) {
	static $now = null;
	if ( null !== $file ) {
		$name = strtolower( (string) preg_replace( '/\.(?:html?|php|aspx?)$/i', '', basename( str_replace( '\\', '/', (string) $file ) ) ) );
		$now  = in_array( $name, array( '', 'index', 'home', 'default' ), true ) ? '' : $name;
	}
	return null !== $now ? $now : (string) get_option( KERF_LINKS_HOME_FILE_OPTION, '' );
}

/**
 * The part of a link's address after `#`, when the address itself names where
 * the link is bound: `index.html#services` bound to the home page, or
 * `about.html#team` to the page `about`. A bound link printed only its page's
 * address, so the inner page's "Services" went to the top of the home page
 * instead of its Services section (scar 134). A link pointed somewhere else in
 * the editor keeps the design's address as its fallback — `index.html#services`
 * now going to About — and gets none: About has no Services section.
 *
 * @param array  $attrs   Block attributes (`linkType`, `linkId`).
 * @param string $written The address as the design wrote it.
 * @return string `#…`, or ''.
 */
function kerf_links_fragment( $attrs, $written ) {
	$at = strpos( (string) $written, '#' );
	if ( false === $at || strlen( (string) $written ) - 1 === $at ) {
		return '';
	}
	$fragment = substr( (string) $written, $at );
	$type     = isset( $attrs['linkType'] ) ? (string) $attrs['linkType'] : '';
	$path     = kerf_links_normalize( $written );

	if ( 'home' === $type ) {
		// `#top` on a logo bound home is the home page's top, from anywhere.
		return 'home' === $path || 0 === strpos( trim( (string) $written ), '#' ) ? $fragment : '';
	}
	if ( 'post' === $type && ! empty( $attrs['linkId'] ) && null !== $path && 'home' !== $path ) {
		$post = get_post( (int) $attrs['linkId'] );
		$leaf = substr( (string) strrchr( '/' . $path, '/' ), 1 );
		if ( $post && ( $leaf === $post->post_name || $path === get_page_uri( $post ) ) ) {
			return $fragment;
		}
	}
	return '';
}

/**
 * Find the post or page a normalized path refers to.
 *
 * Three attempts, widest last:
 *   1. the full path            — `services/brand` finds a child page
 *   2. the last segment as slug — `brand` when the mockup nested it differently
 *   3. the title                — `about-us` matching a page titled "About Us"
 *
 * Attempt 2 exists because a designer's folder layout almost never matches the
 * site's page hierarchy, and attempt 3 because a page created from the site's
 * content plan is usually titled before it is slugged.
 *
 * @param string $path Normalized path from kerf_links_normalize().
 * @return int Post ID, or 0.
 */
function kerf_links_find_post( $path ) {
	static $cache = array();

	// A page this import made from one of the mockup's files: found by the
	// file, whatever it was titled and slugged on the review screen.
	$known = kerf_links_known();
	if ( isset( $known[ $path ] ) ) {
		return $known[ $path ];
	}

	if ( isset( $cache[ $path ] ) ) {
		return $cache[ $path ];
	}

	$types = array( 'page', 'post' );
	$found = 0;

	$page = get_page_by_path( $path, OBJECT, $types );
	if ( $page ) {
		$found = (int) $page->ID;
	}

	if ( ! $found && false !== strpos( $path, '/' ) ) {
		$segments = explode( '/', $path );
		$leaf     = end( $segments );
		$page     = get_page_by_path( $leaf, OBJECT, $types );
		if ( $page ) {
			$found = (int) $page->ID;
		}
	}

	if ( ! $found ) {
		$by_title = get_posts( array(
			'post_type'        => $types,
			'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
			'posts_per_page'   => 1,
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'title'            => str_replace( '-', ' ', $path ),
		) );
		if ( $by_title ) {
			$found = (int) $by_title[0]->ID;
		}
	}

	$cache[ $path ] = $found;

	return $found;
}

/**
 * Pages made from the mockup's own files during this request: normalized
 * path (`about` for about.html) → page ID. Kerf Pro's kerf_import_pages_reserve() fills
 * it before any link is bound, so `about.html` finds the page made from it
 * even when the review screen gave it another title and address.
 *
 * @param string|null $path Normalized path to remember.
 * @param int|null    $id   Its page.
 * @return array<string,int>
 */
function kerf_links_known( $path = null, $id = null ) {
	static $known = array();
	if ( null !== $path && null !== $id ) {
		$known[ (string) $path ] = (int) $id;
	}
	return $known;
}

// ═══════════════════════════════════════════════════════════════════════════════
// BINDING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Walk block markup and bind every internal link it can.
 *
 * Runs as a pass OVER the converter's output rather than inside it, on purpose:
 * `inc/kerf-converter-lib.php` must keep working with no WordPress loaded (see
 * CLAUDE.md §6.3), and resolving a permalink is about as WordPress as it gets.
 *
 * @param string $markup Block markup.
 * @param array  $args   {
 *     @type bool $create_missing Create a draft page for each unmatched link.
 * }
 * @return array{markup:string,bound:int,unresolved:array<string,int>,created:int}
 */
function kerf_links_bind( $markup, $args = array() ) {
	$create = ! empty( $args['create_missing'] );

	$state = array(
		'bound'      => 0,
		'created'    => 0,
		'unresolved' => array(),
	);

	if ( '' === trim( (string) $markup ) ) {
		return array( 'markup' => $markup ) + $state;
	}

	$blocks = parse_blocks( $markup );

	// The site header's logo goes to the home page (kerf_links_find_logo()).
	if ( ! empty( $args['logo'] ) ) {
		$logo = kerf_links_find_logo( $blocks );
		if ( $logo && $logo['rebind'] ) {
			$state['logo_path'] = $logo['path'];
		}
		// The owner's call (2026-10-17): a logo picture with no link round it
		// gets one, to the home page — the one element Kerf adds to a design.
		if ( $logo && ! $logo['linked'] ) {
			$blocks              = kerf_links_wrap_logo( $blocks, $logo['path'] );
			$state['logo_added'] = true;
			$state['bound']++;
		}
	}

	$blocks = kerf_links_walk( $blocks, $state, $create );
	unset( $state['logo_path'] );

	return array( 'markup' => serialize_blocks( $blocks ) ) + $state;
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE LOGO
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The site header's logo in a parsed block tree, and whether it should be
 * bound to the home page — or null when the header has no logo Kerf can tell.
 *
 * A visitor clicks the logo to go home, from every page. Designs link it to
 * `#`, `#top` or `#home` (24 of the 40 designs on the owner's machine), which
 * on every page but the home page goes nowhere, or to the business's old site
 * (`https://www.dreamtimedentistry.com/`), which takes visitors off this one
 * (scar 135). The logo is, in order: the first link named one — a class token
 * `logo`, `brand`, `wordmark`, `site-title` (`site-logo`, `navbar-brand`,
 * `brand__link`…, never a utility like Tailwind's `text-brand-gold`), an
 * `aria-label` or title saying home, or a picture inside it named logo by its
 * class, alt text or file name; else the header's very first link, when it is
 * outside the menu (no `<nav>`, list or menu round it), not a button or a skip
 * link, holds a picture or a short name, and points at `#`, a spot on the page
 * or the home page already.
 *
 * Bound unless it leads to one of the site's pages already, is a phone, email
 * or script link, or someone chose where it goes (kerf_links_is_settled()). A
 * logo found only by its place is bound only from `#`, a spot or nothing. A
 * named logo picture with no link round it (`linked` false) is given one,
 * to the home page (kerf_links_wrap_logo()) — the owner's call: the one
 * element Kerf adds to a design.
 *
 * @param array $blocks Parsed blocks of the header region.
 * @return array{path:int[],href:string,linked:bool,rebind:bool}|null
 */
function kerf_links_find_logo( $blocks ) {
	$found = array( 'anchors' => array(), 'pictures' => array() );
	kerf_links_collect_anchors( $blocks, array(), array(), false, $found );

	foreach ( $found['anchors'] as $anchor ) {
		if ( $anchor['named'] ) {
			return array( 'path' => $anchor['path'], 'href' => $anchor['href'], 'linked' => true, 'rebind' => kerf_links_logo_rebinds( $anchor, true ) );
		}
	}
	// A logo picture with no link, before any guess by place: claude's header
	// opens with a phone link holding an icon, and taken for the logo by its
	// place it hid the real logo after it.
	if ( $found['pictures'] ) {
		return array( 'path' => $found['pictures'][0], 'href' => '', 'linked' => false, 'rebind' => false );
	}
	foreach ( $found['anchors'] as $anchor ) {
		if ( $anchor['skip'] ) {
			continue;
		}
		// Only the header's first link stands in for an unnamed logo, and only
		// when it would be bound.
		if ( ! $anchor['in_menu'] && ! $anchor['button'] && ( $anchor['picture'] || ( '' !== $anchor['text'] && mb_strlen( $anchor['text'] ) <= 40 ) )
			&& kerf_links_logo_rebinds( $anchor, false ) ) {
			return array( 'path' => $anchor['path'], 'href' => $anchor['href'], 'linked' => true, 'rebind' => true );
		}
		break;
	}
	return null;
}

/**
 * Put a link to the home page round the logo picture at this path — an
 * Element `<a>`, bound home, holding the picture as it was (scar 135). The
 * section it is in stays as it was for Update design: when nobody had edited
 * it (its hash still what was written, §5.28), its record is made again, as
 * the walk does for a link it binds (scar 74).
 *
 * @param array $blocks Parsed blocks.
 * @param int[] $path   The picture's path.
 * @return array
 */
function kerf_links_wrap_logo( $blocks, $path ) {
	$top   = $path[0];
	$out   = isset( $blocks[ $top ]['attrs']['kerfSource']['out'] ) ? (string) $blocks[ $top ]['attrs']['kerfSource']['out'] : '';
	$clean = '' !== $out && function_exists( 'kerf_sync_block_hash' ) && kerf_sync_block_hash( $blocks[ $top ] ) === $out;

	$wrap = static function ( $level, $rest ) use ( &$wrap ) {
		$at = array_shift( $rest );
		if ( ! isset( $level[ $at ] ) ) {
			return $level;
		}
		if ( $rest ) {
			$level[ $at ]['innerBlocks'] = $wrap( $level[ $at ]['innerBlocks'], $rest );
			return $level;
		}
		$picture = $level[ $at ];
		$attrs   = array(
			'tagName'          => 'a',
			'customAttributes' => array( 'href' => '/' ),
			'linkType'         => 'home',
			'linkId'           => 0,
			'metadata'         => array( 'name' => __( 'Logo link', 'kerf-blocks' ) ),
		);
		// A section's stamp belongs to what stands at the region's top.
		if ( isset( $picture['attrs']['kerfSource'] ) ) {
			$attrs['kerfSource'] = $picture['attrs']['kerfSource'];
			unset( $picture['attrs']['kerfSource'] );
		}
		$level[ $at ] = array(
			'blockName'    => 'kerf/div',
			'attrs'        => $attrs,
			'innerBlocks'  => array( $picture ),
			'innerHTML'    => '',
			'innerContent' => array( null ),
		);
		return $level;
	};
	$blocks = $wrap( $blocks, $path );

	if ( $clean ) {
		$blocks[ $top ]['attrs']['kerfSource']['out'] = kerf_sync_block_hash( $blocks[ $top ] );
	}
	return $blocks;
}

/**
 * Every link in a block tree, in document order, with what tells a logo —
 * and the pictures named logo that no link holds.
 *
 * @param array $blocks    Parsed blocks.
 * @param int[] $at        This level's path.
 * @param array $ancestors Tags of the elements round it.
 * @param bool  $in_anchor Inside a link already.
 * @param array $found     { anchors, pictures }, by reference.
 */
function kerf_links_collect_anchors( $blocks, $at, $ancestors, $in_anchor, &$found ) {
	foreach ( $blocks as $index => $block ) {
		$name  = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$here  = array_merge( $at, array( $index ) );
		$tag   = 'kerf/div' === $name ? strtolower( isset( $attrs['tagName'] ) ? (string) $attrs['tagName'] : 'div' ) : '';
		$link  = ! $in_anchor && ( 'kerf/link' === $name || 'a' === $tag || ( 'kerf/image' === $name && ! empty( $attrs['linkUrl'] ) ) );

		if ( $link ) {
			$href = (string) ( isset( $attrs['url'] ) ? $attrs['url'] : ( isset( $attrs['customAttributes']['href'] ) ? $attrs['customAttributes']['href'] : ( isset( $attrs['linkUrl'] ) ? $attrs['linkUrl'] : '' ) ) );
			$text = trim( wp_strip_all_tags( kerf_links_block_text( $block ) ) );
			$own  = kerf_links_names_of( $attrs );
			$pictures = 'kerf/image' === $name ? array( $attrs ) : kerf_links_pictures_in( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array() );
			$named = kerf_links_names_logo( $own['names'] ) || (bool) preg_match( '/\bhome(?:\s?page)?\b/i', $own['label'] );
			foreach ( $pictures as $picture ) {
				$named = $named || kerf_links_picture_names_logo( $picture );
			}
			$found['anchors'][] = array(
				'path'    => $here,
				'href'    => $href,
				'attrs'   => $attrs,
				'named'   => $named,
				'text'    => $text,
				'picture' => (bool) $pictures || (bool) kerf_links_has_block( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array(), array( 'kerf/svg', 'kerf/icon' ) ),
				'in_menu' => (bool) array_intersect( $ancestors, array( 'nav', 'ul', 'ol', 'li', 'menu' ) ),
				'button'  => (bool) preg_match( '/(?:^|[\s_-])(?:btn|button|cta)(?:$|[\s_-])/i', $own['names'] ),
				'skip'    => (bool) preg_match( '/(?:^|[\s_-])skip(?:$|[\s_-])/i', $own['names'] ) || 0 === stripos( $text, 'skip to' ),
			);
		} elseif ( ! $in_anchor && ( 'kerf/image' === $name || 'kerf/svg' === $name ) && kerf_links_picture_names_logo( $attrs )
			&& ! array_intersect( $ancestors, array( 'button', 'label', 'summary' ) ) ) {
			// A logo picture with no link round it; one inside a control is
			// that control's.
			$found['pictures'][] = $here;
		}

		if ( ! empty( $block['innerBlocks'] ) ) {
			kerf_links_collect_anchors( $block['innerBlocks'], $here, '' !== $tag ? array_merge( $ancestors, array( $tag ) ) : $ancestors, $in_anchor || $link, $found );
		}
	}
}

/**
 * A block's class names and id, and its accessible label.
 *
 * @param array $attrs Block attributes.
 * @return array{names:string,label:string}
 */
function kerf_links_names_of( $attrs ) {
	$custom = isset( $attrs['customAttributes'] ) && is_array( $attrs['customAttributes'] ) ? $attrs['customAttributes'] : array();
	return array(
		'names' => trim( ( isset( $attrs['className'] ) ? $attrs['className'] : '' ) . ' ' . ( isset( $attrs['anchor'] ) ? $attrs['anchor'] : '' ) . ' ' . ( isset( $custom['id'] ) ? $custom['id'] : '' ) . ' ' . ( isset( $custom['class'] ) ? $custom['class'] : '' ) ),
		'label' => trim( ( isset( $custom['aria-label'] ) ? $custom['aria-label'] : '' ) . ' ' . ( isset( $custom['title'] ) ? $custom['title'] : '' ) . ' ' . ( isset( $attrs['ariaLabel'] ) ? $attrs['ariaLabel'] : '' ) ),
	);
}

/**
 * Does a class name or id say "logo"? Whole words of a token — `logo`,
 * `site-logo`, `brand__link`, `navbar-brand`, `wordmark`, `site-title` —
 * never a utility class that only colours something with the brand's colour
 * (`text-brand-gold`, `hover:bg-brand`): those were icons in a phone link.
 *
 * @param string $names Space-separated class names and ids.
 * @return bool
 */
function kerf_links_names_logo( $names ) {
	foreach ( preg_split( '/\s+/', trim( (string) $names ) ) as $token ) {
		if ( '' === $token || false !== strpos( $token, ':' )
			|| preg_match( '/^(?:text|bg|border|fill|stroke|from|via|to|ring|shadow|decoration|accent|caret|outline|divide|placeholder|underline|font)-/i', $token ) ) {
			continue;
		}
		if ( 'mark' === strtolower( $token ) || preg_match( '/(?:^|[-_])(?:logo|brand|wordmark|site-?title|site-?name)(?:$|[-_])/i', $token ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Is a picture named logo — by its class, its alt text or its file's name?
 *
 * @param array $attrs kerf/image or kerf/svg attributes.
 * @return bool
 */
function kerf_links_picture_names_logo( $attrs ) {
	$own = kerf_links_names_of( $attrs );
	$src = isset( $attrs['src'] ) ? basename( (string) wp_parse_url( (string) $attrs['src'], PHP_URL_PATH ) ) : '';
	return kerf_links_names_logo( $own['names'] )
		|| (bool) preg_match( '/\blogo\b/i', ( isset( $attrs['alt'] ) ? (string) $attrs['alt'] : '' ) . ' ' . $own['label'] )
		|| (bool) preg_match( '/logo/i', $src );
}

/**
 * The kerf/image blocks inside a tree (a link's pictures).
 *
 * @param array $blocks Parsed blocks.
 * @return array[] Their attributes.
 */
function kerf_links_pictures_in( $blocks ) {
	$pictures = array();
	foreach ( $blocks as $block ) {
		if ( isset( $block['blockName'] ) && 'kerf/image' === $block['blockName'] ) {
			$pictures[] = isset( $block['attrs'] ) ? (array) $block['attrs'] : array();
		}
		if ( ! empty( $block['innerBlocks'] ) ) {
			$pictures = array_merge( $pictures, kerf_links_pictures_in( $block['innerBlocks'] ) );
		}
	}
	return $pictures;
}

/**
 * Is a block of one of these types anywhere in a tree?
 *
 * @param array    $blocks Parsed blocks.
 * @param string[] $names  Block names.
 * @return bool
 */
function kerf_links_has_block( $blocks, $names ) {
	foreach ( $blocks as $block ) {
		if ( isset( $block['blockName'] ) && in_array( $block['blockName'], $names, true ) ) {
			return true;
		}
		if ( ! empty( $block['innerBlocks'] ) && kerf_links_has_block( $block['innerBlocks'], $names ) ) {
			return true;
		}
	}
	return false;
}

/**
 * The words a block and what is inside it show, as plain text.
 *
 * @param array $block A parsed block.
 * @return string
 */
function kerf_links_block_text( $block ) {
	$text = isset( $block['attrs']['text'] ) ? (string) $block['attrs']['text'] : '';
	if ( '' === $text && ! empty( $block['innerHTML'] ) && empty( $block['innerBlocks'] ) ) {
		$text = (string) $block['innerHTML'];
	}
	foreach ( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array() as $inner ) {
		$text .= ' ' . kerf_links_block_text( $inner );
	}
	return trim( preg_replace( '/\s+/', ' ', $text ) );
}

/**
 * A link block's address as the design wrote it: kerf/link's `url`, an
 * anchor's `customAttributes.href`, a linked picture's `linkUrl`.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_links_logo_href( $attrs ) {
	if ( ! empty( $attrs['url'] ) ) {
		return (string) $attrs['url'];
	}
	if ( ! empty( $attrs['customAttributes']['href'] ) ) {
		return (string) $attrs['customAttributes']['href'];
	}
	return ! empty( $attrs['linkUrl'] ) ? (string) $attrs['linkUrl'] : '';
}

/**
 * Should the logo found go to the home page?
 *
 * @param array $anchor From kerf_links_collect_anchors().
 * @param bool  $named  Found by its name (else only by its place).
 * @return bool
 */
function kerf_links_logo_rebinds( $anchor, $named ) {
	if ( kerf_links_is_settled( $anchor['attrs'] ) || kerf_links_is_live( $anchor['attrs'] ) ) {
		return false;
	}
	$href = trim( (string) $anchor['href'] );
	if ( '' === $href || '#' === $href[0] ) {
		return true;
	}
	if ( preg_match( '#^(?:mailto|tel|sms|callto|javascript|data):#i', $href ) ) {
		return false;
	}
	$path = kerf_links_normalize( $href );
	if ( 'home' === $path ) {
		return true;
	}
	if ( ! $named ) {
		return false;
	}
	if ( null === $path ) {
		// Another site — the business's old one — but not a file of this one.
		return (bool) preg_match( '#^(?:https?:)?//#i', $href );
	}
	return ! kerf_links_find_post( $path ) && ! isset( kerf_links_chosen()[ $path ] );
}

/**
 * Recursively bind links in a parsed block tree.
 *
 * @param array $blocks  Parsed blocks.
 * @param array $state   Counters, by reference; `logo_path` the header's logo.
 * @param bool  $create  Whether to create missing pages.
 * @param bool  $in_loop Inside a kerf/loop.
 * @param int[] $at      This level's path from the top.
 * @return array
 */
function kerf_links_walk( $blocks, &$state, $create, $in_loop = false, $at = array() ) {
	foreach ( $blocks as $index => $block ) {
		$name = isset( $block['blockName'] ) ? $block['blockName'] : '';
		$here = array_merge( $at, array( $index ) );

		// A section nobody has edited (its hash still matches what was written,
		// §5.28) stays that way: binding is the tool's doing, not an edit. A
		// re-scan used to leave every section it bound a link in flagged
		// "edited in WordPress", unticked under Update from mockup.
		$out   = isset( $block['attrs']['kerfSource']['out'] ) ? (string) $block['attrs']['kerfSource']['out'] : '';
		$clean = '' !== $out && function_exists( 'kerf_sync_block_hash' ) && kerf_sync_block_hash( $block ) === $out;

		// A card's links go to its post or tag (§5.30): never looked up, never
		// a link going nowhere — the sample cards' `blog-post.html` was.
		if ( ! $in_loop && isset( $state['logo_path'] ) && $here === $state['logo_path'] ) {
			// The header's logo: the home page, from every page (scar 135).
			$state['logo'] = kerf_links_logo_href( isset( $block['attrs'] ) ? $block['attrs'] : array() );
			$blocks[ $index ]['attrs']['linkType'] = 'home';
			$blocks[ $index ]['attrs']['linkId']   = 0;
			$state['bound']++;
		} elseif ( ! $in_loop && in_array( $name, kerf_links_bindable_blocks(), true ) ) {
			$blocks[ $index ]['attrs'] = kerf_links_bind_attrs(
				isset( $block['attrs'] ) ? $block['attrs'] : array(),
				$state,
				$create
			);
		}

		// A link inside a heading's or paragraph's words, bound where it stands.
		if ( ! $in_loop && kerf_links_is_rich_text( $name ) && ! empty( $block['innerHTML'] ) && false !== stripos( $block['innerHTML'], '<a' ) ) {
			$html = kerf_links_bind_rich_text( $block['innerHTML'], $state, $create );
			if ( $html !== $block['innerHTML'] ) {
				$blocks[ $index ]['innerHTML']    = $html;
				$blocks[ $index ]['innerContent'] = array( $html );
			}
		}

		if ( ! empty( $block['innerBlocks'] ) ) {
			$blocks[ $index ]['innerBlocks'] = kerf_links_walk( $block['innerBlocks'], $state, $create, $in_loop || 'kerf/loop' === $name, $here );
		}

		if ( $clean ) {
			$blocks[ $index ]['attrs']['kerfSource']['out'] = kerf_sync_block_hash( $blocks[ $index ] );
		}
	}

	return $blocks;
}

/**
 * Does this link already have a destination a re-scan must leave alone?
 *
 * A destination chosen in the editor — the URL as written (`url`), a page, a
 * file — is the owner's decision. The re-scan used to look every link up again
 * from its href, so a link pointed at "Our team" went back to the page its
 * mockup href named, and "use the URL as written" was bound all over again.
 * Only an unbound link, or one whose page or file is gone, is looked up again.
 *
 * @param array $attrs Block attributes.
 * @return bool
 */
function kerf_links_is_settled( $attrs ) {
	$type = isset( $attrs['linkType'] ) ? (string) $attrs['linkType'] : '';
	$id   = isset( $attrs['linkId'] ) ? (int) $attrs['linkId'] : 0;

	if ( 'url' === $type || 'home' === $type ) {
		return true;
	}
	if ( 'post' === $type && $id ) {
		$status = get_post_status( $id );
		return $status && 'trash' !== $status;
	}
	if ( 'media' === $type && $id ) {
		return 'attachment' === get_post_type( $id );
	}

	return false;
}

/**
 * Does WordPress fill this link in as the page renders — a post's own page,
 * the previous or next post, a tag's page (§5.25, §5.30)?
 *
 * Its href is the design's sample (`blog-post.html`, `#`): looking it up
 * found nothing, and every sample card was reported as a link going nowhere.
 *
 * @param array $attrs Block attributes.
 * @return bool
 */
function kerf_links_is_live( $attrs ) {
	if ( ! empty( $attrs['metadata']['bindings']['url'] ) || ! empty( $attrs['kerfSite'] ) ) {
		return true;
	}
	return function_exists( 'kerf_block_fields' )
		&& (bool) array_intersect( kerf_block_fields( $attrs ), array( 'permalink', 'title', 'prev', 'next', 'term-link' ) );
}

/**
 * What a live link goes to, said plainly.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_links_live_label( $attrs ) {
	$key    = isset( $attrs['metadata']['bindings']['url']['args']['key'] ) ? (string) $attrs['metadata']['bindings']['url']['args']['key'] : '';
	$source = isset( $attrs['metadata']['bindings']['url']['source'] ) ? (string) $attrs['metadata']['bindings']['url']['source'] : '';
	$fields = function_exists( 'kerf_block_fields' ) ? kerf_block_fields( $attrs ) : array();

	// The business's phone, email or profile, changed once (§5.36): bound,
	// or an icon link that takes the detail's address (kerf_site_apply()).
	if ( ! empty( $attrs['kerfSite'] ) ) {
		$key    = (string) $attrs['kerfSite'];
		$source = 'kerf/site';
	}
	if ( 'kerf/site' === $source ) {
		/* translators: %s: a detail, e.g. "Phone". */
		return sprintf( __( 'Site details: %s', 'kerf-blocks' ), function_exists( 'kerf_site_label' ) ? kerf_site_label( $key ) : $key );
	}
	if ( 'prev-url' === $key || in_array( 'prev', $fields, true ) ) {
		return __( 'The previous post', 'kerf-blocks' );
	}
	if ( 'next-url' === $key || in_array( 'next', $fields, true ) ) {
		return __( 'The next post', 'kerf-blocks' );
	}
	if ( 'kerf/term' === $source || in_array( 'term-link', $fields, true ) ) {
		return __( 'Each tag\'s or category\'s page', 'kerf-blocks' );
	}
	return __( 'Each post\'s own page', 'kerf-blocks' );
}

/**
 * The media-library attachment an href is the file of, or 0.
 *
 * The converter resolves a link to one of the mockup's files — a lightbox's
 * full-size picture, a brochure — to the file's library URL. Bound to the
 * attachment, the sidebar shows it as the file it is (Link source: Media file)
 * and the link follows it. Only URLs under this site's uploads are looked up;
 * the staged copies there are not attachments and stay as they are.
 *
 * @param string $href
 * @return int
 */
function kerf_links_find_attachment( $href ) {
	// wp_upload_dir() caches per site, so this is cheap per link (and right on
	// a network, where each site has its own uploads).
	$uploads = wp_get_upload_dir();
	$base    = isset( $uploads['baseurl'] ) ? (string) preg_replace( '#^https?:#i', '', (string) $uploads['baseurl'] ) : '';
	$bare    = (string) preg_replace( '#^https?:#i', '', (string) $href );

	if ( '' === $base || 0 !== strpos( $bare, $base . '/' ) || ! preg_match( '/\.[a-z0-9]{2,5}$/i', $bare ) ) {
		return 0;
	}

	return (int) attachment_url_to_postid( $href );
}

/**
 * Bind one block's link attributes.
 *
 * @param array $attrs  Block attributes.
 * @param array $state  Counters, by reference.
 * @param bool  $create Whether to create missing pages.
 * @return array
 */
function kerf_links_bind_attrs( $attrs, &$state, $create ) {
	if ( kerf_links_is_settled( $attrs ) || kerf_links_is_live( $attrs ) ) {
		return $attrs;
	}

	// kerf/link stores its href in `url`; kerf/div (an anchor with children) in
	// customAttributes['href']; kerf/image in `linkUrl`.
	$href = '';
	if ( ! empty( $attrs['url'] ) ) {
		$href = (string) $attrs['url'];
	} elseif ( ! empty( $attrs['customAttributes']['href'] ) ) {
		$href = (string) $attrs['customAttributes']['href'];
	} elseif ( ! empty( $attrs['linkUrl'] ) ) {
		$href = (string) $attrs['linkUrl'];
	}

	if ( '' === $href ) {
		return $attrs;
	}

	// Not counted in `bound`: the report says that many links follow PAGES.
	$attachment = kerf_links_find_attachment( $href );
	if ( $attachment ) {
		$attrs['linkType'] = 'media';
		$attrs['linkId']   = $attachment;
		return $attrs;
	}

	$path = kerf_links_normalize( $href );
	if ( null === $path ) {
		return $attrs;
	}

	if ( 'home' === $path ) {
		$attrs['linkType'] = 'home';
		$attrs['linkId']   = 0;
		$state['bound']++;
		return $attrs;
	}

	// Where the owner said this address goes, on Kerf → Links: kept, so a
	// newer import or an update binds it the same way — unless this very
	// import made a page from the file the address names (kerf_links_known()).
	$chosen = kerf_links_chosen();
	$known  = kerf_links_known();
	if ( ! isset( $known[ $path ] ) && isset( $chosen[ $path ] ) ) {
		$to = (string) $chosen[ $path ];
		if ( 'url' === $to ) {
			$attrs['linkType'] = 'url';
			$attrs['linkId']   = 0;
			return $attrs;
		}
		if ( 'home' === $to ) {
			$attrs['linkType'] = 'home';
			$attrs['linkId']   = 0;
			$state['bound']++;
			return $attrs;
		}
		$id = 0 === strpos( $to, 'post:' ) ? (int) substr( $to, 5 ) : 0;
		if ( $id && get_post_status( $id ) && 'trash' !== get_post_status( $id ) ) {
			$attrs['linkType'] = 'post';
			$attrs['linkId']   = $id;
			$state['bound']++;
			return $attrs;
		}
	}

	$post_id = kerf_links_find_post( $path );

	if ( ! $post_id && $create ) {
		$post_id = kerf_links_create_page( $path );
		if ( $post_id ) {
			$state['created']++;
		}
	}

	if ( $post_id ) {
		$attrs['linkType'] = 'post';
		$attrs['linkId']   = $post_id;
		$state['bound']++;
		return $attrs;
	}

	// Left literal, and named. The href is kept exactly as the mockup wrote it.
	if ( ! isset( $state['unresolved'][ $href ] ) ) {
		$state['unresolved'][ $href ] = 0;
	}
	$state['unresolved'][ $href ]++;

	return $attrs;
}

// ═══════════════════════════════════════════════════════════════════════════════
// LINKS INSIDE A HEADING'S OR PARAGRAPH'S WORDS
// ═══════════════════════════════════════════════════════════════════════════════

/*
 * A heading or paragraph stays WordPress's own block, its words rich text
 * (§5.6), and a link written in them — `<p>Read <a href="about.html">our
 * story</a></p>`, a footer's `<a href="privacy.html">` — was kept as written:
 * on the site it led nowhere, and Kerf → Links never listed it (scar 126).
 * Making the paragraph separate blocks would bind it, at the price of every
 * sentence with a link becoming pieces to edit. So the link is bound where
 * it stands, as a link block is, and remembered on the anchor itself — rich
 * text keeps an attribute it does not know (checked on WordPress 7.1):
 *
 *   data-kerf-href  the address the design wrote, as a link block keeps it
 *   data-kerf-link  where it goes: `post:<id>`, `media:<id>`, `home`, or `url`
 *                   (the owner's "exactly as written")
 *   href            the address it goes to now, so the editor's link popover
 *                   shows the page; made again at render, so it follows the
 *                   page when its address changes
 *
 * Both markers are taken off the page as it renders (kerf_links_render_rich_text()):
 * the markup stays the design's, its link pointing where it should. A link
 * the owner sets in the editor's popover loses them and is the owner's —
 * WordPress's own `data-type`/`data-id` then say which page it is.
 */

/**
 * Is this a block whose words are rich text a link can sit in?
 *
 * @param string $name Block name.
 * @return bool
 */
function kerf_links_is_rich_text( $name ) {
	return in_array( $name, array( 'core/paragraph', 'core/heading' ), true );
}

/**
 * The links in rich text, in order: each one's attributes and its words.
 *
 * @param string $html A heading's or paragraph's HTML.
 * @return array[] { attrs: array<string,string>, text: string }.
 */
function kerf_links_rich_text_anchors( $html ) {
	$anchors = array();
	$open    = null;
	$p       = new WP_HTML_Tag_Processor( (string) $html );

	while ( $p->next_token() ) {
		$type = $p->get_token_type();
		if ( '#tag' === $type && 'A' === $p->get_tag() ) {
			if ( $p->is_tag_closer() ) {
				$open = null;
				continue;
			}
			$attrs = array();
			foreach ( (array) $p->get_attribute_names_with_prefix( '' ) as $name ) {
				$value = $p->get_attribute( $name );
				$attrs[ $name ] = true === $value ? '' : (string) $value;
			}
			$anchors[] = array( 'attrs' => $attrs, 'text' => '' );
			$open      = count( $anchors ) - 1;
		} elseif ( '#text' === $type && null !== $open ) {
			$anchors[ $open ]['text'] .= $p->get_modifiable_text();
		}
	}

	return $anchors;
}

/**
 * An anchor in rich text as the link attributes binding and the Links screen
 * read on a link block: `url`, `linkType`, `linkId`, and what makes it live.
 *
 * @param array<string,string> $a The anchor's attributes.
 * @return array
 */
function kerf_links_inline_attrs( $a ) {
	$attrs = array( 'url' => isset( $a['data-kerf-href'] ) ? (string) $a['data-kerf-href'] : ( isset( $a['href'] ) ? (string) $a['href'] : '' ) );
	$link  = isset( $a['data-kerf-link'] ) ? (string) $a['data-kerf-link'] : '';

	if ( preg_match( '/^(post|media):(\d+)$/', $link, $m ) ) {
		$attrs['linkType'] = $m[1];
		$attrs['linkId']   = (int) $m[2];
	} elseif ( 'home' === $link || 'url' === $link ) {
		$attrs['linkType'] = $link;
		$attrs['linkId']   = 0;
	} elseif ( '' === $link && isset( $a['data-id'] ) && ctype_digit( (string) $a['data-id'] ) && (int) $a['data-id'] > 0 ) {
		// WordPress's own link to a post, chosen in the editor's link popover.
		$attrs['linkType'] = 'post';
		$attrs['linkId']   = (int) $a['data-id'];
	}

	// What WordPress fills in, as on a link block (kerf_links_is_live()).
	if ( isset( $a['data-kerf-field'] ) ) {
		$attrs['customAttributes'] = array( 'data-kerf-field' => (string) $a['data-kerf-field'] );
	}
	if ( isset( $a['data-kerf-site'] ) ) {
		$attrs['kerfSite'] = (string) $a['data-kerf-site'];
	}

	return $attrs;
}

/**
 * Write where an anchor in rich text goes: the markers and its address now.
 *
 * @param WP_HTML_Tag_Processor $p       At the anchor.
 * @param string                $written The address the design wrote.
 * @param array                 $attrs   `linkType`, `linkId`.
 */
function kerf_links_mark_anchor( $p, $written, $attrs ) {
	$type = isset( $attrs['linkType'] ) ? (string) $attrs['linkType'] : '';
	$id   = isset( $attrs['linkId'] ) ? (int) $attrs['linkId'] : 0;

	$p->set_attribute( 'data-kerf-href', $written );
	$p->set_attribute( 'data-kerf-link', in_array( $type, array( 'post', 'media' ), true ) ? $type . ':' . $id : $type );
	$p->set_attribute( 'href', kerf_resolve_link_url( $attrs, $written ) );
	// WordPress's own page link, from the popover, is replaced by this one.
	$p->remove_attribute( 'data-type' );
	$p->remove_attribute( 'data-id' );
}

/**
 * Bind every link in a heading's or paragraph's HTML that can be bound.
 *
 * @param string $html   The block's HTML.
 * @param array  $state  Counters, by reference (kerf_links_bind()).
 * @param bool   $create Whether to create missing pages.
 * @return string
 */
function kerf_links_bind_rich_text( $html, &$state, $create ) {
	$p = new WP_HTML_Tag_Processor( (string) $html );

	while ( $p->next_tag( 'a' ) ) {
		$a = array();
		foreach ( (array) $p->get_attribute_names_with_prefix( '' ) as $name ) {
			$value      = $p->get_attribute( $name );
			$a[ $name ] = true === $value ? '' : (string) $value;
		}
		if ( ! isset( $a['href'] ) && ! isset( $a['data-kerf-href'] ) ) {
			continue;
		}

		$attrs = kerf_links_inline_attrs( $a );
		if ( kerf_links_is_settled( $attrs ) || kerf_links_is_live( $attrs ) ) {
			continue;
		}

		// Looked up as a link block's href is; one that finds nothing is
		// counted in $state and left as written.
		$bound = kerf_links_bind_attrs( $attrs, $state, $create );
		if ( ! empty( $bound['linkType'] ) ) {
			kerf_links_mark_anchor( $p, $attrs['url'], $bound );
		}
	}

	return $p->get_updated_html();
}

/**
 * Point the n-th link in rich text where the owner chose (Kerf → Links).
 *
 * @param string $html    The block's HTML.
 * @param int    $nth     Which link, counting every `<a>`.
 * @param string $written The address the design wrote.
 * @param array  $set     `linkType`, `linkId`.
 * @return string
 */
function kerf_links_set_rich_text_anchor( $html, $nth, $written, $set ) {
	$p = new WP_HTML_Tag_Processor( $html );
	for ( $n = 0; $p->next_tag( 'a' ); $n++ ) {
		if ( $n === $nth ) {
			kerf_links_mark_anchor( $p, $written, $set );
			break;
		}
	}
	return $p->get_updated_html();
}

/**
 * On the page: each bound link in rich text at its address now, and the
 * markers taken off — the markup is the design's.
 *
 * @param string $content Rendered block.
 * @param array  $block   Parsed block.
 * @return string
 */
function kerf_links_render_rich_text( $content, $block ) {
	if ( false === strpos( (string) $content, 'data-kerf-' ) || ! kerf_links_is_rich_text( isset( $block['blockName'] ) ? (string) $block['blockName'] : '' ) ) {
		return $content;
	}

	$p = new WP_HTML_Tag_Processor( (string) $content );
	while ( $p->next_tag( 'a' ) ) {
		$link = $p->get_attribute( 'data-kerf-link' );
		if ( is_string( $link ) && '' !== $link ) {
			$href  = (string) $p->get_attribute( 'href' );
			$attrs = kerf_links_inline_attrs( array( 'data-kerf-link' => $link, 'href' => $href ) );
			$p->set_attribute( 'href', kerf_resolve_link_url( $attrs, $href ) );
		}
		$p->remove_attribute( 'data-kerf-link' );
		$p->remove_attribute( 'data-kerf-href' );
	}

	return $p->get_updated_html();
}
add_filter( 'render_block', 'kerf_links_render_rich_text', 10, 2 );

/**
 * Create a draft page for an unmatched link.
 *
 * Draft, not published: the import has no content for these pages, and a site
 * full of empty published pages is worse than a site with a few broken links —
 * search engines index them and visitors land on nothing. A draft holds the slug
 * so the binding is stable, and shows up in the editor's page list waiting to be
 * filled in.
 *
 * @param string $path Normalized path.
 * @return int Post ID, or 0.
 */
function kerf_links_create_page( $path ) {
	$segments = explode( '/', $path );
	$slug     = sanitize_title( end( $segments ) );

	if ( '' === $slug ) {
		return 0;
	}

	$title = ucwords( str_replace( array( '-', '_' ), ' ', $slug ) );

	$post_id = wp_insert_post( array(
		'post_type'    => 'page',
		'post_status'  => 'draft',
		'post_title'   => $title,
		'post_name'    => $slug,
		'post_content' => '',
	), true );

	if ( is_wp_error( $post_id ) ) {
		return 0;
	}

	update_post_meta( $post_id, '_kerf_created_by_import', 1 );

	return (int) $post_id;
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE REPORT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Store the unresolved-link report.
 *
 * @param array<string,int> $unresolved href => occurrence count.
 */
function kerf_links_save_report( $unresolved ) {
	update_option( KERF_LINKS_OPTION, (array) $unresolved, false );
}

/**
 * The stored unresolved-link report.
 *
 * @return array<string,int>
 */
function kerf_links_get_report() {
	$report = get_option( KERF_LINKS_OPTION, array() );
	return is_array( $report ) ? $report : array();
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHERE THE OWNER SAID A LINK GOES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Addresses the owner pointed somewhere on Kerf → Links: normalized path →
 * 'post:<id>', 'home' or 'url' (exactly as written).
 */
const KERF_LINKS_CHOSEN_OPTION = 'kerf_links_chosen';

/**
 * Where the owner said each address goes.
 *
 * Kept, not just applied: binding consults it first (kerf_links_bind_attrs()),
 * so a newer import, an update or a re-scan binds `services.html` to the page
 * the owner chose — and the section it is in stays one the update may replace.
 * The old way gave the chosen page the mockup's slug, and the page's address
 * changed under it.
 *
 * @return array<string,string>
 */
function kerf_links_chosen() {
	$chosen = get_option( KERF_LINKS_CHOSEN_OPTION, array() );
	return is_array( $chosen ) ? $chosen : array();
}

// ═══════════════════════════════════════════════════════════════════════════════
// EVERY LINK, BY WHERE IT IS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The links going nowhere now, as the report keeps them: href => uses.
 *
 * @param array[]|null $places From kerf_links_places(), if already read.
 * @return array<string,int>
 */
function kerf_links_unresolved_now( $places = null ) {
	$unresolved = array();
	foreach ( null === $places ? kerf_links_places() : $places as $place ) {
		foreach ( $place['links'] as $link ) {
			if ( in_array( $link['state'], array( 'nowhere', 'gone' ), true ) ) {
				$unresolved[ $link['href'] ] = ( isset( $unresolved[ $link['href'] ] ) ? $unresolved[ $link['href'] ] : 0 ) + 1;
			}
		}
	}
	return $unresolved;
}

/**
 * Count the links going nowhere again, once, where a count was kept by an
 * older Kerf: it counted a post card's sample link (`blog-post.html`, which
 * WordPress fills in with each post's address) as going nowhere, and the menu
 * and the Dashboard said so until the next import.
 */
function kerf_links_refresh_report() {
	if ( 2 <= (int) get_option( 'kerf_links_report_version', 0 ) || ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	if ( kerf_links_get_report() ) {
		kerf_links_save_report( kerf_links_unresolved_now() );
	}
	update_option( 'kerf_links_report_version', 2, false );
}
add_action( 'admin_init', 'kerf_links_refresh_report' );

/**
 * Every place the design's links are: the header, around every page, the
 * footer, then the pages made from it — the home page first — then its
 * templates. Only places with links.
 *
 * @return array[] { id, kind, label, note, icon, edit, links }.
 */
function kerf_links_places() {
	$places = array();
	$parts  = array(
		'header'     => array( __( 'Header', 'kerf-blocks' ), __( 'On every page', 'kerf-blocks' ), 'header' ),
		'page-start' => array( __( 'Above every page', 'kerf-blocks' ), __( 'Around the header, on every page', 'kerf-blocks' ), 'header' ),
		'page-end'   => array( __( 'Below every page', 'kerf-blocks' ), __( 'Around the footer, on every page', 'kerf-blocks' ), 'footer' ),
		'footer'     => array( __( 'Footer', 'kerf-blocks' ), __( 'On every page', 'kerf-blocks' ), 'footer' ),
	);

	foreach ( $parts as $slug => $meta ) {
		$part = get_block_template( get_stylesheet() . '//' . $slug, 'wp_template_part' );
		if ( ! $part || empty( $part->wp_id ) ) {
			continue;
		}
		$places[ 'part:' . $slug ] = array(
			'id'    => (int) $part->wp_id,
			'kind'  => 'part',
			'label' => $meta[0],
			'note'  => $meta[1],
			'icon'  => $meta[2],
			'edit'  => admin_url( 'site-editor.php?p=' . rawurlencode( '/wp_template_part/' . get_stylesheet() . '//' . $slug ) . '&canvas=edit' ),
		);
	}

	// The pages made from the design: Kerf blocks in their content.
	$home  = (int) get_option( 'kerf_mockup_page' );
	$front = 'page' === get_option( 'show_on_front' ) ? (int) get_option( 'page_on_front' ) : 0;
	$pages = get_posts( array(
		'post_type'      => 'page',
		'post_status'    => array( 'publish', 'draft', 'private', 'pending', 'future' ),
		'posts_per_page' => 500,
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	usort( $pages, static function ( $a, $b ) use ( $home, $front ) {
		$rank = static function ( $page ) use ( $home, $front ) {
			return (int) $page->ID === $front ? 0 : ( (int) $page->ID === $home ? 1 : 2 );
		};
		return $rank( $a ) <=> $rank( $b );
	} );
	foreach ( $pages as $page ) {
		if ( false === strpos( $page->post_content, '<!-- wp:kerf/' ) ) {
			continue;
		}
		$is_front                   = (int) $page->ID === $front;
		$places[ 'page:' . $page->ID ] = array(
			'id'    => (int) $page->ID,
			'kind'  => 'page',
			'label' => '' !== $page->post_title ? $page->post_title : __( '(no title)', 'kerf-blocks' ),
			'note'  => $is_front ? __( 'The home page', 'kerf-blocks' ) : ( 'publish' === $page->post_status ? __( 'A page', 'kerf-blocks' ) : __( 'A page, not published', 'kerf-blocks' ) ),
			'icon'  => $is_front ? 'home' : 'page',
			'edit'  => (string) get_edit_post_link( $page->ID, 'raw' ),
		);
	}

	// The designer's own blog, post, search and 404 (Kerf Pro imports them).
	$templates = get_posts( array(
		'post_type'      => 'wp_template',
		'post_status'    => array( 'publish' ),
		'posts_per_page' => 100,
		'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a handful of templates, on an admin screen.
			array( 'taxonomy' => 'wp_theme', 'field' => 'name', 'terms' => get_stylesheet() ),
		),
	) );
	foreach ( $templates as $template ) {
		if ( false === strpos( $template->post_content, '<!-- wp:kerf/' ) ) {
			continue;
		}
		$places[ 'template:' . $template->ID ] = array(
			'id'    => (int) $template->ID,
			'kind'  => 'template',
			'label' => '' !== $template->post_title ? $template->post_title : $template->post_name,
			'note'  => __( 'Your design for one of WordPress\'s own pages', 'kerf-blocks' ),
			'icon'  => 'template',
			'edit'  => admin_url( 'site-editor.php?p=' . rawurlencode( '/wp_template/' . get_stylesheet() . '//' . $template->post_name ) . '&canvas=edit' ),
		);
	}

	foreach ( $places as $key => $place ) {
		$post                    = get_post( $place['id'] );
		$places[ $key ]['links'] = $post ? kerf_links_collect( parse_blocks( $post->post_content ) ) : array();
		if ( ! $places[ $key ]['links'] ) {
			unset( $places[ $key ] );
		}
	}

	return $places;
}

/**
 * The links in a block tree, each with where it is (its path of indexes),
 * what it says, what it was written as, and where it goes now.
 *
 * @param array $blocks  Parsed blocks.
 * @param array $path    Internal: the indexes so far.
 * @param bool  $in_loop Internal: inside a card WordPress repeats per post.
 * @return array[] { at, text, href, state, to, choice, path }.
 */
function kerf_links_collect( $blocks, $path = array(), $in_loop = false ) {
	$links = array();
	foreach ( $blocks as $index => $block ) {
		$name  = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
		$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
		$here  = array_merge( $path, array( (int) $index ) );
		$href  = kerf_links_href( $name, $attrs );

		if ( null !== $href ) {
			$links[] = array(
				'at'   => implode( '.', $here ),
				'text' => kerf_links_text( $block ),
				'href' => $href,
			) + ( $in_loop || kerf_links_is_live( $attrs )
				? array( 'state' => 'live', 'to' => kerf_links_live_label( $attrs ), 'choice' => '', 'path' => null )
				: kerf_links_destination( $attrs, $href ) );
		}

		// The links in a heading's or paragraph's words: `<path>~<n>`, the
		// block, then which of its links.
		if ( kerf_links_is_rich_text( $name ) && ! empty( $block['innerHTML'] ) && false !== stripos( $block['innerHTML'], '<a' ) ) {
			foreach ( kerf_links_rich_text_anchors( $block['innerHTML'] ) as $n => $anchor ) {
				$inline = kerf_links_inline_attrs( $anchor['attrs'] );
				if ( ! isset( $anchor['attrs']['href'] ) && ! isset( $anchor['attrs']['data-kerf-href'] ) ) {
					continue;
				}
				$words   = trim( (string) preg_replace( '/\s+/u', ' ', html_entity_decode( $anchor['text'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
				$words   = '' === $words ? __( '(a link with no words)', 'kerf-blocks' ) : ( mb_strlen( $words ) > 70 ? rtrim( mb_substr( $words, 0, 68 ) ) . '…' : $words );
				$links[] = array(
					'at'   => implode( '.', $here ) . '~' . $n,
					'text' => $words,
					'href' => $inline['url'],
				) + ( $in_loop || kerf_links_is_live( $inline )
					? array( 'state' => 'live', 'to' => kerf_links_live_label( $inline ), 'choice' => '', 'path' => null )
					: kerf_links_destination( $inline, $inline['url'] ) );
			}
		}
		if ( ! empty( $block['innerBlocks'] ) ) {
			$links = array_merge( $links, kerf_links_collect( $block['innerBlocks'], $here, $in_loop || 'kerf/loop' === $name ) );
		}
	}
	return $links;
}

/**
 * A block's href, if it is a link: kerf/link's `url`, an anchor element's
 * `href`, a linked picture's `linkUrl`. Null when it is not a link.
 *
 * @param string $name
 * @param array  $attrs
 * @return string|null
 */
function kerf_links_href( $name, $attrs ) {
	if ( 'kerf/link' === $name ) {
		return isset( $attrs['url'] ) ? (string) $attrs['url'] : '';
	}
	if ( 'kerf/div' === $name && isset( $attrs['tagName'] ) && 'a' === $attrs['tagName'] ) {
		return isset( $attrs['customAttributes']['href'] ) ? (string) $attrs['customAttributes']['href'] : '';
	}
	if ( 'kerf/image' === $name && ! empty( $attrs['linkUrl'] ) ) {
		return (string) $attrs['linkUrl'];
	}
	return null;
}

/**
 * What a link says, the way a visitor reads it: its words, a picture's
 * description, else its label.
 *
 * @param array $block
 * @return string
 */
function kerf_links_text( $block ) {
	$words = trim( (string) preg_replace( '/\s+/u', ' ', kerf_links_words( $block ) ) );
	if ( '' === $words ) {
		$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
		foreach ( array( 'aria-label', 'title' ) as $name ) {
			if ( ! empty( $attrs['customAttributes'][ $name ] ) ) {
				$words = (string) $attrs['customAttributes'][ $name ];
				break;
			}
		}
	}
	if ( '' === $words ) {
		return __( '(a link with no words)', 'kerf-blocks' );
	}
	return mb_strlen( $words ) > 70 ? rtrim( mb_substr( $words, 0, 68 ) ) . '…' : $words;
}

/**
 * The words in a block and everything inside it.
 *
 * @param array $block
 * @return string
 */
function kerf_links_words( $block ) {
	$name  = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
	$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();

	if ( 'kerf/image' === $name ) {
		/* translators: %s: a picture's description. */
		return ! empty( $attrs['alt'] ) ? ' ' . sprintf( __( 'Picture: %s', 'kerf-blocks' ), $attrs['alt'] ) . ' ' : ' ' . __( 'A picture', 'kerf-blocks' ) . ' ';
	}
	$words = '';
	if ( isset( $attrs['text'] ) && is_string( $attrs['text'] ) ) {
		$words .= ' ' . wp_strip_all_tags( $attrs['text'] );
	}
	if ( 0 === strpos( $name, 'core/' ) && ! empty( $block['innerHTML'] ) ) {
		$words .= ' ' . wp_strip_all_tags( $block['innerHTML'] );
	}
	foreach ( isset( $block['innerBlocks'] ) ? (array) $block['innerBlocks'] : array() as $inner ) {
		$words .= ' ' . kerf_links_words( $inner );
	}
	return html_entity_decode( $words, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
}

/**
 * Where a link goes now, said plainly, and the choice it stands at.
 *
 * @param array  $attrs
 * @param string $href
 * @return array{state:string,to:string,choice:string,path:?string}
 *         state: page, home, file, url, nowhere, gone, external, anchor, mail, phone, none.
 */
function kerf_links_destination( $attrs, $href ) {
	$type = isset( $attrs['linkType'] ) ? (string) $attrs['linkType'] : '';
	$id   = isset( $attrs['linkId'] ) ? (int) $attrs['linkId'] : 0;
	$path = kerf_links_normalize( $href );
	$out  = array( 'path' => $path );

	if ( 'home' === $type ) {
		return $out + array( 'state' => 'home', 'to' => __( 'The home page', 'kerf-blocks' ), 'choice' => 'home' );
	}
	if ( 'post' === $type && $id ) {
		$status = get_post_status( $id );
		if ( ! $status || 'trash' === $status ) {
			return $out + array( 'state' => 'gone', 'to' => __( 'A page that was deleted', 'kerf-blocks' ), 'choice' => '' );
		}
		$title = get_the_title( $id );
		$title = '' !== $title ? $title : __( '(no title)', 'kerf-blocks' );
		if ( 'publish' !== $status ) {
			/* translators: %s: page title. */
			$title = sprintf( __( '%s (not published)', 'kerf-blocks' ), $title );
		}
		return $out + array( 'state' => 'page', 'to' => $title, 'choice' => 'post:' . $id );
	}
	if ( 'media' === $type && $id ) {
		/* translators: %s: file name. */
		return $out + array( 'state' => 'file', 'to' => sprintf( __( 'The file %s', 'kerf-blocks' ), wp_basename( (string) get_attached_file( $id ) ) ), 'choice' => 'media:' . $id );
	}
	if ( 'url' === $type ) {
		return $out + array( 'state' => 'url', 'to' => __( 'Exactly as written', 'kerf-blocks' ), 'choice' => 'url' );
	}

	$href = trim( $href );
	if ( '' === $href || '#' === $href ) {
		return $out + array( 'state' => 'none', 'to' => __( 'Nowhere — it is written as #', 'kerf-blocks' ), 'choice' => '' );
	}
	if ( 0 === strpos( $href, '#' ) ) {
		return $out + array( 'state' => 'anchor', 'to' => __( 'A place on the same page', 'kerf-blocks' ), 'choice' => '' );
	}
	if ( preg_match( '#^mailto:#i', $href ) ) {
		return $out + array( 'state' => 'mail', 'to' => __( 'An email', 'kerf-blocks' ), 'choice' => '' );
	}
	if ( preg_match( '#^(?:tel|sms|callto):#i', $href ) ) {
		return $out + array( 'state' => 'phone', 'to' => __( 'A phone call', 'kerf-blocks' ), 'choice' => '' );
	}
	if ( null === $path ) {
		$host = wp_parse_url( $href, PHP_URL_HOST );
		/* translators: %s: a website's address. */
		return $out + array( 'state' => 'external', 'to' => $host ? sprintf( __( 'Another site: %s', 'kerf-blocks' ), $host ) : __( 'Exactly as written', 'kerf-blocks' ), 'choice' => '' );
	}
	return $out + array( 'state' => 'nowhere', 'to' => __( 'Nowhere yet', 'kerf-blocks' ), 'choice' => '' );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ADMIN SCREEN
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Add the Links screen under the Kerf menu.
 */
function kerf_links_menu() {
	$count = count( kerf_links_get_report() );

	add_submenu_page(
		'kerf',
		__( 'Links', 'kerf-blocks' ),
		$count
			/* translators: %s: a count badge of links with no destination. */
			? sprintf( __( 'Links %s', 'kerf-blocks' ), '<span class="update-plugins count-' . (int) $count . '"><span class="update-count">' . (int) $count . '</span></span>' )
			: __( 'Links', 'kerf-blocks' ),
		'edit_theme_options',
		'kerf-links',
		'kerf_links_render_page'
	);
}
add_action( 'admin_menu', 'kerf_links_menu', 30 );

/**
 * Render the Links screen: every link in the design, by where it is.
 */
function kerf_links_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to manage links.', 'kerf-blocks' ) );
	}

	$done   = kerf_links_handle_post();
	$places = kerf_links_places();

	// The count the menu and the Dashboard show follows what is here.
	$now = kerf_links_unresolved_now( $places );
	if ( $now !== kerf_links_get_report() ) {
		kerf_links_save_report( $now );
	}
	$show   = isset( $_GET['show'] ) && 'missing' === $_GET['show'] ? 'missing' : 'all'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a filter, nothing changes.
	$total  = 0;
	$broken = 0;
	foreach ( $places as $place ) {
		foreach ( $place['links'] as $link ) {
			$total++;
			$broken += in_array( $link['state'], array( 'nowhere', 'gone' ), true ) ? 1 : 0;
		}
	}

	kerf_ui_open( __( 'Links', 'kerf-blocks' ), array(
		'lede' => __( 'Where every link in your design goes. A link pointed at a page follows it: rename the page or move it, and the link still works. Your design\'s markup is never changed — only where each link leads.', 'kerf-blocks' ),
	) );

	if ( $done ) {
		echo kerf_ui_note( $done, 'ok' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}

	if ( ! $places ) {
		echo '<section class="kerf-panel"><div class="kerf-empty"><h2>' . esc_html__( 'No links yet', 'kerf-blocks' ) . '</h2><p>' . esc_html__( 'Import a design and every link in its header, footer and pages is listed here.', 'kerf-blocks' ) . '</p><p><a class="kerf-btn kerf-btn--primary" href="' . esc_url( admin_url( 'admin.php?page=kerf-import' ) ) . '">' . esc_html__( 'Import a design', 'kerf-blocks' ) . '</a></p></div></section>';
		kerf_ui_close();
		return;
	}

	$pages = get_pages( array( 'number' => 300, 'sort_column' => 'post_title', 'post_status' => 'publish,draft,private' ) );
	$base  = admin_url( 'admin.php?page=kerf-links' );
	?>
	<nav class="kerf-filter" aria-label="<?php esc_attr_e( 'Show', 'kerf-blocks' ); ?>">
		<a href="<?php echo esc_url( $base ); ?>" aria-current="<?php echo 'all' === $show ? 'true' : 'false'; ?>">
			<?php
			/* translators: %d: number of links. */
			echo esc_html( sprintf( __( 'Every link (%d)', 'kerf-blocks' ), $total ) );
			?>
		</a>
		<a href="<?php echo esc_url( add_query_arg( 'show', 'missing', $base ) ); ?>" aria-current="<?php echo 'missing' === $show ? 'true' : 'false'; ?>">
			<?php
			/* translators: %d: number of links. */
			echo esc_html( sprintf( __( 'Going nowhere (%d)', 'kerf-blocks' ), $broken ) );
			?>
		</a>
	</nav>

	<form method="post" class="kerf-links-form kerf-stack" data-working="<?php esc_attr_e( 'Saving where your links go…', 'kerf-blocks' ); ?>">
		<?php wp_nonce_field( 'kerf_links', 'kerf_links_nonce' ); ?>
		<?php
		$shown = 0;
		foreach ( $places as $place ) :
			$links = 'missing' === $show
				? array_filter( $place['links'], static function ( $link ) {
					return in_array( $link['state'], array( 'nowhere', 'gone' ), true );
				} )
				: $place['links'];
			if ( ! $links ) {
				continue;
			}
			$shown++;
			?>
			<section class="kerf-panel kerf-place">
				<div class="kerf-panel__head">
					<span class="kerf-place__icon"><?php echo kerf_ui_icon( $place['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
					<div>
						<h2><?php echo esc_html( $place['label'] ); ?></h2>
						<span class="kerf-help"><?php echo esc_html( $place['note'] ); ?></span>
					</div>
					<?php if ( $place['edit'] ) : ?>
						<a class="kerf-btn kerf-btn--quiet kerf-btn--sm kerf-panel__aside" href="<?php echo esc_url( $place['edit'] ); ?>"><?php esc_html_e( 'Open in the editor', 'kerf-blocks' ); ?></a>
					<?php endif; ?>
				</div>
				<table class="kerf-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Link', 'kerf-blocks' ); ?></th>
							<th><?php esc_html_e( 'Goes to', 'kerf-blocks' ); ?></th>
							<th><?php esc_html_e( 'Change it to', 'kerf-blocks' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $links as $link ) : ?>
							<?php kerf_links_render_row( $place, $link, $pages ); ?>
						<?php endforeach; ?>
					</tbody>
				</table>
			</section>
		<?php endforeach; ?>

		<?php if ( ! $shown ) : ?>
			<?php echo kerf_ui_note( __( 'Every link in your design goes somewhere.', 'kerf-blocks' ), 'ok' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
		<?php endif; ?>

		<div class="kerf-savebar">
			<button type="submit" name="kerf_links_action" value="save" class="kerf-btn kerf-btn--primary" data-save-links><?php esc_html_e( 'Save links', 'kerf-blocks' ); ?></button>
			<p data-changed-count><?php esc_html_e( 'Pick where a link goes, then save.', 'kerf-blocks' ); ?></p>
			<button type="submit" name="kerf_links_action" value="rescan" class="kerf-btn kerf-btn--quiet kerf-actionbar__end" data-working="<?php esc_attr_e( 'Checking every link again…', 'kerf-blocks' ); ?>"><?php echo kerf_ui_icon( 'refresh' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Check every link again', 'kerf-blocks' ); ?></button>
		</div>
	</form>
	<?php
	kerf_ui_working();
	kerf_ui_close();
}

/**
 * One link: what it says, where it goes, and what it could go to instead.
 *
 * @param array     $place
 * @param array     $link
 * @param WP_Post[] $pages
 */
function kerf_links_render_row( $place, $link, $pages ) {
	$icons = array(
		'page'     => 'page',
		'home'     => 'home',
		'file'     => 'file',
		'url'      => 'link',
		'external' => 'external',
		'mail'     => 'mail',
		'phone'    => 'phone',
		'anchor'   => 'link',
		'none'     => 'info',
		'nowhere'  => 'alert',
		'live'     => 'refresh',
		'gone'     => 'alert',
	);
	$broken = in_array( $link['state'], array( 'nowhere', 'gone' ), true );
	// Only a link to this site can be pointed at a page here; an email, a call,
	// another site or a place on the page is the designer's, as written.
	$movable = in_array( $link['state'], array( 'page', 'home', 'url', 'nowhere', 'gone', 'file' ), true ) && null !== $link['path'];
	$field   = 'kerf_link[' . (int) $place['id'] . '][' . $link['at'] . ']';
	?>
	<tr class="kerf-link-row">
		<td>
			<span class="kerf-link-text"><?php echo esc_html( $link['text'] ); ?></span>
			<span class="kerf-link-href"><?php echo esc_html( $link['href'] ); ?></span>
		</td>
		<td>
			<span class="kerf-link-to<?php echo $broken ? ' kerf-link-to--none' : ''; ?>">
				<?php echo kerf_ui_icon( isset( $icons[ $link['state'] ] ) ? $icons[ $link['state'] ] : 'link' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
				<?php echo esc_html( $link['to'] ); ?>
			</span>
		</td>
		<td>
			<?php if ( $movable ) : ?>
				<select name="<?php echo esc_attr( $field ); ?>" data-was="<?php echo esc_attr( $link['choice'] ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: link text. */ __( 'Where “%s” goes', 'kerf-blocks' ), $link['text'] ) ); ?>">
					<?php if ( '' === $link['choice'] ) : ?>
						<option value="" selected><?php esc_html_e( '— Choose a page —', 'kerf-blocks' ); ?></option>
					<?php endif; ?>
					<option value="home" <?php selected( $link['choice'], 'home' ); ?>><?php esc_html_e( 'The home page', 'kerf-blocks' ); ?></option>
					<?php if ( 0 === strpos( $link['choice'], 'media:' ) || ( 0 === strpos( $link['choice'], 'post:' ) && 'page' !== get_post_type( (int) substr( $link['choice'], 5 ) ) ) ) : ?>
						<option value="<?php echo esc_attr( $link['choice'] ); ?>" selected><?php echo esc_html( $link['to'] ); ?></option>
					<?php endif; ?>
					<optgroup label="<?php esc_attr_e( 'Pages', 'kerf-blocks' ); ?>">
						<?php foreach ( $pages as $page ) : ?>
							<option value="<?php echo esc_attr( 'post:' . $page->ID ); ?>" <?php selected( $link['choice'], 'post:' . $page->ID ); ?>>
								<?php
								echo esc_html( '' !== $page->post_title ? $page->post_title : __( '(no title)', 'kerf-blocks' ) );
								if ( 'publish' !== $page->post_status ) {
									echo ' ' . esc_html__( '(not published)', 'kerf-blocks' );
								}
								?>
							</option>
						<?php endforeach; ?>
					</optgroup>
					<?php if ( $broken ) : ?>
						<option value="create"><?php esc_html_e( 'A new draft page for it', 'kerf-blocks' ); ?></option>
					<?php endif; ?>
					<option value="url" <?php selected( $link['choice'], 'url' ); ?>><?php esc_html_e( 'Exactly as written', 'kerf-blocks' ); ?></option>
				</select>
				<input type="hidden" name="<?php echo esc_attr( 'kerf_link_was[' . (int) $place['id'] . '][' . $link['at'] . ']' ); ?>" value="<?php echo esc_attr( md5( $link['href'] ) ); ?>">
			<?php else : ?>
				<span class="kerf-help"><?php esc_html_e( 'Kept as the design wrote it', 'kerf-blocks' ); ?></span>
			<?php endif; ?>
		</td>
	</tr>
	<?php
}

/**
 * Handle the Links screen: save where links go, or check them all again.
 *
 * @return string What was done, for the screen; '' when nothing was asked.
 */
function kerf_links_handle_post() {
	if ( empty( $_POST['kerf_links_action'] ) || ! current_user_can( 'edit_theme_options' ) ) {
		return '';
	}
	if ( ! isset( $_POST['kerf_links_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_links_nonce'] ) ), 'kerf_links' ) ) {
		return '';
	}

	$changed = 0;
	if ( 'save' === sanitize_key( wp_unslash( $_POST['kerf_links_action'] ) ) && ! empty( $_POST['kerf_link'] ) && is_array( $_POST['kerf_link'] ) ) {
		$was = isset( $_POST['kerf_link_was'] ) && is_array( $_POST['kerf_link_was'] ) ? wp_unslash( $_POST['kerf_link_was'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each value is compared with a hash, nothing more.
		foreach ( wp_unslash( $_POST['kerf_link'] ) as $post_id => $links ) { // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each choice is checked in kerf_links_set().
			if ( is_array( $links ) ) {
				$changed += kerf_links_set( (int) $post_id, $links, isset( $was[ $post_id ] ) && is_array( $was[ $post_id ] ) ? $was[ $post_id ] : array() );
			}
		}
	}

	// Every link bound again from what is chosen now: the same address
	// elsewhere follows the owner's choice, and the count is fresh.
	$result = kerf_links_rescan();

	$left = count( $result['unresolved'] );
	if ( $changed ) {
		return sprintf(
			/* translators: 1: links changed, 2: links still going nowhere. */
			_n( 'Saved %1$d link. %2$d still goes nowhere.', 'Saved %1$d links. %2$d still go nowhere.', $changed, 'kerf-blocks' ),
			$changed,
			$left
		);
	}
	return sprintf(
		/* translators: %d: links still going nowhere. */
		_n( 'Checked every link again. %d goes nowhere.', 'Checked every link again. %d go nowhere.', $left, 'kerf-blocks' ),
		$left
	);
}

/**
 * Point links in one part, page or template where the owner chose.
 *
 * Each link is found by its path in the block tree and must still be the link
 * the screen showed (its href's hash): a page saved in between is not
 * overwritten by a stale choice. A choice for an address is also kept
 * (kerf_links_chosen()), so the same address elsewhere — and in a newer
 * import — goes there too. A section only re-pointed stays one an update may
 * replace: its stamp is written again (§5.28, scar 74).
 *
 * @param int                  $post_id
 * @param array<string,string> $links   path => choice.
 * @param array<string,string> $was     path => md5 of the href shown.
 * @return int Links changed.
 */
function kerf_links_set( $post_id, $links, $was ) {
	$post = get_post( $post_id );
	if ( ! $post || ! in_array( $post->post_type, array( 'page', 'wp_template_part', 'wp_template' ), true ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return 0;
	}

	$blocks  = parse_blocks( $post->post_content );
	$chosen  = kerf_links_chosen();
	$changed = 0;

	foreach ( $links as $path => $choice ) {
		$choice = sanitize_text_field( (string) $choice );
		// `<path>~<n>`: the n-th link in that block's words (kerf_links_collect()).
		list( $where, $nth ) = array_pad( explode( '~', (string) $path, 2 ), 2, null );
		$steps               = array_map( 'intval', explode( '.', (string) $where ) );
		if ( '' === $choice || ! preg_match( '/^(?:home|url|create|post:\d+|media:\d+)$/', $choice ) ) {
			continue;
		}

		// Walk to the block, keeping where each step was taken from.
		$ref = &$blocks;
		$top = $steps[0];
		$ok  = true;
		foreach ( $steps as $depth => $step ) {
			if ( 0 === $depth ) {
				if ( ! isset( $ref[ $step ] ) ) {
					$ok = false;
					break;
				}
				$ref = &$ref[ $step ];
				continue;
			}
			if ( ! isset( $ref['innerBlocks'][ $step ] ) ) {
				$ok = false;
				break;
			}
			$ref = &$ref['innerBlocks'][ $step ];
		}
		if ( ! $ok ) {
			unset( $ref );
			continue;
		}

		$name  = isset( $ref['blockName'] ) ? (string) $ref['blockName'] : '';
		$attrs = isset( $ref['attrs'] ) ? (array) $ref['attrs'] : array();
		$href  = kerf_links_href( $name, $attrs );
		if ( null !== $nth ) {
			$anchors = kerf_links_is_rich_text( $name ) ? kerf_links_rich_text_anchors( isset( $ref['innerHTML'] ) ? (string) $ref['innerHTML'] : '' ) : array();
			$attrs   = isset( $anchors[ (int) $nth ] ) ? kerf_links_inline_attrs( $anchors[ (int) $nth ]['attrs'] ) : array();
			$href    = isset( $attrs['url'] ) ? (string) $attrs['url'] : null;
		}
		if ( null === $href || ! isset( $was[ $path ] ) || md5( $href ) !== $was[ $path ] ) {
			unset( $ref );
			continue;
		}
		$now = kerf_links_destination( $attrs, $href );
		if ( $now['choice'] === $choice || null === $now['path'] ) {
			unset( $ref );
			continue;
		}

		$top_out   = isset( $blocks[ $top ]['attrs']['kerfSource']['out'] ) ? (string) $blocks[ $top ]['attrs']['kerfSource']['out'] : '';
		$top_clean = '' !== $top_out && function_exists( 'kerf_sync_block_hash' ) && kerf_sync_block_hash( $blocks[ $top ] ) === $top_out;

		if ( 'create' === $choice ) {
			$created = kerf_links_create_page( $now['path'] );
			if ( ! $created ) {
				unset( $ref );
				continue;
			}
			$choice = 'post:' . $created;
		}

		if ( 'home' === $choice || 'url' === $choice ) {
			$set = array( 'linkType' => $choice, 'linkId' => 0 );
		} elseif ( 0 === strpos( $choice, 'media:' ) ) {
			$set = array( 'linkType' => 'media', 'linkId' => (int) substr( $choice, 6 ) );
		} else {
			$target = (int) substr( $choice, 5 );
			if ( ! get_post( $target ) ) {
				unset( $ref );
				continue;
			}
			$set = array( 'linkType' => 'post', 'linkId' => $target );
		}
		if ( null !== $nth ) {
			$ref['innerHTML']    = kerf_links_set_rich_text_anchor( (string) $ref['innerHTML'], (int) $nth, $href, $set );
			$ref['innerContent'] = array( $ref['innerHTML'] );
		} else {
			$ref['attrs']['linkType'] = $set['linkType'];
			$ref['attrs']['linkId']   = $set['linkId'];
		}
		if ( 'home' !== $now['path'] && 0 !== strpos( $choice, 'media:' ) ) {
			$chosen[ $now['path'] ] = $choice;
		}
		unset( $ref );

		if ( $top_clean ) {
			$blocks[ $top ]['attrs']['kerfSource']['out'] = kerf_sync_block_hash( $blocks[ $top ] );
		}
		$changed++;
	}

	if ( $changed ) {
		update_option( KERF_LINKS_CHOSEN_OPTION, $chosen, false );
		// wp_slash() is mandatory — @see kerf_import_write_template_part().
		wp_update_post( array(
			'ID'           => $post_id,
			'post_content' => wp_slash( serialize_blocks( $blocks ) ),
		) );
	}

	return $changed;
}

/**
 * Re-bind links across every page, post and template part.
 *
 * @return array{bound:int,scanned:int,unresolved:array<string,int>}
 */
function kerf_links_rescan() {
	$posts = get_posts( array(
		'post_type'      => array( 'page', 'post', 'wp_template_part', 'wp_template' ),
		'post_status'    => 'any',
		'posts_per_page' => -1,
	) );

	$bound      = 0;
	$scanned    = 0;
	$unresolved = array();

	foreach ( $posts as $post ) {
		if ( false === strpos( $post->post_content, '<!-- wp:kerf/' ) ) {
			continue;
		}

		// The header part's logo goes to the home page (scar 135).
		$result = kerf_links_bind( $post->post_content, array( 'logo' => 'wp_template_part' === $post->post_type && 'header' === $post->post_name ) );
		$scanned++;
		$bound += $result['bound'];

		foreach ( $result['unresolved'] as $href => $count ) {
			$unresolved[ $href ] = ( $unresolved[ $href ] ?? 0 ) + $count;
		}

		if ( $result['markup'] !== $post->post_content ) {
			// wp_slash() is mandatory — @see kerf_import_write_template_part().
			wp_update_post( array(
				'ID'           => $post->ID,
				'post_content' => wp_slash( $result['markup'] ),
			) );
		}
	}

	kerf_links_save_report( $unresolved );

	return array( 'bound' => $bound, 'scanned' => $scanned, 'unresolved' => $unresolved );
}
