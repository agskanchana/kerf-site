<?php
/**
 * Editor experience for the Kerf block suite.
 *
 * Two jobs: put Kerf's blocks where people will find them, and load the editor
 * scripts that make a converted page workable — the canvas behaviour and the
 * Kerf sidebar.
 *
 * The List View labels and tag colours, which are what make a deep tree of
 * "Element" rows navigable, live in assets/js/kerf-block-labels.js and are
 * registered with the blocks (kerf-blocks.php). They were once a PHP label
 * callback in this file. A PHP closure cannot reach the editor — block types
 * travel to it as JSON — so every row said "Element" and nothing said why.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Put a Kerf category at the top of the inserter.
 *
 * @param array $categories Registered block categories.
 * @return array
 */
function kerf_block_categories( $categories ) {
	array_unshift(
		$categories,
		array(
			'slug'  => 'kerf',
			'title' => __( 'Kerf', 'kerf-blocks' ),
			'icon'  => null,
		)
	);

	return $categories;
}
add_filter( 'block_categories_all', 'kerf_block_categories' );

/**
 * Load the editor enhancements.
 *
 * Registered against `enqueue_block_editor_assets` rather than a block's own
 * editorScript because these apply across every block, including core's.
 */
function kerf_editor_ux_assets() {
	$view  = 'assets/js/kerf-canvas.js';
	$vpath = kerf_plugin_path( $view );

	if ( file_exists( $vpath ) ) {
		wp_enqueue_script(
			'kerf-canvas',
			kerf_plugin_url( $view ),
			// wp-data is load-bearing: the selection pass subscribes to the
			// block-editor store for selection changes.
			array( 'wp-element', 'wp-components', 'wp-i18n', 'wp-data', 'wp-block-editor', 'wp-hooks', 'wp-compose' ),
			filemtime( $vpath ),
			true
		);
		wp_set_script_translations( 'kerf-canvas', 'kerf-blocks', kerf_plugin_path( 'languages' ) );
	}

	// The editor half of kerf/post and kerf/query: what a bound field says it is.
	$bind  = 'assets/js/kerf-bindings-editor.js';
	$bpath = kerf_plugin_path( $bind );

	if ( file_exists( $bpath ) ) {
		wp_enqueue_script( 'kerf-bindings-editor', kerf_plugin_url( $bind ), array( 'wp-blocks', 'wp-i18n', 'wp-data', 'wp-date', 'wp-core-data' ), filemtime( $bpath ), true );

		// The Menu panel: a converted menu edited as a menu.
		$menu  = 'assets/js/kerf-menu-panel.js';
		$mpath = kerf_plugin_path( $menu );
		if ( file_exists( $mpath ) ) {
			wp_enqueue_script( 'kerf-menu-panel', kerf_plugin_url( $menu ), array( 'wp-hooks', 'wp-compose', 'wp-element', 'wp-data', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-i18n' ), filemtime( $mpath ), true );
			wp_set_script_translations( 'kerf-menu-panel', 'kerf-blocks', kerf_plugin_path( 'languages' ) );
		}

		// The Background picture panel (inc/kerf-backgrounds.php).
		$bg     = 'assets/js/kerf-background-panel.js';
		$bgpath = kerf_plugin_path( $bg );
		if ( file_exists( $bgpath ) ) {
			kerf_bg_register_core();
			wp_enqueue_script( 'kerf-background-panel', kerf_plugin_url( $bg ), array( 'wp-hooks', 'wp-compose', 'wp-element', 'wp-data', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-api-fetch', 'kerf-attributes-control', 'kerf-background-core' ), filemtime( $bgpath ), true );
			wp_set_script_translations( 'kerf-background-panel', 'kerf-blocks', kerf_plugin_path( 'languages' ) );
			kerf_bg_editor_data();
		}

		wp_localize_script( 'kerf-bindings-editor', 'KerfBindings', array(
			'keys'   => kerf_bindings_keys(),
			'labels' => array(
				'post'    => __( 'Post (Kerf)', 'kerf-blocks' ),
				'query'   => __( 'Page (Kerf)', 'kerf-blocks' ),
				'comment' => __( 'Comment (Kerf)', 'kerf-blocks' ),
				'term'    => __( 'Tag or category (Kerf)', 'kerf-blocks' ),
				'site'    => __( 'Site details (Kerf)', 'kerf-blocks' ),
			),
			// The business's details, so a bound phone shows its number here
			// as on the page (inc/kerf-site.php).
			'site'   => function_exists( 'kerf_site_details' ) ? kerf_site_details() : array(),
		) );
	}

	// The editor's own document, not the canvas: this styles the List View.
	$css   = 'assets/css/kerf-editor-ui.css';
	$cpath = kerf_plugin_path( $css );

	if ( file_exists( $cpath ) ) {
		wp_enqueue_style( 'kerf-editor-ui', kerf_plugin_url( $css ), array(), filemtime( $cpath ) );
	}

	$rel  = 'assets/js/kerf-editor-ux.js';
	$path = kerf_plugin_path( $rel );

	if ( ! file_exists( $path ) ) {
		return;
	}

	wp_enqueue_script(
		'kerf-editor-ux',
		kerf_plugin_url( $rel ),
		array(
			'wp-blocks', 'wp-element', 'wp-hooks', 'wp-i18n', 'wp-compose',
			'wp-block-editor', 'wp-components', 'wp-data', 'wp-plugins', 'wp-api-fetch',
			'kerf-canvas',
		),
		filemtime( $path ),
		true
	);

	wp_set_script_translations( 'kerf-editor-ux', 'kerf-blocks', kerf_plugin_path( 'languages' ) );

	// Whether what this user saves goes through KSES, which keeps no <svg>
	// (§5.32): the editor warns before a save empties the page's inline SVGs.
	wp_add_inline_script(
		'kerf-editor-ux',
		'window.kerfEditor = ' . wp_json_encode( array( 'unfiltered' => current_user_can( 'unfiltered_html' ) ) ) . ';',
		'before'
	);
}
add_action( 'enqueue_block_editor_assets', 'kerf_editor_ux_assets' );
