<?php
/**
 * "Start here": the brief that makes an AI tool's design import cleanly.
 *
 * Most of what goes wrong with an import is decided before it: an app instead
 * of pages, a header copied differently on every page, a form with no field
 * names, pictures from a placeholder service. This brief asks for what Kerf
 * needs up front — plain files, one header and footer, the markup contract for
 * the blog (kerf_shell_contract_lines()), the forms (§5.35) and the business
 * details (§5.36) marked — so the first import is already a working site. Kerf
 * itself calls no AI (§5.4): the brief is text the owner pastes into whichever
 * tool they use.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The brief.
 *
 * @return string
 */
function kerf_site_brief() {
	$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

	$lines = array(
		'Design a complete website for my business as plain HTML, CSS and JavaScript files. I will import it into WordPress with the Kerf theme, which keeps every tag, class and stylesheet exactly as you write them — so write it exactly as it should look.',
		'',
		'About the business:',
		'[' . ( '' !== $site ? $site . ' — ' : '' ) . 'what you do, where, who your customers are, which pages you need, and the feel you want: "warm and calm, lots of white space, serif headings"]',
		'',
		'What to make:',
		'- index.html (the home page), and one file per page: about.html, services.html, contact.html — whatever the business needs.',
		'- blog.html (the list of blog posts), blog-post.html (one blog post) and 404.html (page not found).',
		'- css/style.css with all the styles. Tailwind is fine — the compiled CSS file, or the Play CDN script.',
		'- js/main.js for the behaviour (menus, sliders, accordions). Alpine.js is fine too.',
		'- Pictures as files in img/ — JPG, PNG, WebP or SVG — with real alt text. No placeholder services (picsum, placehold.co, source.unsplash.com).',
		'- Realistic text written for this business, not lorem ipsum.',
		'- No React, Vue, Svelte, JSX, npm or build step: every page must show all of its content as plain HTML, with JavaScript only adding behaviour.',
		'',
		'Rules for every page:',
		'- The same stylesheets and fonts in <head>, in the same order.',
		'- The site header — <header> holding the logo and the menu in a <nav> — and the <footer> copied exactly onto every page: same markup, same classes. Put the page\'s own content in <main>. All three directly inside <body>.',
		'- Anything the header opens — a search overlay, a menu drawer, a booking pop-up — goes directly after </header> (or inside it), never between the page\'s sections, so every page has it.',
		'- The logo in the header is a link to index.html — <a href="index.html" class="logo"><img src="img/logo.svg" alt="…"></a> — so it takes visitors home from every page.',
		'- Menu links point at the other files by name: index.html, about.html, contact.html.',
		'- One <h1> per page, and a <title> and <meta name="description"> on each.',
		'- Behaviour in js/main.js (or Alpine.js attributes) — never in onclick or other on… attributes, and no document.write.',
		'- js/main.js runs on every page, including the blog, posts and pages WordPress adds that have only the header and footer: check that an element exists before using it (const slider = document.querySelector(\'.slider\'); if (slider) { … }), so a section one page lacks never stops the rest of the script.',
		'',
		'Mark these with data- attributes. They change nothing about how the page looks; they tell WordPress what each part is:',
		'- The business\'s details, wherever they appear (header, footer, contact page): data-kerf-site="phone" on each tel: link, "email" on each mailto: link, "address" on the element holding the address, "hours" on the opening hours, and "facebook", "instagram", "x", "linkedin", "youtube", "tiktok" or "whatsapp" on each social link.',
		'- Every form: <form data-kerf-form="contact"> (or "booking", "quote", "newsletter"), every field with a name attribute (name, email, phone, message…) and a <label>. Inside the form, a thank-you message <div data-kerf-form-success hidden>…</div> and an error message <div data-kerf-form-error hidden>…</div>.',
		'- The banner at the top of each page other than the home page (its title over a photo): data-kerf-field="image" on the element that shows the photo. WordPress then shows each page\'s featured image there, and your photo on pages without one.',
	);

	$lines   = array_merge( $lines, kerf_shell_contract_lines() );
	$lines[] = '';
	$lines[] = 'When you are done, give me the whole folder as a ZIP if you can. Otherwise give me every file\'s complete content, each headed with its path (css/style.css, img/… as a list of what to download).';

	return implode( "\n", $lines );
}

/**
 * The brief on the import screen, above the form: where someone starting from
 * nothing begins.
 */
function kerf_brief_render() {
	?>
	<section class="kerf-panel kerf-brief" id="kerf-brief">
		<div class="kerf-panel__head">
			<h2><?php esc_html_e( 'No design yet?', 'kerf-blocks' ); ?></h2>
		</div>
		<div class="kerf-panel__body">
			<p class="kerf-help"><?php esc_html_e( 'Copy this brief into ChatGPT, Claude, Gemini or any AI tool that writes websites, add a line about your business, and import what it gives you. A design made from it arrives as a working site: its pages, blog, forms and contact details already wired up.', 'kerf-blocks' ); ?></p>
			<p><button type="button" class="kerf-btn kerf-btn--primary kerf-copy" data-copy="kerf-site-brief"><?php echo kerf_ui_icon( 'copy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Copy the brief', 'kerf-blocks' ); ?></button></p>
			<details class="kerf-more">
				<summary><?php echo kerf_ui_icon( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Read it first', 'kerf-blocks' ); ?></summary>
				<textarea readonly rows="14" id="kerf-site-brief" aria-label="<?php esc_attr_e( 'The brief', 'kerf-blocks' ); ?>"><?php echo esc_textarea( kerf_site_brief() ); ?></textarea>
			</details>
		</div>
	</section>
	<?php
}
add_action( 'kerf_import_before_form', 'kerf_brief_render' );

/**
 * The markup contract (§5.25), as a brief states it — shared by the inner
 * pages' two briefs and the "Start here" brief (inc/kerf-brief.php), so all
 * three always ask for the same attributes.
 *
 * @return string[]
 */
function kerf_shell_contract_lines() {
	return array(
		'Mark the parts WordPress fills in with these attributes. They change nothing about how the page looks:',
		'- On <body>: data-kerf-template="home" for the blog page, or "single", "page", "archive", "search", "404".',
		'- On the element that repeats once per post in a list (a card): data-kerf-loop. Keep two or three cards so the design shows; the first one is used for every post. A second list on the same page, such as "Recent posts" in a sidebar, takes data-kerf-loop="latest".',
		'- The same for the post\'s own lists: data-kerf-loop="comments" on each sample comment, data-kerf-loop="tags" on each tag link, data-kerf-loop="categories" on each category link.',
		'- On the element that holds each piece of WordPress data: data-kerf-field="…", one of:',
		'  title, permalink, date, author, category, excerpt, image, tags, comments-count,',
		'  author-bio and author-avatar (an "about the author" box),',
		'  content (the element the post or page body goes into — WordPress puts plain HTML there; when the sample article is several elements, mark each of them content and the post goes where the first one is),',
		'  comments (the comments area: WordPress fills it, unless it holds a comment card marked data-kerf-loop="comments"),',
		'  comment-author, comment-date, comment-text, comment-avatar (inside a comment card),',
		'  comment-form (the <form> visitors write a comment in — keep its name, email, website and message fields; a form inside the comments area is taken as one without the marker),',
		'  term-name (inside a tag or category card), prev and next (links to the previous and next post),',
		'  archive-title, archive-description, search-query, search-form (the <form>), search-input (its text field),',
		'  pagination (the element that holds the page links 1, 2, 3, Next).',
		'- Put data-kerf-field on the innermost element that holds the text or image: <h3><a data-kerf-field="title" href="#">A post title</a></h3>, <img data-kerf-field="image" src="…" alt="">, <span data-kerf-field="date">12 March 2026</span>. A link marked "title" also links to the post. Write the placeholder date in the format you want — WordPress uses the same one.',
		'- Inside a post card or beside the post\'s title, a date, "by Admin" and "12 Comments" are filled in without a marker; write data-kerf-field="none" on one that should stay exactly as written.',
	);
}
