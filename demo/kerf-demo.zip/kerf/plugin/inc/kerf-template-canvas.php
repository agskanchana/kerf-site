<?php
/**
 * Template canvas for block templates — core's wp-includes/template-canvas.php,
 * plus the mockup's `<html>` and `<body>` attributes, minus the
 * `<div class="wp-site-blocks">` wrapper. See inc/kerf-document.php for why.
 *
 * Keep this in step with core's canvas. It has been four statements for years;
 * if core ever adds one, add it here too.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Get the template HTML.
 * This needs to run before <head> so that blocks can add scripts and styles in wp_head().
 */
$kerf_template_html = kerf_unwrap_site_blocks( get_the_block_template_html() );
?><!DOCTYPE html>
<html <?php language_attributes(); ?><?php echo kerf_document_attributes( 'html' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped per attribute. ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?><?php echo kerf_document_attributes( 'body' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped per attribute. ?>>
<?php wp_body_open(); ?>

<?php echo $kerf_template_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- rendered block template, as in core's canvas. ?>

<?php wp_footer(); ?>
</body>
</html>
