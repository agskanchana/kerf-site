<?php
/**
 * Kerf → Dashboard: where the Kerf menu opens.
 *
 * What is on the site — the design, shown live — what needs the owner, and
 * every Kerf screen, one line each. Before anything is imported it is the way
 * in: three steps from an AI tool's design to a working site.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What the last import for the whole site was, for the Dashboard.
 */
const KERF_DESIGN_OPTION = 'kerf_design';

/**
 * The Kerf menu, opening on the Dashboard.
 */
function kerf_dashboard_menu() {
	add_menu_page(
		__( 'Kerf', 'kerf-blocks' ),
		__( 'Kerf', 'kerf-blocks' ),
		'edit_theme_options',
		'kerf',
		'kerf_dashboard_render',
		'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><path fill="black" fill-rule="evenodd" d="M8 2h16a6 6 0 0 1 6 6v16a6 6 0 0 1-6 6H8a6 6 0 0 1-6-6V8a6 6 0 0 1 6-6zm2.5 4.7a1.3 1.3 0 0 0-1.3 1.3v16a1.3 1.3 0 1 0 2.6 0V8a1.3 1.3 0 0 0-1.3-1.3zm12.4.4a1.3 1.3 0 0 0-1.84.07l-7.5 8a1.3 1.3 0 0 0 0 1.78l7.5 8a1.3 1.3 0 0 0 1.9-1.78L16.28 16l6.69-7.11a1.3 1.3 0 0 0-.07-1.84z"/></svg>' ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- WordPress takes a menu icon as a data URI.
		59
	);

	add_submenu_page(
		'kerf',
		__( 'Kerf', 'kerf-blocks' ),
		__( 'Dashboard', 'kerf-blocks' ),
		'edit_theme_options',
		'kerf',
		'kerf_dashboard_render'
	);
}
add_action( 'admin_menu', 'kerf_dashboard_menu', 9 );

/**
 * Remember the design an import for the whole site brought in.
 *
 * @param array $design { title, file, page, match }.
 */
function kerf_dashboard_remember( $design ) {
	update_option( KERF_DESIGN_OPTION, array(
		'title' => isset( $design['title'] ) ? (string) $design['title'] : '',
		'file'  => isset( $design['file'] ) ? (string) $design['file'] : '',
		'page'  => isset( $design['page'] ) ? (int) $design['page'] : 0,
		'match' => isset( $design['match'] ) ? (int) $design['match'] : null,
		'at'    => time(),
	), false );
}

/**
 * The design on the site now, if one was imported for the whole site.
 *
 * A site imported before the Dashboard has no record: its home page stands in.
 *
 * @return array|null { title, file, page, match, at }.
 */
function kerf_dashboard_design() {
	$page   = (int) get_option( 'kerf_mockup_page' );
	$design = get_option( KERF_DESIGN_OPTION, array() );
	$design = is_array( $design ) ? $design : array();

	if ( ! $page || ! get_post( $page ) || 'trash' === get_post_status( $page ) ) {
		return null;
	}

	return array(
		'title' => ! empty( $design['title'] ) ? (string) $design['title'] : get_the_title( $page ),
		'file'  => isset( $design['file'] ) ? (string) $design['file'] : '',
		'page'  => $page,
		'match' => isset( $design['match'] ) ? $design['match'] : null,
		'at'    => ! empty( $design['at'] ) ? (int) $design['at'] : (int) get_option( 'kerf_assets_version', 0 ),
	);
}

/**
 * Is a Kerf screen in the menu now — a Kerf Pro one may not be?
 *
 * @param string $slug
 * @return bool
 */
function kerf_dashboard_has_screen( $slug ) {
	global $submenu;
	foreach ( isset( $submenu['kerf'] ) ? (array) $submenu['kerf'] : array() as $item ) {
		if ( isset( $item[2] ) && $slug === $item[2] ) {
			return true;
		}
	}
	return false;
}

/**
 * The address of a Kerf screen.
 *
 * @param string $slug
 * @return string
 */
function kerf_dashboard_url( $slug ) {
	return false !== strpos( $slug, '.php' ) ? admin_url( $slug ) : admin_url( 'admin.php?page=' . $slug );
}

/**
 * What needs the owner, and what is fine: one line each.
 *
 * @return array[] { tone, text, link, url }.
 */
function kerf_dashboard_status() {
	$lines = array();

	$unresolved = count( kerf_links_get_report() );
	$lines[]    = $unresolved
		? array(
			'tone' => 'warn',
			/* translators: %d: number of links. */
			'text' => sprintf( _n( '%d link in your design goes nowhere yet.', '%d links in your design go nowhere yet.', $unresolved, 'kerf-blocks' ), $unresolved ),
			'link' => __( 'Point them at pages', 'kerf-blocks' ),
			'url'  => kerf_dashboard_url( 'kerf-links' ),
		)
		: array(
			'tone' => 'ok',
			'text' => __( 'Every link in your design goes to a page on this site.', 'kerf-blocks' ),
			'link' => __( 'See them', 'kerf-blocks' ),
			'url'  => kerf_dashboard_url( 'kerf-links' ),
		);

	// A host that sends no email is common, and nothing else would say so.
	$failing = kerf_forms_mail_failing();
	$lines[] = $failing
		? array(
			'tone' => 'bad',
			/* translators: 1: how long ago, e.g. "2 hours", 2: an email address. */
			'text' => sprintf( __( 'The last message from your design\'s forms, %1$s ago, could not be emailed to %2$s: this site may not be able to send email.', 'kerf-blocks' ), human_time_diff( $failing['failed'] ), kerf_forms_recipient() ),
			'link' => __( 'See why, and send a test', 'kerf-blocks' ),
			'url'  => kerf_dashboard_url( 'kerf-settings' ) . '#kerf-forms',
		)
		: array(
			'tone' => 'ok',
			/* translators: %s: an email address. */
			'text' => sprintf( __( 'Messages from your design\'s forms are emailed to %s.', 'kerf-blocks' ), kerf_forms_recipient() ),
			'link' => __( 'Change', 'kerf-blocks' ),
			'url'  => kerf_dashboard_url( 'kerf-settings' ),
		);

	$measured = get_option( KERF_SHELL_MEASURED_OPTION, array() );
	if ( kerf_dashboard_has_screen( 'kerf-inner-pages' ) ) {
		$lines[] = ! empty( $measured )
			? array(
				'tone' => 'ok',
				'text' => __( 'Your blog, posts and search results wear your design\'s fonts and colours.', 'kerf-blocks' ),
				'link' => __( 'Adjust', 'kerf-blocks' ),
				'url'  => kerf_dashboard_url( 'kerf-inner-pages' ),
			)
			: array(
				'tone' => 'warn',
				'text' => __( 'Your blog and posts have not taken your design\'s look yet.', 'kerf-blocks' ),
				'link' => __( 'Read it from the home page', 'kerf-blocks' ),
				'url'  => kerf_dashboard_url( 'kerf-inner-pages' ),
			);
	} else {
		$lines[] = array(
			'tone' => 'quiet',
			'text' => __( 'Your blog, posts and search results use the theme\'s plain look. Kerf Pro gives them your design\'s fonts and colours.', 'kerf-blocks' ),
			'link' => '',
			'url'  => '',
		);
	}

	/**
	 * The Dashboard's status lines: { tone: ok|warn|bad|quiet, text, link, url }.
	 *
	 * @param array[] $lines
	 */
	return (array) apply_filters( 'kerf_dashboard_status', $lines );
}

/**
 * Every Kerf screen, one line each — those this site has.
 *
 * @return array[] { slug, icon, title, text }.
 */
function kerf_dashboard_tools() {
	$can_import = kerf_user_can_import();
	$tools = array(
		array( 'kerf-import', 'upload', __( 'Import a design', 'kerf-blocks' ), $can_import ? __( 'A ZIP from your AI tool becomes the site: header, footer, pages and styles.', 'kerf-blocks' ) : kerf_import_permission_message() ),
		array( 'kerf-update', 'refresh', __( 'Update the design', 'kerf-blocks' ), $can_import ? __( 'Bring in a newer version, section by section. Your edits are kept.', 'kerf-blocks' ) : kerf_import_permission_message() ),
		array( 'kerf-inner-pages', 'template', __( 'Inner pages', 'kerf-blocks' ), __( 'The look of your blog, posts, search and 404 pages.', 'kerf-blocks' ) ),
		array( 'kerf-links', 'link', __( 'Links', 'kerf-blocks' ), __( 'Where every link in your header, footer and pages goes.', 'kerf-blocks' ) ),
		array( 'kerf-site', 'phone', __( 'Site details', 'kerf-blocks' ), __( 'Your phone, email and address, changed once for every page.', 'kerf-blocks' ) ),
		array( 'edit.php?post_type=kerf_entry', 'mail', __( 'Form entries', 'kerf-blocks' ), __( 'Every message sent through your design\'s forms.', 'kerf-blocks' ) ),
		array( 'kerf-settings', 'page', __( 'Settings', 'kerf-blocks' ), __( 'Where form messages go, WordPress\'s own CSS, the design\'s files.', 'kerf-blocks' ) ),
	);

	/**
	 * The Dashboard's tools — an add-on's screens among them (Kerf Pro's
	 * "Build with AI"). Each: [ menu slug, kerf_ui_icon() name, title, one line ];
	 * shown only where the screen exists.
	 *
	 * @param array[] $tools
	 */
	$tools = (array) apply_filters( 'kerf_dashboard_tools', $tools );

	$out = array();
	foreach ( $tools as $tool ) {
		if ( kerf_dashboard_has_screen( $tool[0] ) ) {
			$out[] = array( 'slug' => $tool[0], 'icon' => $tool[1], 'title' => $tool[2], 'text' => $tool[3] );
		}
	}
	return $out;
}

/**
 * Draw the Dashboard.
 */
function kerf_dashboard_render() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to see this page.', 'kerf-blocks' ) );
	}

	$design = kerf_dashboard_design();

	kerf_ui_open( __( 'Dashboard', 'kerf-blocks' ), array(
		'actions' => $design
			? sprintf( '<a class="kerf-btn" href="%s" target="_blank" rel="noopener">%s%s</a>', esc_url( home_url( '/' ) ), kerf_ui_icon( 'external' ), esc_html__( 'View site', 'kerf-blocks' ) )
			: '',
	) );

	if ( ! kerf_theme_active() ) {
		kerf_theme_required_notice();
	}

	if ( ! $design ) {
		kerf_dashboard_render_start();
	} else {
		kerf_dashboard_render_design( $design );
	}

	kerf_ui_close();
}

/**
 * Before any design: the way in.
 */
function kerf_dashboard_render_start() {
	if ( ! kerf_user_can_import() ) {
		echo kerf_ui_note( kerf_import_permission_message(), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		return;
	}
	?>
	<section class="kerf-panel kerf-crop">
		<div class="kerf-empty">
			<div class="kerf-drop__icon"><?php echo kerf_ui_icon( 'upload' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></div>
			<h2><?php esc_html_e( 'Turn your design into this site', 'kerf-blocks' ); ?></h2>
			<p><?php esc_html_e( 'Kerf takes a website your AI tool or designer made — the HTML, the styles, the pictures — and makes it this WordPress site, exactly as it was drawn. Every word and picture stays editable here.', 'kerf-blocks' ); ?></p>
			<p>
				<a class="kerf-btn kerf-btn--primary kerf-btn--lg" href="<?php echo esc_url( kerf_dashboard_url( 'kerf-import' ) ); ?>"><?php esc_html_e( 'Import a design', 'kerf-blocks' ); ?></a>
			</p>
		</div>
		<ol class="kerf-path">
			<li>
				<strong><?php esc_html_e( 'Make the design', 'kerf-blocks' ); ?></strong>
				<span>
					<?php
					printf(
						/* translators: %s: link to the brief. */
						esc_html__( 'In ChatGPT, Claude, Gemini or any tool that writes websites — %s makes it import cleanly.', 'kerf-blocks' ),
						'<a href="' . esc_url( kerf_dashboard_url( 'kerf-import' ) . '#kerf-brief' ) . '">' . esc_html__( 'Kerf\'s brief', 'kerf-blocks' ) . '</a>'
					);
					?>
				</span>
			</li>
			<li>
				<strong><?php esc_html_e( 'Import the ZIP', 'kerf-blocks' ); ?></strong>
				<span><?php esc_html_e( 'Kerf checks it first and says what will and will not work, before anything is written.', 'kerf-blocks' ); ?></span>
			</li>
			<li>
				<strong><?php esc_html_e( 'Edit it in WordPress', 'kerf-blocks' ); ?></strong>
				<span><?php esc_html_e( 'Words, pictures, links and menus, in the editor, with your design drawn as it is.', 'kerf-blocks' ); ?></span>
			</li>
		</ol>
	</section>
	<?php
}

/**
 * With a design: it, what needs the owner, every screen.
 *
 * @param array $design From kerf_dashboard_design().
 */
function kerf_dashboard_render_design( $design ) {
	$page       = (int) $design['page'];
	$front      = 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === $page;
	$status     = kerf_dashboard_status();
	$tools      = kerf_dashboard_tools();
	$undo       = kerf_undo_get();
	$can_import = kerf_user_can_import();
	?>
	<section class="kerf-panel">
		<div class="kerf-design">
			<div class="kerf-crop">
				<div class="kerf-preview">
					<iframe src="<?php echo esc_url( add_query_arg( 'kerf_preview', '1', $front ? home_url( '/' ) : get_permalink( $page ) ) ); ?>" title="<?php esc_attr_e( 'Your home page', 'kerf-blocks' ); ?>" loading="lazy" tabindex="-1" aria-hidden="true"></iframe>
				</div>
			</div>
			<div class="kerf-design__info">
				<h2><?php echo esc_html( $design['title'] ); ?></h2>
				<p class="kerf-design__meta">
					<?php
					if ( $design['at'] ) {
						printf(
							/* translators: 1: page title, 2: how long ago, e.g. "2 hours". */
							esc_html__( 'Imported into “%1$s” %2$s ago.', 'kerf-blocks' ),
							esc_html( get_the_title( $page ) ),
							esc_html( human_time_diff( (int) $design['at'] ) )
						);
					} else {
						/* translators: %s: page title. */
						printf( esc_html__( 'Imported into “%s”.', 'kerf-blocks' ), esc_html( get_the_title( $page ) ) );
					}
					echo ' ';
					echo $front ? esc_html__( 'It is the site\'s home page.', 'kerf-blocks' ) : esc_html__( 'It is not the site\'s home page.', 'kerf-blocks' );
					if ( null !== $design['match'] ) {
						echo ' ';
						printf(
							/* translators: %d: a percentage. */
							esc_html__( '%d%% of the design\'s styles still match its markup.', 'kerf-blocks' ),
							(int) $design['match']
						);
					}
					?>
				</p>
				<div class="kerf-actionbar">
					<a class="kerf-btn kerf-btn--primary" href="<?php echo esc_url( get_edit_post_link( $page ) ); ?>"><?php esc_html_e( 'Edit the home page', 'kerf-blocks' ); ?></a>
					<?php if ( $can_import && kerf_dashboard_has_screen( 'kerf-update' ) ) : ?>
						<a class="kerf-btn" href="<?php echo esc_url( kerf_dashboard_url( 'kerf-update' ) ); ?>"><?php esc_html_e( 'Update the design', 'kerf-blocks' ); ?></a>
					<?php endif; ?>
					<?php if ( $can_import ) : ?>
						<a class="kerf-btn kerf-btn--quiet" href="<?php echo esc_url( kerf_dashboard_url( 'kerf-import' ) ); ?>"><?php esc_html_e( 'Import another design', 'kerf-blocks' ); ?></a>
					<?php endif; ?>
				</div>
				<?php if ( $undo && $can_import ) : ?>
					<p class="kerf-help kerf-design__undo">
						<?php
						printf(
							/* translators: 1: what was done, e.g. "Import into “Home”", 2: how long ago, 3: link. */
							esc_html__( 'Last change: %1$s, %2$s ago. %3$s', 'kerf-blocks' ),
							esc_html( $undo['label'] ),
							esc_html( human_time_diff( (int) $undo['at'] ) ),
							'<a href="' . esc_url( kerf_dashboard_url( 'kerf-import' ) ) . '">' . esc_html__( 'Undo it', 'kerf-blocks' ) . '</a>'
						);
						?>
					</p>
				<?php endif; ?>
			</div>
		</div>
	</section>

	<div class="kerf-cols kerf-gap-top">
		<section class="kerf-panel">
			<div class="kerf-panel__head"><h2><?php esc_html_e( 'Everything in Kerf', 'kerf-blocks' ); ?></h2></div>
			<ul class="kerf-tools">
				<?php foreach ( $tools as $tool ) : ?>
					<li>
						<a href="<?php echo esc_url( kerf_dashboard_url( $tool['slug'] ) ); ?>">
							<?php echo kerf_ui_icon( $tool['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
							<strong><?php echo esc_html( $tool['title'] ); ?></strong>
							<span><?php echo esc_html( $tool['text'] ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		</section>

		<section class="kerf-panel">
			<div class="kerf-panel__head"><h2><?php esc_html_e( 'On your site', 'kerf-blocks' ); ?></h2></div>
			<div class="kerf-panel__body">
				<ul class="kerf-status">
					<?php foreach ( $status as $line ) : ?>
						<?php $tone = in_array( $line['tone'], array( 'ok', 'warn', 'bad' ), true ) ? $line['tone'] : 'info'; ?>
						<li class="kerf-check--<?php echo esc_attr( 'bad' === $tone ? 'block' : $tone ); ?>">
							<span class="kerf-check__mark">
								<?php echo kerf_ui_icon( array( 'ok' => 'check', 'warn' => 'alert', 'bad' => 'stop', 'info' => 'info' )[ $tone ] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
							</span>
							<div>
								<p><?php echo esc_html( $line['text'] ); ?></p>
								<?php if ( '' !== $line['url'] ) : ?>
									<a href="<?php echo esc_url( $line['url'] ); ?>"><?php echo esc_html( $line['link'] ); ?></a>
								<?php endif; ?>
							</div>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</section>
	</div>
	<?php
}
