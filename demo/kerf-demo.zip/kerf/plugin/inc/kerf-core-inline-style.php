<?php
/**
 * Keep the mockup's inline styles on the core blocks the converter emits.
 *
 * The Kerf blocks solve this with a real `inlineStyle` attribute their PHP
 * renderer prints (see kerf_render_inline_style_attr()). Core's heading,
 * paragraph, list, quote and table blocks can't: they are STATIC blocks whose
 * saved markup has to match what their JS `save()` regenerates, and a `style`
 * attribute nothing in the block schema accounts for fails block validation —
 * the editor greets the page with "This block contains unexpected or invalid
 * content" and offers to throw the markup away.
 *
 * So the declarations ride in the block comment instead:
 *
 *     <!-- wp:heading {"inlineStyle":"color:#fff"} -->
 *     <h2 class="wp-block-heading">…</h2>
 *     <!-- /wp:heading -->
 *
 * The comment is not part of the validated markup, so save() is untouched and
 * the block stays valid. This file puts the style back on the element at render
 * time, and assets/js/kerf-core-inline-style.js declares the attribute in the
 * editor (otherwise Gutenberg drops the unknown key on the next save), shows it
 * in the sidebar, and previews it on the canvas.
 *
 * Populated by kerf_mc_style_attr() during conversion.
 *
 * The same passthrough carries the mockup's OTHER attributes, as
 * `customAttributes` — exactly the shape the Kerf blocks store them in. Through
 * session 5 a heading or paragraph kept only its class, id and style:
 * `<h2 data-aos="fade-up">` lost its entrance animation, `data-wow-delay` its
 * timing, and every JS hook on a heading its target, with no warning (scar 43).
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Core blocks that carry an `inlineStyle` attribute.
 *
 * Exactly the static core blocks the mockup converter emits. Dynamic core
 * blocks are excluded — they render from attributes, so their own supports
 * already cover styling.
 *
 * @return string[]
 */
function kerf_core_inline_style_blocks() {
	/**
	 * Filter the core blocks that support the Kerf inline-style passthrough.
	 *
	 * @param string[] $blocks Block names.
	 */
	return (array) apply_filters(
		'kerf_core_inline_style_blocks',
		array( 'core/heading', 'core/paragraph' )
	);
}

/**
 * The tag the style belongs on, when it isn't the block's outermost element.
 *
 * Always the first tag in Kerf: the only core blocks the converter emits are
 * heading and paragraph, and neither wraps its content. The hook is kept because
 * the wrapping-block problem is real for anyone who filters
 * `kerf_core_inline_style_blocks` to add, say, core/table — whose markup is
 * `<figure class="wp-block-table"><table>`, and whose mockup `style` meant the
 * table, not the figure.
 *
 * @param string $block_name
 * @return string Uppercase tag name, or '' for "first tag".
 */
function kerf_core_inline_style_target_tag( $block_name ) {
	/**
	 * Filter the element an inline style is applied to for a given core block.
	 *
	 * @param string $tag        Uppercase tag name, or '' for the first tag.
	 * @param string $block_name Block being rendered.
	 */
	return (string) apply_filters( 'kerf_core_inline_style_target_tag', '', $block_name );
}

/**
 * Declare the attribute server-side.
 *
 * `render_block` reads the raw parsed attrs so it doesn't strictly need this,
 * but the REST block-renderer and any code going through WP_Block do, and an
 * undeclared attribute there is silently dropped.
 *
 * @param array  $args Block type registration args.
 * @param string $name Block name.
 * @return array
 */
function kerf_core_inline_style_register_attribute( $args, $name ) {
	if ( ! in_array( $name, kerf_core_inline_style_blocks(), true ) ) {
		return $args;
	}
	if ( empty( $args['attributes'] ) || ! is_array( $args['attributes'] ) ) {
		$args['attributes'] = array();
	}
	$args['attributes']['inlineStyle']      = array( 'type' => 'string', 'default' => '' );
	$args['attributes']['customAttributes'] = array( 'type' => 'object', 'default' => array() );
	// Where a top-level heading came from in the mockup (§5.28).
	$args['attributes']['kerfSource'] = array( 'type' => 'object' );

	// A designer's heading or paragraph bound to a comment or a tag (§5.25)
	// reads it from the loop's context, and WP_Block hands a block only the
	// context its type asks for.
	$args['uses_context'] = array_values( array_unique( array_merge(
		isset( $args['uses_context'] ) ? (array) $args['uses_context'] : array(),
		array( 'postId', 'postType', 'commentId', 'termId', 'taxonomy' )
	) ) );
	return $args;
}
add_filter( 'register_block_type_args', 'kerf_core_inline_style_register_attribute', 10, 2 );

/**
 * Put the saved declarations back onto the rendered element.
 *
 * Merges with (rather than replaces) any style the block already printed from
 * its own supports, and comes last so the field an author edits wins.
 *
 * @param string $block_content Rendered block HTML.
 * @param array  $block         Parsed block (raw comment attrs in `attrs`).
 * @return string
 */
function kerf_core_inline_style_render( $block_content, $block ) {
	if ( ( empty( $block['attrs']['inlineStyle'] ) && empty( $block['attrs']['customAttributes'] ) )
		|| '' === trim( (string) $block_content ) ) {
		return $block_content;
	}
	$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
	if ( ! in_array( $name, kerf_core_inline_style_blocks(), true ) ) {
		return $block_content;
	}

	// Shared with the Kerf blocks: decodes kses escaping and refuses a hostile
	// declaration; the attribute policy is kerf_attribute_pairs(), theirs too.
	$style = kerf_inline_style_value( $block['attrs'] );
	$pairs = kerf_attribute_pairs( $block['attrs'] );
	if ( '' === $style && empty( $pairs ) ) {
		return $block_content;
	}

	$tags   = new WP_HTML_Tag_Processor( $block_content );
	$target = kerf_core_inline_style_target_tag( $name );
	$found  = $target ? $tags->next_tag( array( 'tag_name' => $target ) ) : $tags->next_tag();
	if ( ! $found ) {
		return $block_content;
	}

	if ( '' !== $style ) {
		$existing = $tags->get_attribute( 'style' );
		$existing = is_string( $existing ) ? trim( $existing, " \t\n\r;" ) : '';
		$tags->set_attribute( 'style', $existing ? $existing . ';' . $style : $style );
	}

	foreach ( $pairs as $attribute => $value ) {
		// What the block itself printed wins: its class and id are its own.
		if ( null === $tags->get_attribute( $attribute ) ) {
			$tags->set_attribute( $attribute, $value );
		}
	}

	return $tags->get_updated_html();
}
add_filter( 'render_block', 'kerf_core_inline_style_render', 9, 2 );

/**
 * Whether the paragraphs rendering now are WordPress content (a post written
 * in the editor) rather than the mockup's. A stack, because post content can
 * render inside a template that is itself inside a page.
 *
 * @param bool|null $push  True/false to enter a scope, null to leave one; omit to read.
 * @param bool      $pop   Leave the current scope.
 * @param bool      $depth Return how many post contents deep the render is instead.
 * @return bool|int The current scope: true inside WordPress content.
 */
function kerf_paragraph_scope( $push = null, $pop = false, $depth = false ) {
	static $stack = array();
	if ( $pop ) {
		array_pop( $stack );
	} elseif ( null !== $push ) {
		$stack[] = (bool) $push;
	}
	if ( $depth ) {
		return count( $stack );
	}
	return ! empty( $stack ) && end( $stack );
}

/**
 * Enter a post's content: WordPress content, unless the post is the mockup.
 *
 * @param array $parsed_block
 * @return array
 */
function kerf_paragraph_scope_enter( $parsed_block ) {
	if ( isset( $parsed_block['blockName'] ) && 'core/post-content' === $parsed_block['blockName'] ) {
		kerf_paragraph_scope( ! ( function_exists( 'kerf_shell_is_mockup_post' ) && kerf_shell_is_mockup_post( get_post() ) ) );
	}
	return $parsed_block;
}
add_filter( 'render_block_data', 'kerf_paragraph_scope_enter', 5 );

/**
 * Leave it.
 *
 * @param string $block_content
 * @param array  $block
 * @return string
 */
function kerf_paragraph_scope_leave( $block_content, $block ) {
	if ( isset( $block['blockName'] ) && 'core/post-content' === $block['blockName'] ) {
		kerf_paragraph_scope( null, true );
	}
	return $block_content;
}
add_filter( 'render_block', 'kerf_paragraph_scope_leave', 5, 2 );

/**
 * Take WordPress 7.0's `wp-block-paragraph` back off the mockup's paragraphs.
 *
 * WordPress 7.0 began adding the class to every paragraph at render
 * (block_core_paragraph_add_class()). §5.6 chose core/paragraph because it
 * added nothing at all; now it adds a class the designer never wrote, and
 * `p:not([class])` — how a lot of typography CSS picks plain paragraphs —
 * stops matching every paragraph that had none (scar 46). Paragraphs written in
 * WordPress keep it; the mockup's lose it, unless the designer wrote it.
 *
 * @param string $block_content
 * @param array  $block
 * @return string
 */
function kerf_paragraph_strip_core_class( $block_content, $block ) {
	if ( kerf_paragraph_scope() || '' === (string) $block_content ) {
		return $block_content;
	}
	// Under another theme only the mockup's own content is Kerf's; that theme's
	// templates keep the class its CSS may be written against.
	if ( ! kerf_theme_active() && 0 === kerf_paragraph_scope( null, false, true ) ) {
		return $block_content;
	}
	$own = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( preg_match( '/(?:^|\s)wp-block-paragraph(?:\s|$)/', $own ) ) {
		return $block_content;
	}

	$tags = new WP_HTML_Tag_Processor( $block_content );
	if ( $tags->next_tag( 'p' ) ) {
		$tags->remove_class( 'wp-block-paragraph' );
	}
	return $tags->get_updated_html();
}
add_filter( 'render_block_core/paragraph', 'kerf_paragraph_strip_core_class', 20, 2 );

/**
 * Editor side: declare the attribute, expose it in the sidebar, preview it.
 */
function kerf_core_inline_style_editor_assets() {
	$rel  = 'assets/js/kerf-core-inline-style.js';
	$path = kerf_plugin_path( $rel );

	// filemtime() on a missing file is a warning AND a cache-buster of `false`,
	// so guard rather than assume. The script itself is not optional: see its
	// docblock — without it the editor drops the attribute on save.
	if ( ! file_exists( $path ) ) {
		return;
	}

	wp_enqueue_script(
		'kerf-core-inline-style',
		kerf_plugin_url( $rel ),
		array( 'wp-hooks', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-compose', 'wp-i18n' ),
		filemtime( $path ),
		true
	);
	wp_set_script_translations( 'kerf-core-inline-style', 'kerf-blocks', kerf_plugin_path( 'languages' ) );

	wp_localize_script(
		'kerf-core-inline-style',
		'KerfCoreInlineStyle',
		array( 'blocks' => array_values( kerf_core_inline_style_blocks() ) )
	);
}
add_action( 'enqueue_block_editor_assets', 'kerf_core_inline_style_editor_assets' );
