<?php
/**
 * The document shell: `<html>`, `<body>`, and what sits directly between them.
 *
 * A converted page's MARKUP is the mockup's, block for block. The shell around
 * it was WordPress', and it disagreed with the mockup in three ways that no
 * block can fix:
 *
 *   1. `<html>` attributes were dropped. Bootstrap's own examples size the page
 *      with `<html class="h-100">` and pick a colour scheme with
 *      `data-bs-theme`; a Modernizr template gates its styles on `class="no-js"`.
 *   2. `<body>` kept only its classes. Scripts configure themselves from the body
 *      — Bootstrap 4 scrollspy is `<body data-spy="scroll" data-target="…">` and
 *      nothing else — and `<body id="page-top">` is what a Start Bootstrap
 *      template's "back to top" links point at.
 *   3. Core wraps every block template in `<div class="wp-site-blocks">`. So
 *      `body > header` stopped matching, and a sticky-footer layout written as
 *      `body { display:flex; flex-direction:column }` found one flex item — the
 *      wrapper — instead of the header, main and footer it was written for.
 *
 * All three are fixed at the one place they can be: the template canvas, the
 * PHP file core renders every block template through. Kerf ships an exact copy
 * of core's that prints the mockup's attributes and leaves the wrapper out. It is
 * swapped in through `template_include` and only replaces core's own canvas, so
 * a plugin that routes to its own template is untouched.
 *
 * Nothing here affects the editor, which renders its own document.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option holding the mockup's `<html>` attributes.
 */
const KERF_HTML_OPTION = 'kerf_html_attributes';

/**
 * Option holding the page frame: kerf/div attributes, outermost first. See
 * kerf_import_split(), rule 1, and kerf_render_frame_block().
 */
const KERF_FRAME_OPTION = 'kerf_frame';

/**
 * The stored page frame, validated: a list of kerf/div attribute arrays.
 *
 * @return array[]
 */
function kerf_frame_get() {
	$frame = get_option( KERF_FRAME_OPTION, array() );
	if ( ! is_array( $frame ) ) {
		return array();
	}
	return array_values( array_filter( $frame, 'is_array' ) );
}

/**
 * Render kerf/frame — the mockup's page wrapper, around every page.
 *
 * Templates wrap the header part, the content and the footer part in this
 * block. With no frame recorded (most mockups) it renders its content and
 * nothing else. With one (`<div id="wrapper">` around the whole of HTML5 UP's
 * Massively, `.cover-container` around Bootstrap's cover example) it re-emits
 * the designer's element — through kerf/div's renderer, so the attribute policy
 * and URL handling are the ones every other element gets — and puts what sat
 * beside it in the mockup, the `page-start` and `page-end` parts, outside it.
 * The home page's DOM is therefore exactly the mockup's, and every other page
 * is framed the same way.
 *
 * The frame is not a block anyone edits: it comes from the import, and a
 * designer's wrapper element belongs to the whole site, not to a template.
 *
 * @param array  $attrs   Block attributes (unused).
 * @param string $content Inner blocks, rendered.
 * @return string
 */
function kerf_render_frame_block( $attrs, $content = '' ) {
	$frame = kerf_frame_get();
	if ( empty( $frame ) ) {
		return $content;
	}

	$html = $content;
	foreach ( array_reverse( $frame ) as $element ) {
		$html = kerf_render_div_block( $element, $html );
	}

	return kerf_frame_render_part( 'page-start' ) . $html . kerf_frame_render_part( 'page-end' );
}

/**
 * Hand the frame to its editor script, so the canvas draws the same element.
 */
function kerf_frame_editor_data() {
	if ( wp_script_is( 'kerf-frame-editor', 'registered' ) ) {
		wp_localize_script( 'kerf-frame-editor', 'KerfFrame', array( 'frame' => kerf_frame_get() ) );
	}
}
add_action( 'init', 'kerf_frame_editor_data', 21 );

/**
 * Render one of the frame's companion template parts, unwrapped.
 *
 * @param string $slug 'page-start' or 'page-end'.
 * @return string
 */
function kerf_frame_render_part( $slug ) {
	return do_blocks( '<!-- wp:template-part ' . wp_json_encode( array( 'slug' => $slug, 'theme' => get_stylesheet() ) ) . ' /-->' );
}

/**
 * Wrap a Kerf theme template in kerf/frame as it loads.
 *
 * The frame used to be written into every template file. The theme's
 * templates are WordPress' own blocks now, so the theme stands on its own
 * (§8.14) — and the plugin adds the frame as a template loads, for the page
 * and the Site Editor alike, in exactly the markup the files had. Once: a
 * template that already holds a frame (saved in the Site Editor with one, or
 * written by Kerf Pro's import, kerf_import_template_content()) is left alone.
 * Blank has none — its header and footer are in the page — and a template
 * another plugin registered is that plugin's.
 *
 * @param WP_Block_Template|null $template
 * @return WP_Block_Template|null
 */
function kerf_frame_wrap( $template ) {
	if ( ! $template instanceof WP_Block_Template || 'wp_template' !== $template->type || 'blank' === $template->slug ) {
		return $template;
	}
	if ( 'plugin' === $template->source || ! kerf_theme_active() ) {
		return $template;
	}

	$content = (string) $template->content;
	if ( false !== strpos( $content, '<!-- wp:kerf/frame' ) ) {
		return $template;
	}

	$template->content = '<!-- wp:kerf/frame {"lock":{"move":true,"remove":true}} -->' . "\n" . rtrim( $content ) . "\n" . '<!-- /wp:kerf/frame -->' . "\n";

	return $template;
}

/**
 * The frame for every template a query returns.
 *
 * @param WP_Block_Template[] $templates
 * @param array               $query
 * @param string              $type
 * @return WP_Block_Template[]
 */
function kerf_frame_wrap_templates( $templates, $query = array(), $type = 'wp_template' ) {
	if ( 'wp_template' !== $type || ! is_array( $templates ) ) {
		return $templates;
	}
	return array_map( 'kerf_frame_wrap', $templates );
}
add_filter( 'get_block_templates', 'kerf_frame_wrap_templates', 10, 3 );

/**
 * The frame for one template looked up by id.
 *
 * @param WP_Block_Template|null $template
 * @param string                 $id
 * @param string                 $type
 * @return WP_Block_Template|null
 */
function kerf_frame_wrap_template( $template, $id = '', $type = 'wp_template' ) {
	return 'wp_template' === $type ? kerf_frame_wrap( $template ) : $template;
}
add_filter( 'get_block_template', 'kerf_frame_wrap_template', 10, 3 );
add_filter( 'get_block_file_template', 'kerf_frame_wrap_template', 10, 3 );

/**
 * Should a block marked `kerfOnly: "front"` render on this request?
 *
 * "Front" means the page the mockup was imported as: the header part's home
 * intro belongs to that page wherever it sits. It is usually the front page,
 * and a site that never set one still shows the intro on the imported page.
 *
 * @return bool
 */
function kerf_block_is_home() {
	$page = (int) get_option( 'kerf_mockup_page', 0 );

	if ( $page && is_page( $page ) ) {
		return true;
	}

	return is_front_page() && ( ! $page || (int) get_option( 'page_on_front' ) === $page );
}

/**
 * Leave the designer's text exactly as written.
 *
 * Core rewrites text on its way to the page, and on a converted page all of it
 * is the mockup's copy:
 *
 *   wptexturize()      `I'm` → `I’m`, `...` → `…`, `--` → `–`. Runs over the
 *                      whole block template, so it reaches the header and
 *                      footer parts on every page, not just the post content.
 *   capital_P_dangit() `Wordpress Developer` → `WordPress Developer`, in the
 *                      middle of someone's CV.
 *   convert_smilies()  `:)` → an <img>, an element the designer never wrote.
 *
 * Each also changes glyph widths, so a heading can wrap differently. Found on
 * two of the first two real templates tried. Site-wide, because the template
 * parts that carry mockup text render on every page; a site that wants smart
 * quotes back in its blog posts can say so.
 */
function kerf_verbatim_text() {
	// Another theme's posts keep WordPress' text as that theme expects.
	if ( ! kerf_theme_active() ) {
		return;
	}

	/**
	 * Filter whether core's text-rewriting filters are switched off.
	 *
	 * @param bool $verbatim True to render text exactly as written.
	 */
	if ( ! apply_filters( 'kerf_verbatim_text', true ) ) {
		return;
	}

	add_filter( 'run_wptexturize', '__return_false' );
	add_filter( 'option_use_smilies', '__return_false' );
	remove_filter( 'the_content', 'capital_P_dangit', 11 );

	// And the emoji script, which swaps a design's emoji for <img class="emoji">
	// wherever the browser's own emoji font is missing: a logo's "⚡" became an
	// image, the bar it sat in 4px shorter, and every element below it moved.
	// Browsers have drawn emoji themselves for years.
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
}
add_action( 'after_setup_theme', 'kerf_verbatim_text' );

/**
 * Use Kerf's canvas wherever core would use its own.
 *
 * @param string $template Template file about to be included.
 * @return string
 */
function kerf_template_canvas( $template ) {
	if ( wp_normalize_path( (string) $template ) !== wp_normalize_path( ABSPATH . WPINC . '/template-canvas.php' ) ) {
		return $template;
	}

	// Another block theme's pages keep core's canvas: the mockup's document
	// attributes and the unwrapped `wp-site-blocks` belong to Kerf's templates.
	if ( ! kerf_theme_active() ) {
		return $template;
	}

	/**
	 * Filter whether Kerf renders block templates through its own canvas.
	 *
	 * Return false to get core's canvas back — the mockup's `<html>` and
	 * `<body>` attributes are then lost again, and the `wp-site-blocks` wrapper
	 * returns.
	 *
	 * @param bool $use Whether to use Kerf's canvas.
	 */
	if ( ! apply_filters( 'kerf_use_template_canvas', true ) ) {
		return $template;
	}

	$canvas = kerf_plugin_path( 'inc/kerf-template-canvas.php' );

	return file_exists( $canvas ) ? $canvas : $template;
}
add_filter( 'template_include', 'kerf_template_canvas', 20 );

/**
 * Remove core's `<div class="wp-site-blocks">` from rendered template HTML.
 *
 * Core builds the string as `'<div class="wp-site-blocks">' . $content . '</div>'`
 * and may insert its skip link in front of it. So the wrapper is exactly the
 * first occurrence of that opening tag and the final `</div>` — nothing has to
 * be parsed, and anything that does not have that exact shape is left alone.
 *
 * @param string $html Output of get_the_block_template_html().
 * @return string
 */
function kerf_unwrap_site_blocks( $html ) {
	$html  = (string) $html;
	$open  = '<div class="wp-site-blocks">';
	$start = strpos( $html, $open );
	$end   = strrpos( $html, '</div>' );

	if ( false === $start || false === $end || $end < $start + strlen( $open ) ) {
		return $html;
	}
	if ( '' !== trim( substr( $html, $end + 6 ) ) ) {
		return $html;
	}

	return substr( $html, 0, $start )
		. substr( $html, $start + strlen( $open ), $end - $start - strlen( $open ) );
}

/**
 * The mockup's attributes for the document's `<html>` or `<body>` tag.
 *
 * Printed after what WordPress prints (`language_attributes()`, `body_class()`),
 * so anything WordPress owns is never duplicated: the site's `lang` stays the
 * site's, the body's classes arrive through `body_class`, and a `dir` is only
 * added where WordPress printed none.
 *
 * The mockup is third-party markup, so the same policy as a block's attributes
 * applies — kerf_render_attributes() drops event handlers, `srcdoc`, script
 * URLs and malformed names, and `style` goes through the same filter as a
 * block's inline style.
 *
 * @param string $which 'html' or 'body'.
 * @return string Leading-space-prefixed attribute markup, or ''.
 */
function kerf_document_attributes( $which ) {
	$out = '';
	// The site's design, or this page's own (kerf_assets_design()).
	$design = kerf_assets_design();

	if ( 'html' === $which ) {
		$attrs = $design['html'];

		unset( $attrs['lang'], $attrs['xml:lang'] );
		if ( is_rtl() ) {
			unset( $attrs['dir'] );
		}

		if ( ! empty( $attrs['class'] ) ) {
			$out .= ' class="' . esc_attr( trim( $attrs['class'] ) ) . '"';
		}
	} else {
		$body  = $design['body'];
		$attrs = isset( $body['attributes'] ) && is_array( $body['attributes'] ) ? $body['attributes'] : array();

		// Same shape check as a block anchor: an id with whitespace or a quote in
		// it is not an id.
		$id = isset( $body['id'] ) ? trim( (string) $body['id'] ) : '';
		if ( '' !== $id && ! preg_match( '/["\'\s<>]/', $id ) ) {
			$out .= ' id="' . esc_attr( $id ) . '"';
		}
	}

	if ( isset( $attrs['style'] ) ) {
		$style = kerf_inline_style_value( array( 'inlineStyle' => (string) $attrs['style'] ) );
		if ( '' !== $style ) {
			$out .= ' style="' . esc_attr( $style ) . '"';
		}
	}

	return $out . kerf_render_attributes( array( 'customAttributes' => $attrs ) );
}
