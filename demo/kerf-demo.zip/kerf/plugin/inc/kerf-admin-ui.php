<?php
/**
 * Kerf's admin screens: the frame every one of them is drawn in.
 *
 * One header — the mark, the screen's name, what the screen can do — one
 * stylesheet (assets/css/kerf-admin.css) and one script (assets/js/kerf-admin.js)
 * for every Kerf screen, the free plugin's and Kerf Pro's, so the menu reads as
 * one product: Dashboard, Import, Update, Inner pages, Links, Site details,
 * Form entries, Settings, in the order someone works through them.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The Kerf menu's order, by slug: what comes first is what a site owner does
 * first. A screen an add-on adds and this list does not name goes before
 * Settings.
 *
 * @return string[]
 */
function kerf_ui_menu_order() {
	return array(
		'kerf',
		'kerf-import',
		// Kerf Pro's "Build with AI": a design made, then imported.
		'kerf-build',
		// Kerf Pro's "Make a page": one more page, in the design imported.
		'kerf-page',
		'kerf-update',
		'kerf-inner-pages',
		'kerf-links',
		'kerf-site',
		'edit.php?post_type=kerf_entry',
		'kerf-settings',
		// Freemius's pages for a sold copy (kerf_fs(), functions.php): the
		// licence, a message to kerf.site, more sites.
		'kerf-account',
		'kerf-contact',
		'kerf-pricing',
	);
}

/**
 * Put the Kerf menu in that order. WordPress lists a menu's screens in the
 * order they were added, and a post type's screen (Form entries) is added
 * before any plugin's — it came first.
 */
function kerf_ui_sort_menu() {
	global $submenu;

	if ( empty( $submenu['kerf'] ) || ! is_array( $submenu['kerf'] ) ) {
		return;
	}

	$order    = kerf_ui_menu_order();
	$settings = array_search( 'kerf-settings', $order, true );
	$rank     = static function ( $item ) use ( $order, $settings ) {
		$at = array_search( isset( $item[2] ) ? $item[2] : '', $order, true );
		return false === $at ? $settings - 0.5 : $at;
	};

	$items = array_values( $submenu['kerf'] );
	foreach ( $items as $index => $item ) {
		$items[ $index ]['kerf_rank'] = array( $rank( $item ), $index );
	}
	usort( $items, static function ( $a, $b ) {
		return $a['kerf_rank'] <=> $b['kerf_rank'];
	} );
	foreach ( $items as $index => $item ) {
		unset( $items[ $index ]['kerf_rank'] );
	}

	$submenu['kerf'] = $items; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- reordering Kerf's own menu, the one way WordPress offers.
}
add_action( 'admin_menu', 'kerf_ui_sort_menu', 999 );

/**
 * Is this admin screen one of Kerf's?
 *
 * @param string $hook The screen's hook suffix.
 * @return bool
 */
function kerf_ui_is_kerf_screen( $hook ) {
	if ( 'toplevel_page_kerf' === $hook || 0 === strpos( (string) $hook, 'kerf_page_' ) ) {
		return true;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	return $screen && 'kerf_entry' === $screen->post_type;
}

/**
 * The stylesheet and script every Kerf screen shares.
 *
 * @param string $hook
 */
function kerf_ui_admin_assets( $hook ) {
	if ( ! kerf_ui_is_kerf_screen( $hook ) ) {
		return;
	}

	foreach ( array( 'css/kerf-admin.css', 'js/kerf-admin.js' ) as $rel ) {
		$path = kerf_plugin_path( 'assets/' . $rel );
		if ( ! file_exists( $path ) ) {
			continue;
		}
		if ( '.css' === substr( $rel, -4 ) ) {
			wp_enqueue_style( 'kerf-admin', kerf_plugin_url( 'assets/' . $rel ), array(), filemtime( $path ) );
		} else {
			wp_enqueue_script( 'kerf-admin', kerf_plugin_url( 'assets/' . $rel ), array( 'wp-i18n' ), filemtime( $path ), true );
			wp_set_script_translations( 'kerf-admin', 'kerf-blocks', kerf_plugin_path( 'languages' ) );
		}
	}
}
add_action( 'admin_enqueue_scripts', 'kerf_ui_admin_assets' );

/**
 * Open a Kerf screen: the header, WordPress's notices under it, and the
 * screen's lede.
 *
 * @param string $title The screen's name.
 * @param array  $args  {
 *     @type string $lede    One or two sentences on what the screen is for.
 *     @type string $actions HTML for the header's end: a button or two.
 *     @type string $class   More classes on the wrap.
 * }
 */
function kerf_ui_open( $title, $args = array() ) {
	$args = wp_parse_args( $args, array(
		'lede'    => '',
		'actions' => '',
		'class'   => '',
	) );

	printf( '<div class="wrap kerf-admin kerf-ui %s">', esc_attr( $args['class'] ) );
	echo '<header class="kerf-head">';
	printf(
		'<a class="kerf-head__brand" href="%s">%s<span>%s</span></a>',
		esc_url( admin_url( 'admin.php?page=kerf' ) ),
		kerf_ui_mark(), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG.
		esc_html__( 'Kerf', 'kerf-blocks' )
	);
	echo '<span class="kerf-head__sep" aria-hidden="true"></span>';
	echo '<h1 class="kerf-head__title">' . esc_html( $title ) . '</h1>';

	$end = $args['actions'];
	/**
	 * Whether the header shows the Pro badge — Kerf Pro answers, with its
	 * licence.
	 *
	 * @param bool $pro
	 */
	if ( apply_filters( 'kerf_ui_pro_active', false ) ) {
		$end .= '<span class="kerf-pill kerf-pill--pro">' . esc_html__( 'Pro', 'kerf-blocks' ) . '</span>';
	}
	if ( '' !== $end ) {
		echo '<div class="kerf-head__end">' . $end . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the caller's escaped markup.
	}
	echo '</header>';

	// WordPress moves its notices here, under the header rather than into it.
	echo '<hr class="wp-header-end">';

	if ( '' !== $args['lede'] ) {
		echo '<p class="kerf-lede">' . esc_html( $args['lede'] ) . '</p>';
	}
}

/**
 * Close a Kerf screen.
 */
function kerf_ui_close() {
	echo '</div>';
}

/**
 * Kerf's mark: a k whose arm is cut away from its stem by a thin gap — the
 * kerf, the slot a saw leaves.
 *
 * @param string $class
 * @return string SVG.
 */
function kerf_ui_mark( $class = 'kerf-head__mark' ) {
	return '<svg class="' . esc_attr( $class ) . '" viewBox="0 0 32 32" aria-hidden="true" focusable="false">'
		. '<rect width="32" height="32" rx="8" fill="currentColor"/>'
		. '<path d="M10.5 8v16M22 8l-7.5 8 7.5 8" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>'
		. '</svg>';
}

/**
 * A small line icon, drawn in the text's colour.
 *
 * @param string $name check, alert, stop, info, upload, file, page, header,
 *                     footer, template, link, external, undo, refresh, copy, paste,
 *                     image, mail, phone, home, chevron, spark.
 * @return string SVG, or '' for an unknown name.
 */
function kerf_ui_icon( $name ) {
	$paths = array(
		'check'    => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
		'alert'    => '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5M12 17.5v.01"/>',
		'stop'     => '<circle cx="12" cy="12" r="8.5"/><path d="M9 9l6 6M15 9l-6 6"/>',
		'info'     => '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5.5M12 7.5v.01"/>',
		'upload'   => '<path d="M12 15V4.5M7.5 9L12 4.5 16.5 9"/><path d="M4.5 15.5v3a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5v-3"/>',
		'file'     => '<path d="M14 3.5H7a1.5 1.5 0 0 0-1.5 1.5v14A1.5 1.5 0 0 0 7 20.5h10a1.5 1.5 0 0 0 1.5-1.5V8z"/><path d="M14 3.5V8h4.5"/>',
		'page'     => '<rect x="5.5" y="3.5" width="13" height="17" rx="1.5"/><path d="M8.5 8h7M8.5 11.5h7M8.5 15h4"/>',
		'header'   => '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M3.5 9h17"/>',
		'footer'   => '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M3.5 15h17"/>',
		'template' => '<rect x="3.5" y="4.5" width="17" height="15" rx="1.5"/><path d="M9 4.5v15M9 10h11.5"/>',
		'link'     => '<path d="M10 14a3.5 3.5 0 0 0 5 0l3-3a3.5 3.5 0 0 0-5-5l-1 1"/><path d="M14 10a3.5 3.5 0 0 0-5 0l-3 3a3.5 3.5 0 0 0 5 5l1-1"/>',
		'external' => '<path d="M13.5 4.5h6v6M19.5 4.5l-8 8"/><path d="M17.5 13.5v4.5a1.5 1.5 0 0 1-1.5 1.5H6a1.5 1.5 0 0 1-1.5-1.5V8A1.5 1.5 0 0 1 6 6.5h4.5"/>',
		'undo'     => '<path d="M8.5 5L4.5 9l4 4"/><path d="M4.5 9h10a5 5 0 0 1 0 10H9"/>',
		'refresh'  => '<path d="M19.5 12a7.5 7.5 0 0 1-13.1 5"/><path d="M4.5 12a7.5 7.5 0 0 1 13.1-5"/><path d="M17.6 3.5V7h-3.5M6.4 20.5V17h3.5"/>',
		'copy'     => '<rect x="8.5" y="8.5" width="11" height="11" rx="1.5"/><path d="M15.5 8.5V6A1.5 1.5 0 0 0 14 4.5H6A1.5 1.5 0 0 0 4.5 6v8A1.5 1.5 0 0 0 6 15.5h2.5"/>',
		'paste'    => '<rect x="5.5" y="4.5" width="13" height="16" rx="1.5"/><path d="M9.5 4.5V3.5h5v1M9 10h6M9 13.5h6M9 17h3.5"/>',
		'image'    => '<rect x="3.5" y="5" width="17" height="14" rx="1.5"/><circle cx="9" cy="10" r="1.75"/><path d="M20.5 16l-5-5L6 19"/>',
		'mail'     => '<rect x="3.5" y="5.5" width="17" height="13" rx="1.5"/><path d="M4 7l8 6 8-6"/>',
		'phone'    => '<path d="M7.5 4h2.5l1.5 4-2 1.25a9 9 0 0 0 4.75 4.75L15.5 12l4 1.5V16a2 2 0 0 1-2 2A13.5 13.5 0 0 1 5.5 6a2 2 0 0 1 2-2z"/>',
		'home'     => '<path d="M4.5 11L12 4.5l7.5 6.5"/><path d="M6.5 9.5v9.5h11V9.5"/>',
		'chevron'  => '<path d="M9 6l6 6-6 6"/>',
		// AI's mark (Kerf Pro's kerf_pro_ai_icon()), for its Dashboard tile.
		'spark'    => '<path d="M11 5c.6 4.6 3.4 7.4 8 8-4.6.6-7.4 3.4-8 8-.6-4.6-3.4-7.4-8-8 4.6-.6 7.4-3.4 8-8z"/><path d="M18.5 3v4M16.5 5h4"/>',
	);
	if ( ! isset( $paths[ $name ] ) ) {
		return '';
	}
	return '<svg class="kerf-icon kerf-icon--' . esc_attr( $name ) . '" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">' . $paths[ $name ] . '</svg>';
}

/**
 * A short label: a state, a kind, a count.
 *
 * @param string $text
 * @param string $tone ok, warn, bad, quiet, pro.
 * @return string
 */
function kerf_ui_pill( $text, $tone = 'quiet' ) {
	return '<span class="kerf-pill kerf-pill--' . esc_attr( $tone ) . '">' . esc_html( $text ) . '</span>';
}

/**
 * A message inside a screen, in the screen's own look (WordPress's notices
 * are for the whole admin).
 *
 * @param string $text Plain text.
 * @param string $tone ok, warn, bad, info.
 * @return string
 */
function kerf_ui_note( $text, $tone = 'info' ) {
	$icons = array( 'ok' => 'check', 'warn' => 'alert', 'bad' => 'stop', 'info' => 'info' );
	return '<div class="kerf-note kerf-note--' . esc_attr( $tone ) . '" role="' . ( 'bad' === $tone ? 'alert' : 'status' ) . '">'
		. kerf_ui_icon( isset( $icons[ $tone ] ) ? $icons[ $tone ] : 'info' )
		. '<p>' . esc_html( $text ) . '</p></div>';
}

/**
 * The line over the screen while the server works on a submitted form
 * (`data-working` on the form or its button; assets/js/kerf-admin.js).
 */
function kerf_ui_working() {
	echo '<div class="kerf-working" aria-hidden="true"><div class="kerf-working__box" role="status" aria-live="polite"><div class="kerf-working__bar"></div><p class="kerf-working__text"></p></div></div>';
}

/**
 * One setting on Kerf → Settings: its name and what it does, then its
 * control (printed between this and kerf_ui_setting_close()). The settings
 * sections an add-on adds (`kerf_settings_sections`) use it too.
 *
 * @param string $name
 * @param string $description
 */
function kerf_ui_setting_open( $name, $description = '' ) {
	echo '<div class="kerf-setting"><div class="kerf-setting__name"><strong>' . esc_html( $name ) . '</strong>';
	if ( '' !== $description ) {
		echo '<p>' . esc_html( $description ) . '</p>';
	}
	echo '</div><div class="kerf-setting__control">';
}

/**
 * Close a setting opened with kerf_ui_setting_open().
 */
function kerf_ui_setting_close() {
	echo '</div></div>';
}

/**
 * Where a design's ZIP is dropped or chosen — the import's, the update's —
 * inside the crop marks. A plain file field without the screen's script.
 *
 * @param string $name  The file field.
 * @param string $title What to drop.
 */
function kerf_ui_drop( $name = 'kerf_zip', $title = '' ) {
	?>
	<div class="kerf-crop">
		<label class="kerf-drop">
			<input type="file" name="<?php echo esc_attr( $name ); ?>" accept=".zip,application/zip">
			<span class="kerf-drop__empty">
				<span class="kerf-drop__icon"><?php echo kerf_ui_icon( 'upload' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
				<span class="kerf-drop__title"><?php echo esc_html( '' !== $title ? $title : __( 'Drop the ZIP here', 'kerf-blocks' ) ); ?></span>
				<span class="kerf-drop__hint">
					<?php
					printf(
						/* translators: %s: "choose it on your computer", a link-like phrase. */
						esc_html__( 'or %s. Up to 64 MB.', 'kerf-blocks' ),
						'<span class="kerf-drop__browse">' . esc_html__( 'choose it on your computer', 'kerf-blocks' ) . '</span>'
					);
					?>
				</span>
			</span>
			<span class="kerf-drop__file">
				<?php echo kerf_ui_icon( 'file' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
				<span>
					<strong data-file-name></strong>
					<span data-file-meta></span>
				</span>
			</span>
		</label>
	</div>
	<?php
}

/**
 * A flow's steps, and where the screen is among them.
 *
 * @param string[] $steps   Their names, in order.
 * @param int      $current 1-based.
 * @param string   $label   What the steps are of, for screen readers.
 */
function kerf_ui_steps( $steps, $current, $label ) {
	echo '<ol class="kerf-steps" aria-label="' . esc_attr( $label ) . '">';
	foreach ( array_values( $steps ) as $i => $name ) {
		$n = $i + 1;
		printf(
			'<li class="%s"%s>%s</li>',
			esc_attr( $n < $current ? 'is-done' : ( $n === $current ? 'is-current' : '' ) ),
			$n === $current ? ' aria-current="step"' : '',
			esc_html( $name )
		);
	}
	echo '</ol>';
}

/**
 * Kerf's header on the screens WordPress draws for Kerf — the list of form
 * entries and each entry (Kerf Pro's) — above WordPress's own.
 */
function kerf_ui_wp_screen_head() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'kerf_entry' !== $screen->post_type ) {
		return;
	}
	printf(
		'<div class="kerf-ui kerf-ui--strip"><div class="kerf-head"><a class="kerf-head__brand" href="%s">%s<span>%s</span></a><span class="kerf-head__sep" aria-hidden="true"></span><span class="kerf-head__title">%s</span>%s</div></div>',
		esc_url( admin_url( 'admin.php?page=kerf' ) ),
		kerf_ui_mark(), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG.
		esc_html__( 'Kerf', 'kerf-blocks' ),
		esc_html( 'post' === $screen->base ? __( 'Form entry', 'kerf-blocks' ) : __( 'Form entries', 'kerf-blocks' ) ),
		apply_filters( 'kerf_ui_pro_active', false ) ? '<div class="kerf-head__end"><span class="kerf-pill kerf-pill--pro">' . esc_html__( 'Pro', 'kerf-blocks' ) . '</span></div>' : ''
	);
}
add_action( 'in_admin_header', 'kerf_ui_wp_screen_head' );
