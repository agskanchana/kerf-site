<?php
/**
 * The pause between an import's check and its writing — and Kerf Pro's
 * update's — by token (inc/kerf-import.php, THE CHECK, AND THE PAUSE).
 *
 * Its own file, loaded late and only if nothing has these yet: they were Kerf
 * Pro's until session 16, and a Kerf Pro from before then declares them too.
 * Declared twice is a fatal error on every page of the site, between
 * updating one plugin and the other. peek() and put() came in 0.4.0, for
 * Kerf Pro's AI; a Kerf Pro that calls them declares none of these.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'KERF_IMPORT_PENDING_OPTION' ) ) {
	/**
	 * Imports and updates paused before writing, by token.
	 */
	define( 'KERF_IMPORT_PENDING_OPTION', 'kerf_import_pending' );
}

// Every function below reads the pause from the database, not from what this
// PHP process read earlier (wp_cache_delete() first): Kerf Pro's AI marks a
// page in the pause after a minute of the model's work, and get_option() would
// answer with the pause as it was before that minute — every other import
// started, finished or marked meanwhile written back over (scar 100).

/**
 * Park a staged design until the owner has chosen — an import's, or an
 * update's comparison (Kerf Pro).
 *
 * @param array|null $staging From kerf_import_unzip(), documents included; null for a paste.
 * @param string[]   $actions What was done so far, for the report.
 * @param string     $kind    'import' or 'sync'.
 * @param array      $extra   More to keep: the check's findings, the paste.
 * @return string Token.
 */
function kerf_import_pending_save( $staging, $actions, $kind = 'import', $extra = array() ) {
	wp_cache_delete( KERF_IMPORT_PENDING_OPTION, 'options' );
	$all   = kerf_import_pending_prune( get_option( KERF_IMPORT_PENDING_OPTION, array() ) );
	$token = strtolower( wp_generate_password( 24, false ) );

	$all[ $token ] = array_merge(
		array(
			'html'      => '',
			'preflight' => array(),
			'base_url'  => '',
			'name'      => '',
			'title'     => '',
		),
		(array) $extra,
		array(
			'kind'    => $kind,
			'user'    => get_current_user_id(),
			'created' => time(),
			'staging' => $staging,
			'actions' => $actions,
		)
	);
	update_option( KERF_IMPORT_PENDING_OPTION, $all, false );

	return $token;
}

/**
 * Take a parked design: once, only by the user who started it, and only for
 * what it was parked for — an import or an update's comparison.
 *
 * @param string $token
 * @param string $kind 'import' or 'sync'.
 * @return array|null
 */
function kerf_import_pending_take( $token, $kind = 'import' ) {
	wp_cache_delete( KERF_IMPORT_PENDING_OPTION, 'options' );
	$all = get_option( KERF_IMPORT_PENDING_OPTION, array() );
	if ( ! is_array( $all ) || ! isset( $all[ $token ] ) ) {
		return null;
	}
	$pending = $all[ $token ];
	if ( (int) $pending['user'] !== get_current_user_id()
		|| ( isset( $pending['kind'] ) ? $pending['kind'] : 'import' ) !== $kind ) {
		return null;
	}
	unset( $all[ $token ] );
	update_option( KERF_IMPORT_PENDING_OPTION, $all, false );
	return $pending;
}

/**
 * Read a parked design without taking it — for an add-on that changes what
 * it holds before the owner imports it (Kerf Pro's AI marks a page). The same
 * rules as taking it: only its user, only for its kind, and not after a day.
 *
 * @param string $token
 * @param string $kind 'import' or 'sync'.
 * @return array|null
 */
function kerf_import_pending_peek( $token, $kind = 'import' ) {
	wp_cache_delete( KERF_IMPORT_PENDING_OPTION, 'options' );
	$all = get_option( KERF_IMPORT_PENDING_OPTION, array() );
	if ( ! is_array( $all ) || ! isset( $all[ $token ] ) || ! is_array( $all[ $token ] ) ) {
		return null;
	}
	$pending = $all[ $token ];
	if ( (int) $pending['user'] !== get_current_user_id()
		|| ( isset( $pending['kind'] ) ? $pending['kind'] : 'import' ) !== $kind
		|| empty( $pending['created'] ) || (int) $pending['created'] < time() - DAY_IN_SECONDS ) {
		return null;
	}
	return $pending;
}

/**
 * Put a parked design back, changed. Whose it is, what it is for and when it
 * was parked stay as they were: only what it holds changes.
 *
 * Read it again (kerf_import_pending_peek()) just before: what was read before
 * a slow step — a model's answer — may have been changed by another request
 * since, and this replaces the whole of it.
 *
 * @param string $token
 * @param array  $pending From kerf_import_pending_peek(), changed.
 * @param string $kind    'import' or 'sync'.
 * @return bool Whether it was put back.
 */
function kerf_import_pending_put( $token, $pending, $kind = 'import' ) {
	wp_cache_delete( KERF_IMPORT_PENDING_OPTION, 'options' );
	$all = get_option( KERF_IMPORT_PENDING_OPTION, array() );
	if ( ! is_array( $all ) || ! isset( $all[ $token ] ) || ! is_array( $pending ) ) {
		return false;
	}
	$was = $all[ $token ];
	if ( (int) $was['user'] !== get_current_user_id() || ( isset( $was['kind'] ) ? $was['kind'] : 'import' ) !== $kind ) {
		return false;
	}
	foreach ( array( 'user', 'kind', 'created' ) as $kept ) {
		$pending[ $kept ] = isset( $was[ $kept ] ) ? $was[ $kept ] : null;
	}
	$all[ $token ] = $pending;
	update_option( KERF_IMPORT_PENDING_OPTION, $all, false );
	return true;
}

/**
 * Drop what nobody finished within a day, with its staged files.
 *
 * @param mixed $all
 * @return array
 */
function kerf_import_pending_prune( $all ) {
	$all = is_array( $all ) ? $all : array();
	foreach ( $all as $token => $pending ) {
		if ( empty( $pending['created'] ) || (int) $pending['created'] < time() - DAY_IN_SECONDS ) {
			kerf_import_discard( isset( $pending['staging'] ) ? $pending['staging'] : null );
			unset( $all[ $token ] );
		}
	}
	return $all;
}
