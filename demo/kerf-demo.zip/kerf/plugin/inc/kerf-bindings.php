<?php
/**
 * Live WordPress data in the designer's markup.
 *
 * A designed blog page is a list of cards someone wrote by hand. Making it show
 * real posts must not replace those cards with WordPress' own (`core/query`,
 * `core/post-template`, `core/post-title` — every one of them adds wrappers and
 * `wp-block-*` classes the designer's CSS never targets). So nothing is replaced.
 * The designer's element stays, byte for byte, and only its VALUE comes from
 * WordPress, through the Block Bindings API:
 *
 *   kerf/post    the post in context — the loop's current post, or the one
 *                being viewed: title, link, date, author, excerpt, image,
 *                category, tags, comment count, previous and next post
 *   kerf/query   the page as a whole: the archive or search title, its
 *                description, the search terms, the number of results
 *
 * Bindings are recorded by the converter from the markup contract — the
 * `data-kerf-field` attributes a designer (or their AI) puts on the mockup; see
 * kerf_mc_field_bindings() — and by the theme's own inner-page templates.
 *
 * Three blocks carry what a binding cannot: `kerf/loop` repeats one card per
 * post, `kerf/post-content` puts the post's body inside the designer's article
 * element, and `kerf/pagination` rebuilds the designer's own page links.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The bindable attributes of Kerf's blocks. Core's heading and paragraph are
 * bindable already.
 *
 * @return array<string,string[]>
 */
function kerf_bindings_supported_attributes() {
	return array(
		'kerf/text'  => array( 'text' ),
		'kerf/link'  => array( 'text', 'url' ),
		'kerf/image' => array( 'src', 'alt', 'mediaId' ),
		'kerf/div'   => array( 'backgroundImage', 'backgroundImageId' ),
	);
}

foreach ( kerf_bindings_supported_attributes() as $kerf_block => $kerf_attributes ) {
	add_filter(
		'block_bindings_supported_attributes_' . $kerf_block,
		function ( $supported ) use ( $kerf_attributes ) {
			return array_values( array_unique( array_merge( (array) $supported, $kerf_attributes ) ) );
		}
	);
}
unset( $kerf_block, $kerf_attributes );

/**
 * Register the two sources.
 */
function kerf_bindings_register_sources() {
	if ( ! function_exists( 'register_block_bindings_source' ) ) {
		return;
	}

	register_block_bindings_source( 'kerf/post', array(
		'label'              => __( 'Post (Kerf)', 'kerf-blocks' ),
		'get_value_callback' => 'kerf_bindings_post_value',
		'uses_context'       => array( 'postId', 'postType' ),
	) );

	register_block_bindings_source( 'kerf/query', array(
		'label'              => __( 'Page (Kerf)', 'kerf-blocks' ),
		'get_value_callback' => 'kerf_bindings_query_value',
	) );

	register_block_bindings_source( 'kerf/comment', array(
		'label'              => __( 'Comment (Kerf)', 'kerf-blocks' ),
		'get_value_callback' => 'kerf_bindings_comment_value',
		'uses_context'       => array( 'commentId' ),
	) );

	register_block_bindings_source( 'kerf/term', array(
		'label'              => __( 'Tag or category (Kerf)', 'kerf-blocks' ),
		'get_value_callback' => 'kerf_bindings_term_value',
		'uses_context'       => array( 'termId', 'taxonomy' ),
	) );
}
add_action( 'init', 'kerf_bindings_register_sources' );

/**
 * The keys each source understands, with a label for the editor.
 *
 * @return array{post:array<string,string>,query:array<string,string>}
 */
function kerf_bindings_keys() {
	return array(
		'post'  => array(
			'title'          => __( 'Post title', 'kerf-blocks' ),
			'permalink'      => __( 'Post link', 'kerf-blocks' ),
			'date'           => __( 'Post date', 'kerf-blocks' ),
			'modified'       => __( 'Last updated', 'kerf-blocks' ),
			'author'         => __( 'Author', 'kerf-blocks' ),
			'author-url'     => __( 'Author link', 'kerf-blocks' ),
			'author-bio'     => __( 'Author bio', 'kerf-blocks' ),
			'author-avatar'  => __( 'Author picture', 'kerf-blocks' ),
			'excerpt'        => __( 'Excerpt', 'kerf-blocks' ),
			'image'          => __( 'Featured image', 'kerf-blocks' ),
			'image-alt'      => __( 'Featured image alt text', 'kerf-blocks' ),
			'image-id'       => __( 'Featured image', 'kerf-blocks' ),
			'category'       => __( 'Category', 'kerf-blocks' ),
			'category-url'   => __( 'Category link', 'kerf-blocks' ),
			'tags'           => __( 'Tags', 'kerf-blocks' ),
			'comments-count' => __( 'Comment count', 'kerf-blocks' ),
			'prev-title'     => __( 'Previous post title', 'kerf-blocks' ),
			'prev-url'       => __( 'Previous post link', 'kerf-blocks' ),
			'next-title'     => __( 'Next post title', 'kerf-blocks' ),
			'next-url'       => __( 'Next post link', 'kerf-blocks' ),
		),
		'query' => array(
			'title'        => __( 'Page title', 'kerf-blocks' ),
			'description'  => __( 'Archive description', 'kerf-blocks' ),
			'search-query' => __( 'Search terms', 'kerf-blocks' ),
			'count'        => __( 'Number of results', 'kerf-blocks' ),
		),
		'comment' => array(
			'author'     => __( 'Commenter', 'kerf-blocks' ),
			'author-url' => __( 'Commenter\'s website', 'kerf-blocks' ),
			'date'       => __( 'Comment date', 'kerf-blocks' ),
			'text'       => __( 'Comment', 'kerf-blocks' ),
			'avatar'     => __( 'Commenter\'s picture', 'kerf-blocks' ),
			'link'       => __( 'Comment link', 'kerf-blocks' ),
		),
		'term'    => array(
			'name'  => __( 'Tag or category', 'kerf-blocks' ),
			'link'  => __( 'Tag or category link', 'kerf-blocks' ),
			'count' => __( 'Number of posts', 'kerf-blocks' ),
		),
	);
}

/**
 * The words the designer wrote around a value — "by Admin", "20 Comments" —
 * kept around the real one (kerf_mc_text_binding() recorded them).
 *
 * @param string $value
 * @param array  $args  `before` / `after`.
 * @return string
 */
function kerf_bindings_affix( $value, array $args ) {
	$value = (string) $value;
	if ( '' === $value ) {
		return '';
	}
	return ( isset( $args['before'] ) ? (string) $args['before'] : '' ) . $value . ( isset( $args['after'] ) ? (string) $args['after'] : '' );
}

/**
 * The comment a kerf/comment binding reads: the loop's.
 *
 * @param WP_Block $block
 * @return WP_Comment|null
 */
function kerf_bindings_comment( $block ) {
	$id = 0;
	if ( $block instanceof WP_Block && ! empty( $block->context['commentId'] ) ) {
		$id = (int) $block->context['commentId'];
	}
	if ( ! $id ) {
		$item = kerf_bindings_current_item();
		$id   = isset( $item['commentId'] ) ? (int) $item['commentId'] : 0;
	}
	$comment = $id ? get_comment( $id ) : null;
	if ( ! $comment ) {
		return null;
	}
	// Approved, or the visitor's own awaiting moderation — what the loop lists.
	if ( '1' !== (string) $comment->comment_approved ) {
		$commenter = wp_get_current_commenter();
		$own       = ( is_user_logged_in() && (int) $comment->user_id === get_current_user_id() )
			|| ( ! empty( $commenter['comment_author_email'] ) && $commenter['comment_author_email'] === $comment->comment_author_email );
		if ( '0' !== (string) $comment->comment_approved || ! $own ) {
			return null;
		}
	}
	// A comment on a post the visitor cannot read is not theirs to see either.
	$post = get_post( $comment->comment_post_ID );
	if ( ! $post || ( 'publish' !== $post->post_status && ! current_user_can( 'read_post', $post->ID ) ) ) {
		return null;
	}
	return $comment;
}

/**
 * kerf/comment: a value of the comment in context.
 *
 * @param array    $args `key`, and `format` (date) / `size` (avatar).
 * @param WP_Block $block
 * @param string   $attribute
 * @return mixed
 */
function kerf_bindings_comment_value( array $args, $block, $attribute ) {
	$comment = kerf_bindings_comment( $block );
	if ( ! $comment ) {
		return null;
	}

	switch ( isset( $args['key'] ) ? (string) $args['key'] : '' ) {
		case 'author':
			return kerf_bindings_text_for( kerf_bindings_plain( get_comment_author( $comment ) ), $block );
		case 'author-url':
			return (string) get_comment_author_url( $comment );
		case 'date':
			$format = isset( $args['format'] ) && '' !== $args['format'] ? (string) $args['format'] : get_option( 'date_format' );
			return kerf_bindings_text_for( kerf_bindings_plain( get_comment_date( $format, $comment ) ), $block );
		case 'text':
			return kerf_bindings_text_for( kerf_bindings_plain( get_comment_text( $comment ) ), $block );
		case 'avatar':
			return (string) get_avatar_url( $comment, array( 'size' => isset( $args['size'] ) ? max( 16, min( 512, (int) $args['size'] ) ) : 96 ) );
		case 'link':
			return (string) get_comment_link( $comment );
	}

	return null;
}

/**
 * kerf/term: a value of the tag or category in context.
 *
 * @param array    $args `key`.
 * @param WP_Block $block
 * @param string   $attribute
 * @return mixed
 */
function kerf_bindings_term_value( array $args, $block, $attribute ) {
	$id = 0;
	if ( $block instanceof WP_Block && ! empty( $block->context['termId'] ) ) {
		$id = (int) $block->context['termId'];
	}
	if ( ! $id ) {
		$item = kerf_bindings_current_item();
		$id   = isset( $item['termId'] ) ? (int) $item['termId'] : 0;
	}
	$term = $id ? get_term( $id ) : null;
	if ( ! $term || is_wp_error( $term ) ) {
		return null;
	}

	switch ( isset( $args['key'] ) ? (string) $args['key'] : '' ) {
		case 'name':
			return kerf_bindings_text_for( kerf_bindings_plain( $term->name ), $block );
		case 'link':
			$link = get_term_link( $term );
			return is_wp_error( $link ) ? '' : (string) $link;
		case 'count':
			return kerf_bindings_text_for( (string) (int) $term->count, $block );
	}

	return null;
}

/**
 * Plain text from something WordPress hands back as HTML with entities.
 *
 * @param string $html
 * @return string
 */
function kerf_bindings_plain( $html ) {
	return trim( html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
}

/**
 * Shape a text value for the block it is going into.
 *
 * Core's rich-text attributes are spliced into HTML (through wp_kses_post), so
 * they need escaped text. Kerf's blocks escape at render and want it plain.
 *
 * @param string   $text  Plain text.
 * @param WP_Block $block
 * @return string
 */
function kerf_bindings_text_for( $text, $block ) {
	$name = ( $block instanceof WP_Block ) ? (string) $block->name : '';
	return 0 === strpos( $name, 'core/' ) ? esc_html( $text ) : $text;
}

/**
 * The post a kerf/post binding reads: the loop's, or the one being viewed.
 *
 * @param WP_Block $block
 * @return WP_Post|null
 */
function kerf_bindings_post( $block ) {
	$id = 0;
	// `context` holds only what the block's TYPE declares (every Kerf block
	// that binds declares postId). `available_context` is not readable from
	// outside WP_Block in current WordPress, so it is no fallback; the global
	// post is — kerf/loop sets it for each card, as core/post-template does.
	if ( $block instanceof WP_Block && ! empty( $block->context['postId'] ) ) {
		$id = (int) $block->context['postId'];
	}
	if ( ! $id ) {
		$id = (int) get_the_ID();
	}

	$post = $id ? get_post( $id ) : null;
	if ( ! $post ) {
		return null;
	}

	// The loop only ever queries published posts; anything reached another way
	// (a stale postId in hand-edited markup) must be one the visitor may read.
	if ( 'publish' !== $post->post_status && ! current_user_can( 'read_post', $post->ID ) ) {
		return null;
	}

	return $post;
}

/**
 * kerf/post: a value of the post in context.
 *
 * Returns null when there is nothing to show, which leaves the designer's
 * placeholder in place — except for the keys a missing value should blank,
 * like a post with no image.
 *
 * @param array    $args      `key`, and `format` (date) / `words` (excerpt) / `size` (image).
 * @param WP_Block $block
 * @param string   $attribute The attribute being bound.
 * @return mixed
 */
function kerf_bindings_post_value( array $args, $block, $attribute ) {
	$key  = isset( $args['key'] ) ? (string) $args['key'] : '';
	$post = kerf_bindings_post( $block );

	if ( ! $post ) {
		return null;
	}

	switch ( $key ) {
		case 'title':
			return kerf_bindings_text_for( kerf_bindings_plain( get_the_title( $post ) ), $block );

		case 'permalink':
			return (string) get_permalink( $post );

		case 'date':
		case 'modified':
			$format = isset( $args['format'] ) && '' !== $args['format'] ? (string) $args['format'] : get_option( 'date_format' );
			$value  = 'date' === $key ? get_the_date( $format, $post ) : get_the_modified_date( $format, $post );
			return kerf_bindings_text_for( kerf_bindings_plain( $value ), $block );

		case 'author':
			return kerf_bindings_text_for( kerf_bindings_affix( (string) get_the_author_meta( 'display_name', $post->post_author ), $args ), $block );

		case 'author-url':
			return (string) get_author_posts_url( (int) $post->post_author );

		case 'author-bio':
			return kerf_bindings_text_for( kerf_bindings_plain( get_the_author_meta( 'description', $post->post_author ) ), $block );

		case 'author-avatar':
			return (string) get_avatar_url( (int) $post->post_author, array( 'size' => isset( $args['size'] ) ? max( 16, min( 512, (int) $args['size'] ) ) : 96 ) );

		case 'excerpt':
			$words = isset( $args['words'] ) ? max( 1, min( 200, (int) $args['words'] ) ) : 30;
			$text  = post_password_required( $post ) ? '' : kerf_bindings_plain( get_the_excerpt( $post ) );
			return kerf_bindings_text_for( wp_trim_words( $text, $words, '…' ), $block );

		case 'image':
		case 'image-alt':
		case 'image-id':
			// No featured image: a background outside a loop — a page's
			// banner marked for it — keeps the design's picture (null leaves
			// the attribute as written), so an imported page looks as
			// designed until one is chosen. A picture of the post itself (an
			// <img>), or a card's in a loop, shows none: the sample is no
			// picture of this post.
			if ( ! has_post_thumbnail( $post ) ) {
				if ( ! kerf_bindings_in_loop() && in_array( (string) $attribute, array( 'backgroundImage', 'backgroundImageId' ), true ) ) {
					return null;
				}
				return 'image-id' === $key ? 0 : '';
			}
			if ( 'image-alt' === $key ) {
				return (string) get_post_meta( get_post_thumbnail_id( $post ), '_wp_attachment_image_alt', true );
			}
			if ( 'image-id' === $key ) {
				return (int) get_post_thumbnail_id( $post );
			}
			// The slot the sample picture filled (`fit`: its width and height),
			// else a named size, else large.
			if ( isset( $args['fit'] ) && is_array( $args['fit'] ) && count( $args['fit'] ) === 2 ) {
				$size = array( max( 1, (int) $args['fit'][0] ), max( 1, (int) $args['fit'][1] ) );
			} else {
				$size = isset( $args['size'] ) ? sanitize_key( $args['size'] ) : 'large';
				$size = '' !== $size ? $size : 'large';
			}
			return (string) wp_get_attachment_image_url( get_post_thumbnail_id( $post ), $size );

		case 'category':
		case 'category-url':
			$terms = get_the_category( $post->ID );
			if ( empty( $terms ) ) {
				return 'category' === $key ? '' : null;
			}
			return 'category' === $key
				? kerf_bindings_text_for( kerf_bindings_plain( $terms[0]->name ), $block )
				: (string) get_category_link( $terms[0] );

		case 'tags':
			$tags = get_the_tags( $post->ID );
			return kerf_bindings_text_for( is_array( $tags ) ? implode( ', ', wp_list_pluck( $tags, 'name' ) ) : '', $block );

		case 'comments-count':
			return kerf_bindings_text_for( kerf_bindings_affix( (string) get_comments_number( $post ), $args ), $block );

		case 'prev-title':
		case 'prev-url':
		case 'next-title':
		case 'next-url':
			$adjacent = kerf_bindings_adjacent( $post, 0 === strpos( $key, 'prev' ) );
			if ( ! $adjacent ) {
				return null;
			}
			return '-url' === substr( $key, -4 )
				? (string) get_permalink( $adjacent )
				: kerf_bindings_text_for( kerf_bindings_plain( get_the_title( $adjacent ) ), $block );
	}

	return null;
}

/**
 * The post before or after this one, by date, in the same post type.
 *
 * @param WP_Post $post
 * @param bool    $previous
 * @return WP_Post|null
 */
function kerf_bindings_adjacent( $post, $previous ) {
	$saved           = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
	$GLOBALS['post'] = $post; // get_adjacent_post() reads the global.
	$adjacent        = get_adjacent_post( false, '', $previous );
	$GLOBALS['post'] = $saved;

	return $adjacent instanceof WP_Post ? $adjacent : null;
}

/**
 * kerf/query: a value of the page being viewed.
 *
 * @param array    $args  `key`.
 * @param WP_Block $block
 * @return string|null
 */
function kerf_bindings_query_value( array $args, $block ) {
	$key = isset( $args['key'] ) ? (string) $args['key'] : '';

	switch ( $key ) {
		case 'title':
			return kerf_bindings_text_for( kerf_bindings_query_title(), $block );

		case 'description':
			$description = '';
			if ( is_category() || is_tag() || is_tax() ) {
				$description = term_description();
			} elseif ( is_author() ) {
				$description = get_the_author_meta( 'description', (int) get_query_var( 'author' ) );
			}
			return kerf_bindings_text_for( kerf_bindings_plain( $description ), $block );

		case 'search-query':
			return kerf_bindings_text_for( get_search_query( false ), $block );

		case 'count':
			global $wp_query;
			return kerf_bindings_text_for( (string) (int) ( $wp_query ? $wp_query->found_posts : 0 ), $block );
	}

	return null;
}

/**
 * The title of whatever page is being viewed, as a visitor would say it.
 *
 * @return string Plain text.
 */
function kerf_bindings_query_title() {
	if ( is_search() ) {
		/* translators: %s: search terms. */
		return sprintf( __( 'Search results for “%s”', 'kerf-blocks' ), get_search_query( false ) );
	}
	if ( is_404() ) {
		return __( 'Page not found', 'kerf-blocks' );
	}
	if ( is_home() ) {
		$page = (int) get_option( 'page_for_posts' );
		return $page ? kerf_bindings_plain( get_the_title( $page ) ) : __( 'Blog', 'kerf-blocks' );
	}
	if ( is_category() || is_tag() || is_tax() ) {
		return kerf_bindings_plain( single_term_title( '', false ) );
	}
	if ( is_author() ) {
		return kerf_bindings_plain( get_the_author_meta( 'display_name', (int) get_query_var( 'author' ) ) );
	}
	if ( is_post_type_archive() ) {
		return kerf_bindings_plain( post_type_archive_title( '', false ) );
	}
	if ( is_archive() ) {
		// "Month: September 2026" → "September 2026"; the prefix is a label for
		// screen readers in core's own markup, not a heading.
		add_filter( 'get_the_archive_title_prefix', '__return_empty_string', 99 );
		$title = get_the_archive_title();
		remove_filter( 'get_the_archive_title_prefix', '__return_empty_string', 99 );
		return kerf_bindings_plain( $title );
	}
	if ( is_singular() ) {
		return kerf_bindings_plain( get_the_title() );
	}

	return kerf_bindings_plain( get_bloginfo( 'name' ) );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE THREE BLOCKS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Render kerf/loop — the designer's first card, once per post.
 *
 * No element of its own: the cards are the designer's, and they sit directly
 * in the designer's container, so `.blog-grid > .blog-card` and `:nth-child()`
 * match exactly as they did against the hand-written cards.
 *
 * `query: "main"` repeats over the posts WordPress queried for this page (the
 * blog, an archive, search results) — which is also what makes pagination
 * work. Anything else runs its own query for the latest `perPage` posts: the
 * "Latest from our blog" section of a home page.
 *
 * No posts, no cards — never the mockup's sample posts, which on a live site
 * are fake news with fake dates.
 *
 * @param array    $attrs
 * @param string   $content Unused; the card is rendered once per post.
 * @param WP_Block $block
 * @return string
 */
function kerf_render_loop_block( $attrs, $content = '', $block = null ) {
	if ( ! $block instanceof WP_Block || empty( $block->parsed_block['innerBlocks'] ) ) {
		return '';
	}

	$kind = isset( $attrs['query'] ) ? (string) $attrs['query'] : 'latest';

	// The post's own comments, tags or categories: one card each, with the
	// comment or term as context for kerf/comment and kerf/term.
	if ( in_array( $kind, array( 'comments', 'tags', 'categories' ), true ) ) {
		return kerf_render_item_loop( $kind, $attrs, $block );
	}

	$main = 'main' === $kind;

	if ( $main ) {
		global $wp_query;
		$query = $wp_query;
	} else {
		$per_page = isset( $attrs['perPage'] ) ? max( 1, min( 24, (int) $attrs['perPage'] ) ) : 3;
		$query    = new WP_Query( array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $per_page,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'post__not_in'        => is_singular( 'post' ) ? array( get_the_ID() ) : array(), // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- one ID: the post being read, out of its own "latest".
		) );
	}

	if ( ! $query || empty( $query->posts ) ) {
		return '';
	}

	// Render the inner blocks, not the loop: core/post-template does the same.
	$card              = $block->parsed_block;
	$card['blockName'] = 'core/null';
	$separator         = ! isset( $attrs['gap'] ) || $attrs['gap'] ? "\n" : '';
	$saved             = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
	$out               = array();

	foreach ( $query->posts as $post ) {
		$post = get_post( $post );
		if ( ! $post ) {
			continue;
		}
		// Blocks that read the global post (and core's own post blocks, if a
		// designer's card contains one) see the card's post.
		$GLOBALS['post'] = $post;
		setup_postdata( $post );

		kerf_bindings_in_loop( 1 );
		$out[] = ( new WP_Block( $card, array(
			'postId'   => $post->ID,
			'postType' => $post->post_type,
		) ) )->render( array( 'dynamic' => false ) );
		kerf_bindings_in_loop( -1 );
	}

	$GLOBALS['post'] = $saved;
	if ( $saved instanceof WP_Post ) {
		setup_postdata( $saved );
	}

	return implode( $separator, $out );
}

/**
 * kerf/loop over the post's comments, tags or categories.
 *
 * Comments: the approved ones, oldest first, flat — a designer's sample
 * comment is one card, and a reply drawn indented would need its own. The
 * visitor's own comment awaiting moderation shows too, as WordPress's list
 * does. Tags and categories: the post's, in WordPress's order.
 *
 * @param string   $kind  'comments', 'tags' or 'categories'.
 * @param array    $attrs
 * @param WP_Block $block
 * @return string
 */
function kerf_render_item_loop( $kind, $attrs, $block ) {
	$post = kerf_bindings_post( $block );
	if ( ! $post || post_password_required( $post ) ) {
		return '';
	}

	$contexts = array();

	if ( 'comments' === $kind ) {
		$args = array(
			'post_id' => $post->ID,
			'status'  => 'approve',
			'type'    => 'comment',
			'order'   => 'ASC',
		);
		$commenter = wp_get_current_commenter();
		if ( is_user_logged_in() ) {
			$args['include_unapproved'] = array( get_current_user_id() );
		} elseif ( ! empty( $commenter['comment_author_email'] ) ) {
			$args['include_unapproved'] = array( $commenter['comment_author_email'] );
		}
		foreach ( get_comments( $args ) as $comment ) {
			$contexts[] = array( 'postId' => $post->ID, 'postType' => $post->post_type, 'commentId' => (int) $comment->comment_ID );
		}
	} else {
		$taxonomy = 'tags' === $kind ? 'post_tag' : 'category';
		$terms    = get_the_terms( $post, $taxonomy );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$contexts[] = array( 'postId' => $post->ID, 'postType' => $post->post_type, 'termId' => (int) $term->term_id, 'taxonomy' => $taxonomy );
			}
		}
	}

	$card              = $block->parsed_block;
	$card['blockName'] = 'core/null';
	$separator         = ! isset( $attrs['gap'] ) || $attrs['gap'] ? "\n" : '';
	$out               = array();

	foreach ( $contexts as $context ) {
		kerf_bindings_current_item( $context );
		$out[] = ( new WP_Block( $card, $context ) )->render( array( 'dynamic' => false ) );
		kerf_bindings_current_item( null, true );
	}

	return implode( $separator, $out );
}

/**
 * Is a post loop's card being rendered? Every block has a post in context
 * (WordPress gives the global one), so only the loop can say: a card's
 * picture is its post's, and a page's own banner keeps the design's picture
 * where the page has none (kerf_bg_mark()).
 *
 * @param int $step 1 entering a card, -1 leaving it.
 * @return bool
 */
function kerf_bindings_in_loop( $step = 0 ) {
	static $depth = 0;
	$depth = max( 0, $depth + (int) $step );
	return $depth > 0;
}

/**
 * The comment or term a card of kerf_render_item_loop() is being rendered
 * for — the fallback for a block whose type does not ask for that context.
 * WP_Block hands a block only the context its type declares, and nothing
 * else reaches it: the post loop has the global post for this, and comments
 * and terms have no global of their own.
 *
 * @param array|null $push Context to enter.
 * @param bool       $pop  Leave the current one.
 * @return array The current item's context, or an empty array.
 */
function kerf_bindings_current_item( $push = null, $pop = false ) {
	static $stack = array();
	if ( $pop ) {
		array_pop( $stack );
	} elseif ( null !== $push ) {
		$stack[] = (array) $push;
	}
	return $stack ? end( $stack ) : array();
}

/**
 * Render kerf/comments — the post's comments where the designer marked them.
 *
 * WordPress's own list (wp_list_comments()), and its form when the page has no
 * form of the designer's (`form: false` otherwise — kerf_mc_contract_prepass()
 * decided at import). Inside the designer's own `<ul>`/`<ol>` (`items`), only
 * the items; elsewhere, wrapped in the `<ol class="comment-list">` WordPress's
 * themes use. It replaces core's legacy comments block, which the editor shows
 * as a "switch to editable mode" warning instead of the design.
 *
 * @param array    $attrs
 * @param string   $content Unused.
 * @param WP_Block $block
 * @return string
 */
function kerf_render_comments_block( $attrs, $content = '', $block = null ) {
	$post = kerf_bindings_post( $block );
	if ( ! $post || post_password_required( $post ) ) {
		return '';
	}

	if ( function_exists( 'kerf_shell_enqueue_prose' ) ) {
		kerf_shell_enqueue_prose();
	}

	$args = array(
		'post_id' => $post->ID,
		'status'  => 'approve',
		'order'   => 'ASC',
	);
	$commenter = wp_get_current_commenter();
	if ( is_user_logged_in() ) {
		$args['include_unapproved'] = array( get_current_user_id() );
	} elseif ( ! empty( $commenter['comment_author_email'] ) ) {
		$args['include_unapproved'] = array( $commenter['comment_author_email'] );
	}

	$in_list  = ! empty( $attrs['items'] );
	$comments = ( ! isset( $attrs['list'] ) || $attrs['list'] ) ? get_comments( $args ) : array();
	$html     = '';

	if ( $comments ) {
		$items = wp_list_comments( array(
			'echo'        => false,
			'style'       => 'ol',
			'avatar_size' => 48,
		), $comments );
		$html .= $in_list ? $items : '<ol class="comment-list">' . $items . '</ol>';
	}

	if ( ! $in_list && ( ! isset( $attrs['form'] ) || $attrs['form'] ) && comments_open( $post ) ) {
		ob_start();
		comment_form( array(), $post );
		$html .= ob_get_clean();
	}

	return $html;
}

/**
 * The comment form a designer drew posts to wp-comments-post.php with the
 * post's id in the URL (kerf_apply_element_fields()): putting it in a hidden
 * field would add an element they never wrote. WordPress reads the id from
 * $_POST, after `init` — so it is copied there.
 */
function kerf_comment_form_post_id() {
	if ( 'wp-comments-post.php' !== ( isset( $GLOBALS['pagenow'] ) ? $GLOBALS['pagenow'] : '' ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification -- WordPress's own comment form has no nonce either; this only names the post.
	if ( isset( $_GET['kerf_post'] ) && empty( $_POST['comment_post_ID'] ) ) {
		$_POST['comment_post_ID'] = (string) absint( $_GET['kerf_post'] ); // phpcs:ignore WordPress.Security.NonceVerification -- as above.
	}
}
add_action( 'init', 'kerf_comment_form_post_id', 1 );

/**
 * Render kerf/post-content — the post's body, with no element of its own.
 *
 * The designer's article element around it is theirs (a kerf/div); what goes
 * inside is WordPress content, filtered as `the_content` always is.
 *
 * @param array    $attrs
 * @param string   $content
 * @param WP_Block $block
 * @return string
 */
function kerf_render_post_content_block( $attrs, $content = '', $block = null ) {
	static $seen = array();

	$post = kerf_bindings_post( $block );
	if ( ! $post ) {
		return '';
	}

	// A post that contains its own template (or a template that contains the
	// post) must not render itself forever.
	if ( isset( $seen[ $post->ID ] ) ) {
		return '';
	}
	if ( post_password_required( $post ) ) {
		return get_the_password_form( $post );
	}

	$seen[ $post->ID ] = true;

	if ( function_exists( 'kerf_shell_enqueue_prose' ) ) {
		kerf_shell_enqueue_prose();
	}

	$saved           = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;
	$GLOBALS['post'] = $post;
	setup_postdata( $post );

	// WordPress content: its paragraphs keep WordPress' own class.
	kerf_paragraph_scope( true );
	$html = apply_filters( 'the_content', str_replace( ']]>', ']]&gt;', get_the_content( null, false, $post ) ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- core's filter, applied as WordPress applies it to a post's content.
	kerf_paragraph_scope( null, true );

	$GLOBALS['post'] = $saved;
	if ( $saved instanceof WP_Post ) {
		setup_postdata( $saved );
	}
	unset( $seen[ $post->ID ] );

	return $html;
}

/**
 * Render kerf/pagination — the designer's page links, for the real pages.
 *
 * The converter records the shape of the designer's links (kerf_mc_pagination
 * _pattern()): the element around each item if there is one, the link, the
 * classes that mark the current page, and whatever the designer used for
 * "previous" and "next". Rendered from the main query; nothing when there is
 * only one page.
 *
 * @param array $attrs
 * @return string
 */
function kerf_render_pagination_block( $attrs ) {
	global $wp_query;

	$total = $wp_query ? (int) $wp_query->max_num_pages : 0;
	if ( $total < 2 ) {
		return '';
	}

	$current = max( 1, (int) get_query_var( 'paged' ) );
	$item    = isset( $attrs['item'] ) && is_array( $attrs['item'] ) ? $attrs['item'] : array();
	$out     = '';

	if ( ! empty( $attrs['prev'] ) && $current > 1 ) {
		$out .= kerf_pagination_item( $item, get_pagenum_link( $current - 1 ), $attrs['prev'], false );
	}

	foreach ( kerf_pagination_pages( $current, $total ) as $page ) {
		if ( null === $page ) {
			$out .= kerf_pagination_item( $item, '', array( 'text' => '…' ), false, true );
			continue;
		}
		$out .= kerf_pagination_item( $item, get_pagenum_link( $page ), array( 'text' => (string) $page ), $page === $current );
	}

	if ( ! empty( $attrs['next'] ) && $current < $total ) {
		$out .= kerf_pagination_item( $item, get_pagenum_link( $current + 1 ), $attrs['next'], false );
	}

	return $out;
}

/**
 * The page numbers to show: all of them up to seven, else the first, the last
 * and two either side of the current one, with null where pages are skipped.
 *
 * @param int $current
 * @param int $total
 * @return array<int|null>
 */
function kerf_pagination_pages( $current, $total ) {
	if ( $total <= 7 ) {
		return range( 1, $total );
	}

	$pages = array( 1 );
	$from  = max( 2, $current - 2 );
	$to    = min( $total - 1, $current + 2 );

	if ( $from > 2 ) {
		$pages[] = null;
	}
	for ( $i = $from; $i <= $to; $i++ ) {
		$pages[] = $i;
	}
	if ( $to < $total - 1 ) {
		$pages[] = null;
	}
	$pages[] = $total;

	return $pages;
}

/**
 * One pagination item in the designer's shape.
 *
 * @param array  $item    {wrap:{tag,class,currentClass}|null, link:{tag,class,currentClass}}.
 * @param string $url     '' for a gap.
 * @param array  $label   {text, icon} — what the link shows.
 * @param bool   $current
 * @param bool   $gap
 * @return string
 */
function kerf_pagination_item( $item, $url, $label, $current, $gap = false ) {
	$wrap = isset( $item['wrap'] ) && is_array( $item['wrap'] ) ? $item['wrap'] : null;
	$link = isset( $item['link'] ) && is_array( $item['link'] ) ? $item['link'] : array( 'tag' => 'a' );

	// "Previous" and "Next" the designer styled apart from the numbers.
	if ( ! empty( $label['class'] ) ) {
		$link['class'] = (string) $label['class'];
	}

	$classes = function ( $spec ) use ( $current ) {
		$class = isset( $spec['class'] ) ? (string) $spec['class'] : '';
		if ( $current && ! empty( $spec['currentClass'] ) ) {
			$class = trim( $class . ' ' . $spec['currentClass'] );
		}
		return '' === $class ? '' : ' class="' . esc_attr( $class ) . '"';
	};

	$inner = '';
	if ( ! empty( $label['icon'] ) ) {
		$inner .= '<i class="' . esc_attr( $label['icon'] ) . '"></i>';
	}
	if ( isset( $label['text'] ) && '' !== $label['text'] ) {
		$inner .= esc_html( $label['text'] );
	}

	// The designer's own tags: `.pagination a.active` has to keep matching. A gap
	// is not a link; the current page is one only if the designer made it one.
	if ( $gap || '' === $url ) {
		$tag = 'span';
	} elseif ( $current && isset( $link['currentTag'] ) && 'span' === $link['currentTag'] ) {
		$tag = 'span';
	} else {
		$tag = 'a';
	}

	$html  = '<' . $tag . $classes( $link );
	$html .= 'a' === $tag ? ' href="' . esc_url( $url ) . '"' : '';
	$html .= $current ? ' aria-current="page"' : '';
	$html .= '>' . $inner . '</' . $tag . '>';

	if ( $wrap ) {
		$wrap_tag = kerf_safe_tag( isset( $wrap['tag'] ) ? $wrap['tag'] : 'li', 'li' );
		$html     = '<' . $wrap_tag . $classes( $wrap ) . '>' . $html . '</' . $wrap_tag . '>';
	}

	return $html;
}

// ═══════════════════════════════════════════════════════════════════════════════
// FIELDS ON THE DESIGNER'S OWN ELEMENTS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The data-kerf-field names on a block, from its custom attributes.
 *
 * @param array $attrs
 * @return string[]
 */
function kerf_block_fields( $attrs ) {
	// The designer's marker, and the one Kerf sets itself on a search form it
	// recognised (`kerfFields`, never printed).
	$raw = trim(
		( isset( $attrs['customAttributes']['data-kerf-field'] ) ? (string) $attrs['customAttributes']['data-kerf-field'] : '' )
		. ' ' . ( isset( $attrs['kerfFields'] ) ? (string) $attrs['kerfFields'] : '' )
	);
	return '' === $raw ? array() : array_values( array_unique( preg_split( '/\s+/', strtolower( $raw ) ) ) );
}

/**
 * Apply the fields that live in an element's attributes rather than its value:
 * a card's link to its post, and the designer's search form.
 *
 * Block bindings replace block ATTRIBUTES; an element's `href` or a form's
 * `action` is one entry in `customAttributes`, which a binding cannot address.
 * So these are applied at render, from the marker the designer wrote.
 *
 * @param array         $attrs kerf/div (or kerf/text) attributes.
 * @param WP_Block|null $block
 * @return array The attributes to render with.
 */
function kerf_apply_element_fields( $attrs, $block = null ) {
	$fields = kerf_block_fields( $attrs );
	if ( empty( $fields ) ) {
		return $attrs;
	}

	$custom = isset( $attrs['customAttributes'] ) && is_array( $attrs['customAttributes'] ) ? $attrs['customAttributes'] : array();

	if ( in_array( 'comments', $fields, true ) && function_exists( 'kerf_shell_enqueue_prose' ) ) {
		kerf_shell_enqueue_prose();
	}

	if ( array_key_exists( 'href', $custom ) ) {
		$post   = kerf_bindings_post( $block );
		$target = null;

		if ( $post && array_intersect( $fields, array( 'permalink', 'title' ) ) ) {
			$target = $post;
		} elseif ( $post && array_intersect( $fields, array( 'prev', 'next' ) ) ) {
			// A "previous post" link built from an icon and a label: the label
			// is the designer's, the destination is the neighbouring post.
			$target = kerf_bindings_adjacent( $post, in_array( 'prev', $fields, true ) );
		}

		if ( $target ) {
			$custom['href']    = (string) get_permalink( $target );
			$attrs['linkType'] = ''; // A bound link goes to its post, not to a page.
		}

		// A tag or category card that is one link (kerf_mc_mark_card_links()).
		if ( in_array( 'term-link', $fields, true ) ) {
			$link = kerf_bindings_term_value( array( 'key' => 'link' ), $block, 'href' );
			if ( is_string( $link ) && '' !== $link ) {
				$custom['href']    = $link;
				$attrs['linkType'] = '';
			}
		}
	}

	// A background a script sets from `data-setbg` (or `data-bg`, `data-src`):
	// the post's featured image goes where the script will read it. Without
	// one, a card in a loop shows none; a page's own banner, the design's.
	if ( in_array( 'image', $fields, true ) ) {
		$post  = kerf_bindings_post( $block );
		$image = ( $post && has_post_thumbnail( $post ) ) ? (string) wp_get_attachment_image_url( get_post_thumbnail_id( $post ), 'large' ) : '';
		foreach ( '' !== $image || kerf_bindings_in_loop() ? $custom : array() as $name => $value ) {
			if ( 0 === strpos( (string) $name, 'data-' ) && is_string( $value )
				&& preg_match( '/\.(?:jpe?g|png|gif|webp|avif|svg)(?:[?#].*)?$/i', trim( $value ) ) ) {
				if ( '' !== $image ) {
					$custom[ $name ] = $image;
				} else {
					unset( $custom[ $name ] );
				}
			}
		}
	}

	if ( in_array( 'search-form', $fields, true ) ) {
		$custom['action'] = home_url( '/' );
		$custom['method'] = 'get';
		$custom['role']   = isset( $custom['role'] ) ? $custom['role'] : 'search';
		// The design's own answer to a search — a mockup's script searched the
		// page it was on, or nothing — no longer stops it reaching WordPress
		// (assets/js/kerf-search.js); an inline one goes, as a sent form's does.
		unset( $custom['onsubmit'] );
		if ( function_exists( 'kerf_enqueue_front_script' ) ) {
			kerf_enqueue_front_script( 'kerf-search' );
		}
	}

	if ( in_array( 'search-input', $fields, true ) ) {
		$custom['name']  = 's';
		$custom['value'] = get_search_query( false );
	}

	// The designer's comment form, sent to WordPress as drawn: the post's id
	// travels in the URL (kerf_comment_form_post_id()), so no hidden field is
	// added to their markup.
	if ( in_array( 'comment-form', $fields, true ) ) {
		$post             = kerf_bindings_post( $block );
		$custom['action'] = add_query_arg( 'kerf_post', $post ? $post->ID : 0, site_url( '/wp-comments-post.php' ) );
		$custom['method'] = 'post';
	}

	// Its fields, by the names WordPress reads — filled in for a returning
	// visitor, as WordPress's own form is, from the cookies it set.
	$names     = array(
		'comment-text'   => array( 'comment', '' ),
		'comment-author' => array( 'author', 'comment_author' ),
		'comment-email'  => array( 'email', 'comment_author_email' ),
		'comment-url'    => array( 'url', 'comment_author_url' ),
	);
	$commenter = null;
	foreach ( $names as $field => $name ) {
		if ( ! in_array( $field, $fields, true ) ) {
			continue;
		}
		$custom['name'] = $name[0];
		if ( '' !== $name[1] ) {
			$commenter = null === $commenter ? wp_get_current_commenter() : $commenter;
			if ( ! empty( $commenter[ $name[1] ] ) ) {
				$custom['value'] = $commenter[ $name[1] ];
			}
		}
	}

	$attrs['customAttributes'] = $custom;

	return $attrs;
}

/**
 * Should a bound element be left out altogether? A "next post" link on the
 * newest post, a category line on an uncategorised one.
 *
 * @param array         $attrs
 * @param WP_Block|null $block
 * @return bool
 */
function kerf_field_is_empty( $attrs, $block = null ) {
	$fields = kerf_block_fields( $attrs );

	// A comment form on a post that takes no comments has nothing to send.
	if ( in_array( 'comment-form', $fields, true ) ) {
		$post = kerf_bindings_post( $block );
		return ! $post || post_password_required( $post ) || ! comments_open( $post );
	}

	if ( ! array_intersect( $fields, array( 'prev', 'next' ) ) ) {
		return false;
	}

	$post = kerf_bindings_post( $block );
	if ( ! $post ) {
		return true;
	}

	return null === kerf_bindings_adjacent( $post, in_array( 'prev', $fields, true ) );
}
