<?php
/**
 * The business's details, changed once (§5.36).
 *
 * A phone number is in the top bar, the footer and the contact page; so are
 * the email, the address and the social links. The converter binds each
 * occurrence to one key (kerf_mc_site_detail(): a `tel:` link, a `mailto:`
 * link, a profile link, or anything marked `data-kerf-site`), the import keeps
 * the design's values here, and Kerf → Site details changes every place at
 * once. A text link or text leaf is bound through Block Bindings (`kerf/site`),
 * so the editor shows the value too; an icon link or an address written on two
 * lines carries `kerfSite`, read at render (kerf_site_apply()).
 *
 * Finding and binding them at import, and the Site details screen, are Kerf
 * Pro's (its import asks the converter for `site_details`;
 * pro/inc/kerf-pro-site-details.php). Here: the stored details and everything
 * that shows them, so what Pro bound keeps showing without it.
 *
 * Stored as `kerf_site_details`: key => { text: as shown, href: the link }.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_SITE_OPTION = 'kerf_site_details';

/**
 * Every stored detail.
 *
 * @return array<string,array{text:string,href:string}>
 */
function kerf_site_details() {
	$details = get_option( KERF_SITE_OPTION, array() );
	return is_array( $details ) ? $details : array();
}

/**
 * The keys Kerf knows, with a label; others (`phone-2`) are labelled from these.
 *
 * @return array<string,string>
 */
function kerf_site_labels() {
	return array(
		'phone'     => __( 'Phone', 'kerf-blocks' ),
		'email'     => __( 'Email', 'kerf-blocks' ),
		'address'   => __( 'Address', 'kerf-blocks' ),
		'hours'     => __( 'Opening hours', 'kerf-blocks' ),
		'facebook'  => 'Facebook',
		'instagram' => 'Instagram',
		'x'         => 'X (Twitter)',
		'linkedin'  => 'LinkedIn',
		'youtube'   => 'YouTube',
		'tiktok'    => 'TikTok',
		'whatsapp'  => 'WhatsApp',
		'pinterest' => 'Pinterest',
		'threads'   => 'Threads',
	);
}

/**
 * A key's label: "Phone", "Phone 2".
 *
 * @param string $key
 * @return string
 */
function kerf_site_label( $key ) {
	$labels = kerf_site_labels();
	if ( isset( $labels[ $key ] ) ) {
		return $labels[ $key ];
	}
	if ( preg_match( '/^(.+)-(\d+)$/', $key, $m ) && isset( $labels[ $m[1] ] ) ) {
		return $labels[ $m[1] ] . ' ' . $m[2];
	}
	return ucfirst( str_replace( '-', ' ', $key ) );
}

/**
 * Keep what an import found, for keys not set yet: the owner's own changes are
 * never overwritten by a newer design's sample number.
 *
 * @param array $found key => { text, href }, from the converter.
 * @return string[] The keys added.
 */
function kerf_site_remember( $found ) {
	$details = kerf_site_details();
	$added   = array();
	foreach ( (array) $found as $key => $detail ) {
		$key = sanitize_key( (string) $key );
		if ( '' === $key || isset( $details[ $key ] ) || ! is_array( $detail ) ) {
			continue;
		}
		$details[ $key ] = kerf_site_clean( $detail );
		$added[]         = $key;
	}
	if ( $added ) {
		update_option( KERF_SITE_OPTION, $details, false );
	}
	return $added;
}

/**
 * What this import has found so far, for the next conversion to match against
 * (`site_known`).
 *
 * Within one import, by value: the phone in the header and the same phone on
 * the contact page are one detail, a second branch's phone is `phone-2`.
 * Across imports, never: a new design's first phone IS the business's phone,
 * whatever number its sample shows — so the number the owner keeps under Kerf
 * → Site details is the one the new design shows.
 *
 * @param array|null $found Details a conversion returned, to add; null to read.
 * @return array<string,array{text:string,href:string}>
 */
function kerf_site_run_known( $found = null ) {
	static $known = array();
	if ( null !== $found ) {
		$known = (array) $found + $known;
	}
	return $known;
}

/**
 * Set the details the owner confirmed for a design — on Kerf Pro's build
 * screen — over the stored ones. An imported template's samples never replace
 * what the site keeps (kerf_site_remember()); these are the owner's own words,
 * so a design made with them shows them (in the lab, a gym made with its own
 * phone showed a dental clinic's, kept from an earlier design).
 *
 * @param array<string,string> $details key => text.
 * @return string[] The keys set.
 */
function kerf_site_confirm( $details ) {
	$stored = kerf_site_details();
	$set    = array();
	foreach ( (array) $details as $key => $text ) {
		$key  = sanitize_key( (string) $key );
		$text = is_scalar( $text ) ? trim( sanitize_text_field( (string) $text ) ) : '';
		if ( '' === $key || '' === $text ) {
			continue;
		}
		// The link follows the words, as on Kerf → Site details.
		$base = preg_replace( '/-\d+$/', '', $key );
		$href = '';
		if ( 'phone' === $base || ( 'whatsapp' === $base && ! preg_match( '#^https?://#i', $text ) ) ) {
			$href = ( 'whatsapp' === $base ? 'https://wa.me/' : 'tel:' ) . preg_replace( '/[^\d+]/', '', $text );
		} elseif ( 'email' === $base && is_email( $text ) ) {
			$href = 'mailto:' . $text;
		} elseif ( preg_match( '#^https?://#i', $text ) ) {
			$href = $text;
		}
		$stored[ $key ] = kerf_site_clean( array( 'text' => $text, 'href' => $href ) );
		$set[]          = $key;
	}
	if ( $set ) {
		update_option( KERF_SITE_OPTION, $stored, false );
	}
	return $set;
}

/**
 * One detail, safe to store: plain text, and a link with a scheme that is a
 * link (`tel:`, `mailto:`, `https:`).
 *
 * @param array $detail
 * @return array{text:string,href:string}
 */
function kerf_site_clean( $detail ) {
	$text = isset( $detail['text'] ) ? sanitize_textarea_field( (string) $detail['text'] ) : '';
	$href = isset( $detail['href'] ) ? trim( (string) $detail['href'] ) : '';
	$href = '' === $href ? '' : esc_url_raw( $href, array( 'http', 'https', 'tel', 'mailto', 'sms' ) );
	return array( 'text' => $text, 'href' => $href );
}

// ─────────────────────────────────────────────────────────────────────────────
// The page
// ─────────────────────────────────────────────────────────────────────────────

/**
 * The binding source.
 */
function kerf_site_register_source() {
	if ( ! function_exists( 'register_block_bindings_source' ) ) {
		return;
	}
	register_block_bindings_source( 'kerf/site', array(
		'label'              => __( 'Site details (Kerf)', 'kerf-blocks' ),
		'get_value_callback' => 'kerf_site_value',
	) );
}
add_action( 'init', 'kerf_site_register_source' );

/**
 * A bound value: the text as shown, or the link. Core's paragraph and heading
 * take HTML, where a line break is a `<br>`; Kerf's blocks take text.
 *
 * @param array    $args      { key, part }.
 * @param WP_Block $block
 * @param string   $attribute
 * @return string|null Null keeps what the design wrote.
 */
function kerf_site_value( $args, $block, $attribute ) {
	$details = kerf_site_details();
	$key     = isset( $args['key'] ) ? sanitize_key( (string) $args['key'] ) : '';
	if ( '' === $key || empty( $details[ $key ] ) ) {
		return null;
	}
	$part  = isset( $args['part'] ) && 'href' === $args['part'] ? 'href' : 'text';
	$value = isset( $details[ $key ][ $part ] ) ? (string) $details[ $key ][ $part ] : '';
	if ( '' === $value ) {
		return null;
	}
	// The words the design wrote around it: "Call " a number.
	if ( 'text' === $part ) {
		$value = ( isset( $args['before'] ) ? (string) $args['before'] : '' ) . $value . ( isset( $args['after'] ) ? (string) $args['after'] : '' );
	}
	return 'content' === $attribute ? kerf_site_lines( $value ) : $value;
}

/**
 * Text as HTML, each line break a `<br>` — with nothing after it, as the design
 * wrote `2104 S Lamar Blvd<br>Austin`.
 *
 * @param string $text
 * @return string
 */
function kerf_site_lines( $text ) {
	return implode( '<br>', array_map( 'esc_html', explode( "\n", (string) $text ) ) );
}

/**
 * An element bound by `kerfSite`: a link gets the detail's address, anything
 * else the detail's text — line breaks as `<br>`, as an address is written.
 *
 * @param array  $attrs
 * @param string $content Rendered children.
 * @return array{0:array,1:string}
 */
function kerf_site_apply( $attrs, $content ) {
	$key = isset( $attrs['kerfSite'] ) ? sanitize_key( (string) $attrs['kerfSite'] ) : '';
	if ( '' === $key ) {
		return array( $attrs, $content );
	}
	$details = kerf_site_details();
	if ( empty( $details[ $key ] ) ) {
		return array( $attrs, $content );
	}

	if ( 'a' === strtolower( isset( $attrs['tagName'] ) ? (string) $attrs['tagName'] : 'div' ) ) {
		if ( '' !== $details[ $key ]['href'] ) {
			$attrs['customAttributes']         = isset( $attrs['customAttributes'] ) && is_array( $attrs['customAttributes'] ) ? $attrs['customAttributes'] : array();
			$attrs['customAttributes']['href'] = $details[ $key ]['href'];
			$attrs['linkType']                 = '';
		}
	} elseif ( '' !== $details[ $key ]['text'] ) {
		$content = kerf_site_lines( $details[ $key ]['text'] );
	}

	return array( $attrs, $content );
}
