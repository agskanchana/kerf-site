<?php
/**
 * The SVG sanitizer: one DOM allowlist for every inline SVG Kerf prints and
 * every SVG file it stages. Its twin in the editor is kerf.sanitizeSvg()
 * (assets/js/kerf-attributes-control.js); tests/bin/svg-parity.php keeps them
 * agreeing.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sanitize inline SVG markup with a DOM allowlist.
 *
 * Used by kerf/svg, which stores whatever `<svg>` the mockup contained. A regex
 * pass is not enough here: it misses unquoted event handlers, `<foreignObject>`,
 * `<use xlink:href="data:…">`, `<animate attributeName="href">` and CDATA
 * sections. Walking the tree and dropping anything not on the allowlist is the
 * only version that holds, and it is cheap — an icon is a few dozen nodes.
 *
 * `file` is an SVG FILE staged for someone who may not add scripts (§5.32):
 * a document of its own, where a `<style>` styles only itself and an
 * `<image>` of a raster picture is what an exported illustration is made of —
 * both allowed there, and nothing that runs. Inline, a `<style>` would style
 * the whole page. (The editor's copy, `kerf.sanitizeSvg()`, mirrors `inline`.)
 *
 * @param string $svg     Raw SVG markup.
 * @param string $context 'inline' (default) or 'file'.
 * @return string Sanitized markup, or '' when nothing survives.
 */
function kerf_sanitize_svg_markup( $svg, $context = 'inline' ) {
	$svg  = (string) $svg;
	$file = 'file' === $context;
	if ( '' === trim( $svg ) || false === stripos( $svg, '<svg' ) ) {
		return '';
	}

	// Hard cap: an SVG bigger than this in a mockup is a traced photograph, not
	// an icon, and walking it is not worth the memory.
	if ( strlen( $svg ) > ( $file ? 2048 : 512 ) * 1024 ) {
		return '';
	}

	// A file's own XML declaration (after a byte-order mark, perhaps) would
	// come after the one prepended below, which is not XML at all.
	$svg = (string) preg_replace( '/^(?:\xEF\xBB\xBF)?\s*<\?xml\b[^>]*\?>/i', '', $svg );

	$allowed_tags = array(
		'svg', 'g', 'defs', 'symbol', 'use', 'title', 'desc',
		'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
		'text', 'tspan', 'textpath',
		'lineargradient', 'radialgradient', 'stop', 'pattern',
		'clippath', 'mask', 'marker', 'switch',
		'filter', 'fegaussianblur', 'feoffset', 'feblend', 'feflood',
		'fecomposite', 'femerge', 'femergenode', 'fecolormatrix', 'fedropshadow',
	);

	$allowed_attrs = array(
		'id', 'class', 'style', 'transform', 'viewbox', 'xmlns', 'xmlns:xlink',
		'width', 'height', 'x', 'y', 'x1', 'y1', 'x2', 'y2', 'cx', 'cy', 'r', 'rx', 'ry',
		'd', 'points', 'fill', 'fill-rule', 'fill-opacity', 'clip-rule', 'clip-path',
		'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray',
		'stroke-dashoffset', 'stroke-opacity', 'stroke-miterlimit',
		'opacity', 'offset', 'stop-color', 'stop-opacity', 'gradientunits',
		'gradienttransform', 'patternunits', 'patterncontentunits', 'maskunits',
		'clippathunits', 'markerwidth', 'markerheight', 'refx', 'refy', 'orient',
		'preserveaspectratio', 'overflow', 'vector-effect', 'paint-order',
		'font-family', 'font-size', 'font-weight', 'font-style', 'text-anchor',
		'dominant-baseline', 'letter-spacing', 'dx', 'dy',
		'stddeviation', 'in', 'in2', 'result', 'mode', 'type', 'values', 'flood-color',
		'flood-opacity', 'operator',
		'role', 'aria-label', 'aria-hidden', 'aria-labelledby', 'focusable',
	);

	if ( $file ) {
		$allowed_tags[] = 'style';
		$allowed_tags[] = 'image';
	}

	// NOT LIBXML_NOENT. The name reads like "no entities" and means the
	// opposite: substitute them — and since libxml 2.9 it is the one flag that
	// turns external entities back ON. With it, `<!ENTITY x SYSTEM
	// "file:///…/wp-config.php">` and `<text>&x;</text>` put the file's
	// contents into the sanitized output (LIBXML_NONET stops only the network).
	// Without it an entity stays a reference node, which the walk removes.
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$loaded = $doc->loadXML(
		'<?xml version="1.0" encoding="utf-8"?>' . $svg,
		LIBXML_NONET | LIBXML_NOCDATA
	);
	libxml_clear_errors();

	if ( ! $loaded || ! $doc->documentElement ) {
		return '';
	}
	if ( 'svg' !== strtolower( $doc->documentElement->nodeName ) ) {
		return '';
	}

	// Strip DTDs and processing instructions outright — an external entity
	// declaration is the one thing loadXML() can be talked into fetching.
	foreach ( iterator_to_array( $doc->childNodes ) as $top ) {
		if ( XML_DOCUMENT_TYPE_NODE === $top->nodeType || XML_PI_NODE === $top->nodeType ) {
			$doc->removeChild( $top );
		}
	}

	$unsafe_css = '/(?:javascript|vbscript|data)\s*:|expression\s*\(|behaviou?r\s*:|@import/i';

	$clean = function ( DOMElement $element, $tag ) use ( $allowed_attrs, $unsafe_css ) {
		foreach ( iterator_to_array( $element->attributes ) as $attr ) {
			$name = strtolower( $attr->nodeName );
			$val  = (string) $attr->nodeValue;

			if ( ! in_array( $name, $allowed_attrs, true ) && 'xlink:href' !== $name && 'href' !== $name ) {
				$element->removeAttribute( $attr->nodeName );
				continue;
			}

			// href / xlink:href may only point at a same-document fragment.
			// `data:` and `javascript:` are both live script vectors in a
			// <use>, and an absolute URL is an SSRF/tracking beacon. A file's
			// <image> may also show a raster picture: embedded, or a relative
			// path — neither can carry script.
			if ( 'href' === $name || 'xlink:href' === $name ) {
				$ok = preg_match( '/^#[A-Za-z0-9_:.-]+$/', trim( $val ) )
					|| ( 'image' === $tag && (
						preg_match( '#^data:image/(?:png|jpe?g|gif|webp|avif);base64,[A-Za-z0-9+/=\s]+$#i', trim( $val ) )
						|| preg_match( '#^(?![a-z][a-z0-9+.-]*:|/)[^\s"\'<>?\#]+\.(?:png|jpe?g|gif|webp|avif)$#i', trim( $val ) )
					) );
				if ( ! $ok ) {
					$element->removeAttribute( $attr->nodeName );
				}
				continue;
			}

			if ( 'style' === $name && preg_match( $unsafe_css, $val ) ) {
				$element->removeAttribute( $attr->nodeName );
			}
		}
	};

	$walk = function ( DOMNode $node ) use ( &$walk, $clean, $allowed_tags, $unsafe_css ) {
		foreach ( iterator_to_array( $node->childNodes ) as $child ) {
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				// Comments and PIs can carry markup that a later re-parse revives.
				if ( XML_TEXT_NODE !== $child->nodeType ) {
					$node->removeChild( $child );
				}
				continue;
			}

			$tag = strtolower( $child->nodeName );
			if ( ! in_array( $tag, $allowed_tags, true ) ) {
				$node->removeChild( $child );
				continue;
			}

			// A file's <style> (see `file` above): its text, nothing inside it,
			// and none of what the style attribute may not hold either.
			if ( 'style' === $tag ) {
				foreach ( iterator_to_array( $child->childNodes ) as $inner ) {
					if ( XML_TEXT_NODE !== $inner->nodeType ) {
						$child->removeChild( $inner );
					}
				}
				if ( preg_match( $unsafe_css, (string) $child->textContent ) ) {
					$node->removeChild( $child );
					continue;
				}
			}

			$clean( $child, $tag );
			$walk( $child );
		}
	};

	// The root too. It used to be walked INTO and never checked itself, so
	// `<svg onload="…">` — the first thing anyone tries — kept its handler on
	// the page, while the editor's copy (kerf.sanitizeSvg) removed it.
	$clean( $doc->documentElement, 'svg' );
	$walk( $doc->documentElement );

	$out = $doc->saveXML( $doc->documentElement );

	return is_string( $out ) ? $out : '';
}
