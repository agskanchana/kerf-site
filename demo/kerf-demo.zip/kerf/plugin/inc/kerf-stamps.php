<?php
/**
 * Section stamps: what lets a newer version of a design be applied section by
 * section (CLAUDE.md §5.28).
 *
 * Every import stamps the top-level sections it writes (`kerfSource` on the
 * block: a key that finds the section again, a hash of its markup in the
 * mockup, a hash of what was written), whoever imports — so a site made with
 * the free plugin can be updated the day Kerf Pro is added. The update itself
 * (compare, preview, apply, the screen) is Kerf Pro's; these helpers are the
 * free plugin's, used by the import and by Kerf → Links.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ═══════════════════════════════════════════════════════════════════════════════
// STAMPS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Markup with the stamps taken out — for the fidelity audit, which searches
 * the markup as text and must not find a class in a hash.
 *
 * @param string $markup
 * @return string
 */
function kerf_sync_strip_stamps( $markup ) {
	return (string) preg_replace( '/,?"kerfSource":\{[^{}]*\}/', '', (string) $markup );
}

/**
 * A block as written, reduced to what an edit would change: attributes
 * sorted, the block type's defaults and the stamp left out, whitespace
 * collapsed. The editor re-serializes on save — different key order, different
 * escaping, defaults dropped — and none of that is an edit.
 *
 * @param array $block Parsed block.
 * @return array
 */
function kerf_sync_normalize( $block ) {
	$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	unset( $attrs['kerfSource'] );

	$type = ! empty( $block['blockName'] ) ? WP_Block_Type_Registry::get_instance()->get_registered( $block['blockName'] ) : null;
	if ( $type && is_array( $type->attributes ) ) {
		foreach ( $type->attributes as $name => $definition ) {
			if ( array_key_exists( $name, $attrs ) && is_array( $definition ) && array_key_exists( 'default', $definition )
				&& $attrs[ $name ] == $definition['default'] ) { // phpcs:ignore Universal.Operators.StrictComparisons -- {} and [] are one default.
				unset( $attrs[ $name ] );
			}
		}
	}

	$html = '';
	foreach ( isset( $block['innerContent'] ) ? (array) $block['innerContent'] : array() as $piece ) {
		if ( is_string( $piece ) ) {
			$html .= $piece;
		}
	}

	return array(
		isset( $block['blockName'] ) ? (string) $block['blockName'] : '',
		kerf_sync_sort( $attrs ),
		array_map( 'kerf_sync_normalize', isset( $block['innerBlocks'] ) ? (array) $block['innerBlocks'] : array() ),
		trim( preg_replace( '/\s+/u', ' ', $html ) ),
	);
}

/**
 * @param mixed $value
 * @return mixed Arrays key-sorted, all the way down.
 */
function kerf_sync_sort( $value ) {
	if ( ! is_array( $value ) ) {
		return $value;
	}
	ksort( $value );
	return array_map( 'kerf_sync_sort', $value );
}

/**
 * @param array $block Parsed block.
 * @return string
 */
function kerf_sync_block_hash( $block ) {
	return substr( md5( (string) wp_json_encode( kerf_sync_normalize( $block ) ) ), 0, 12 );
}

/**
 * The elements a region's sections sit in, as Kerf wrote them — the page's
 * `<main id="content">`, a header's lone `<nav>` (kerf_mc_section_parent()):
 * a hash of each one's own element, children aside.
 *
 * A wrapper is no section, and an update used to leave it as it was: a design
 * whose new version gave its `<nav>` an `id="nav"` kept the old `<nav>`, and
 * the new script, looking for `#nav`, stopped the page's other scripts with
 * it. Each section's stamp keeps this hash (`kerfSource.wrap`), so an update
 * can tell a wrapper changed in WordPress since from one the designer changed.
 *
 * What WordPress keeps on a block for itself is left out — the gaps between
 * its children (they change with the children), its List View name, its
 * lock, a link's binding — and so are the type's defaults, as
 * kerf_sync_normalize() leaves them out.
 *
 * @param array[] $chain Parsed blocks, outermost first; never a template's
 *                       kerf/frame. array() for sections at the top.
 * @return string
 */
function kerf_sync_wrapper_sign( $chain ) {
	$own = array();
	foreach ( (array) $chain as $block ) {
		$normal = kerf_sync_normalize( array(
			'blockName' => isset( $block['blockName'] ) ? $block['blockName'] : '',
			'attrs'     => isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? array_diff_key( $block['attrs'], array_flip( array( 'gaps', 'metadata', 'lock', 'linkType', 'linkId' ) ) ) : array(),
		) );
		$own[]  = array( $normal[0], $normal[1] );
	}
	return substr( md5( (string) wp_json_encode( $own ) ), 0, 12 );
}

/**
 * Record what was written into each stamped section: `kerfSource.out`, and
 * what it sits in, `kerfSource.wrap` (kerf_sync_wrapper_sign()).
 *
 * @param string $markup Block markup, stamped by the converter.
 * @return string
 */
function kerf_sync_stamp_out( $markup ) {
	if ( false === strpos( (string) $markup, 'kerfSource' ) ) {
		return (string) $markup;
	}
	return serialize_blocks( kerf_sync_stamp_blocks( parse_blocks( $markup ) ) );
}

/**
 * kerf_sync_stamp_out() on parsed blocks: a section may sit inside the page's
 * one wrapper (kerf_mc_section_parent()), so the walk goes down until it meets
 * one.
 *
 * @param array[] $blocks
 * @param array[] $chain  The blocks walked through to get here.
 * @return array[]
 */
function kerf_sync_stamp_blocks( $blocks, $chain = array() ) {
	foreach ( $blocks as &$block ) {
		if ( ! empty( $block['attrs']['kerfSource'] ) && is_array( $block['attrs']['kerfSource'] ) ) {
			$block['attrs']['kerfSource']['out']  = kerf_sync_block_hash( $block );
			$block['attrs']['kerfSource']['wrap'] = kerf_sync_wrapper_sign( $chain );
		} elseif ( ! empty( $block['innerBlocks'] ) ) {
			$block['innerBlocks'] = kerf_sync_stamp_blocks( $block['innerBlocks'], array_merge( $chain, array( $block ) ) );
		}
	}
	unset( $block );
	return $blocks;
}

/**
 * Where the sections are: the path (indexes of blocks, each into its inner
 * blocks) to the first list that holds a stamped block. Null when there is
 * none — a page imported before stamps existed.
 *
 * @param array[] $blocks
 * @param int[]   $path
 * @return int[]|null
 */
function kerf_sync_find_list( $blocks, $path = array() ) {
	foreach ( $blocks as $block ) {
		if ( ! empty( $block['attrs']['kerfSource'] ) ) {
			return $path;
		}
	}
	foreach ( $blocks as $i => $block ) {
		if ( ! empty( $block['innerBlocks'] ) ) {
			$found = kerf_sync_find_list( $block['innerBlocks'], array_merge( $path, array( $i ) ) );
			if ( null !== $found ) {
				return $found;
			}
		}
	}
	return null;
}

/**
 * @param array[] $blocks
 * @param int[]   $path
 * @return array[] The list at that path.
 */
function kerf_sync_list_at( $blocks, $path ) {
	foreach ( $path as $i ) {
		$blocks = isset( $blocks[ $i ]['innerBlocks'] ) ? $blocks[ $i ]['innerBlocks'] : array();
	}
	return $blocks;
}

/**
 * Put a list back at a path, rebuilding each parent's inner content: one
 * placeholder per inner block, the parent's own opening and closing markup
 * around them.
 *
 * @param array[] $blocks
 * @param int[]   $path
 * @param array[] $list
 * @return array[]
 */
function kerf_sync_with_list( $blocks, $path, $list ) {
	if ( ! $path ) {
		return array_values( $list );
	}

	$i      = array_shift( $path );
	$parent = $blocks[ $i ];
	$inner  = kerf_sync_with_list( $parent['innerBlocks'], $path, $list );

	$content = isset( $parent['innerContent'] ) ? (array) $parent['innerContent'] : array();
	$first   = array_search( null, $content, true );
	$last    = false === $first ? false : max( array_keys( $content, null, true ) );
	$head    = '';
	$tail    = '';
	foreach ( $content as $k => $piece ) {
		if ( is_string( $piece ) && ( false === $first || $k < $first ) ) {
			$head .= $piece;
		} elseif ( is_string( $piece ) && false !== $last && $k > $last ) {
			$tail .= $piece;
		}
	}

	$pieces = array( $head );
	foreach ( $inner as $n => $unused ) {
		$pieces[] = null;
		$pieces[] = $n < count( $inner ) - 1 ? "\n" : $tail;
	}
	if ( ! $inner ) {
		$pieces[] = $tail;
	}

	$parent['innerBlocks']  = array_values( $inner );
	$parent['innerContent'] = $pieces;
	$parent['innerHTML']    = implode( '', array_filter( $pieces, 'is_string' ) );
	$blocks[ $i ]           = $parent;

	return $blocks;
}

/**
 * Every stamped block, wherever it sits, by key (the first of each).
 *
 * @param array[] $blocks
 * @param array   $found
 * @return array<string,array>
 */
function kerf_sync_stamped( $blocks, $found = array() ) {
	foreach ( $blocks as $block ) {
		$key = kerf_sync_key( $block );
		if ( '' !== $key ) {
			if ( ! isset( $found[ $key ] ) ) {
				$found[ $key ] = $block;
			}
		} elseif ( ! empty( $block['innerBlocks'] ) ) {
			$found = kerf_sync_stamped( $block['innerBlocks'], $found );
		}
	}
	return $found;
}

/**
 * A block's section key, as the mockup spells it; '' when it has none.
 *
 * Saved by someone without unfiltered_html — a network's site admin, an
 * import run by one — every string attribute goes through KSES, which
 * writes the `>` of a nested key (`main#content > section.hero`) as `&gt;`,
 * and the section would never be found again.
 *
 * @param array $block
 * @return string
 */
function kerf_sync_key( $block ) {
	$key = isset( $block['attrs']['kerfSource']['key'] ) && is_scalar( $block['attrs']['kerfSource']['key'] ) ? (string) $block['attrs']['kerfSource']['key'] : '';
	return false === strpos( $key, '&' ) ? $key : wp_specialchars_decode( $key, ENT_QUOTES );
}

