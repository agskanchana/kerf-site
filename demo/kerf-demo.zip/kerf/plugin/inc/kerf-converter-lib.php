<?php
/**
 * Mockup HTML → WordPress block markup. The conversion engine.
 *
 * THE CONTRACT: whatever the mockup says, the page says. Every tag, class, id,
 * attribute and nesting relationship in the input appears in the output, and
 * the mockup's own stylesheet styles the result with no adaptation. There is no
 * canonical markup to conform to, no design vocabulary to learn, and no element
 * the converter refuses.
 *
 * That is why almost everything becomes `kerf/div` — a block whose entire job is
 * to render one element with one set of attributes. The exceptions are all
 * additive rather than normalizing:
 *
 *   core/heading    adds `wp-block-heading` to a heading's class list, which no
 *                   mockup selector cares about, and buys real heading UX plus
 *                   every SEO/outline tool that reads core blocks.
 *   core/paragraph  adds nothing at all.
 *   kerf/image      resolves `src` through the media library instead of shipping
 *                   a dead relative path.
 *   kerf/text       carries a bare text run without paragraph margins.
 *   kerf/icon       exists only so icons get an editor affordance; its classes
 *                   pass through untouched.
 *
 * Blocks that WRAP — core/table's `<figure class="wp-block-table">`,
 * core/quote's `wp-block-quote`, core/audio's figure, core/separator's
 * `has-alpha-channel-opacity` — are deliberately NOT used. Each one inserts an
 * element or class the designer did not write, and a mockup laid out with
 * `.pricing > table { }` stops matching the moment core slips a figure in
 * between. A table converts to nested `kerf/div` instead: less convenient to
 * edit, still perfectly editable, and identical in the DOM.
 *
 * WHAT IS NOT HERE: `<script>`, `<style>` and `<link rel=stylesheet>` never
 * reach post content. They are captured by inc/kerf-assets.php during import and
 * re-emitted as properly enqueued assets, so the mockup's JS and CSS still run —
 * they just run from the asset layer where they belong, instead of sitting in a
 * post_content blob that no cache can version and every admin can edit.
 *
 * Runs without WordPress: inc/kerf-shim.php supplies the five escaping helpers
 * this file needs, so tools/kerf-convert.php converts from the CLI.
 *
 * @package kerf
 */

// Without WordPress the engine is loaded by tools/kerf-convert.php and
// tests/bin/golden.php, which define ABSPATH as WordPress does.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * parse_url(), as WordPress has it (wp_parse_url()) when the engine runs
 * inside WordPress; tools/kerf-convert.php runs it without.
 *
 * @param string $url
 * @param int    $component A PHP_URL_* constant, or -1 for every part.
 * @return mixed
 */
function kerf_mc_parse_url( $url, $component = -1 ) {
	if ( function_exists( 'wp_parse_url' ) ) {
		return wp_parse_url( $url, $component );
	}
	return parse_url( $url, $component ); // phpcs:ignore WordPress.WP.AlternativeFunctions.parse_url_parse_url -- the engine without WordPress (tools/kerf-convert.php).
}

/**
 * Nesting depth at which conversion stops descending.
 *
 * kerf_mc_convert_node() and kerf_mc_convert_children() are mutually recursive,
 * and PHP's stack overflow is a SIGSEGV, not a catchable Error — a mockup with
 * ten thousand nested divs takes the whole process down and no amount of
 * try/catch helps. The cap has to be enforced on the way in. Real markup does
 * not approach it: a deeply nested Bootstrap page runs about 25 levels.
 */
if ( ! defined( 'KERF_MC_MAX_DEPTH' ) ) {
	define( 'KERF_MC_MAX_DEPTH', 100 );
}

/**
 * Total elements converted before the engine gives up.
 *
 * Bounds output size and conversion time for a pathological input. A large
 * real page is 3-5k elements.
 */
if ( ! defined( 'KERF_MC_MAX_ELEMENTS' ) ) {
	define( 'KERF_MC_MAX_ELEMENTS', 25000 );
}

// ═══════════════════════════════════════════════════════════════════════════════
// WORDPRESS SHIM
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Escape for an HTML attribute.
 *
 * Wrapping core's esc_attr() rather than calling it directly is what lets this
 * file run under `php tools/kerf-convert.php`. Calling the bare function was a
 * fatal the moment an element had an `id`.
 *
 * @param string $text
 * @return string
 */
function kerf_mc_esc_attr( $text ) {
	if ( function_exists( 'esc_attr' ) ) {
		return esc_attr( $text );
	}
	return htmlspecialchars( (string) $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
}

/**
 * Escape for HTML text content.
 *
 * @param string $text
 * @return string
 */
function kerf_mc_esc_html( $text ) {
	if ( function_exists( 'esc_html' ) ) {
		return esc_html( $text );
	}
	return htmlspecialchars( (string) $text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
}

// ═══════════════════════════════════════════════════════════════════════════════
// CONTEXT (replaces globals)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Get or set the converter context (media map, manifest, warnings, counters).
 *
 * @param array|null $ctx Array to merge into the current context, or null to read.
 * @return array
 */
function kerf_mc_context( $ctx = null ) {
	static $context = null;
	if ( null === $context ) {
		$context = kerf_mc_blank_context();
	}
	if ( null !== $ctx ) {
		$context = array_merge( $context, $ctx );
	}
	return $context;
}

/**
 * A fresh context.
 *
 * @return array
 */
function kerf_mc_blank_context() {
	return array(
		'media_by_name' => array(),
		'media_by_path' => array(),
		'base_rel'      => '',
		'manifest'      => null,
		'warnings'      => array(),
		'report'        => array(),
		'elements'      => 0,
		'truncated'     => false,
		'base_url'      => '',
		'eager_images'  => false,
		'staging_url'   => '',
		// The page type being converted, when it is a template ('home',
		// 'archive', 'search', 'single', 'page', '404'): a loop on a listing
		// repeats over the page's own posts rather than the latest few.
		'template'      => '',
		// Whether that loop has been placed, and which page-wide containers
		// (content, comments) have. Declared here because kerf_mc_context()
		// MERGES: a key missing from this list would carry over from one
		// conversion into the next.
		'main_loop'     => false,
		'placed'        => array(),
		// Whether the page has a designer's comment form (the comment list
		// then comes without WordPress's), and the text nodes that hold sample
		// post meta — both found by kerf_mc_contract_prepass() before the walk.
		'comment_form'  => false,
		'auto_text'     => null,
		// Section nodes → where they came from, while stamping (§5.28).
		'stamps'        => null,
		// Whether attributes that run code (kerf_mc_is_directive_attribute())
		// may be kept: false when the importer may not add scripts (§5.32).
		// And the ones left out, by name, for one report line.
		'directives'      => true,
		'directive_drops' => array(),
		// The business's details found on the page — key => {text, href} —
		// bound to Kerf → Site details (§5.36), and handed back for it. Found
		// only when asked (`site_details`: Kerf Pro's import asks).
		'site'            => array(),
		'site_details'    => false,
		// Whether the markup contract fills in WordPress's content — loops,
		// post fields, comments, sample post meta (§5.25, §5.30) — or leaves
		// the design's samples as written. Only when asked (`dynamic`: Kerf
		// Pro's import asks); a search box and a form work either way.
		'dynamic'         => false,
	);
}

/**
 * Append a warning to the converter context.
 *
 * Every warning also lands in the structured loss report, because the report is
 * product surface: it is the thing that tells a designer which of their
 * selectors just stopped matching. Categories:
 *
 *   media     – an image/video source that did not resolve to a library item
 *   converted – an element rescued into a more specific block than kerf/div
 *   asset     – markup handed to the asset pipeline instead of post content
 *   dropped   – content that could not be preserved at all
 *   limit     – a resource cap was hit; output is incomplete
 *   general   – everything else
 *
 * @param string $message
 * @param string $category
 */
function kerf_mc_warn( $message, $category = 'general' ) {
	$ctx               = kerf_mc_context();
	$ctx['warnings'][] = $message;
	$ctx['report'][]   = array(
		'category' => $category,
		'message'  => $message,
	);
	kerf_mc_context( $ctx );
}

// ═══════════════════════════════════════════════════════════════════════════════
// TAG POLICY
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Elements that render nothing and close themselves.
 *
 * kerf/div needs this to know not to emit a closing tag or InnerBlocks for an
 * `<input>` or `<br>` — a `<br></br>` is two line breaks in some parsers.
 *
 * @return string[]
 */
function kerf_mc_void_tags() {
	return array(
		'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
		'link', 'meta', 'param', 'source', 'track', 'wbr',
	);
}

/**
 * Elements that never become blocks.
 *
 * Two different reasons, deliberately kept in one list because the effect is the
 * same — the element does not reach post_content:
 *
 * ASSET-OWNED (`script`, `style`, `link`, `title`, `meta`, `base`): these are
 * the mockup's stylesheets and behaviour. inc/kerf-assets.php lifts them out of
 * the document before conversion and re-registers them as real enqueued assets,
 * so they still run. Letting them through to post content instead would put
 * executable markup inside a database field that every Editor can write — an
 * admin pasting a third-party designer's mockup is the normal case here, and the
 * mockup is the untrusted party, not the admin.
 *
 * NEVER-SAFE (`object`, `embed`, `applet`, `param`, `frame`, `frameset`,
 * `noscript`): plugin containers and parser-state oddities with no legitimate
 * use in a 2020s mockup. `<iframe>` is deliberately NOT in this list — a Maps
 * or YouTube embed is normal markup — but its `srcdoc` is stripped and its
 * `src` is scheme-checked in kerf_mc_extract_custom_attributes().
 *
 * `<template>` was here too, and every Alpine list and toggle went with it:
 * `<template x-for>` and `<template x-if>` are how Alpine repeats and shows
 * markup. Its content is inert until a script uses it, so it converts as an
 * element like any other, and what may run from it is decided where its
 * attributes are (kerf_mc_is_directive_attribute()).
 *
 * @return string[]
 */
function kerf_mc_dropped_tags() {
	return array(
		'script', 'style', 'link', 'title', 'meta', 'base',
		'object', 'embed', 'applet', 'param', 'frame', 'frameset',
		'noscript',
	);
}

/**
 * Attributes whose value is a URL, and which therefore get scheme-checked and
 * resolved through the media manifest.
 *
 * @return string[]
 */
function kerf_mc_url_attributes() {
	return array( 'href', 'src', 'poster', 'action', 'formaction', 'cite', 'data', 'background', 'longdesc' );
}

/**
 * Is this a script URL that runs nothing — `javascript:void(0)`,
 * `javascript:;`, `javascript:` — what a template writes on a link only a
 * script answers? Refused, the link lost its address: out of the keyboard's
 * reach, without a hand cursor, and — written back as `#` — jumping to the top
 * of the page on every click. Nothing after the no-op is allowed (control
 * characters stripped first, as everywhere: `javascript:void(0)\nalert(1)`).
 *
 * @param string $url
 * @return bool
 */
function kerf_mc_noop_script_url( $url ) {
	$url = (string) preg_replace( '/[\x00-\x1F\x7F]/', '', (string) $url );
	return (bool) preg_match( '/^\s*javascript\s*:\s*(?:void\s*\(\s*0\s*\)|void\s+0|undefined)?\s*;?\s*$/i', $url );
}

/**
 * Why a URL may not be kept, or '' when it may.
 *
 * The same rule kerf_esc_url() applies at render: no script URL, and a `data:`
 * URL only for a picture — `data:text/html` is a document, and a document in
 * an iframe src or a link runs. Checked here too so the loss is REPORTED
 * rather than found as an empty attribute on the page (§6.6). Control
 * characters are stripped first, as there: `java\nscript:` is the classic way
 * past a pattern.
 *
 * @param string $url
 * @return string
 */
function kerf_mc_unsafe_url( $url ) {
	$url = trim( (string) preg_replace( '/[\x00-\x1F\x7F]/', '', (string) $url ) );

	if ( preg_match( '/^(?:javascript|vbscript)\s*:/i', $url ) && ! kerf_mc_noop_script_url( $url ) ) {
		return 'a script URL';
	}
	if ( preg_match( '#^data:#i', $url ) && ! preg_match( '#^data:image/(?:png|jpe?g|gif|webp|avif|svg\+xml)[;,]#i', $url ) ) {
		return 'a data: URL that is not a picture';
	}
	return '';
}

/**
 * Must this inline script run where it was written, rather than in the footer?
 *
 * The asset pipeline moves a body script to the footer, which is right for code
 * that wires up the page. It is wrong for code that WRITES INTO the page at its
 * own position: `Copyright &copy;<script>document.write(new Date()
 * .getFullYear())</script> All rights reserved` — the footer credit on hundreds
 * of free templates — printed the year at the bottom of the document, under the
 * footer, and left the copyright line without one.
 *
 * Shared by the asset scanner (which then leaves the script out of the footer)
 * and the converter (which puts a kerf/script block where it was), so the two
 * can never disagree about which scripts these are.
 *
 * @param string $code The script's source.
 * @return bool
 */
function kerf_mc_is_inplace_script( $code ) {
	return (bool) preg_match( '/\bdocument\s*\.\s*(?:write(?:ln)?\s*\(|currentScript\b)/', (string) $code );
}

/**
 * A stable reference to an inline script, from its source.
 *
 * Whitespace-insensitive, because the asset scanner reads the raw markup and
 * the converter reads the parsed DOM. And blind to end tags: libxml drops one
 * written in the script's own text — `document.write('<span>©</span>')` reached
 * the converter as `document.write('<span>©')` — so the block's reference and
 * the stored script's never met, and the script wrote nothing (scar 110). A
 * script with no end tag in it keeps the reference it always had.
 *
 * @param string $code
 * @return string
 */
function kerf_mc_script_ref( $code ) {
	$code = preg_replace( '#</[a-zA-Z][^>]*>#', '', (string) $code );
	return substr( md5( preg_replace( '/\s+/', ' ', trim( $code ) ) ), 0, 16 );
}

/**
 * File extensions that make a reference an ASSET rather than a page.
 *
 * @return string Regex alternation.
 */
function kerf_mc_asset_extensions() {
	return 'jpe?g|png|gif|webp|avif|svg|bmp|ico|mp4|webm|ogv|ogg|mp3|wav|m4a|oga|pdf|vtt';
}

/**
 * Is this a relative path to a file in the mockup's own folder?
 *
 * A single path only — not a list, not JSON, not a URL with a scheme, not
 * root-relative and not a fragment — ending in an asset extension. Narrow on
 * purpose: `data-lightbox="gallery"` and `data-text="v1.2"` must pass through
 * untouched, and only a value that is unmistakably a file path gets resolved.
 *
 * @param string $value
 * @return bool
 */
function kerf_mc_is_relative_asset( $value ) {
	$value = trim( (string) $value );

	if ( '' === $value || preg_match( '/[\s,{}\[\]<>"\']/', $value ) ) {
		return false;
	}
	if ( preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//|/|\#)#i', $value ) ) {
		return false;
	}

	return (bool) preg_match( '/\.(?:' . kerf_mc_asset_extensions() . ')$/i', preg_replace( '/[?#].*$/', '', $value ) );
}

/**
 * Point a relative asset path at the file WordPress actually serves.
 *
 * A mockup's relative paths resolve against the HTML file's folder. On a
 * WordPress page they resolve against the PAGE's URL — `/services/`, `/about/`
 * — where nothing exists, so the image 404s. The browser cannot be told
 * otherwise (a `<base>` element would also re-point every `#anchor` link), so
 * the reference itself is resolved: through the media cascade, landing on the
 * library copy of an image or on the staged file.
 *
 * `src` already went through this for images. What did not, and failed on real
 * templates, is everything a SCRIPT reads: `data-setbg` (every Colorlib
 * template sets its backgrounds from it), `data-src` for lazy loaders,
 * `data-image-src` for parallax, and the `href` a lightbox opens — `<a
 * href="img/gallery-1.jpg">` is how Magnific Popup, Lightbox2 and GLightbox are
 * all wired.
 *
 * @param string $value
 * @return string The resolved URL, or the value unchanged.
 */
function kerf_mc_resolve_asset_reference( $value ) {
	if ( ! kerf_mc_is_relative_asset( $value ) ) {
		return $value;
	}

	$resolved = kerf_mc_resolve_media( $value );

	return $resolved && '' !== $resolved['url'] ? $resolved['url'] : $value;
}

// ═══════════════════════════════════════════════════════════════════════════════
// DOCUMENT PREPARATION
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Reduce a full HTML document to its body content.
 *
 * A full document would be mangled by the synthetic `<div>` root that
 * kerf_mc_convert_html() wraps the input in: a DOCTYPE or `<head>` inside a div
 * makes libxml restructure the tree, and content after the header can silently
 * vanish. Section pastes (no doctype/html/head/body) pass through unchanged.
 *
 * @param string $html
 * @return string
 */
function kerf_mc_extract_body( $html ) {
	$html = (string) $html;

	if ( preg_match( '/<body[^>]*>(.*)<\/body>/is', $html, $m ) ) {
		$html = $m[1];
	} elseif ( preg_match( '/<!DOCTYPE|<html[\s>]|<head[\s>]/i', $html ) ) {
		$html = preg_replace( '/<!DOCTYPE[^>]*>/i', '', $html );
		$html = preg_replace( '/<head[^>]*>.*?<\/head>/is', '', $html );
		$html = preg_replace( '/<\/?(?:html|body)[^>]*>/i', '', $html );
	}

	// Every parse of a mockup starts here (the converter, the split, the
	// section keys, the audit), so this is where names the parser would lose
	// are made safe for it, and where its elements are closed where a browser
	// closes them (scar 102).
	return kerf_mc_balance_markup( kerf_mc_encode_attribute_names( $html ) );
}

/**
 * Attribute names the HTML parser cannot read, encoded so they survive it.
 *
 * libxml's HTML parser stops at a name with `@`, `#` or a bracket in it, says
 * "error parsing attribute name" and drops it — or keeps a fragment:
 * `x-bind:[key]` came out as `x-bind:` and a stray `false`. That is how Alpine
 * and Vue are written (`@click="open = !open"`, `#default`, `x-bind:[key]`),
 * so every menu toggle in an Alpine mockup was lost, and nothing said so
 * (§6.6). Such a name becomes `kerf-x-<hex of the name>` before parsing —
 * which every parser keeps and no mockup uses — and is turned back wherever
 * names are read (kerf_mc_decode_attribute_name()) or markup is written out
 * (kerf_mc_decode_attribute_names()).
 *
 * Only start tags are rewritten. Comments, and the text of script, style,
 * textarea and title, are copied as they are: code is never touched.
 *
 * @param string $html
 * @return string
 */
function kerf_mc_encode_attribute_names( $html ) {
	$html = (string) $html;
	if ( false === strpbrk( $html, '@#[]' ) ) {
		return $html;
	}

	$out    = '';
	$offset = 0;
	$tag_re = '/<!--.*?(?:-->|\z)|<([a-zA-Z][a-zA-Z0-9:-]*)((?:[^>"\']++|"[^"]*+"|\'[^\']*+\')*+)>/s';

	while ( preg_match( $tag_re, $html, $m, PREG_OFFSET_CAPTURE, $offset ) ) {
		$out   .= substr( $html, $offset, $m[0][1] - $offset );
		$offset = $m[0][1] + strlen( $m[0][0] );

		if ( empty( $m[1] ) || '' === $m[1][0] ) {
			$out .= $m[0][0];
			continue;
		}

		$out .= '<' . $m[1][0] . preg_replace_callback(
			'/(\s+)([^\s"\'>\/=]+)(\s*=\s*(?:"[^"]*+"|\'[^\']*+\'|[^\s"\'>]++))?/',
			static function ( $a ) {
				$value = isset( $a[3] ) ? $a[3] : '';
				return preg_match( '/^[a-z_:][a-z0-9_:.-]*$/i', $a[2] )
					? $a[0]
					: $a[1] . 'kerf-x-' . bin2hex( $a[2] ) . $value;
			},
			$m[2][0]
		) . '>';

		// Raw text: up to the closing tag, as it is.
		if ( in_array( strtolower( $m[1][0] ), array( 'script', 'style', 'textarea', 'title' ), true ) ) {
			$end = preg_match( '/<\/' . preg_quote( $m[1][0], '/' ) . '\s*>/i', $html, $close, PREG_OFFSET_CAPTURE, $offset )
				? $close[0][1] + strlen( $close[0][0] )
				: strlen( $html );
			$out   .= substr( $html, $offset, $end - $offset );
			$offset = $end;
		}
	}

	return $out . substr( $html, $offset );
}

/**
 * The markup with every element closed where a browser closes it.
 *
 * libxml's HTML parser recovers from a mistake by rules no browser uses: an
 * end tag arriving while a `<div>` is still open inside its element is
 * IGNORED (a misplaced end tag may only close what ranks no higher, and to
 * libxml a div outranks a section). AI-made designs leave a div open often.
 * A dental clinic's hero `<section>` ended with one still open: the browser
 * closed it there, libxml kept the section open, and every section after it
 * — the footer too — went inside the hero, whose photo then stretched behind
 * the whole page (scar 102). One `</div>` too many closed the converter's
 * synthetic root, and everything after it was dropped without a word; a
 * paragraph before a `<section>`, a `<div/>`, `</br>` — each was read
 * otherwise than a browser reads it.
 *
 * So the end tags are settled before libxml sees the markup, by the HTML
 * standard's tree-building rules for them (the "in body" insertion mode): an
 * end tag closes what is still open inside its element (but `</form>`, which
 * leaves it open, the form closing after it), or is dropped where a browser
 * ignores it; a start tag that ends a paragraph, a list item or a table cell
 * ends it; `<div/>` is an open div, as to a browser (inside an
 * `<svg>` a slash closes, as there); what is open at the end is closed. Text,
 * attributes and comments are copied as they are, so well-formed markup comes
 * back byte for byte. Not done: the adoption agency (an unclosed `<b>` or
 * `<a>` a browser opens again in the next block — such an end tag is left for
 * libxml), foster parenting (what a browser moves out of a `<table>`), quirks
 * mode, and a `<form>` inside a form.
 *
 * @param string $html Body markup, its attribute names encoded.
 * @return string
 */
function kerf_mc_balance_markup( $html ) {
	$html = (string) $html;
	if ( false === strpos( $html, '<' ) ) {
		return $html;
	}

	static $sets = null;
	if ( null === $sets ) {
		$words = static function ( $list ) {
			return array_flip( explode( ' ', $list ) );
		};
		$sets  = array(
			'void'         => $words( 'area base basefont bgsound br col embed frame hr img input keygen link meta param source track wbr' ),
			// Their text is not markup: copied to their end tag as it is.
			'raw'          => $words( 'script style textarea title xmp iframe noembed noframes noscript' ),
			// The document's own: nothing in a body opens or closes them.
			'document'     => $words( 'html head body frameset' ),
			'closes_p'     => $words( 'address article aside blockquote center details dialog dir div dl fieldset figcaption figure footer header hgroup main menu nav ol p search section summary ul h1 h2 h3 h4 h5 h6 pre listing form table hr xmp li dd dt' ),
			'block_end'    => $words( 'address applet article aside blockquote button center details dialog dir div dl dd dt fieldset figcaption figure footer form header hgroup listing main marquee menu nav object ol pre search section select summary template ul' ),
			'table_end'    => $words( 'table caption colgroup tbody thead tfoot tr td th' ),
			'headings'     => $words( 'h1 h2 h3 h4 h5 h6' ),
			'formatting'   => $words( 'a b big code em font i nobr s small strike strong tt u' ),
			'special'      => $words( 'address applet area article aside base basefont bgsound blockquote body br button caption center col colgroup dd details dir div dl dt embed fieldset figcaption figure footer form frame frameset h1 h2 h3 h4 h5 h6 head header hgroup hr html iframe img input keygen li link listing main marquee menu meta nav noembed noframes noscript object ol p param plaintext pre script search section select source style summary table tbody td template textarea tfoot th thead title tr track ul wbr xmp foreignobject desc mi mo mn ms mtext annotation-xml' ),
			'scope'        => $words( 'applet caption html table td th marquee object template foreignobject desc title mi mo mn ms mtext annotation-xml' ),
			'button_scope' => $words( 'applet caption html table td th marquee object template foreignobject desc title mi mo mn ms mtext annotation-xml button' ),
			'list_scope'   => $words( 'applet caption html table td th marquee object template foreignobject desc title mi mo mn ms mtext annotation-xml ol ul' ),
			'table_scope'  => $words( 'html table template' ),
			// Where a new <a> stops looking for an open one.
			'markers'      => $words( 'applet caption html marquee object template td th' ),
			// Inside an <svg> or <math>, where HTML is read again.
			'integration'  => $words( 'foreignobject desc title mi mo mn ms mtext annotation-xml' ),
			// HTML elements that cannot be inside an <svg> or <math>: they close it.
			'breakout'     => $words( 'b big blockquote body br center code dd div dl dt em embed h1 h2 h3 h4 h5 h6 head hr i img li listing menu meta nobr ol p pre ruby s small span strong strike sub sup table tt u ul var' ),
		);
	}

	// The nearest open element named in $targets, or -1 when an element in
	// $boundaries stands between. An ended form is no longer open.
	$find = static function ( $stack, $targets, $boundaries ) {
		for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
			if ( $stack[ $i ][2] ) {
				continue;
			}
			if ( isset( $targets[ $stack[ $i ][0] ] ) ) {
				return $i;
			}
			if ( isset( $boundaries[ $stack[ $i ][0] ] ) ) {
				return -1;
			}
		}
		return -1;
	};
	// Close the top element — with $tag, or an end tag of its name — and a
	// form under it that ended while it was open.
	$pop = static function ( &$stack, $tag = null ) {
		$top = array_pop( $stack );
		$out = null !== $tag ? $tag : '</' . $top[0] . '>';
		while ( $stack && $stack[ count( $stack ) - 1 ][2] ) {
			$out .= '</' . array_pop( $stack )[0] . '>';
		}
		return $out;
	};
	// End tags for the elements open from the top down to $i, $i included.
	$close = static function ( &$stack, $i ) use ( $pop ) {
		$out = '';
		while ( count( $stack ) > $i ) {
			$out .= $pop( $stack );
		}
		return $out;
	};
	// Whether nothing open above $i is an element that ends searches.
	$plain_above = static function ( $stack, $i ) use ( $sets ) {
		for ( $j = count( $stack ) - 1; $j > $i; $j-- ) {
			if ( ! $stack[ $j ][2] && isset( $sets['special'][ $stack[ $j ][0] ] ) ) {
				return false;
			}
		}
		return true;
	};

	// A tag's attributes as a browser reads them: a quote starts a value only
	// after `=`. One read as "inside quotes" from any quote would run past
	// the tag's `>` on a stray one.
	$attrs = '(?:[^>"\'=]++|=\s*+(?:"[^"]*+"|\'[^\']*+\')?|["\'])*+';
	$out   = '';
	// Open elements, outermost first: array( name, inside svg/math, a form
	// that ended with elements still open inside it ).
	$stack = array();
	$len   = strlen( $html );
	$pos   = 0;

	while ( $pos < $len ) {
		$lt = strpos( $html, '<', $pos );
		if ( false === $lt ) {
			$out .= substr( $html, $pos );
			break;
		}
		$out .= substr( $html, $pos, $lt - $pos );
		$pos  = $lt;

		// A comment, a doctype, CDATA, a processing instruction: as written.
		if ( preg_match( '/\G(?:<!--.*?(?:-->|\z)|<!\[CDATA\[.*?(?:\]\]>|\z)|<[!?][^>]*+(?:>|\z))/s', $html, $m, 0, $pos ) ) {
			$out .= $m[0];
			$pos += strlen( $m[0] );
			continue;
		}

		if ( preg_match( '/\G<\/([a-zA-Z][^\s\/>]*+)' . $attrs . '>/', $html, $m, 0, $pos ) ) {
			$pos += strlen( $m[0] );
			$name = strtolower( $m[1] );

			// Inside an <svg> or <math>, its own end tag closes what is open
			// in it; any other is read as HTML.
			for ( $i = count( $stack ) - 1; $i >= 0 && $stack[ $i ][1]; $i-- ) {
				if ( $stack[ $i ][0] === $name ) {
					break;
				}
			}
			if ( $i >= 0 && $stack[ $i ][1] ) {
				$out .= $close( $stack, $i + 1 );
				$out .= $pop( $stack, $m[0] );
				continue;
			}

			if ( 'br' === $name ) {
				$out .= '<br>'; // A line break, to a browser.
				continue;
			}
			if ( isset( $sets['document'][ $name ] ) ) {
				continue;
			}

			// A form ended with elements still open inside it keeps them: a
			// browser takes the form off its open elements and goes on adding
			// to them, so the form closes after the last of them.
			if ( 'form' === $name ) {
				$i = $find( $stack, array( 'form' => 0 ), $sets['scope'] );
				if ( $i >= 0 && $i < count( $stack ) - 1 ) {
					$stack[ $i ][2] = true;
					continue;
				}
			}

			if ( 'p' === $name ) {
				$i = $find( $stack, array( 'p' => 0 ), $sets['button_scope'] );
				if ( $i < 0 ) {
					$out .= '<p></p>'; // A browser makes an empty paragraph of it.
					continue;
				}
			} elseif ( 'li' === $name ) {
				$i = $find( $stack, array( 'li' => 0 ), $sets['list_scope'] );
			} elseif ( isset( $sets['headings'][ $name ] ) ) {
				// `<h2>…</h3>` closes the h2.
				$i = $find( $stack, $sets['headings'], $sets['scope'] );
			} elseif ( isset( $sets['table_end'][ $name ] ) ) {
				$i = $find( $stack, array( $name => 0 ), $sets['table_scope'] );
			} elseif ( isset( $sets['block_end'][ $name ] ) ) {
				$i = $find( $stack, array( $name => 0 ), $sets['scope'] );
			} elseif ( isset( $sets['formatting'][ $name ] ) ) {
				$i = $find( $stack, array( $name => 0 ), $sets['scope'] );
				if ( $i >= 0 && ! $plain_above( $stack, $i ) ) {
					// A block opened inside it: a browser's adoption agency
					// rebuilds this. Left as written, for libxml (see above).
					$out .= $m[0];
					continue;
				}
			} else {
				// Any other: the nearest open element of the name, unless an
				// element that ends searches comes first.
				$i = -1;
				for ( $j = count( $stack ) - 1; $j >= 0; $j-- ) {
					if ( $stack[ $j ][2] ) {
						continue;
					}
					if ( $stack[ $j ][0] === $name ) {
						$i = $j;
						break;
					}
					if ( isset( $sets['special'][ $stack[ $j ][0] ] ) ) {
						break;
					}
				}
			}

			// Nothing of that name open where it could close: a browser
			// ignores the end tag. Left in, it could close the wrong element —
			// one `</div>` too many closed the converter's root.
			if ( $i < 0 ) {
				continue;
			}
			$out .= $close( $stack, $i + 1 );
			$out .= $pop( $stack, $stack[ $i ][0] === $name ? $m[0] : null );
			continue;
		}

		if ( preg_match( '/\G<([a-zA-Z][^\s\/>]*+)(' . $attrs . ')>/', $html, $m, 0, $pos ) ) {
			$pos += strlen( $m[0] );
			$name = strtolower( $m[1] );
			$tag  = $m[0];
			// `/>`, unless the slash ends an unquoted value (`href=/`).
			$self = '/' === substr( rtrim( $m[2] ), -1 ) && ! preg_match( '/=\s*+[^\s"\'>]*\/\s*$/', $m[2] );
			$top  = $stack ? $stack[ count( $stack ) - 1 ] : null;

			// Inside an <svg> or <math>: its own elements, a slash closing
			// them — until an HTML element that cannot be there closes it.
			if ( $top && $top[1] && ! isset( $sets['integration'][ $top[0] ] ) ) {
				if ( ! isset( $sets['breakout'][ $name ] ) && ! ( 'font' === $name && preg_match( '/\s(?:color|face|size)\s*=/i', ' ' . $m[2] ) ) ) {
					if ( ! $self ) {
						$stack[] = array( $name, true, false );
					}
					$out .= $tag;
					continue;
				}
				while ( $stack && $stack[ count( $stack ) - 1 ][1] && ! isset( $sets['integration'][ $stack[ count( $stack ) - 1 ][0] ] ) ) {
					$out .= $pop( $stack );
				}
			}

			if ( isset( $sets['document'][ $name ] ) ) {
				$out .= $tag;
				continue;
			}

			// A list item ends the one before it; a term or a description, the
			// one before it.
			if ( 'li' === $name || 'dd' === $name || 'dt' === $name ) {
				$same = 'li' === $name ? array( 'li' => 0 ) : array( 'dd' => 0, 'dt' => 0 );
				for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
					$node = $stack[ $i ][0];
					if ( $stack[ $i ][2] ) {
						continue;
					}
					if ( isset( $same[ $node ] ) ) {
						$out .= $close( $stack, $i );
						break;
					}
					if ( isset( $sets['special'][ $node ] ) && 'address' !== $node && 'div' !== $node && 'p' !== $node ) {
						break;
					}
				}
			}

			// A block ends an open paragraph; a heading is not inside a heading.
			if ( isset( $sets['closes_p'][ $name ] ) ) {
				$i = $find( $stack, array( 'p' => 0 ), $sets['button_scope'] );
				if ( $i >= 0 ) {
					$out .= $close( $stack, $i );
				}
				if ( isset( $sets['headings'][ $name ] ) && $stack && isset( $sets['headings'][ $stack[ count( $stack ) - 1 ][0] ] ) ) {
					$out .= $pop( $stack );
				}
			}

			// A cell ends the cell before it; a row, the row; a table section,
			// the section.
			if ( isset( $sets['table_end'][ $name ] ) && 'table' !== $name && 'caption' !== $name && 'colgroup' !== $name ) {
				$levels = array( array( 'td' => 0, 'th' => 0 ) );
				if ( 'td' !== $name && 'th' !== $name ) {
					$levels[] = array( 'tr' => 0 );
				}
				if ( 'tbody' === $name || 'thead' === $name || 'tfoot' === $name ) {
					$levels[] = array( 'tbody' => 0, 'thead' => 0, 'tfoot' => 0 );
				}
				foreach ( $levels as $level ) {
					$i = $find( $stack, $level, $sets['table_scope'] );
					if ( $i >= 0 ) {
						$out .= $close( $stack, $i );
					}
				}
			}

			if ( 'option' === $name || 'optgroup' === $name ) {
				if ( $stack && 'option' === $stack[ count( $stack ) - 1 ][0] ) {
					$out .= $pop( $stack );
				}
				if ( 'optgroup' === $name && $stack && 'optgroup' === $stack[ count( $stack ) - 1 ][0] ) {
					$out .= $pop( $stack );
				}
			}

			// A link does not hold a link; a button, a button.
			if ( 'a' === $name ) {
				for ( $i = count( $stack ) - 1; $i >= 0 && ! isset( $sets['markers'][ $stack[ $i ][0] ] ); $i-- ) {
					if ( 'a' === $stack[ $i ][0] && ! $stack[ $i ][2] ) {
						if ( $plain_above( $stack, $i ) ) {
							$out .= $close( $stack, $i );
						}
						break;
					}
				}
			} elseif ( 'button' === $name ) {
				$i = $find( $stack, array( 'button' => 0 ), $sets['scope'] );
				if ( $i >= 0 ) {
					$out .= $close( $stack, $i );
				}
			}

			if ( isset( $sets['raw'][ $name ] ) ) {
				$end   = preg_match( '/<\/' . $name . '(?=[\s\/>])[^>]*+>/i', $html, $e, PREG_OFFSET_CAPTURE, $pos ) ? $e[0][1] + strlen( $e[0][0] ) : $len;
				$out  .= $tag . substr( $html, $pos, $end - $pos );
				$pos   = $end;
				continue;
			}
			if ( isset( $sets['void'][ $name ] ) ) {
				$out .= $tag;
				continue;
			}

			if ( 'svg' === $name || 'math' === $name ) {
				if ( ! $self ) {
					$stack[] = array( $name, true, false );
				}
				$out .= $tag;
				continue;
			}

			if ( $self ) {
				// An open element to a browser; libxml would close it.
				$tag = '<' . $m[1] . preg_replace( '/\/\s*$/', '', $m[2] ) . '>';
			}
			$stack[] = array( $name, false, false );
			$out    .= $tag;
			continue;
		}

		// A `<` that starts nothing is text.
		$out .= '<';
		$pos++;
	}

	return $out . $close( $stack, 0 );
}

/**
 * The attribute name a mockup wrote, from the one the parser saw.
 *
 * @param string $name Lowercased by the parser.
 * @return string Lowercase, as a browser reads an HTML attribute name.
 */
function kerf_mc_decode_attribute_name( $name ) {
	$name = strtolower( (string) $name );
	if ( 0 === strpos( $name, 'kerf-x-' ) && preg_match( '/^kerf-x-((?:[0-9a-f]{2})+)$/', $name, $m ) ) {
		return strtolower( (string) hex2bin( $m[1] ) );
	}
	return $name;
}

/**
 * kerf_mc_decode_attribute_name() over serialized markup: inside tags only.
 *
 * @param string $html
 * @return string
 */
function kerf_mc_decode_attribute_names( $html ) {
	$html = (string) $html;
	if ( false === strpos( $html, 'kerf-x-' ) ) {
		return $html;
	}
	return (string) preg_replace_callback(
		'/<[a-zA-Z][^>]*>/',
		static function ( $tag ) {
			return (string) preg_replace_callback(
				'/(\s)(kerf-x-(?:[0-9a-f]{2})+)(?=[\s=\/>])/',
				static function ( $a ) {
					return $a[1] . kerf_mc_decode_attribute_name( $a[2] );
				},
				$tag[0]
			);
		},
		$html
	);
}

/**
 * The shape an attribute name may have to be stored and printed: what a
 * browser reads as one name, without anything that would end it early.
 * Shared with the renderer (kerf_attribute_pairs()), which must agree.
 *
 * @param string $name Lowercase.
 * @return bool
 */
function kerf_mc_attribute_name_ok( $name ) {
	return (bool) preg_match( '/^[a-z_:@#][a-z0-9_.:@#\[\]-]*$/', (string) $name );
}

/**
 * Does a front-end framework run this attribute as code?
 *
 * Alpine (`x-on:click`, `@click`, `:class`, `x-init`), Vue (`v-…`, `@`, `:`,
 * `#`), htmx (`hx-…`, `data-hx-…` — a request whose answer is put into the
 * page, scripts included), AngularJS (`ng-…`), Knockout (`data-bind`),
 * hyperscript (`_`, `script`), Datastar's handlers and signals. With the
 * library on the page, these ARE scripts: `x-init="…"` runs like an inline
 * `onload`. So they follow the rule scripts follow (§5.32): kept from an
 * import by someone who may add scripts, and added or changed by no one else
 * (the converter, and kerf_directives_guard_post_data() on every save).
 *
 * Datastar's `data-text`, `data-show` and `data-class` are left out: CSS
 * effects use `data-text` everywhere, and gating it would stop Authors editing
 * a glitch heading. A site running Datastar needs those gated too (§9.22).
 *
 * And the browser's own: an inline event handler (`onclick`, `onerror`) is
 * the same kind of code. It was refused outright, from everyone — and AI
 * tools write `<button onclick="toggleMenu()">`: a design's phone menu, its
 * tabs and its picture fallbacks did nothing on the site (scar 108).
 *
 * @param string $name Lowercase attribute name.
 * @return bool
 */
function kerf_mc_is_directive_attribute( $name ) {
	return (bool) preg_match(
		'/^(?:[@:#]|x-|v-|hx-|data-hx-|ng-|data-ng-|data-on[-:]|data-signals|data-computed|data-effect)|^(?:_|script|data-script|data-bind|on[a-z]+)$/',
		(string) $name
	);
}

/**
 * Is this element one of the business's details, and which?
 *
 * Marked (`data-kerf-site="phone"`), or found: a `tel:` link is the phone, a
 * `mailto:` link the email, a link to a profile on a social network that
 * network — a share button (`sharer`, `intent/tweet`) is not a profile. The
 * same key with another value — a second branch's phone — becomes `phone-2`.
 *
 * @param DOMElement $node
 * @return array{key:string,text:string,href:string,bind_text:bool}|null
 */
function kerf_mc_site_detail( $node ) {
	$tag    = strtolower( $node->nodeName );
	$href   = 'a' === $tag ? trim( $node->getAttribute( 'href' ) ) : '';
	$marked = strtolower( trim( $node->getAttribute( 'data-kerf-site' ) ) );
	$key    = '';

	if ( '' !== $marked ) {
		$key = preg_replace( '/[^a-z0-9-]/', '', 'twitter' === $marked ? 'x' : $marked );
	} elseif ( preg_match( '/^tel:/i', $href ) ) {
		$key = 'phone';
	} elseif ( preg_match( '/^mailto:/i', $href ) ) {
		$key = 'email';
	} elseif ( preg_match( '#^https?://(?:[a-z0-9-]+\.)*(facebook|fb|instagram|twitter|x|linkedin|youtube|youtu|tiktok|pinterest|wa|whatsapp|threads)\.(?:com|me|be|net)/#i', $href, $m )
		&& ! preg_match( '#sharer|share\.php|/intent/|shareArticle|/share\?|pin/create#i', $href ) ) {
		$networks = array( 'fb' => 'facebook', 'twitter' => 'x', 'youtu' => 'youtube', 'wa' => 'whatsapp' );
		$key      = isset( $networks[ strtolower( $m[1] ) ] ) ? $networks[ strtolower( $m[1] ) ] : strtolower( $m[1] );
	}
	if ( '' === $key ) {
		return null;
	}

	$text   = kerf_mc_text_with_breaks( $node );
	$base   = preg_replace( '/-\d+$/', '', $key );
	$value  = $text;
	$before = '';
	$after  = '';

	// A link's own text is the value only where it shows one: "(512) 555-0142",
	// not "Facebook" or an icon — and of "Call (512) 555-0142", the number, with
	// "Call " kept around it as the design wrote it. A marked element that is
	// not a link is its text.
	$bind_text = 'a' !== $tag;
	if ( 'a' === $tag && ( 'phone' === $base || 'email' === $base ) ) {
		$pattern = 'phone' === $base ? '/\+?\(?\d[\d\s().\-]{5,}\d/' : '/[^\s@<>()]+@[^\s@<>()]+\.[a-z]{2,}/i';
		if ( preg_match( $pattern, $text, $m, PREG_OFFSET_CAPTURE ) ) {
			$value     = $m[0][0];
			$before    = substr( $text, 0, $m[0][1] );
			$after     = substr( $text, $m[0][1] + strlen( $m[0][0] ) );
			$bind_text = true;
		}
	}

	// One key per detail. A phone or an email is the number it dials, however
	// it is written; a second, different one is phone-2.
	$ctx = kerf_mc_context();
	for ( $n = 2; isset( $ctx['site'][ $key ] ) && ! kerf_mc_site_same( $ctx['site'][ $key ], $href, $value ); $n++ ) {
		$key = $base . '-' . $n;
	}
	if ( ! isset( $ctx['site'][ $key ] ) ) {
		$ctx['site'][ $key ] = array( 'text' => $bind_text ? $value : '', 'href' => $href );
		kerf_mc_context( array( 'site' => $ctx['site'] ) );
	} elseif ( $bind_text && '' !== $ctx['site'][ $key ]['text'] && $ctx['site'][ $key ]['text'] !== $value ) {
		// The same number written another way ("555.000.1111"): it follows the
		// link, and keeps its own writing rather than being changed at import.
		$bind_text = false;
	}

	return array( 'key' => $key, 'text' => $value, 'href' => $href, 'bind_text' => $bind_text, 'before' => $before, 'after' => $after );
}

/**
 * Is this the detail already known as that key? By what a link opens when
 * both have one; by text otherwise.
 *
 * @param array  $known { text, href }
 * @param string $href
 * @param string $text
 * @return bool
 */
function kerf_mc_site_same( $known, $href, $text ) {
	if ( '' !== $href && ! empty( $known['href'] ) ) {
		return strtolower( $known['href'] ) === strtolower( $href );
	}
	return isset( $known['text'] ) && $known['text'] === $text;
}

/**
 * An element's text with each `<br>` as a line break — an address is often
 * written on two lines.
 *
 * @param DOMNode $node
 * @return string
 */
function kerf_mc_text_with_breaks( $node ) {
	$text = '';
	foreach ( $node->childNodes as $child ) {
		if ( XML_TEXT_NODE === $child->nodeType ) {
			$text .= $child->textContent;
		} elseif ( XML_ELEMENT_NODE === $child->nodeType ) {
			$text .= 'br' === strtolower( $child->nodeName ) ? "\n" : kerf_mc_text_with_breaks( $child );
		}
	}
	return trim( implode( "\n", array_map( static function ( $line ) {
		return trim( (string) preg_replace( '/\s+/u', ' ', $line ) );
	}, explode( "\n", $text ) ) ) );
}

/**
 * Bind a converted block to a business detail: a text link or a text leaf
 * through Block Bindings (`kerf/site`, so the editor shows the value too); an
 * element — an icon link, an address on two lines — by `kerfSite`, read at
 * render (kerf_site_apply()).
 *
 * @param string $markup
 * @param array  $detail From kerf_mc_site_detail().
 * @return string
 */
function kerf_mc_bind_site( $markup, $detail ) {
	$root = kerf_mc_root_block( $markup );
	$bind = static function ( $part ) use ( $detail ) {
		$args = array( 'key' => $detail['key'], 'part' => $part );
		// The words the design wrote around the value: "Call " a number.
		if ( 'text' === $part && ( '' !== $detail['before'] || '' !== $detail['after'] ) ) {
			$args['before'] = $detail['before'];
			$args['after']  = $detail['after'];
		}
		return array( 'source' => 'kerf/site', 'args' => $args );
	};

	if ( 'kerf/link' === $root['name'] ) {
		$bindings = '' !== $detail['href'] ? array( 'url' => $bind( 'href' ) ) : array();
		if ( $detail['bind_text'] ) {
			$bindings['text'] = $bind( 'text' );
		}
		return $bindings ? kerf_mc_add_root_attrs( $markup, array( 'metadata' => array( 'bindings' => $bindings ) ) ) : $markup;
	}
	if ( 'kerf/text' === $root['name'] && $detail['bind_text'] && empty( $root['attrs']['bare'] ) ) {
		return kerf_mc_add_root_attrs( $markup, array( 'metadata' => array( 'bindings' => array( 'text' => $bind( 'text' ) ) ) ) );
	}
	if ( 'kerf/div' === $root['name'] ) {
		return kerf_mc_add_root_attrs( $markup, array( 'kerfSite' => $detail['key'] ) );
	}
	// `<p data-kerf-site="address">`: core's text is bindable as it is.
	if ( in_array( $root['name'], array( 'core/paragraph', 'core/heading' ), true ) && $detail['bind_text'] ) {
		return kerf_mc_add_root_attrs( $markup, array( 'metadata' => array( 'bindings' => array( 'content' => $bind( 'text' ) ) ) ) );
	}

	kerf_mc_warn( sprintf( '%s is the business\'s %s but converted to a block that cannot follow Kerf → Site details; change it there and here.', kerf_mc_describe_name( $markup ), $detail['key'] ), 'general' );
	return $markup;
}

/**
 * A block's name, for a report line.
 *
 * @param string $markup
 * @return string
 */
function kerf_mc_describe_name( $markup ) {
	$root = kerf_mc_root_block( $markup );
	return '' !== $root['name'] ? $root['name'] : 'An element';
}

/**
 * Should Kerf send this form, and as what? '' when not.
 *
 * Yes when the designer marked it `data-kerf-form` (its value names it), and
 * when it would send nowhere on its own — no `action`, `#`, a script URL, or a
 * Netlify form (that only works on Netlify) — and holds a field a person fills
 * in. A form with a password field is a login and is left alone; so is one
 * posting to a real address.
 *
 * @param DOMElement $form
 * @return string The form's name: the marker's, a Netlify form's, `newsletter` for an email alone, else `contact`.
 */
function kerf_mc_form_to_send( $form ) {
	$clean = static function ( $name ) {
		return strtolower( trim( (string) preg_replace( '/[^a-z0-9_-]+/i', '-', (string) $name ), '-' ) );
	};

	$fields = 0;
	$email  = 0;
	foreach ( $form->getElementsByTagName( '*' ) as $element ) {
		$tag  = strtolower( $element->nodeName );
		$type = strtolower( trim( $element->getAttribute( 'type' ) ) );
		if ( 'input' === $tag && 'password' === $type ) {
			return '';
		}
		// A file field counts: what it sends goes with the email (inc/kerf-forms.php).
		if ( 'textarea' === $tag || 'select' === $tag
			|| ( 'input' === $tag && ! in_array( $type, array( 'hidden', 'submit', 'button', 'reset', 'image', 'search' ), true ) ) ) {
			$fields++;
			$email += 'email' === $type ? 1 : 0;
		}
	}

	if ( $form->hasAttribute( 'data-kerf-form' ) ) {
		$name = $clean( $form->getAttribute( 'data-kerf-form' ) );
		return '' !== $name ? $name : 'contact';
	}
	if ( ! $fields ) {
		return '';
	}

	$action  = trim( $form->getAttribute( 'action' ) );
	$netlify = $form->hasAttribute( 'netlify' ) || $form->hasAttribute( 'data-netlify' );
	if ( '' !== $action && '#' !== $action && ! preg_match( '/^\s*javascript:/i', $action ) && ! $netlify ) {
		return '';
	}

	if ( $netlify && '' !== $clean( $form->getAttribute( 'name' ) ) ) {
		return $clean( $form->getAttribute( 'name' ) );
	}
	return ( 1 === $fields && 1 === $email ) ? 'newsletter' : 'contact';
}

/**
 * Give a name to each field of a form Kerf sends that has none, so its answer
 * arrives: a browser submits only named fields, and AI-written forms often
 * leave them out. From the field's type, else its placeholder, label or id.
 *
 * A file field that takes several files sends each under its name, and PHP
 * keeps only the last of a name sent twice unless it ends in `[]`: such a
 * field's name gets the `[]` (`$multiple`), so every file chosen arrives.
 *
 * @param DOMElement $form
 * @param string[]   $multiple Out: the file fields renamed so.
 * @return string[] The names given.
 */
function kerf_mc_name_form_fields( $form, &$multiple = array() ) {
	$taken    = array();
	$todo     = array();
	$multiple = array();
	foreach ( $form->getElementsByTagName( '*' ) as $element ) {
		$tag  = strtolower( $element->nodeName );
		$type = strtolower( trim( $element->getAttribute( 'type' ) ) );
		if ( ! in_array( $tag, array( 'input', 'textarea', 'select' ), true )
			|| in_array( $type, array( 'hidden', 'submit', 'button', 'reset', 'image' ), true ) ) {
			continue;
		}
		if ( '' !== trim( $element->getAttribute( 'name' ) ) ) {
			$taken[ strtolower( trim( $element->getAttribute( 'name' ) ) ) ] = true;
		} else {
			$todo[] = $element;
		}
	}

	$given = array();
	foreach ( $todo as $element ) {
		$tag  = strtolower( $element->nodeName );
		$type = strtolower( trim( $element->getAttribute( 'type' ) ) );
		$hint = strtolower( $element->getAttribute( 'placeholder' ) . ' ' . $element->getAttribute( 'aria-label' ) . ' ' . $element->getAttribute( 'id' ) );
		$by_type = array( 'email' => 'email', 'tel' => 'phone', 'date' => 'date', 'time' => 'time', 'number' => 'number', 'url' => 'website', 'checkbox' => 'agree', 'radio' => 'choice', 'file' => 'file' );

		if ( 'textarea' === $tag ) {
			$name = 'message';
		} elseif ( 'select' === $tag ) {
			$name = 'choice';
		} elseif ( isset( $by_type[ $type ] ) ) {
			$name = $by_type[ $type ];
		} elseif ( preg_match( '/\b(?:e-?mail)\b/', $hint ) ) {
			$name = 'email';
		} elseif ( preg_match( '/\b(?:phone|mobile|tel)\b/', $hint ) ) {
			$name = 'phone';
		} elseif ( preg_match( '/\bcompany\b/', $hint ) ) {
			$name = 'company';
		} elseif ( preg_match( '/\bsubject\b/', $hint ) ) {
			$name = 'subject';
		} elseif ( preg_match( '/\bname\b/', $hint ) ) {
			$name = 'name';
		} else {
			$name = 'field';
		}

		$unique = $name;
		for ( $n = 2; isset( $taken[ $unique ] ); $n++ ) {
			$unique = $name . '-' . $n;
		}
		$taken[ $unique ] = true;
		$element->setAttribute( 'name', $unique );
		$given[] = $unique;
	}

	foreach ( $form->getElementsByTagName( 'input' ) as $element ) {
		$name = trim( $element->getAttribute( 'name' ) );
		if ( 'file' === strtolower( trim( $element->getAttribute( 'type' ) ) ) && $element->hasAttribute( 'multiple' )
			&& '' !== $name && '[]' !== substr( $name, -2 ) ) {
			$element->setAttribute( 'name', $name . '[]' );
			$multiple[] = $name . '[]';
		}
	}

	return $given;
}

/**
 * Quoted relative asset paths in code — an Alpine gallery's
 * `images: ['img/tote-1.jpg', …]`, a `:src="'img/a.jpg'"` — resolved to the
 * file WordPress serves (kerf_mc_resolve_asset_reference()). Only a quoted
 * string that is a path with an asset extension, and only when it resolves:
 * anything else in the code is left exactly as written.
 *
 * @param string $code
 * @return string
 */
function kerf_mc_resolve_asset_literals( $code ) {
	$code = (string) $code;
	if ( ! preg_match( '/\.(?:' . kerf_mc_asset_extensions() . ')[\'"`]/i', $code ) ) {
		return $code;
	}
	return (string) preg_replace_callback(
		'/([\'"`])((?:\.{1,2}\/)*[\w%.\/-]+\.(?:' . kerf_mc_asset_extensions() . '))\1/i',
		static function ( $m ) {
			$resolved = kerf_mc_resolve_asset_reference( $m[2] );
			return $resolved === $m[2] ? $m[0] : $m[1] . $resolved . $m[1];
		},
		$code
	);
}

/**
 * Record an attribute that runs code, left out because the importer may not
 * add scripts. One report line for the whole conversion, by name and count
 * (kerf_mc_report_directives()): an Alpine page has hundreds.
 *
 * @param string $name
 */
function kerf_mc_drop_directive( $name ) {
	$ctx = kerf_mc_context();
	$ctx['directive_drops'][ $name ] = ( isset( $ctx['directive_drops'][ $name ] ) ? $ctx['directive_drops'][ $name ] : 0 ) + 1;
	kerf_mc_context( array( 'directive_drops' => $ctx['directive_drops'] ) );
}

/**
 * The report line for kerf_mc_drop_directive(), once per conversion.
 */
function kerf_mc_report_directives() {
	$ctx = kerf_mc_context();
	if ( empty( $ctx['directive_drops'] ) ) {
		return;
	}
	$names = array();
	foreach ( $ctx['directive_drops'] as $name => $count ) {
		$names[] = '`' . $name . '`' . ( $count > 1 ? ' ×' . $count : '' );
	}
	kerf_mc_warn(
		'Attributes that run code (onclick and the like, Alpine, htmx, Vue) were left out, because only someone who may add scripts can import them: '
			. implode( ', ', array_slice( $names, 0, 12 ) ) . ( count( $names ) > 12 ? ' and ' . ( count( $names ) - 12 ) . ' more' : '' ) . '. Ask an administrator who may (on a network, a super admin) to run this import.',
		'dropped'
	);
}

/**
 * The `<body>` element's attributes, if the input was a full document.
 *
 * Mockups routinely hang page-level styling off `<body class="home dark-theme">`
 * — dropping it loses the whole colour scheme with nothing to show for it. The
 * class reaches the rendered body through `body_class`; the id and the rest
 * through Kerf's template canvas (inc/kerf-document.php).
 *
 * Everything ELSE on the tag is kept too, under `attributes`. Scripts configure
 * themselves from the body — Bootstrap's scrollspy is `<body data-spy="scroll"
 * data-target="…">` and nothing else — and a template anchoring its "back to
 * top" links at `<body id="page-top">` needs that id to exist.
 *
 * @param string $html
 * @return array{class:string,id:string,attributes:array<string,string>}
 */
function kerf_mc_extract_body_attributes( $html ) {
	$out = array( 'class' => '', 'id' => '', 'attributes' => array() );

	$attrs = kerf_mc_extract_tag_attributes( $html, 'body' );

	$out['class'] = isset( $attrs['class'] ) ? trim( $attrs['class'] ) : '';
	$out['id']    = isset( $attrs['id'] ) ? trim( $attrs['id'] ) : '';

	unset( $attrs['class'], $attrs['id'] );
	$out['attributes'] = $attrs;

	return $out;
}

/**
 * The `<html>` element's attributes, if the input was a full document.
 *
 * `<html class="h-100" data-bs-theme="auto">` is how Bootstrap's own examples
 * size the page and pick a colour scheme; `class="no-js"` is how a Modernizr
 * template gates its styles.
 *
 * @param string $html
 * @return array<string,string>
 */
function kerf_mc_extract_html_attributes( $html ) {
	return kerf_mc_extract_tag_attributes( $html, 'html' );
}

/**
 * Every attribute on the first opening `<$tag>` in a document.
 *
 * @param string $html
 * @param string $tag
 * @return array<string,string> Lowercased names. A valueless attribute maps to ''.
 */
function kerf_mc_extract_tag_attributes( $html, $tag ) {
	$out = array();

	if ( ! preg_match( '/<' . $tag . '\b((?:"[^"]*"|\'[^\']*\'|[^>])*)>/i', (string) $html, $m ) ) {
		return $out;
	}

	// A name is whatever a browser reads as one, `@keydown.escape` included —
	// a narrower pattern started the match after the `@` and stored the
	// attribute as `keydown.escape`.
	if ( preg_match_all(
		'/([^\s"\'>\/=]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'>]+)))?/',
		$m[1],
		$pairs,
		PREG_SET_ORDER
	) ) {
		foreach ( $pairs as $pair ) {
			$name = strtolower( $pair[1] );
			if ( ! kerf_mc_attribute_name_ok( $name ) ) {
				continue;
			}
			$value = '';
			foreach ( array( 2, 3, 4 ) as $group ) {
				if ( isset( $pair[ $group ] ) && '' !== $pair[ $group ] ) {
					$value = $pair[ $group ];
					break;
				}
			}
			$out[ $name ] = html_entity_decode( $value, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
	}

	return $out;
}

/**
 * Demote a single outer `<header>`/`<footer>`/`<main>` to a `<div>`.
 *
 * A converted header is written INTO the header template part, and the template
 * that renders the part already emits the landmark — so the result was
 * `<header><header class="main-header">…`. Nested `<header>` is invalid, gives
 * screen readers two banner landmarks, and stacks two positioned wrappers.
 *
 * Only the OUTERMOST element is touched, and only when it is the sole root.
 * Every class, id and attribute is kept, so CSS written as `.main-header` still
 * matches. A selector written as `header.main-header` would not; that is the
 * trade, and it is reported.
 *
 * @param string $html
 * @return array{html:string,demoted:string} demoted is '' when nothing changed.
 */
function kerf_mc_demote_root_landmark( $html ) {
	$html      = (string) $html;
	$landmarks = array( 'header', 'footer', 'main' );

	// Confirm via the DOM that the landmark really is the only root element — a
	// regex alone cannot tell a wrapper from the first of several siblings.
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML(
		'<?xml encoding="utf-8"?><div data-kerf-mc-root="1">' . kerf_mc_extract_body( $html ) . '</div>',
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
	);
	libxml_clear_errors();

	$root = $doc->documentElement;
	if ( ! $root ) {
		return array( 'html' => $html, 'demoted' => '' );
	}

	$elements = array();
	foreach ( $root->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			$elements[] = $child;
		}
	}
	if ( 1 !== count( $elements ) ) {
		return array( 'html' => $html, 'demoted' => '' );
	}

	$tag = strtolower( $elements[0]->nodeName );
	if ( ! in_array( $tag, $landmarks, true ) ) {
		return array( 'html' => $html, 'demoted' => '' );
	}

	// Swap the outermost open/close tags only, leaving everything between them
	// byte-for-byte intact.
	$open = preg_replace( '/^(\s*)<' . $tag . '(\s[^>]*)?>/i', '$1<div$2>', $html, 1, $open_count );
	if ( ! $open_count ) {
		return array( 'html' => $html, 'demoted' => '' );
	}
	$closed = preg_replace( '/<\/' . $tag . '\s*>(\s*)$/i', '</div>$1', $open, 1, $close_count );
	if ( ! $close_count ) {
		return array( 'html' => $html, 'demoted' => '' );
	}

	return array( 'html' => $closed, 'demoted' => $tag );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN ENTRY POINT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Convert an HTML string to WordPress block markup.
 *
 * @param string     $html          Markup to convert.
 * @param array|null $manifest_data Manifest with 'upload_url' and 'media' keys.
 * @param array      $options       {
 *     @type string $base_url     Absolute URL the mockup came from, used to
 *                                absolutize relative hrefs. Default ''.
 *     @type bool   $eager_images Mark every image in this pass as above the
 *                                fold. Set when converting a header, where
 *                                lazy-loading the logo delays the one image
 *                                every visitor sees. Default false.
 *     @type string $staging_url  Public URL of the staged mockup folder. Used
 *                                as the last resort for media that did not
 *                                resolve to a library attachment. Default ''.
 *     @type bool   $directives   Keep attributes that run code (Alpine, htmx…,
 *                                kerf_mc_is_directive_attribute()). False when
 *                                the importer may not add scripts. Default true.
 * }
 * @return array{markup:string,warnings:string[],report:array[],elements:int,truncated:bool}
 */
function kerf_mc_convert_html( $html, $manifest_data = null, $options = array() ) {
	$html = kerf_mc_extract_body( $html );

	// Media is found by PATH, the way the browser found it — `thumbs/01.jpg` and
	// `fulls/01.jpg` are two different images, and a lightbox gallery pairs them
	// on every thumbnail. A bare-name lookup is kept only for names that are
	// unambiguous within the mockup; see kerf_mc_resolve_media().
	$media_by_name = array();
	$media_by_path = array();
	$ambiguous     = array();
	if ( $manifest_data && ! empty( $manifest_data['media'] ) ) {
		foreach ( $manifest_data['media'] as $item ) {
			if ( empty( $item['filename'] ) ) {
				continue;
			}
			$name = strtolower( $item['filename'] );
			if ( isset( $media_by_name[ $name ] ) && ( $media_by_name[ $name ]['id'] ?? 0 ) !== ( $item['id'] ?? 0 ) ) {
				$ambiguous[ $name ] = true;
			}
			$media_by_name[ $name ] = $item;
			if ( ! empty( $item['path'] ) ) {
				$media_by_path[ strtolower( $item['path'] ) ] = $item;
			}
		}
	}

	$ctx                  = kerf_mc_blank_context();
	$ctx['media_by_name'] = array_diff_key( $media_by_name, $ambiguous );
	$ctx['media_by_path'] = $media_by_path;
	$ctx['manifest']      = $manifest_data;
	$ctx['base_url']      = isset( $options['base_url'] ) ? (string) $options['base_url'] : '';
	$ctx['eager_images']  = ! empty( $options['eager_images'] );
	$ctx['staging_url']   = isset( $options['staging_url'] ) ? (string) $options['staging_url'] : '';
	$ctx['base_rel']      = isset( $options['base_rel'] ) ? trim( (string) $options['base_rel'], '/' ) : '';
	$ctx['template']      = isset( $options['template'] ) ? (string) $options['template'] : '';
	$ctx['directives']    = ! isset( $options['directives'] ) || ! empty( $options['directives'] );
	// The business details the site already has, as the design had them: the
	// same phone on this page is the same key, another is phone-2 (§5.36).
	$ctx['site']          = isset( $options['site_known'] ) && is_array( $options['site_known'] ) ? $options['site_known'] : array();
	// Whether to find and bind them at all: off unless asked — without it a
	// phone link is the design's link, as written.
	$ctx['site_details']  = ! empty( $options['site_details'] );
	// Live posts where the design marks them, or its samples (kerf_mc_live_fields()).
	$ctx['dynamic']       = ! empty( $options['dynamic'] );
	kerf_mc_context( $ctx );

	// Wrap in a synthetic root so multiple top-level siblings (two consecutive
	// <section>s, say) all survive — LIBXML_HTML_NOIMPLIED otherwise leaves
	// documentElement pointing at only the first, silently dropping the rest.
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML(
		'<?xml encoding="utf-8"?><div data-kerf-mc-root="1">' . $html . '</div>',
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
	);
	libxml_clear_errors();

	$root     = $doc->documentElement;
	$output   = '';
	$sections = array();

	// Where each section came from, read before the prepass touches anything:
	// what a later version of the mockup is compared against. The blocks are
	// stamped as they are converted (kerf_mc_convert_node()), by node, so a
	// section inside the page's one <main> is stamped where it stands.
	if ( ! empty( $options['stamp'] ) && $root && $root->hasAttribute( 'data-kerf-mc-root' ) ) {
		$stamps = new SplObjectStorage();
		foreach ( kerf_mc_section_keys( $root ) as $entry ) {
			$stamps[ $entry['node'] ] = $entry;
			unset( $entry['node'] );
			$sections[] = $entry;
		}
		kerf_mc_context( array( 'stamps' => $stamps ) );
	}

	if ( $root && kerf_mc_context()['dynamic'] ) {
		kerf_mc_contract_prepass( $root );
	}

	// Unasked, what the design marks for WordPress to fill in keeps the
	// design's samples — said once, so the owner knows why.
	$live_marked = $root && ! kerf_mc_context()['dynamic'] ? kerf_mc_count_live_marked( $root ) : 0;
	if ( $live_marked ) {
		kerf_mc_warn( sprintf(
			'%d %s marked to show your posts or comments (data-kerf-loop, data-kerf-field): %s the design\'s sample content, as written.',
			$live_marked,
			1 === $live_marked ? 'place is' : 'places are',
			1 === $live_marked ? 'it shows' : 'they show'
		), 'general' );
	}

	if ( $root && $root->hasAttribute( 'data-kerf-mc-root' ) ) {
		$output = kerf_mc_convert_children( $root, 0 );
	} else {
		// Defensive fallback if the wrapper did not survive parsing.
		$body    = $doc->getElementsByTagName( 'body' )->item( 0 );
		$html_el = $doc->getElementsByTagName( 'html' )->item( 0 );
		if ( $body ) {
			$output = kerf_mc_convert_children( $body, 0 );
		} elseif ( $html_el ) {
			$output = kerf_mc_convert_children( $html_el, 0 );
		} elseif ( $root ) {
			$output = kerf_mc_convert_node( $root, 0 );
		}
	}

	kerf_mc_report_directives();
	$ctx = kerf_mc_context();

	return array(
		'markup'    => $output,
		'warnings'  => $ctx['warnings'],
		'report'    => $ctx['report'],
		'elements'  => $ctx['elements'],
		'truncated' => $ctx['truncated'],
		'sections'  => $sections,
		'site'      => $ctx['site'],
		// Places marked for live content that kept the samples (unasked).
		'live_marked' => $live_marked,
	);
}

/**
 * The top-level sections of a mockup region, as a later version of the same
 * mockup will be compared against them: a key that finds the same section
 * again, and a hash of its markup.
 *
 * The key is the element's tag with its id, or else its first class, and a
 * count when several share it: `section#pricing`, `section.page-section~2`.
 * Content may change; what a designer calls a section rarely does. The hash
 * is of the markup with its whitespace collapsed — re-indenting a file is not
 * changing it.
 *
 * @param string $html Region HTML (a mockup body, or part of one).
 * @return array<int,array{key:string,src:string,label:string}> Keyed by position among the root's child nodes.
 */
function kerf_mc_sections( $html ) {
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML(
		'<?xml encoding="utf-8"?><div data-kerf-mc-root="1">' . kerf_mc_extract_body( $html ) . '</div>',
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
	);
	libxml_clear_errors();

	$out = array();
	foreach ( $doc->documentElement ? kerf_mc_section_keys( $doc->documentElement ) : array() as $entry ) {
		unset( $entry['node'] );
		$out[] = $entry;
	}
	return $out;
}

/**
 * The element whose children are a region's sections, and the wrappers on
 * the way to it.
 *
 * A region is usually a run of sections. Just as often it is ONE wrapper
 * holding them — the page's `<main id="content">`, a `<div class="wrapper">`
 * — and keyed at the top, every change anywhere would be "the page changed",
 * replacing all of it and every edit made in WordPress with it. So a lone
 * wrapper with several children is gone through, up to three deep.
 *
 * @param DOMElement $root
 * @return array{0:DOMElement,1:string[]} The parent, and the wrappers' keys.
 */
function kerf_mc_section_parent( $root ) {
	$parent = $root;
	$path   = array();

	for ( $depth = 0; $depth < 3; $depth++ ) {
		$only  = null;
		$count = 0;
		foreach ( $parent->childNodes as $child ) {
			if ( XML_ELEMENT_NODE === $child->nodeType && ! kerf_mc_is_asset_tag( $child ) ) {
				$count++;
				$only = $child;
			} elseif ( XML_TEXT_NODE === $child->nodeType && '' !== trim( $child->textContent ) ) {
				$count += 2;
			}
		}
		if ( 1 !== $count || kerf_mc_element_count( $only ) < 2 ) {
			break;
		}
		$path[] = kerf_mc_section_base( $only );
		$parent = $only;
	}

	return array( $parent, $path );
}

/**
 * Tags that are not sections: what the asset pipeline lifts out.
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_mc_is_asset_tag( $node ) {
	return in_array( strtolower( $node->nodeName ), array( 'script', 'style', 'link', 'meta', 'noscript', 'template' ), true );
}

/**
 * `section#pricing`, `section.page-section`, `div`.
 *
 * @param DOMElement $node
 * @return string
 */
function kerf_mc_section_base( $node ) {
	$tag   = strtolower( $node->nodeName );
	$id    = trim( $node->getAttribute( 'id' ) );
	$class = strtok( trim( $node->getAttribute( 'class' ) ) . ' ', " \t\n" );
	return $tag . ( '' !== $id ? '#' . $id : ( false !== $class && '' !== $class ? '.' . $class : '' ) );
}

/**
 * kerf_mc_sections() on a parsed root, with each section's node.
 *
 * @param DOMElement $root
 * @return array[] Each: key, src, label, node.
 */
function kerf_mc_section_keys( $root ) {
	list( $parent, $path ) = kerf_mc_section_parent( $root );

	$keys   = array();
	$seen   = array();
	$prefix = $path ? implode( ' > ', $path ) . ' > ' : '';

	foreach ( iterator_to_array( $parent->childNodes ) as $child ) {
		if ( XML_ELEMENT_NODE !== $child->nodeType || kerf_mc_is_asset_tag( $child ) ) {
			continue;
		}

		$base          = kerf_mc_section_base( $child );
		$seen[ $base ] = isset( $seen[ $base ] ) ? $seen[ $base ] + 1 : 1;
		$source        = trim( preg_replace( '/\s+/u', ' ', $child->ownerDocument->saveHTML( $child ) ) );

		$keys[] = array(
			'key'   => $prefix . ( 1 === $seen[ $base ] ? $base : $base . '~' . $seen[ $base ] ),
			'src'   => substr( md5( $source ), 0, 12 ),
			'label' => kerf_mc_section_label( $child ),
			'node'  => $child,
		);
	}

	return $keys;
}

/**
 * A section as a person would name it: its first heading, else its opening
 * words.
 *
 * @param DOMNode $node
 * @return string
 */
function kerf_mc_section_label( $node ) {
	if ( XML_ELEMENT_NODE === $node->nodeType ) {
		foreach ( array( 'h1', 'h2', 'h3', 'h4' ) as $tag ) {
			$heading = $node->getElementsByTagName( $tag )->item( 0 );
			if ( $heading && '' !== trim( $heading->textContent ) ) {
				return kerf_mc_trim_label( $heading->textContent );
			}
		}
	}
	return kerf_mc_trim_label( $node->textContent );
}

/**
 * @param string $text
 * @return string At most eight words.
 */
function kerf_mc_trim_label( $text ) {
	$words = preg_split( '/\s+/u', trim( (string) $text ), -1, PREG_SPLIT_NO_EMPTY );
	return implode( ' ', array_slice( $words, 0, 8 ) ) . ( count( $words ) > 8 ? '…' : '' );
}

// ═══════════════════════════════════════════════════════════════════════════════
// NODE TRAVERSAL
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Convert all child nodes of a parent element.
 *
 * @param DOMNode $parent
 * @param int     $depth
 * @return string
 */
function kerf_mc_convert_children( $parent, $depth ) {
	$output = '';
	foreach ( $parent->childNodes as $node ) {
		$output .= kerf_mc_convert_node( $node, $depth );
	}
	return $output;
}

/**
 * Convert a single DOM node, honouring Kerf's markers on it.
 *
 * `data-kerf-only` is written by the import's split (kerf_import_split(),
 * rule 4), never by a designer: it is removed before conversion and becomes the
 * block's `kerfOnly`, which the renderer enforces.
 *
 * `data-kerf-loop` and `data-kerf-field` are the MARKUP CONTRACT: written by a
 * designer, or their AI, to say which parts of a page WordPress fills in. They
 * stay on the element — they are the designer's attributes — and become a
 * kerf/loop around the first card, bindings on the element's block, or the
 * post body / page links inside it. See kerf_mc_convert_field_node().
 *
 * @param DOMNode $node
 * @param int     $depth
 * @return string
 */
function kerf_mc_convert_node( $node, $depth ) {
	// A section of the mockup (kerf_mc_section_keys()): its block carries where
	// it came from — `kerfSource` {key, src}, never rendered, kept on save.
	$ctx = kerf_mc_context();
	// Array syntax, not contains()/detach(): both are deprecated in PHP 8.5.
	if ( $ctx['stamps'] instanceof SplObjectStorage && isset( $ctx['stamps'][ $node ] ) ) {
		$entry = $ctx['stamps'][ $node ];
		unset( $ctx['stamps'][ $node ] );
		$markup = kerf_mc_convert_node( $node, $depth );
		return '' === trim( $markup )
			? $markup
			: kerf_mc_add_root_attrs( $markup, array( 'kerfSource' => array( 'key' => $entry['key'], 'src' => $entry['src'] ) ) );
	}

	// The business's details — a phone, an email, an address, a social
	// profile — bound to one place, so they are changed once (§5.36), when
	// asked (`site_details`). The node converts as it would, and its block is
	// then bound.
	if ( XML_ELEMENT_NODE === $node->nodeType && kerf_mc_context()['site_details'] && ! $node->hasAttribute( 'data-kerf-site-done' ) ) {
		$detail = kerf_mc_site_detail( $node );
		if ( $detail ) {
			$node->setAttribute( 'data-kerf-site-done', '1' );
			return kerf_mc_bind_site( kerf_mc_convert_node( $node, $depth ), $detail );
		}
	}

	// A mockup's own search box is wired to WordPress search without being
	// marked: the form, and the one text field in it. (§8.10, step 6.)
	if ( XML_ELEMENT_NODE === $node->nodeType && 'form' === strtolower( $node->nodeName )
		&& ! $node->hasAttribute( 'data-kerf-field' ) && ! $node->hasAttribute( 'data-kerf-auto' ) ) {
		$input = kerf_mc_is_search_form( $node );
		if ( $input ) {
			$node->setAttribute( 'data-kerf-auto', 'search-form' );
			$input->setAttribute( 'data-kerf-auto', 'search-input' );
			kerf_mc_warn( sprintf( '%s is a search form, so it now searches this site.', kerf_mc_describe( $node ) ), 'general' );
		} else {
			// A form that sends nowhere by itself — no address, `#`, a Netlify
			// form — or one the designer marked data-kerf-form: Kerf sends it
			// (inc/kerf-forms.php, §5.35). A form posting to a real address
			// (Formspree, a CRM) works already and is left alone.
			$form_name = kerf_mc_form_to_send( $node );
			if ( '' !== $form_name ) {
				$multiple = array();
				$named    = kerf_mc_name_form_fields( $node, $multiple );
				$files    = false;
				foreach ( $node->getElementsByTagName( 'input' ) as $input ) {
					$files = $files || 'file' === strtolower( trim( $input->getAttribute( 'type' ) ) );
				}
				$node->setAttribute( 'data-kerf-form-auto', $form_name );
				kerf_mc_warn( sprintf(
					'%s now sends: each message is emailed to you.%s%s%s',
					kerf_mc_describe( $node ),
					$files ? ' Files chosen in it are attached to the email.' : '',
					$named ? ' Its fields with no name were given one, so their answers arrive: ' . implode( ', ', $named ) . '.' : '',
					$multiple ? ' A field taking several files was renamed so that every file arrives, not just the last: ' . implode( ', ', $multiple ) . '.' : ''
				), 'general' );
			}
		}
	}

	// Unasked (`dynamic`), a loop or a post field is the designer's attribute
	// and nothing more; a search box marked for search still searches.
	$dynamic = ! empty( $ctx['dynamic'] );
	if ( XML_ELEMENT_NODE !== $node->nodeType
		|| ! ( $node->hasAttribute( 'data-kerf-only' ) || ( $dynamic && $node->hasAttribute( 'data-kerf-loop' ) )
			|| kerf_mc_live_fields( $node ) || $node->hasAttribute( 'data-kerf-auto' )
			|| $node->hasAttribute( 'data-kerf-auto-field' ) || $node->hasAttribute( 'data-kerf-slot' )
			|| $node->hasAttribute( 'data-kerf-form-auto' ) ) ) {
		return kerf_mc_convert_node_as_written( $node, $depth );
	}

	// Where the post's comment list goes when the designer's own form stays
	// (kerf_mc_contract_prepass()): in place of their sample list, or just
	// before the form. Internal markers, never rendered.
	$slot = $node->getAttribute( 'data-kerf-slot' );
	if ( 'comments-list' === $slot || 'comments-before' === $slot ) {
		$node->removeAttribute( 'data-kerf-slot' );
		if ( 'comments-list' === $slot ) {
			// The designer's own <ul>/<ol>: WordPress's items go straight in.
			return kerf_mc_container_with( $node, $depth, '<!-- wp:kerf/comments {"form":false,"items":true} /-->', "the post's comments" );
		}
		return str_repeat( '  ', $depth ) . '<!-- wp:kerf/comments {"form":false} /-->' . "\n" . kerf_mc_convert_node( $node, $depth );
	}

	$only = '';
	if ( $node->hasAttribute( 'data-kerf-only' ) ) {
		$only = strtolower( trim( $node->getAttribute( 'data-kerf-only' ) ) );
		$node->removeAttribute( 'data-kerf-only' );
	}

	// The first marked card repeats for every post; the ones after it were
	// the designer's samples. kerf_mc_wrap_loop() reports them, once.
	$loop = $dynamic && $node->hasAttribute( 'data-kerf-loop' );
	if ( $loop && kerf_mc_marked_sibling( $node, 'data-kerf-loop', 'previous' ) ) {
		return '';
	}

	$fields = kerf_mc_live_fields( $node );

	// Sample post meta the prepass recognised: bound like a marked field, but
	// never written into the page — the designer did not write it. On an
	// element (a card link wrapping a picture) it is recorded in kerfFields,
	// where the render reads element fields.
	$auto_field = '';
	if ( $node->hasAttribute( 'data-kerf-auto-field' ) ) {
		if ( ! $fields ) {
			$auto_field = $node->getAttribute( 'data-kerf-auto-field' );
			$fields     = array( $auto_field );
		}
		$node->removeAttribute( 'data-kerf-auto-field' );
	}

	// A sample article is often several elements — an intro, a picture, a
	// quote — each marked `content`: the first holds the post's body, the
	// rest were samples of it. Likewise two comment lists: the post's comments
	// go where the first one is. Page-wide, not per parent. A comments area
	// holding the designer's comment FORM is not a list (the form stays), so
	// it does not count.
	foreach ( array( 'content', 'comments' ) as $container ) {
		if ( ! in_array( $container, $fields, true ) ) {
			continue;
		}
		if ( 'comments' === $container && kerf_mc_comment_form_in( $node ) ) {
			continue;
		}
		$ctx = kerf_mc_context();
		if ( ! empty( $ctx['placed'][ $container ] ) ) {
			kerf_mc_warn( sprintf(
				'%1$s is marked %2$s as well; the first element marked %2$s holds it, so this one — more of the sample — was left out.',
				kerf_mc_describe( $node ),
				$container
			), 'converted' );
			return '';
		}
		$ctx['placed'][ $container ] = true;
		kerf_mc_context( $ctx );
	}

	// Auto-wired search: the input of a form kerf_mc_is_search_form()
	// recognised (see below). A block attribute, not an HTML one: the
	// designer's markup is not added to.
	$auto = '';
	if ( $node->hasAttribute( 'data-kerf-auto' ) ) {
		$auto = $node->getAttribute( 'data-kerf-auto' );
		$node->removeAttribute( 'data-kerf-auto' );
	}

	// A form Kerf sends (above): which one, as a block attribute — never written
	// into the designer's markup.
	$form_auto = '';
	if ( $node->hasAttribute( 'data-kerf-form-auto' ) ) {
		$form_auto = $node->getAttribute( 'data-kerf-form-auto' );
		$node->removeAttribute( 'data-kerf-form-auto' );
	}

	$markup = $fields
		? kerf_mc_convert_field_node( $node, $depth, $fields )
		: kerf_mc_convert_node_as_written( $node, $depth );

	if ( '' !== $auto ) {
		$markup = kerf_mc_add_root_attrs( $markup, array( 'kerfFields' => $auto ), 'kerf/' );
	}
	if ( '' !== $form_auto ) {
		$markup = kerf_mc_add_root_attrs( $markup, array( 'kerfForm' => $form_auto ), 'kerf/div' );
	}
	if ( '' !== $auto_field ) {
		$root = kerf_mc_root_block( $markup );
		if ( 'kerf/div' === $root['name'] ) {
			$have   = isset( $root['attrs']['kerfFields'] ) ? $root['attrs']['kerfFields'] . ' ' : '';
			$markup = kerf_mc_add_root_attrs( $markup, array( 'kerfFields' => trim( $have . $auto_field ) ), 'kerf/div' );
		}
	}

	if ( $loop && '' !== trim( $markup ) ) {
		$markup = kerf_mc_wrap_loop( $node, $depth, $markup );
	}

	if ( 'front' === $only ) {
		$marked = kerf_mc_add_root_attrs( $markup, array( 'kerfOnly' => 'front' ), 'kerf/' );
		if ( $marked === $markup && '' !== trim( $markup ) ) {
			kerf_mc_warn( sprintf(
				'<%s> is the home page\'s intro but converted to a block that cannot be limited to the home page; it will show on every page.',
				strtolower( $node->nodeName )
			), 'converted' );
		}
		$markup = $marked;
	}

	return $markup;
}

/**
 * Merge attributes into the first (root) block comment of converted markup.
 *
 * Block comments cannot contain `--` (kerf_mc_json_encode_block_attrs() escapes
 * it), so the comment ends at the first `-->` after it opens, and the JSON is
 * everything in between.
 *
 * @param string $markup  Converted block markup.
 * @param array  $add     Attributes to merge; later keys win.
 * @param string $prefix  Only touch blocks whose name starts with this, or ''.
 * @return string The markup, unchanged when there is no matching root block.
 */
function kerf_mc_add_root_attrs( $markup, $add, $prefix = '' ) {
	if ( ! preg_match( '/^(\s*)<!-- wp:([a-z0-9-]+\/[a-z0-9-]+|[a-z0-9-]+) (?:(\{.*?\}) )?(\/)?-->/s', $markup, $m, PREG_OFFSET_CAPTURE ) ) {
		return $markup;
	}

	$name = $m[2][0];
	if ( '' !== $prefix && 0 !== strpos( $name, $prefix ) ) {
		return $markup;
	}

	$attrs = array();
	if ( isset( $m[3] ) && -1 !== $m[3][1] && '' !== $m[3][0] ) {
		$decoded = json_decode( $m[3][0], true );
		if ( ! is_array( $decoded ) ) {
			return $markup;
		}
		$attrs = $decoded;
	}

	$attrs   = array_replace_recursive( $attrs, $add );
	$closing = ( isset( $m[4] ) && -1 !== $m[4][1] && '/' === $m[4][0] ) ? '/-->' : '-->';
	$comment = $m[1][0] . '<!-- wp:' . $name . ' ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' ' . $closing;

	return $comment . substr( $markup, strlen( $m[0][0] ) );
}

/**
 * Convert a single DOM node to WordPress block markup.
 *
 * @param DOMNode $node
 * @param int     $depth
 * @return string
 */
function kerf_mc_convert_node_as_written( $node, $depth ) {
	// Comments carry no rendered output, and a conditional comment carrying
	// markup would be re-parsed by whatever reads the block later.
	if ( XML_COMMENT_NODE === $node->nodeType ) {
		return '';
	}

	// Bare significant text between elements, at the top level. Emitting
	// kerf/text rather than dropping it keeps copy that lives directly inside a
	// flex container; `bare` renders it as the text it was, with no element.
	if ( XML_TEXT_NODE === $node->nodeType ) {
		$text = trim( $node->textContent );
		if ( '' === $text ) {
			return '';
		}
		return str_repeat( '  ', $depth )
			. '<!-- wp:kerf/text ' . kerf_mc_json_encode_block_attrs( kerf_mc_bare_text_attrs( $node, $text ) ) . ' /-->' . "\n";
	}

	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return '';
	}

	if ( ! kerf_mc_budget_ok( $depth ) ) {
		return '';
	}

	$tag = strtolower( $node->nodeName );

	// A script that writes into the page stays where it was written. Only a
	// REFERENCE goes into the block: the code itself is kept with the imported
	// assets, which only an administrator can change, so nobody who can edit a
	// page can put script into it through this block.
	if ( 'script' === $tag && '' === $node->getAttribute( 'src' ) ) {
		$type = strtolower( trim( $node->getAttribute( 'type' ) ) );
		if ( in_array( $type, array( '', 'text/javascript', 'application/javascript' ), true )
			&& kerf_mc_is_inplace_script( $node->textContent ) ) {
			return str_repeat( '  ', $depth )
				. '<!-- wp:kerf/script ' . kerf_mc_json_encode_block_attrs( array( 'ref' => kerf_mc_script_ref( $node->textContent ) ) ) . ' /-->' . "\n";
		}
	}

	// A <script> that is not JavaScript: data a script reads stays where it
	// was written, by reference as an in-place script does — from an import
	// by someone who may add scripts (the asset list holds it, scar 112).
	// JSON-LD, or anyone else's, is not imported — nor enqueued, whatever the
	// asset-owned line below would say.
	if ( 'script' === $tag && ! kerf_mc_is_js_type( $node->getAttribute( 'type' ) ) ) {
		$type = strtolower( trim( $node->getAttribute( 'type' ) ) );
		if ( kerf_mc_context()['directives'] && kerf_mc_is_kept_data_script( $type ) && '' === $node->getAttribute( 'src' ) && '' !== trim( $node->textContent ) ) {
			return str_repeat( '  ', $depth )
				. '<!-- wp:kerf/script ' . kerf_mc_json_encode_block_attrs( array( 'ref' => kerf_mc_script_ref( $node->textContent ) ) ) . ' /-->' . "\n";
		}
		kerf_mc_warn( kerf_mc_data_script_message( $type ), 'dropped' );
		return '';
	}

	// Asset-owned and never-safe elements.
	if ( in_array( $tag, kerf_mc_dropped_tags(), true ) ) {
		return kerf_mc_report_dropped( $tag );
	}

	// core/heading and core/paragraph keep their inner HTML verbatim, as rich
	// text. A <script> inside one therefore went into POST CONTENT — and the
	// asset pipeline also lifted the same script into the footer, so a
	// `Copyright <script>document.write(…)</script>` line ran twice: the year
	// in place, and again under the footer. Converted as an element instead,
	// the script becomes a kerf/script reference and the text around it bare
	// text, exactly where they were.
	//
	// The same goes for a marker of the markup contract inside one — `<h3><a
	// data-kerf-field="title">` — which in rich text would never become a
	// block, so never be bound.
	//
	// And for media, or anything never safe, inside one. Rich text writes its
	// inner HTML through verbatim — fine for <strong>/<em>/<a>/<br>, fatal for
	// an <img>: its src is never looked up in the media library, so a mockup's
	// `assets/images/team.jpg` ships as a dead relative path with no srcset
	// and no way to swap the picture in the editor. `<p><img></p>` is how most
	// editors wrap a standalone image, and `<h1 class="logo"><a><img>` is how
	// most templates write their logo. An <svg> in a heading lost its
	// `viewBox` case there (scar 3) and was never sanitized; an <object> in a
	// paragraph was never dropped. As elements, each gets its own block.
	if ( ( 'p' === $tag || preg_match( '/^h[1-6]$/', $tag ) )
		&& ( $node->getElementsByTagName( 'script' )->length > 0 || kerf_mc_has_marked_descendant( $node )
			|| $node->hasAttribute( 'data-kerf-auto-text' ) || kerf_mc_rich_text_needs_blocks( $node ) ) ) {
		return kerf_mc_convert_element( $node, $depth, $tag );
	}

	// Headings → core/heading. The only normalizing block kept, because
	// `wp-block-heading` is purely additive and heading UX is worth it.
	if ( preg_match( '/^h([1-6])$/', $tag, $m ) ) {
		return kerf_mc_convert_heading( $node, $depth, (int) $m[1] );
	}

	if ( 'p' === $tag ) {
		return kerf_mc_convert_paragraph( $node, $depth );
	}

	if ( 'img' === $tag ) {
		return kerf_mc_convert_image( $node, $depth );
	}

	// <picture> → kerf/image from its <img> fallback. The theme regenerates
	// modern formats and srcset at render time, so <source> variants are
	// redundant and would only pin the page to the mockup's file layout.
	if ( 'picture' === $tag ) {
		return kerf_mc_convert_picture( $node, $depth );
	}

	if ( 'figure' === $tag ) {
		return kerf_mc_convert_figure( $node, $depth );
	}

	if ( 'video' === $tag ) {
		return kerf_mc_convert_video( $node, $depth );
	}

	if ( 'svg' === $tag ) {
		return kerf_mc_convert_svg( $node, $depth );
	}

	// An anchor with element children keeps its whole subtree, so it has to be
	// an element block; a text-only one becomes kerf/link, which has a proper
	// URL control in the sidebar.
	if ( 'a' === $tag ) {
		if ( kerf_mc_has_element_children( $node ) ) {
			return kerf_mc_convert_element( $node, $depth, 'a' );
		}
		return kerf_mc_convert_link( $node, $depth );
	}

	// A standalone icon element. Purely an editor affordance — kerf/icon renders
	// exactly what kerf/div with tagName=i would, and the classes are passed
	// through byte-for-byte whichever icon set they belong to.
	if ( in_array( $tag, array( 'i', 'span' ), true )
		&& kerf_mc_looks_like_icon( $node )
		&& '' === trim( $node->textContent )
		&& ! kerf_mc_has_element_children( $node ) ) {
		return kerf_mc_convert_icon( $node, $depth );
	}

	// A text-only inline element becomes kerf/text, which stores its content as
	// a plain string and is therefore directly editable.
	$inline_tags = array(
		'span', 'small', 'strong', 'b', 'em', 'i', 'u', 's', 'mark', 'time',
		'label', 'sup', 'sub', 'abbr', 'cite', 'code', 'kbd', 'samp', 'var',
		'q', 'del', 'ins', 'bdi', 'bdo', 'data', 'output', 'dfn',
	);
	if ( in_array( $tag, $inline_tags, true )
		&& ! kerf_mc_has_element_children( $node )
		&& '' !== trim( $node->textContent ) ) {
		return kerf_mc_convert_text( $node, $depth, $tag );
	}

	// Everything else — section, nav, ul, li, table, tr, td, details, summary,
	// form, input, iframe, canvas, dl, and any tag not invented yet — is one
	// element with one set of attributes, which is exactly what kerf/div is.
	//
	// This is the branch that makes the promise true. There is no "unsupported
	// element" path and no raw-HTML fallback: an element the converter has never
	// heard of still round-trips, still keeps its classes, and is still editable
	// as a block, because the block does not need to understand the tag to render
	// it. Empty inline elements land here too, and they matter — an empty <span>
	// in a mockup is drawn entirely by its parent's CSS (`.rule span{flex:1}` for
	// a divider, `.stars i` for rating pips), so dropping them as noise silently
	// deletes half the design.
	return kerf_mc_convert_element( $node, $depth, $tag );
}

/**
 * Charge one element against the conversion budget.
 *
 * @param int $depth Current nesting depth.
 * @return bool False when conversion of this node (and its subtree) must stop.
 */
function kerf_mc_budget_ok( $depth ) {
	$ctx = kerf_mc_context();

	if ( $depth > KERF_MC_MAX_DEPTH ) {
		if ( ! $ctx['truncated'] ) {
			$ctx['truncated'] = true;
			kerf_mc_context( $ctx );
			kerf_mc_warn(
				'Nesting deeper than ' . KERF_MC_MAX_DEPTH . ' levels was not converted. '
					. 'Markup this deep is normally an unclosed tag earlier in the file.',
				'limit'
			);
		}
		return false;
	}

	$ctx['elements']++;
	if ( $ctx['elements'] > KERF_MC_MAX_ELEMENTS ) {
		if ( ! $ctx['truncated'] ) {
			$ctx['truncated'] = true;
			kerf_mc_context( $ctx );
			kerf_mc_warn(
				'Stopped after ' . KERF_MC_MAX_ELEMENTS . ' elements — the rest of the document was not converted. '
					. 'Split the mockup into separate pages and convert them one at a time.',
				'limit'
			);
		}
		return false;
	}

	kerf_mc_context( $ctx );
	return true;
}

/**
 * Does a `<script type>` run as JavaScript? No type, a JavaScript type, a
 * module. Shared by the asset scanner and the converter.
 *
 * @param string $type
 * @return bool
 */
function kerf_mc_is_js_type( $type ) {
	return in_array( strtolower( trim( (string) $type ) ), array( '', 'module', 'text/javascript', 'application/javascript' ), true );
}

/**
 * Is this `<script>` type data a design's script reads — `application/json`,
 * `text/template`, `x-shader/x-vertex` — kept, inert, where it was written?
 * Not JavaScript, not an import map (kept apart), and not JSON-LD, which
 * describes the mockup's sample business (kerf_mc_data_script_message()).
 *
 * @param string $type Lowercase.
 * @return bool
 */
function kerf_mc_is_kept_data_script( $type ) {
	$type = strtolower( trim( (string) $type ) );
	return 'application/ld+json' !== $type && ! kerf_mc_is_js_type( $type )
		&& (bool) preg_match( '#^[a-z][a-z0-9.+-]*/[a-z0-9.+-]+$#', $type );
}

/**
 * What the report says of a `<script>` that is not JavaScript, which is not
 * imported: JSON-LD describes the mockup's sample content — its company, its
 * address — and on a WordPress site structured data is an SEO plugin's to
 * write. A template or data a mockup script reads is kept since 0.9.0 — from
 * an import by someone who may add scripts (scar 112). It used to be stored,
 * never printed, and reported as enqueued.
 *
 * @param string $type The script's type, lower-cased.
 * @return string
 */
function kerf_mc_data_script_message( $type ) {
	if ( 'application/ld+json' === $type ) {
		return 'Structured data (<script type="application/ld+json">) was not imported: it describes the mockup\'s sample content, and on WordPress an SEO plugin writes it.';
	}
	return 'A <script type="' . $type . '"> was not imported: it is data or a template for a script to read, not JavaScript, and Kerf keeps none.';
}

/**
 * Record a dropped element and return nothing.
 *
 * @param string $tag
 * @return string Always ''.
 */
function kerf_mc_report_dropped( $tag ) {
	static $asset_owned = array( 'script', 'style', 'link', 'title', 'meta', 'base' );

	if ( in_array( $tag, $asset_owned, true ) ) {
		kerf_mc_warn(
			"<$tag> is handled by the asset pipeline, not page content — it is enqueued on the front end rather than stored in the post.",
			'asset'
		);
	} else {
		kerf_mc_warn( "<$tag> was dropped; it has no safe equivalent in post content.", 'dropped' );
	}

	return '';
}

// ═══════════════════════════════════════════════════════════════════════════════
// BLOCK CONVERTERS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Convert any element to kerf/div.
 *
 * The workhorse. Emits the tag, its class, its id, its inline style, every other
 * attribute, and its converted children.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @param string     $tag_name Tag to render.
 * @return string
 */
function kerf_mc_convert_element( $node, $depth, $tag_name ) {
	$indent = str_repeat( '  ', $depth );
	$attrs  = array();

	if ( 'div' !== $tag_name ) {
		$attrs['tagName'] = $tag_name;
	}

	$class = $node->getAttribute( 'class' );
	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}

	// The element id becomes the block's anchor. Dropping it broke anything the
	// mockup addressed by id — `#header` scroll handlers, skip links, `#id` CSS,
	// in-page anchor links, `getElementById()` in the mockup's own JS.
	$id = trim( $node->getAttribute( 'id' ) );
	if ( '' !== $id ) {
		$attrs['anchor'] = $id;
	}

	$inline_style = $node->getAttribute( 'style' );
	if ( '' !== $inline_style ) {
		// A background image is RECORDED in its own attribute, so the editor can
		// offer a media picker for it — but the style itself is kept whole, in
		// the order the mockup wrote it. It used to be cut out and re-emitted as
		// a `background-image:` prefix, which was wrong twice over: a shorthand
		// `background: url(x) center/cover no-repeat` lost its position, size and
		// repeat along with the url, and `background:#000; background-image:url(x)`
		// came out reversed, so the shorthand reset the image to none.
		$bg = kerf_mc_extract_background_image( $inline_style );
		if ( '' !== $bg['url'] ) {
			$attrs['backgroundImage'] = $bg['url'];
			if ( $bg['mediaId'] ) {
				$attrs['backgroundImageId'] = $bg['mediaId'];
			}
		}
		$style = trim( kerf_mc_resolve_style_urls( $inline_style ), " ;\t\n\r" );
		if ( '' !== $style ) {
			$attrs['inlineStyle'] = $style;
		}
	}

	$custom = kerf_mc_extract_custom_attributes( $node );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	$attrs_json = empty( $attrs ) ? '' : ' ' . kerf_mc_json_encode_block_attrs( $attrs );

	// A void element has no children and no closing tag, so it serializes as a
	// self-closing block.
	if ( in_array( $tag_name, kerf_mc_void_tags(), true ) ) {
		return $indent . '<!-- wp:kerf/div' . $attrs_json . ' /-->' . "\n";
	}

	// Mixed content (text AND element children): convert each child on its own,
	// so bare text becomes kerf/text and elements dispatch normally. A
	// whole-wrapper raw blob is never emitted.
	if ( kerf_mc_has_mixed_content( $node ) ) {
		return kerf_mc_wrap_children( 'kerf/div', $attrs, kerf_mc_convert_children_spaced( $node, $depth + 1 ), $indent );
	}

	// Text-only: the element IS the text, so it becomes one kerf/text carrying
	// that tag — not a wrapper with a text child.
	//
	// The wrapper-plus-child shape is the obvious one and it is wrong. It renders
	// `<td><span>Studio</span></td>` for a mockup that wrote `<td>Studio</td>`,
	// and `<summary><span>…</span></summary>` for a plain `<summary>`. The extra
	// span is invisible in a screenshot and load-bearing in CSS: `td:empty`,
	// `summary::marker`, `button > *`, any `:first-child` rule, and every
	// `display:flex` container that now has one child instead of a text run.
	// Adding an element the designer did not write is exactly the thing this
	// converter exists not to do.
	//
	// The cost is that a kerf/text is a leaf — you cannot drop a block inside it
	// without changing its type first. That is a real but recoverable editing
	// limitation, and it is worth less than markup fidelity here.
	//
	// A background image is the one case that still needs the wrapper, since
	// kerf/text has nowhere to put one — and the text inside it is bare, so on
	// the page it is still one element with text in it, as written.
	if ( kerf_mc_has_text_only( $node ) && ! isset( $attrs['backgroundImage'] ) ) {
		unset( $attrs['tagName'] );
		$text_attrs = array( 'tagName' => $tag_name, 'text' => trim( $node->textContent ) ) + $attrs;

		return $indent . '<!-- wp:kerf/text ' . kerf_mc_json_encode_block_attrs( $text_attrs ) . ' /-->' . "\n";
	}

	return kerf_mc_wrap_children( 'kerf/div', $attrs, kerf_mc_convert_children_spaced( $node, $depth + 1 ), $indent );
}

/**
 * Emit a container block around converted children, recording their gaps.
 *
 * @param string $name     Block name.
 * @param array  $attrs    Block attributes.
 * @param array  $children From kerf_mc_convert_children_spaced().
 * @param string $indent
 * @return string
 */
function kerf_mc_wrap_children( $name, $attrs, $children, $indent ) {
	if ( '' !== $children['gaps'] ) {
		$attrs['gaps'] = $children['gaps'];
	}

	$attrs_json = empty( $attrs ) ? '' : ' ' . kerf_mc_json_encode_block_attrs( $attrs );

	return $indent . '<!-- wp:' . $name . $attrs_json . ' -->' . "\n"
		. $children['markup']
		. $indent . '<!-- /wp:' . $name . ' -->' . "\n";
}

/**
 * Convert to core/heading.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @param int        $level 1-6.
 * @return string
 */
function kerf_mc_convert_heading( $node, $depth, $level ) {
	$indent = str_repeat( '  ', $depth );
	$class  = $node->getAttribute( 'class' );
	$inner  = kerf_mc_rich_text_html( $node );
	$attrs  = array( 'level' => $level );

	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}
	$attrs += kerf_mc_anchor_attr( $node );

	// Core blocks save static markup, so an inline style CANNOT go on the tag —
	// an attribute the block's save() does not regenerate fails block validation
	// and greets the editor with "unexpected or invalid content". It rides in the
	// block comment instead and kerf_core_inline_style_render() puts it back on
	// the element at render time.
	$attrs += kerf_mc_style_attr( $node );

	// So do its other attributes — `data-aos`, `data-wow-delay`, a script's
	// hook. They used to be dropped here without a word (scar 43).
	$custom = kerf_mc_extract_custom_attributes( $node );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	$class_attr = 'wp-block-heading' . ( '' !== $class ? ' ' . $class : '' );

	return $indent . '<!-- wp:heading ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' -->' . "\n"
		. $indent . '<h' . $level . ' class="' . kerf_mc_esc_attr( $class_attr ) . '"'
		. kerf_mc_anchor_html_attr( $node ) . '>' . trim( $inner ) . '</h' . $level . '>' . "\n"
		. $indent . '<!-- /wp:heading -->' . "\n";
}

/**
 * Convert to core/paragraph.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_paragraph( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$class  = $node->getAttribute( 'class' );
	$inner  = trim( kerf_mc_rich_text_html( $node ) );
	$attrs  = array();

	// An empty paragraph is often where a script writes: `<p class="search-status"
	// role="status" aria-live="polite"></p>`, a form's result line. It was
	// dropped here without a word — Brighton's search panel lost its status
	// line, and the fidelity score only listed the class as missing. As an
	// element it renders exactly as written, and the editor shows no empty
	// paragraph's "Type / to choose a block".
	if ( '' === $inner ) {
		return kerf_mc_convert_element( $node, $depth, 'p' );
	}
	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}
	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node );

	// See kerf_mc_convert_heading(): kept in the comment, put back at render.
	$custom = kerf_mc_extract_custom_attributes( $node );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	$attrs_json = empty( $attrs ) ? '' : ' ' . kerf_mc_json_encode_block_attrs( $attrs );
	$class_attr = '' !== $class ? ' class="' . kerf_mc_esc_attr( $class ) . '"' : '';

	return $indent . '<!-- wp:paragraph' . $attrs_json . ' -->' . "\n"
		. $indent . '<p' . $class_attr . kerf_mc_anchor_html_attr( $node ) . '>' . $inner . '</p>' . "\n"
		. $indent . '<!-- /wp:paragraph -->' . "\n";
}

/**
 * Convert to kerf/image.
 *
 * The media cascade, in order: the import manifest (filenames the pipeline just
 * uploaded) → a basename match anywhere in the media library (the image was
 * already there from a previous import) → the original src, left alone and
 * reported. The last case is a warning rather than a placeholder because a
 * mockup pointing at a CDN URL is legitimate and rewriting it would be wrong.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_image( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$src    = $node->getAttribute( 'src' );
	$alt    = $node->getAttribute( 'alt' );
	$width  = $node->getAttribute( 'width' );
	$height = $node->getAttribute( 'height' );
	$class  = $node->getAttribute( 'class' );
	$load   = $node->getAttribute( 'loading' );
	$style  = kerf_mc_parse_inline_style( $node->getAttribute( 'style' ) );
	$attrs  = array();

	// Lazy-loading libraries park the real URL in data-src and leave src as a
	// placeholder; taking src literally imports a 1×1 GIF for every image on the
	// page. This is near-universal in exported/scraped pages.
	foreach ( array( 'data-src', 'data-lazy-src', 'data-original' ) as $lazy_attr ) {
		$candidate = trim( $node->getAttribute( $lazy_attr ) );
		if ( '' !== $candidate && ( '' === $src || preg_match( '/^data:|placeholder|blank\.(gif|png)$/i', $src ) ) ) {
			$src = $candidate;
			break;
		}
	}

	// Blanked at render by kerf_esc_url(); said so here.
	$why = kerf_mc_unsafe_url( $src );
	if ( '' !== $why ) {
		kerf_mc_warn( "A `src` using $why on <img> was dropped.", 'dropped' );
		$src = '';
	}

	$resolved = kerf_mc_resolve_media( $src );
	if ( $resolved ) {
		$attrs['src']     = $resolved['url'];
		$attrs['mediaId'] = $resolved['id'];
		if ( '' === $alt && ! empty( $resolved['alt'] ) ) {
			$alt = $resolved['alt'];
		}
		// The library's width/height are NOT copied onto an image the mockup
		// left undimensioned. Presentational width/height attributes set the
		// rendered height, and a stylesheet with `max-width:100%` but no
		// `height:auto` — the usual Bootstrap-3/4-era reset — then squashes the
		// image horizontally while the attribute pins its height: every card in
		// a grid grows a few pixels and the photograph is distorted. Found on a
		// real template, 7px per card.
	} elseif ( '' !== $src ) {
		$attrs['src'] = $src;
		kerf_mc_warn(
			'Image "' . basename( $src ) . '" is not in the media library — it still points at "' . $src . '".',
			'media'
		);
	}

	if ( '' !== $alt )    { $attrs['alt'] = $alt; }
	if ( '' !== $width )  { $attrs['width'] = $width; }
	if ( '' !== $height ) { $attrs['height'] = $height; }
	if ( '' !== $load )   { $attrs['loading'] = $load; }
	if ( '' !== $class )  { $attrs['className'] = $class; }

	// A header is above the fold by definition, and the logo is usually the
	// first thing painted. Defaulting it to lazy — which is right for the other
	// forty images on the page — delays the one image every visitor sees and
	// costs LCP on every single page of the site.
	$ctx = kerf_mc_context();
	if ( ! empty( $ctx['eager_images'] ) && '' === $load ) {
		$attrs['hero'] = true;
	}
	if ( isset( $style['object-fit'] ) ) { $attrs['objectFit'] = $style['object-fit']; }

	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node, array( 'object-fit' ) );

	$custom = kerf_mc_extract_custom_attributes( $node, array( 'src', 'alt', 'width', 'height', 'loading' ) );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	return $indent . '<!-- wp:kerf/image ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' /-->' . "\n";
}

/**
 * Convert <picture> to kerf/image using its <img> fallback.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_picture( $node, $depth ) {
	$img = $node->getElementsByTagName( 'img' )->item( 0 );

	if ( ! $img ) {
		// No fallback <img> means the sources are the only content — keep the
		// element intact rather than guessing.
		return kerf_mc_convert_element( $node, $depth, 'picture' );
	}

	kerf_mc_warn(
		'<picture> converted to a single image — the theme regenerates modern formats and srcset, so the <source> variants are redundant.',
		'converted'
	);

	return kerf_mc_convert_image( $img, $depth );
}

/**
 * Convert <figure> to kerf/figure, recursively converting children.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_figure( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$class  = $node->getAttribute( 'class' );
	$attrs  = array();

	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}
	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node );

	$custom = kerf_mc_extract_custom_attributes( $node );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	return kerf_mc_wrap_children( 'kerf/figure', $attrs, kerf_mc_convert_children_spaced( $node, $depth + 1 ), $indent );
}

/**
 * Convert a text-only <a> to kerf/link.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_link( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$url    = trim( $node->getAttribute( 'href' ) );
	$class  = $node->getAttribute( 'class' );
	$target = $node->getAttribute( 'target' );
	$rel    = $node->getAttribute( 'rel' );
	$text   = trim( $node->textContent );
	$attrs  = array();

	// The href goes straight into `url`, past the check every other URL
	// attribute gets in kerf_mc_extract_custom_attributes() — so a
	// `javascript:` link was stored, then blanked at render, and nothing said
	// so (§8.2a).
	$why = kerf_mc_unsafe_url( $url );
	if ( '' !== $why ) {
		kerf_mc_warn( "A `href` using $why on <a> was dropped.", 'dropped' );
		$url = '';
	}

	// A text link to a file (a PDF brochure, a lightbox's full-size image) is
	// resolved like any other asset reference; a link to a page is left for
	// the binding pass.
	if ( '' !== $url ) {
		$attrs['url'] = kerf_mc_is_relative_asset( $url )
			? kerf_mc_resolve_asset_reference( $url )
			: kerf_mc_resolve_link_url( $url );
	}
	if ( '' !== $text )   { $attrs['text'] = $text; }
	if ( '' !== $class )  { $attrs['className'] = $class; }
	if ( '_blank' === $target ) { $attrs['newTab'] = true; }
	if ( '' !== $rel )    { $attrs['rel'] = $rel; }

	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node );

	$custom = kerf_mc_extract_custom_attributes( $node, array( 'href', 'target', 'rel' ) );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	$attrs_json = empty( $attrs ) ? '' : ' ' . kerf_mc_json_encode_block_attrs( $attrs );

	return $indent . '<!-- wp:kerf/link' . $attrs_json . ' /-->' . "\n";
}

/**
 * Convert an icon element to kerf/icon.
 *
 * The class list is passed through EXACTLY as written. Kerf ships no icon font
 * and translates nothing: an `<i class="ri-home-line">` stays a
 * `ri-home-line`, because the mockup's own icon stylesheet was imported
 * alongside it and is what renders the glyph. Rewriting classes to a bundled
 * set was the single biggest source of "it looked right in the mockup" bugs —
 * every unmapped glyph silently became a blank square.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_icon( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$tag    = strtolower( $node->nodeName );
	$attrs  = array( 'iconClass' => $node->getAttribute( 'class' ) );

	if ( 'i' !== $tag ) {
		$attrs['tagName'] = $tag;
	}

	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node );

	$custom = kerf_mc_extract_custom_attributes( $node );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	return $indent . '<!-- wp:kerf/icon ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' /-->' . "\n";
}

/**
 * Convert a text-only inline element to kerf/text.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @param string     $tag
 * @return string
 */
function kerf_mc_convert_text( $node, $depth, $tag ) {
	$indent = str_repeat( '  ', $depth );
	$class  = $node->getAttribute( 'class' );
	$attrs  = array( 'tagName' => $tag, 'text' => trim( $node->textContent ) );

	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}

	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node );

	$custom = kerf_mc_extract_custom_attributes( $node );
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	return $indent . '<!-- wp:kerf/text ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' /-->' . "\n";
}

/**
 * Convert inline <svg> to kerf/svg.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_svg( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$class  = $node->getAttribute( 'class' );

	// An event handler runs as surely as a <script>: `<svg onload>` is the
	// first thing anyone tries. Removed here, on a copy, for the reason given
	// below — and reported, because the sanitizer removing it at render
	// would be a silent drop (§6.6).
	$copy       = $node->cloneNode( true );
	$handlers   = array();
	$directives = array();
	foreach ( array_merge( array( $copy ), iterator_to_array( $copy->getElementsByTagName( '*' ) ) ) as $element ) {
		foreach ( iterator_to_array( $element->attributes ) as $attr ) {
			$name = kerf_mc_decode_attribute_name( $attr->nodeName );
			if ( 0 === strpos( $name, 'on' ) ) {
				$handlers[ $name ] = true;
				$element->removeAttribute( $attr->nodeName );
			} elseif ( kerf_mc_is_directive_attribute( $name ) ) {
				// Inline SVG keeps only drawing attributes (the render
				// allowlist), so an Alpine `@click` here would vanish at render.
				$directives[ $name ] = true;
				$element->removeAttribute( $attr->nodeName );
			}
		}
	}
	if ( $handlers ) {
		kerf_mc_warn( 'An event handler on an inline <svg> was removed (' . implode( ', ', array_keys( $handlers ) ) . ').', 'dropped' );
	}
	if ( $directives ) {
		kerf_mc_warn( 'An attribute that runs code on an inline <svg> was removed (' . implode( ', ', array_keys( $directives ) ) . '): inline SVG keeps only what draws it. Put it on the element around the SVG.', 'dropped' );
	}

	$markup = kerf_mc_restore_svg_case( kerf_mc_get_outer_html( $copy ) );

	// The render-time sanitizer would strip this anyway, but a stored attribute
	// is a thing people read, diff and copy out of the editor — leaving live
	// script sitting in it and trusting one function to catch it every time is
	// how a second consumer eventually gets it wrong.
	$clean = preg_replace( '#<script\b[^>]*>.*?</script\s*>#is', '', $markup );
	$clean = preg_replace( '#<script\b[^>]*/\s*>#i', '', (string) $clean );
	if ( $clean !== $markup ) {
		kerf_mc_warn( 'A <script> inside an inline <svg> was removed.', 'dropped' );
		$markup = $clean;
	}

	$attrs = array( 'svg' => trim( $markup ) );

	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}
	$aria = trim( $node->getAttribute( 'aria-label' ) );
	if ( '' !== $aria ) {
		$attrs['ariaLabel'] = $aria;
	}

	$attrs += kerf_mc_anchor_attr( $node );

	return $indent . '<!-- wp:kerf/svg ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' /-->' . "\n";
}

/**
 * Restore the camelCase spelling of SVG element and attribute names.
 *
 * `DOMDocument::loadHTML()` parses to the HTML rules, where tag and attribute
 * names are case-insensitive and get folded to lowercase. SVG is XML, where they
 * are case-SENSITIVE — so an icon comes out of the HTML parser carrying
 * `viewbox` instead of `viewBox`, and `viewbox` means nothing to a renderer. The
 * graphic then draws at its intrinsic size and ignores every width/height rule
 * pointed at it, which reads as "the logo is suddenly enormous" and has nothing
 * visible in the markup to explain it.
 *
 * The same applies to `clipPath`, `linearGradient`, `stdDeviation` and the rest
 * of the filter vocabulary: silently lowercased, silently inert.
 *
 * Only names on the map are touched, and only where they appear as a tag or an
 * attribute — so text content and URLs are never rewritten.
 *
 * @param string $markup SVG markup as produced by the HTML parser.
 * @return string
 */
function kerf_mc_restore_svg_case( $markup ) {
	static $elements = array(
		'clipPath', 'linearGradient', 'radialGradient', 'textPath', 'foreignObject',
		'animateMotion', 'animateTransform', 'feBlend', 'feColorMatrix',
		'feComponentTransfer', 'feComposite', 'feConvolveMatrix', 'feDiffuseLighting',
		'feDisplacementMap', 'feDistantLight', 'feDropShadow', 'feFlood', 'feFuncA',
		'feFuncB', 'feFuncG', 'feFuncR', 'feGaussianBlur', 'feImage', 'feMerge',
		'feMergeNode', 'feMorphology', 'feOffset', 'fePointLight', 'feSpecularLighting',
		'feSpotLight', 'feTile', 'feTurbulence',
	);

	static $attributes = array(
		'viewBox', 'preserveAspectRatio', 'baseProfile', 'clipPathUnits',
		'gradientTransform', 'gradientUnits', 'markerHeight', 'markerUnits',
		'markerWidth', 'maskContentUnits', 'maskUnits', 'patternContentUnits',
		'patternTransform', 'patternUnits', 'primitiveUnits', 'refX', 'refY',
		'repeatCount', 'repeatDur', 'requiredExtensions', 'requiredFeatures',
		'spreadMethod', 'startOffset', 'stdDeviation', 'stitchTiles', 'surfaceScale',
		'systemLanguage', 'tableValues', 'targetX', 'targetY', 'textLength',
		'lengthAdjust', 'pathLength', 'attributeName', 'attributeType',
		'baseFrequency', 'calcMode', 'diffuseConstant', 'edgeMode', 'filterUnits',
		'kernelMatrix', 'kernelUnitLength', 'keyPoints', 'keySplines', 'keyTimes',
		'limitingConeAngle', 'numOctaves', 'pointsAtX', 'pointsAtY', 'pointsAtZ',
		'specularConstant', 'specularExponent', 'xChannelSelector', 'yChannelSelector',
		'zoomAndPan',
	);

	$markup = (string) $markup;

	foreach ( $elements as $name ) {
		$markup = preg_replace(
			'#<(/?)' . strtolower( $name ) . '(?=[\s/>])#i',
			'<$1' . $name,
			$markup
		);
	}

	foreach ( $attributes as $name ) {
		$markup = preg_replace(
			'/(\s)' . strtolower( $name ) . '(\s*=)/i',
			'$1' . $name . '$2',
			$markup
		);
	}

	return $markup;
}

/**
 * Convert <video> to kerf/video.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_video( $node, $depth ) {
	$indent = str_repeat( '  ', $depth );
	$src    = trim( $node->getAttribute( 'src' ) );
	$class  = $node->getAttribute( 'class' );

	// The URL is usually on a <source> child rather than the element itself.
	if ( '' === $src ) {
		$source = $node->getElementsByTagName( 'source' )->item( 0 );
		if ( $source ) {
			$src = trim( $source->getAttribute( 'src' ) );
		}
	}

	// Blanked at render by kerf_esc_url(); said so here.
	$poster = trim( $node->getAttribute( 'poster' ) );
	$why    = kerf_mc_unsafe_url( $src );
	if ( '' !== $why ) {
		kerf_mc_warn( "A `src` using $why on <video> was dropped.", 'dropped' );
		$src = '';
	}
	$why = kerf_mc_unsafe_url( $poster );
	if ( '' !== $why ) {
		kerf_mc_warn( "A `poster` using $why on <video> was dropped.", 'dropped' );
		$poster = '';
	}

	$resolved = kerf_mc_resolve_media( $src );
	$attrs    = array( 'src' => $resolved ? $resolved['url'] : $src );

	if ( ! $resolved && '' !== $src ) {
		kerf_mc_warn(
			'Video "' . basename( $src ) . '" is not in the media library — it still points at "' . $src . '".',
			'media'
		);
	}

	if ( '' !== $poster ) {
		$poster_resolved   = kerf_mc_resolve_media( $poster );
		$attrs['poster'] = $poster_resolved ? $poster_resolved['url'] : $poster;
	}

	foreach ( array( 'autoplay', 'loop', 'muted', 'playsinline', 'controls' ) as $flag ) {
		if ( $node->hasAttribute( $flag ) ) {
			$attrs[ $flag ] = true;
		}
	}
	// An explicit `controls` absent in the source must stay absent — a background
	// video that suddenly grows a control bar is a visible regression.
	if ( ! $node->hasAttribute( 'controls' ) ) {
		$attrs['controls'] = false;
	}

	$preload = trim( $node->getAttribute( 'preload' ) );
	if ( '' !== $preload ) {
		$attrs['preload'] = $preload;
	}
	if ( '' !== $class ) {
		$attrs['className'] = $class;
	}

	$attrs += kerf_mc_anchor_attr( $node );
	$attrs += kerf_mc_style_attr( $node );

	$custom = kerf_mc_extract_custom_attributes(
		$node,
		array( 'src', 'poster', 'autoplay', 'loop', 'muted', 'playsinline', 'controls', 'preload' )
	);
	if ( ! empty( $custom ) ) {
		$attrs['customAttributes'] = $custom;
	}

	return $indent . '<!-- wp:kerf/video ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' /-->' . "\n";
}

// ═══════════════════════════════════════════════════════════════════════════════
// ATTRIBUTES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Pull every pass-through attribute off a DOM node.
 *
 * This is the function that makes "no constraint" literal, and it is an
 * allowlist by POLICY rather than by name. The reference implementation forwarded
 * only `data-*`, `aria-*` and eight static names, which meant a `<input
 * placeholder="Email" name="email" required>` arrived on the page as a nameless,
 * placeholder-less text box — the markup survived and the form did not.
 *
 * Everything is forwarded except:
 *
 *   class / id / style   already captured by dedicated block attributes; a
 *                        second copy here would print the attribute twice.
 *   code                 attributes that run code — inline event handlers
 *                        (`onclick`), Alpine's, htmx's — unless whoever imports
 *                        may add scripts (kerf_mc_is_directive_attribute()).
 *                        The mockup is authored by a third party and post
 *                        content is rendered unescaped: an `onerror` from an
 *                        import nobody may add scripts through is stored XSS.
 *                        Kept, an attribute like it is added or changed by no
 *                        one else afterwards (kerf-directives.php).
 *   srcdoc               an entire HTML document, script included, inlined as
 *                        an attribute value. Same reasoning, narrower vector.
 *   javascript:/vbscript: in any URL-bearing attribute.
 *
 * Non-`data-` attribute names are also shape-checked, because a name containing
 * a quote or a space would break out of the attribute when rendered.
 *
 * @param DOMElement $node
 * @param string[]   $skip Attributes already captured by a dedicated block
 *                         attribute on this particular block.
 * @return array<string,string>
 */
function kerf_mc_extract_custom_attributes( $node, $skip = array() ) {
	$out = array();
	if ( ! $node || ! $node->hasAttributes() ) {
		return $out;
	}

	// The engine's own markers (kerf_mc_contract_prepass()) are never the
	// designer's attributes, so they never reach the page. class, id and style
	// have block attributes of their own.
	$never = array_merge(
		array( 'class', 'id', 'style', 'data-kerf-auto', 'data-kerf-auto-field', 'data-kerf-auto-text', 'data-kerf-slot', 'data-kerf-form-auto', 'data-kerf-site-done' ),
		array_map( 'strtolower', $skip )
	);
	$urls  = kerf_mc_url_attributes();

	$directives = kerf_mc_context()['directives'];

	foreach ( $node->attributes as $attr ) {
		$name  = kerf_mc_decode_attribute_name( $attr->nodeName );
		$value = (string) $attr->nodeValue;

		if ( in_array( $name, $never, true ) ) {
			continue;
		}

		if ( kerf_mc_is_directive_attribute( $name ) ) {
			if ( ! $directives ) {
				kerf_mc_drop_directive( $name );
				continue;
			}
			// `x-data="{ images: ['img/tote-1.jpg'] }"`, `onerror="this.src=
			// 'img/fallback.jpg'"`: a path the browser resolves against the
			// page — which on WordPress is not the mockup's folder. Resolved
			// like any other asset reference.
			$value = kerf_mc_resolve_asset_literals( $value );
		}

		// A whole document that runs with the page's own origin. It sat in the
		// list above, with class and id, and so went without a word (§8.2a).
		if ( 'srcdoc' === $name ) {
			kerf_mc_warn( 'The `srcdoc` of <' . strtolower( $node->nodeName ) . '> was dropped: it is a page of its own that would run as this site.', 'dropped' );
			continue;
		}

		// A name no browser would read as one — it was skipped without a word.
		if ( ! kerf_mc_attribute_name_ok( $name ) ) {
			kerf_mc_warn( 'An attribute named `' . $name . '` on <' . strtolower( $node->nodeName ) . '> was dropped: no browser reads that as an attribute name.', 'dropped' );
			continue;
		}

		if ( in_array( $name, $urls, true ) ) {
			$why = kerf_mc_unsafe_url( $value );
			if ( '' !== $why ) {
				kerf_mc_warn(
					"A `$name` using $why on <" . strtolower( $node->nodeName ) . '> was dropped.',
					'dropped'
				);
				continue;
			}
			$value = kerf_mc_is_relative_asset( $value )
				? kerf_mc_resolve_asset_reference( $value )
				: kerf_mc_resolve_link_url( $value );
		} elseif ( 0 === strpos( $name, 'data-' ) ) {
			// Scripts read these as URLs; see kerf_mc_resolve_asset_reference().
			$value = kerf_mc_resolve_asset_reference( $value );
		}

		$out[ $name ] = $value;
	}

	return $out;
}

/**
 * The element's id as a block `anchor` attribute.
 *
 * Every block the converter emits supports `anchor` and renders it back as `id`,
 * so an id in the mockup always survives.
 *
 * @param DOMElement $node
 * @return array{anchor?:string}
 */
function kerf_mc_anchor_attr( $node ) {
	$id = trim( $node->getAttribute( 'id' ) );
	return ( '' === $id ) ? array() : array( 'anchor' => $id );
}

/**
 * The same id as a ready-to-print ` id="…"` HTML attribute.
 *
 * Static core blocks (heading, paragraph) render their SAVED markup, so the id
 * has to be written onto the element itself — the block attribute alone would be
 * ignored on the front end.
 *
 * @param DOMElement $node
 * @return string
 */
function kerf_mc_anchor_html_attr( $node ) {
	$id = trim( $node->getAttribute( 'id' ) );
	return ( '' === $id ) ? '' : ' id="' . kerf_mc_esc_attr( $id ) . '"';
}

/**
 * The element's inline `style` as a block `inlineStyle` attribute.
 *
 * Mockups hang real design on inline styles — a `border-radius` on a CTA, a
 * per-card `background`, a `max-width` on a column. `url()` references resolve
 * through the media cascade, the same as a background image.
 *
 * @param DOMElement $node
 * @param string[]   $skip Properties already captured by a dedicated attribute.
 * @return array{inlineStyle?:string}
 */
function kerf_mc_style_attr( $node, $skip = array() ) {
	$style = trim( (string) $node->getAttribute( 'style' ) );
	if ( '' === $style ) {
		return array();
	}

	$style = kerf_mc_resolve_style_urls( $style );

	foreach ( $skip as $prop ) {
		$style = preg_replace( '/(?:^|;)\s*' . preg_quote( $prop, '/' ) . '\s*:[^;]*/i', ';', $style );
	}

	$style = trim( preg_replace( '/;\s*;+/', ';', $style ), " \t\n\r;" );

	return ( '' === $style ) ? array() : array( 'inlineStyle' => $style );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MEDIA + URL RESOLUTION
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Resolve a mockup media path to a library attachment.
 *
 * Manifest first (this import's uploads), then the library by basename (a
 * previous import), then nothing.
 *
 * @param string $src
 * @return array|null { id, url, alt, width, height } or null.
 */
function kerf_mc_resolve_media( $src ) {
	$src = trim( (string) $src );
	if ( '' === $src ) {
		return null;
	}

	$ctx      = kerf_mc_context();
	$filename = strtolower( basename( kerf_mc_parse_url( $src, PHP_URL_PATH ) ?: $src ) );

	if ( '' === $filename ) {
		return null;
	}

	$as_item = static function ( $item ) {
		return array(
			'id'     => isset( $item['id'] ) ? (int) $item['id'] : 0,
			'url'    => isset( $item['url'] ) ? $item['url'] : '',
			'alt'    => isset( $item['alt'] ) ? $item['alt'] : '',
			'width'  => isset( $item['width'] ) ? (int) $item['width'] : 0,
			'height' => isset( $item['height'] ) ? (int) $item['height'] : 0,
		);
	};

	$absolute = (bool) preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//)#i', $src );

	// 1. By path, resolved against the document's folder — exact.
	if ( ! $absolute && ! empty( $ctx['media_by_path'] ) ) {
		$path = strtolower( kerf_mc_join_path( $ctx['base_rel'], $src ) );
		if ( '' !== $path && ! empty( $ctx['media_by_path'][ $path ] ) ) {
			return $as_item( $ctx['media_by_path'][ $path ] );
		}
	}

	// 2. By name, when only one image in this mockup has it. Never for an
	//    absolute URL: `https://cdn…/hero.jpg` is somebody else's hero.jpg.
	if ( ! $absolute && ! empty( $ctx['media_by_name'][ $filename ] ) ) {
		return $as_item( $ctx['media_by_name'][ $filename ] );
	}

	// 3. By name across the whole library — only outside an import. During one
	//    the manifest is authoritative, and a same-named file from an earlier
	//    mockup is a different photograph: `team-1.jpg` from the last template
	//    put its trainer where this one's plumber should be.
	if ( empty( $ctx['manifest'] ) ) {
		$attachment = kerf_mc_find_attachment_by_basename( $filename );
		if ( $attachment ) {
			return $attachment;
		}
	}

	// Last resort: the staged copy of the mockup folder. Only images are
	// imported into the media library — a video, an audio file or a poster
	// referenced from markup has no attachment to find, and left alone it ships
	// as a relative path that 404s the moment the page is viewed from anywhere
	// but the site root. The staged file definitely exists and definitely has a
	// public URL, so pointing at it is always better than pointing at nothing.
	if ( '' !== $ctx['staging_url'] && ! preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//|/)#i', $src ) ) {
		return array(
			'id'     => 0,
			'url'    => $ctx['staging_url'] . ltrim( preg_replace( '#^\./#', '', $src ), '/' ),
			'alt'    => '',
			'width'  => 0,
			'height' => 0,
		);
	}

	return null;
}

/**
 * Resolve a reference against a folder, the way a browser resolves a relative
 * URL against its document — as a path relative to the mockup's root.
 *
 * @param string $base_rel Folder of the referring document, relative to the root.
 * @param string $ref      The reference as the mockup wrote it.
 * @return string Root-relative path, or '' when it is not a local path or
 *                climbs out of the root.
 */
function kerf_mc_join_path( $base_rel, $ref ) {
	$ref = trim( (string) $ref );

	if ( '' === $ref || preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//|\#)#i', $ref ) ) {
		return '';
	}

	$ref = preg_replace( '/[?#].*$/', '', $ref );

	// Root-relative means relative to the site the mockup was served from,
	// which is the mockup's root.
	$segments = 0 === strpos( $ref, '/' ) ? array() : array_values( array_filter( explode( '/', (string) $base_rel ), 'strlen' ) );

	foreach ( explode( '/', $ref ) as $segment ) {
		if ( '' === $segment || '.' === $segment ) {
			continue;
		}
		if ( '..' === $segment ) {
			if ( ! $segments ) {
				return '';
			}
			array_pop( $segments );
			continue;
		}
		$segments[] = rawurldecode( $segment );
	}

	return implode( '/', $segments );
}

/**
 * Absolutize a relative link against the mockup's source URL, when one is known.
 *
 * A mockup written as a folder of files links to `about.html`. Left alone that
 * is a 404 on the live site; rewritten against the source URL it at least points
 * somewhere real, and the import pipeline can remap it to a WordPress page.
 * With no base URL the value is returned untouched — guessing would be worse.
 *
 * @param string $url
 * @return string
 */
function kerf_mc_resolve_link_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return $url;
	}

	// Already absolute, a fragment, or a non-http scheme the author meant.
	if ( preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//|\#)#i', $url ) ) {
		return $url;
	}

	$ctx  = kerf_mc_context();
	$base = $ctx['base_url'];
	if ( '' === $base ) {
		return $url;
	}

	$parts = kerf_mc_parse_url( $base );
	if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
		return $url;
	}

	$origin = $parts['scheme'] . '://' . $parts['host'] . ( empty( $parts['port'] ) ? '' : ':' . $parts['port'] );

	if ( 0 === strpos( $url, '/' ) ) {
		return $origin . $url;
	}

	$dir = isset( $parts['path'] ) ? preg_replace( '#/[^/]*$#', '/', $parts['path'] ) : '/';

	return $origin . $dir . $url;
}

/**
 * Look up an attachment in the media library by file basename.
 *
 * Returns null when WordPress is not loaded (CLI conversion) or nothing matches.
 * Memoized per request — a page with fifty images referencing ten files should
 * not issue fifty queries.
 *
 * @param string $filename Lowercased basename.
 * @return array|null { id, url, alt, width, height } or null.
 */
function kerf_mc_find_attachment_by_basename( $filename ) {
	static $cache = array();

	$filename = strtolower( trim( (string) $filename ) );
	if ( '' === $filename ) {
		return null;
	}
	if ( array_key_exists( $filename, $cache ) ) {
		return $cache[ $filename ];
	}

	if ( ! defined( 'ABSPATH' ) || ! function_exists( 'wp_get_attachment_url' ) ) {
		$cache[ $filename ] = null;
		return null;
	}

	global $wpdb;
	if ( ! isset( $wpdb ) ) {
		$cache[ $filename ] = null;
		return null;
	}

	// _wp_attached_file values look like "2026/01/hero-1.jpg" — match by
	// trailing basename (case-insensitive via the column collation).
	$att_id = $wpdb->get_var( $wpdb->prepare( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- an attachment by its file's name, a postmeta value no API searches; cached per request above.
		"SELECT post_id FROM {$wpdb->postmeta}
		 WHERE meta_key = '_wp_attached_file'
		   AND ( meta_value LIKE %s OR meta_value = %s )
		 ORDER BY post_id DESC
		 LIMIT 1",
		'%/' . $wpdb->esc_like( $filename ),
		$filename
	) );

	if ( ! $att_id ) {
		$cache[ $filename ] = null;
		return null;
	}

	$url = wp_get_attachment_url( $att_id );
	if ( ! $url ) {
		$cache[ $filename ] = null;
		return null;
	}

	$meta = wp_get_attachment_metadata( $att_id );

	$cache[ $filename ] = array(
		'id'     => (int) $att_id,
		'url'    => $url,
		'alt'    => (string) get_post_meta( $att_id, '_wp_attachment_image_alt', true ),
		'width'  => isset( $meta['width'] ) ? (int) $meta['width'] : 0,
		'height' => isset( $meta['height'] ) ? (int) $meta['height'] : 0,
	);

	return $cache[ $filename ];
}

/**
 * Resolve url() references in an inline style string through the media cascade.
 *
 * @param string $style_string
 * @return string
 */
function kerf_mc_resolve_style_urls( $style_string ) {
	return preg_replace_callback(
		'/url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)/',
		function ( $matches ) {
			$resolved = kerf_mc_resolve_media( $matches[1] );
			return $resolved ? 'url(' . $resolved['url'] . ')' : $matches[0];
		},
		(string) $style_string
	);
}

/**
 * Extract background-image from an inline style string.
 *
 * @param string $style_string
 * @return array{url:string,mediaId:int,remaining:string}
 */
function kerf_mc_extract_background_image( $style_string ) {
	$result = array( 'url' => '', 'mediaId' => 0, 'remaining' => (string) $style_string );

	if ( ! preg_match( '/url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)/', (string) $style_string, $m ) ) {
		return $result;
	}

	// Only a background declaration owns the dedicated attribute. A url() in a
	// mask-image, list-style-image or cursor stays in inlineStyle, where
	// kerf_mc_resolve_style_urls() still resolves it.
	if ( ! preg_match( '/background(-image)?\s*:\s*[^;]*url\(/i', (string) $style_string ) ) {
		return $result;
	}

	$resolved = kerf_mc_resolve_media( $m[1] );
	if ( $resolved ) {
		$result['url']     = $resolved['url'];
		$result['mediaId'] = $resolved['id'];
	} else {
		$result['url'] = $m[1];
		kerf_mc_warn(
			'Background image "' . basename( $m[1] ) . '" is not in the media library — it still points at "' . $m[1] . '".',
			'media'
		);
	}

	$remaining             = preg_replace( '/background(-image)?\s*:\s*[^;]*url\([^)]*\)[^;]*;?\s*/i', '', (string) $style_string );
	$result['remaining'] = trim( $remaining, " ;\t\n\r" );

	return $result;
}

// ═══════════════════════════════════════════════════════════════════════════════
// NODE HELPERS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Parse an inline style string into property => value pairs.
 *
 * @param string $style_string
 * @return array<string,string>
 */
function kerf_mc_parse_inline_style( $style_string ) {
	$result = array();
	if ( ! $style_string ) {
		return $result;
	}

	foreach ( explode( ';', $style_string ) as $part ) {
		$part = trim( $part );
		if ( '' === $part ) {
			continue;
		}
		$colon = strpos( $part, ':' );
		if ( false === $colon ) {
			continue;
		}
		$result[ strtolower( trim( substr( $part, 0, $colon ) ) ) ] = trim( substr( $part, $colon + 1 ) );
	}

	return $result;
}

/**
 * Does this element look like an icon?
 *
 * Recognising the common icon-set prefixes is purely about which block the
 * element lands in — kerf/icon gives it an editor panel, kerf/div would not.
 * The classes themselves are never touched either way, so a false negative
 * costs a sidebar affordance and never changes rendered output.
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_mc_looks_like_icon( $node ) {
	$class = $node->getAttribute( 'class' );
	if ( '' === $class ) {
		return false;
	}

	static $families = array(
		'fa', 'fas', 'far', 'fab', 'fal', 'fad', 'fass', 'fasr',
		'las', 'lar', 'lab', 'dashicons', 'material-icons', 'glyphicon', 'iconify',
	);
	static $prefixes = array(
		'fa-', 'la-', 'ri-', 'bi-', 'ti-', 'ion-', 'icofont-', 'feather-', 'lucide-',
		'dashicons-', 'glyphicon-', 'material-symbols', 'mdi-', 'pi-', 'bx-', 'bxs-',
		'uil-', 'eva-', 'ph-', 'tabler-', 'ti-', 'icon-',
	);

	foreach ( preg_split( '/\s+/', $class, -1, PREG_SPLIT_NO_EMPTY ) as $token ) {
		$token = strtolower( $token );
		if ( in_array( $token, $families, true ) ) {
			return true;
		}
		foreach ( $prefixes as $prefix ) {
			if ( 0 === strpos( $token, $prefix ) ) {
				return true;
			}
		}
	}

	return false;
}

/**
 * Does this node contain media that has to become a block of its own?
 *
 * These are the elements whose sources resolve through the media cascade;
 * leaving one inside a rich-text attribute silently strands its URL.
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_mc_has_media_descendant( $node ) {
	foreach ( array( 'img', 'picture', 'svg', 'video', 'audio', 'iframe', 'canvas' ) as $tag ) {
		if ( $node->getElementsByTagName( $tag )->length > 0 ) {
			return true;
		}
	}
	return false;
}

/**
 * Does a heading or paragraph hold what rich text must not keep verbatim?
 *
 * Media, which needs blocks of its own; a never-safe element
 * (kerf_mc_dropped_tags() — an <object>, an <embed>, a <style>), which is
 * dropped and reported only on the way to becoming a block; an element with
 * no text or a form field, which rich text loses (scar 125). A link inside
 * one stays in it, bound where it stands (kerf_links_bind_rich_text()).
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_mc_rich_text_needs_blocks( $node ) {
	if ( kerf_mc_has_media_descendant( $node ) ) {
		return true;
	}
	foreach ( kerf_mc_dropped_tags() as $tag ) {
		if ( $node->getElementsByTagName( $tag )->length > 0 ) {
			return true;
		}
	}
	foreach ( $node->getElementsByTagName( '*' ) as $element ) {
		$tag = strtolower( $element->nodeName );
		// WordPress's text editor holds an element only around text. An empty
		// one — an icon (`<i class="fa-solid fa-star"></i>`), the slot a script
		// fills (`&copy; <span id="current-year"></span>`, a typing effect's
		// target), a decorative dot — and a form field were never drawn in the
		// editor and were gone from the page the first time its words were
		// edited (wp.richText drops them; checked on WordPress 7.1). As an
		// element, each is a block of its own.
		if ( in_array( $tag, array( 'input', 'select', 'textarea' ), true )
			|| ( ! in_array( $tag, array( 'br', 'wbr' ), true ) && '' === trim( $element->textContent ) ) ) {
			return true;
		}
	}
	// A business detail marked inside the text (`<p><a data-kerf-site="phone">`)
	// must be a block of its own to follow Kerf → Site details (§5.36), like
	// any other contract marker (§5.27) — when details are bound at all.
	if ( kerf_mc_context()['site_details'] ) {
		foreach ( $node->getElementsByTagName( '*' ) as $element ) {
			if ( $element->hasAttribute( 'data-kerf-site' ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * A heading's or paragraph's inner HTML, as rich text may keep it.
 *
 * Rich text is saved as written and printed as written: no render-time policy
 * reaches inside a core block the way kerf_render_attributes() guards a Kerf
 * one. So the converter is the only place the attribute policy can hold there
 * — `<p>Call <a href="tel:…" onclick="track()">us</a></p>` kept its handler
 * and ran it, and a `javascript:` link inside a paragraph was never reported.
 * Script URLs and `srcdoc` are taken off a copy, each reported; handlers and
 * the other attributes that run code too, unless whoever imports may add
 * scripts (as on an element, kerf_mc_extract_custom_attributes()).
 *
 * @param DOMElement $node
 * @return string
 */
function kerf_mc_rich_text_html( $node ) {
	$copy       = $node->cloneNode( true );
	$urls       = array_merge( kerf_mc_url_attributes(), array( 'xlink:href' ) );
	$directives = kerf_mc_context()['directives'];

	foreach ( iterator_to_array( $copy->getElementsByTagName( '*' ) ) as $element ) {
		$tag = strtolower( $element->nodeName );
		foreach ( iterator_to_array( $element->attributes ) as $attr ) {
			$name = kerf_mc_decode_attribute_name( $attr->nodeName );
			$why  = in_array( $name, $urls, true ) ? kerf_mc_unsafe_url( $attr->nodeValue ) : '';
			if ( ! $directives && kerf_mc_is_directive_attribute( $name ) ) {
				kerf_mc_drop_directive( $name );
			} elseif ( 'srcdoc' === $name ) {
				kerf_mc_warn( "The `srcdoc` of <$tag> was dropped: it is a page of its own that would run as this site.", 'dropped' );
			} elseif ( '' !== $why ) {
				kerf_mc_warn( "A `$name` using $why on <$tag> was dropped.", 'dropped' );
			} else {
				continue;
			}
			$element->removeAttribute( $attr->nodeName );
		}
	}

	return kerf_mc_get_inner_html( $copy );
}

/**
 * Does the node have element children (not just text)?
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_mc_has_element_children( $node ) {
	foreach ( $node->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			return true;
		}
	}
	return false;
}

/**
 * Does the node have BOTH element children and significant text?
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_mc_has_mixed_content( $node ) {
	$has_elements = false;
	$has_text     = false;

	foreach ( $node->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			$has_elements = true;
		} elseif ( XML_TEXT_NODE === $child->nodeType && '' !== trim( $child->textContent ) ) {
			$has_text = true;
		}
	}

	return $has_elements && $has_text;
}

/**
 * Does the node have only text (no element children)?
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_mc_has_text_only( $node ) {
	$has_text = false;

	foreach ( $node->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			return false;
		}
		if ( XML_TEXT_NODE === $child->nodeType && '' !== trim( $child->textContent ) ) {
			$has_text = true;
		}
	}

	return $has_text;
}

/**
 * Convert mixed children to a sequence of blocks.
 *
 * Bare text becomes kerf/text; element children dispatch normally, so a table or
 * an svg inside a text-carrying div still gets its proper block. Consecutive
 * inline blocks reflow inline on the front end, preserving text flow.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @return string
 */
function kerf_mc_convert_inline_mixed_children( $node, $depth ) {
	$result = kerf_mc_convert_children_spaced( $node, $depth );
	return $result['markup'];
}

/**
 * Convert an element's children, recording where the mockup put whitespace.
 *
 * Block markup puts a newline between every pair of blocks, and inside every
 * container before its first child and after its last. In block layout that is
 * invisible. In INLINE layout it is a rendered space — and inline is where
 * designers write tight markup on purpose: `<a><i class="fa fa-facebook"></i></a>`
 * gained a space inside the link and every social icon grew 3.5px;
 * `<span class="icon"></span>Home` gained a gap between the arrow and the word.
 *
 * So the gaps are recorded as the mockup had them: one '1' (whitespace) or '0'
 * (none) per gap — before the first child, between each pair, after the last —
 * and kerf_apply_gaps() re-applies them when the block renders. Returned as ''
 * when every gap had whitespace, which is what the markup gives anyway, so only
 * the containers that need it carry the attribute.
 *
 * Bare text beside an element becomes a kerf/text marked `bare`. A block has
 * to be something in the editor, where it is a span; on the page it renders as
 * the plain text it was, with no element added — it used to become a real
 * `<span>`, reported as one of the three documented differences.
 *
 * @param DOMNode $node
 * @param int     $depth Depth of the children.
 * @return array{markup:string,gaps:string}
 */
function kerf_mc_convert_children_spaced( $node, $depth ) {
	$indent  = str_repeat( '  ', $depth );
	$markup  = '';
	$gaps    = '';
	$pending = false; // Whitespace seen since the last block.
	$space   = " \t\n\r\f"; // HTML's whitespace. Not trim()'s: NBSP is content.

	foreach ( $node->childNodes as $child ) {
		if ( XML_TEXT_NODE === $child->nodeType ) {
			$raw  = $child->textContent;
			$text = trim( $raw, $space );

			if ( '' === $text ) {
				$pending = $pending || '' !== $raw;
				continue;
			}

			$gaps   .= ( $pending || strlen( ltrim( $raw, $space ) ) < strlen( $raw ) ) ? '1' : '0';
			$pending = strlen( rtrim( $raw, $space ) ) < strlen( $raw );

			$markup .= $indent . '<!-- wp:kerf/text '
				. kerf_mc_json_encode_block_attrs( kerf_mc_bare_text_attrs( $child, $text ) ) . ' /-->' . "\n";
			continue;
		}

		// Comments render nothing, so they are neither a block nor a gap.
		if ( XML_ELEMENT_NODE !== $child->nodeType ) {
			continue;
		}

		$block = kerf_mc_convert_node( $child, $depth );

		// Dropped (a <script>, past the element budget): not a block either.
		if ( '' === $block ) {
			continue;
		}

		$gaps   .= $pending ? '1' : '0';
		$pending = false;
		$markup .= $block;
	}

	$gaps .= $pending ? '1' : '0';

	return array(
		'markup' => $markup,
		'gaps'   => false === strpos( $gaps, '0' ) ? '' : $gaps,
	);
}

/**
 * Inner HTML of a node.
 *
 * @param DOMNode $node
 * @return string
 */
function kerf_mc_get_inner_html( $node ) {
	$html = '';
	foreach ( $node->childNodes as $child ) {
		$html .= $node->ownerDocument->saveHTML( $child );
	}
	// Names the parser could not read were encoded on the way in.
	return kerf_mc_decode_attribute_names( $html );
}

/**
 * Outer HTML of a node.
 *
 * @param DOMNode $node
 * @return string
 */
function kerf_mc_get_outer_html( $node ) {
	return kerf_mc_decode_attribute_names( $node->ownerDocument->saveHTML( $node ) );
}

/**
 * JSON-encode block attributes in WordPress block-comment format.
 *
 * Mirrors core's serialize_block_attributes(): `<`, `>`, `&` and `"` are
 * hex-escaped and double hyphens unicode-escaped, so an attribute value
 * containing markup (kerf/svg's `svg`, most obviously) can never terminate the
 * block comment early.
 *
 * @param array $attrs
 * @return string
 */
function kerf_mc_json_encode_block_attrs( $attrs ) {
	$encoded = json_encode(
		$attrs,
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_HEX_APOS
	);

	return str_replace( '--', '\\u002d\\u002d', (string) $encoded );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE MARKUP CONTRACT
// ═══════════════════════════════════════════════════════════════════════════════
//
// How a designer (or their AI) tells Kerf which parts of a page WordPress fills
// in — the brief is kerf_shell_prompt() in inc/kerf-shell-admin.php:
//
//   <body data-kerf-template="home|single|page|archive|search|404">
//   data-kerf-loop                on each card of a list; the first repeats —
//                                 posts by default, or ="comments", ="tags",
//                                 ="categories" for the post's own
//   data-kerf-field="title …"     on the element holding a value
//
// Everything here is the engine's side: no WordPress. The markers become block
// attributes — bindings to the kerf/post, kerf/query, kerf/comment and
// kerf/term sources, a kerf/loop, a kerf/post-content, kerf/comments or
// kerf/pagination block — and inc/kerf-bindings.php fills them in at render.
//
// Some of it needs no marker. A search form is wired wherever it is
// (kerf_mc_is_search_form()); a form with a textarea in the comments area is
// the comment form; and inside a post's card or header, text that can only be
// post meta — a date, "20 Comments", "by Admin" — is filled in, reported, and
// kept as written with data-kerf-field="none" (kerf_mc_contract_prepass()).

/**
 * The fields Kerf understands, and what each binds to on a text-holding block
 * and on a link.
 *
 * @return array{text:array<string,array>,url:array<string,array>,other:string[]}
 */
function kerf_mc_contract_fields() {
	$post  = function ( $key ) {
		return array( 'source' => 'kerf/post', 'args' => array( 'key' => $key ) );
	};
	$query = function ( $key ) {
		return array( 'source' => 'kerf/query', 'args' => array( 'key' => $key ) );
	};
	$comment = function ( $key ) {
		return array( 'source' => 'kerf/comment', 'args' => array( 'key' => $key ) );
	};
	$term = function ( $key ) {
		return array( 'source' => 'kerf/term', 'args' => array( 'key' => $key ) );
	};

	return array(
		'text'  => array(
			'title'               => $post( 'title' ),
			'date'                => $post( 'date' ),
			'author'              => $post( 'author' ),
			'category'            => $post( 'category' ),
			'excerpt'             => $post( 'excerpt' ),
			'tags'                => $post( 'tags' ),
			'comments-count'      => $post( 'comments-count' ),
			'prev'                => $post( 'prev-title' ),
			'next'                => $post( 'next-title' ),
			'archive-title'       => $query( 'title' ),
			'archive-description' => $query( 'description' ),
			'search-query'        => $query( 'search-query' ),
			'result-count'        => $query( 'count' ),
			'author-bio'          => $post( 'author-bio' ),
			'comment-author'      => $comment( 'author' ),
			'comment-date'        => $comment( 'date' ),
			'comment-text'        => $comment( 'text' ),
			'term-name'           => $term( 'name' ),
		),
		'url'   => array(
			'title'     => $post( 'permalink' ),
			'permalink' => $post( 'permalink' ),
			'category'  => $post( 'category-url' ),
			'author'    => $post( 'author-url' ),
			'prev'      => $post( 'prev-url' ),
			'next'      => $post( 'next-url' ),
			'comment-author' => $comment( 'author-url' ),
			'term-name'      => $term( 'link' ),
			'term-link'      => $term( 'link' ),
		),
		'other' => array( 'image', 'author-avatar', 'comment-avatar', 'content', 'comments', 'comment-form', 'pagination', 'search-form', 'search-input', 'none' ),
	);
}

/**
 * The field names on an element: `data-kerf-field="title permalink"`.
 *
 * @param DOMElement $node
 * @return string[]
 */
function kerf_mc_node_fields( $node ) {
	$raw = strtolower( trim( $node->getAttribute( 'data-kerf-field' ) ) );
	return '' === $raw ? array() : array_values( array_unique( preg_split( '/\s+/', $raw ) ) );
}

/**
 * The fields on an element this conversion fills in: all of them when asked
 * for live content (`dynamic`), otherwise only a search box's — which works
 * the same marked or not (kerf_mc_is_search_form()). The others stay the
 * designer's attribute, over the design's sample.
 *
 * @param DOMElement $node
 * @return string[]
 */
function kerf_mc_live_fields( $node ) {
	$fields = kerf_mc_node_fields( $node );
	if ( ! $fields || kerf_mc_context()['dynamic'] ) {
		return $fields;
	}
	return array_values( array_intersect( $fields, array( 'search-form', 'search-input' ) ) );
}

/**
 * How many places the design marks for live content: each loop's first card,
 * and each element with a post field. For the one report line an import makes
 * when it was not asked to fill them in.
 *
 * @param DOMElement $root
 * @return int
 */
function kerf_mc_count_live_marked( $root ) {
	$count = 0;
	foreach ( $root->getElementsByTagName( '*' ) as $el ) {
		if ( $el->hasAttribute( 'data-kerf-loop' ) ) {
			$count += kerf_mc_marked_sibling( $el, 'data-kerf-loop', 'previous' ) ? 0 : 1;
		} elseif ( array_diff( kerf_mc_node_fields( $el ), array( 'search-form', 'search-input', 'none' ) ) ) {
			$count++;
		}
	}
	return $count;
}

/**
 * Does anything inside this element carry a contract marker?
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_mc_has_marked_descendant( $node ) {
	$dynamic = kerf_mc_context()['dynamic'];
	foreach ( $node->getElementsByTagName( '*' ) as $el ) {
		if ( kerf_mc_live_fields( $el ) || ( $dynamic && $el->hasAttribute( 'data-kerf-loop' ) )
			|| $el->hasAttribute( 'data-kerf-auto' ) || $el->hasAttribute( 'data-kerf-auto-field' )
			|| $el->hasAttribute( 'data-kerf-auto-text' ) || $el->hasAttribute( 'data-kerf-slot' ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Is $inner inside $outer (or $outer itself)?
 *
 * @param DOMNode $outer
 * @param DOMNode $inner
 * @return bool
 */
function kerf_mc_contains( $outer, $inner ) {
	for ( $n = $inner; $n; $n = $n->parentNode ) {
		if ( $n === $outer ) {
			return true;
		}
	}
	return false;
}

/**
 * The nearest element, from $node up, marked with this field.
 *
 * @param DOMNode $node
 * @param string  $field
 * @return DOMElement|null
 */
function kerf_mc_marked_ancestor( $node, $field ) {
	for ( $el = $node; $el && XML_ELEMENT_NODE === $el->nodeType; $el = $el->parentNode ) {
		if ( $el->hasAttribute( 'data-kerf-field' ) && in_array( $field, kerf_mc_node_fields( $el ), true ) ) {
			return $el;
		}
	}
	return null;
}

/**
 * Is this element inside a card of a post loop (or one itself)?
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_mc_in_post_loop( $node ) {
	for ( $el = $node; $el && XML_ELEMENT_NODE === $el->nodeType; $el = $el->parentNode ) {
		if ( $el->hasAttribute( 'data-kerf-loop' )
			&& in_array( strtolower( trim( $el->getAttribute( 'data-kerf-loop' ) ) ), array( '', 'main', 'latest' ), true ) ) {
			return true;
		}
	}
	return false;
}

/**
 * The first form with a textarea in it: this element, or inside it.
 *
 * @param DOMElement $node
 * @return DOMElement|null
 */
function kerf_mc_comment_form_in( $node ) {
	$forms = 'form' === strtolower( $node->nodeName ) ? array( $node ) : iterator_to_array( $node->getElementsByTagName( 'form' ) );
	foreach ( $forms as $form ) {
		if ( $form->getElementsByTagName( 'textarea' )->length ) {
			return $form;
		}
	}
	return null;
}

/**
 * Does a card inside this element repeat over the given loop kind?
 *
 * @param DOMElement $node
 * @param string     $kind 'comments', 'tags', 'categories'.
 * @return bool
 */
function kerf_mc_loop_in( $node, $kind ) {
	foreach ( $node->getElementsByTagName( '*' ) as $el ) {
		if ( $el->hasAttribute( 'data-kerf-loop' ) && $kind === strtolower( trim( $el->getAttribute( 'data-kerf-loop' ) ) ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Before the walk: what the markup contract implies but the designer did not
 * write down. Two things.
 *
 * 1. THE COMMENT FORM. A form with a textarea in the comments area — or one
 *    marked `comment-form` — is the post's comment form: kept as drawn, with
 *    its fields named for WordPress at render (kerf_apply_element_fields()).
 *    The comment list then comes without WordPress's own form (kerf/comments,
 *    `form: false`): in place of the designer's sample list (a `ul`/`ol`
 *    named for comments), or, when there is none and nothing else is marked
 *    for the list, just before the form. Until now every comments area was
 *    emptied for WordPress's list AND form, so the designer's form — the one
 *    thing they drew for it — was the one thing never used.
 *
 * 2. SAMPLE POST META. Inside a post's card, and around a single post's
 *    title, text that can only be post meta — a date, "20 Comments", "by
 *    Admin" — was left as the designer's sample: every post "by Admin", every
 *    one with 20 comments. It is bound like a marked field, reported, and
 *    `data-kerf-field="none"` keeps it as written. Nothing else is guessed: a
 *    heading could be a title or a tagline, a paragraph an excerpt or a quote.
 *
 * The markers set here (`data-kerf-auto`, `data-kerf-auto-field`,
 * `data-kerf-auto-text`, `data-kerf-slot`) are the engine's own: read by
 * kerf_mc_convert_node(), skipped by kerf_mc_extract_custom_attributes(),
 * never rendered.
 *
 * @param DOMElement $root
 */
function kerf_mc_contract_prepass( $root ) {
	// Read, never written back whole: kerf_mc_warn() below updates the report
	// in the context, and writing a copy taken before it would erase those
	// lines (kerf_mc_context() MERGES — only the keys set here are passed).
	$ctx = kerf_mc_context();

	// ── 1. Comment forms.
	$forms = array();
	foreach ( iterator_to_array( $root->getElementsByTagName( 'form' ) ) as $form ) {
		if ( ! $form->getElementsByTagName( 'textarea' )->length ) {
			continue;
		}
		$explicit = in_array( 'comment-form', kerf_mc_node_fields( $form ), true );
		if ( ! $explicit && ! kerf_mc_marked_ancestor( $form->parentNode, 'comments' ) ) {
			continue;
		}
		if ( ! $explicit && ! $form->hasAttribute( 'data-kerf-auto' ) ) {
			$form->setAttribute( 'data-kerf-auto', 'comment-form' );
		}
		kerf_mc_warn( sprintf( '%s is the post\'s comment form: it now sends comments to WordPress, as drawn.', kerf_mc_describe( $form ) ), 'converted' );
		kerf_mc_mark_comment_inputs( $form );
		$forms[] = $form;
	}
	kerf_mc_context( array( 'comment_form' => ! empty( $forms ) ) );

	if ( $forms ) {
		$areas    = array();
		$has_list = false;
		foreach ( iterator_to_array( $root->getElementsByTagName( '*' ) ) as $el ) {
			if ( $el->hasAttribute( 'data-kerf-loop' ) && 'comments' === strtolower( trim( $el->getAttribute( 'data-kerf-loop' ) ) ) ) {
				$has_list = true;
			}
			if ( $el->hasAttribute( 'data-kerf-field' ) && in_array( 'comments', kerf_mc_node_fields( $el ), true ) ) {
				$areas[] = $el;
				if ( ! kerf_mc_comment_form_in( $el ) ) {
					$has_list = true;
				}
			}
		}

		// The designer's sample comments beside their form.
		foreach ( $areas as $area ) {
			$form = kerf_mc_comment_form_in( $area );
			if ( ! $form || kerf_mc_loop_in( $area, 'comments' ) ) {
				continue;
			}
			foreach ( $area->getElementsByTagName( '*' ) as $el ) {
				$tag = strtolower( $el->nodeName );
				if ( ( 'ul' === $tag || 'ol' === $tag )
					&& preg_match( '/comment/i', $el->getAttribute( 'class' ) . ' ' . $el->getAttribute( 'id' ) )
					&& ! kerf_mc_contains( $el, $form ) ) {
					$el->setAttribute( 'data-kerf-slot', 'comments-list' );
					$has_list = true;
					break;
				}
			}
		}

		// Nowhere for the list yet: just before the first form, at the level
		// of the comments area's child that holds it.
		if ( ! $has_list ) {
			$branch = $forms[0];
			$area   = kerf_mc_marked_ancestor( $branch->parentNode, 'comments' );
			if ( $area ) {
				while ( $branch->parentNode && $branch->parentNode !== $area ) {
					$branch = $branch->parentNode;
				}
			}
			$branch->setAttribute( 'data-kerf-slot', 'comments-before' );
		}
	}

	// ── 2. Sample post meta: in the first card of each post loop, and in a
	// single post's header — the title's parent, or its grandparent when the
	// parent holds nothing but the title.
	$store = new SplObjectStorage();
	kerf_mc_context( array( 'auto_text' => $store ) );

	$scopes = array();
	foreach ( iterator_to_array( $root->getElementsByTagName( '*' ) ) as $el ) {
		if ( ! $el->hasAttribute( 'data-kerf-loop' ) || kerf_mc_marked_sibling( $el, 'data-kerf-loop', 'previous' ) ) {
			continue;
		}
		$kind = strtolower( trim( $el->getAttribute( 'data-kerf-loop' ) ) );
		if ( in_array( $kind, array( '', 'main', 'latest' ), true ) ) {
			$scopes[] = $el;
			kerf_mc_mark_card_links( $el, 'permalink' );
		} elseif ( 'tags' === $kind || 'categories' === $kind ) {
			kerf_mc_mark_card_links( $el, 'term-link' );
		}
	}
	if ( 'single' === $ctx['template'] ) {
		foreach ( iterator_to_array( $root->getElementsByTagName( '*' ) ) as $el ) {
			if ( in_array( 'title', kerf_mc_node_fields( $el ), true ) && ! kerf_mc_in_post_loop( $el ) ) {
				$scope = $el->parentNode;
				if ( $scope && XML_ELEMENT_NODE === $scope->nodeType && 1 === kerf_mc_element_count( $scope )
					&& $scope->parentNode && XML_ELEMENT_NODE === $scope->parentNode->nodeType ) {
					$scope = $scope->parentNode;
				}
				if ( $scope && XML_ELEMENT_NODE === $scope->nodeType && $scope !== $root ) {
					$scopes[] = $scope;
				}
				break;
			}
		}
	}

	foreach ( $scopes as $scope ) {
		kerf_mc_mark_sample_meta( $scope, $store );
	}
}

/**
 * How many element children a node has.
 *
 * @param DOMNode $node
 * @return int
 */
function kerf_mc_element_count( $node ) {
	$count = 0;
	foreach ( $node->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			$count++;
		}
	}
	return $count;
}

/**
 * Name a comment form's fields for WordPress: the textarea is the comment,
 * and the inputs are the name, email and website, by type first and then by
 * what they are called. The checkbox, the button and anything else keep what
 * the designer wrote.
 *
 * @param DOMElement $form
 */
function kerf_mc_mark_comment_inputs( $form ) {
	$taken = array();
	$mark  = function ( $el, $field ) use ( &$taken ) {
		if ( isset( $taken[ $field ] ) || $el->hasAttribute( 'data-kerf-field' ) || $el->hasAttribute( 'data-kerf-auto' ) ) {
			return false;
		}
		$el->setAttribute( 'data-kerf-auto', $field );
		$taken[ $field ] = true;
		return true;
	};

	foreach ( $form->getElementsByTagName( 'textarea' ) as $textarea ) {
		$mark( $textarea, 'comment-text' );
		break;
	}

	$text = array();
	foreach ( $form->getElementsByTagName( 'input' ) as $input ) {
		$type  = strtolower( $input->getAttribute( 'type' ) );
		$names = strtolower( $input->getAttribute( 'name' ) . ' ' . $input->getAttribute( 'id' ) . ' ' . $input->getAttribute( 'placeholder' ) . ' ' . $input->getAttribute( 'class' ) );
		if ( 'email' === $type || ( in_array( $type, array( '', 'text' ), true ) && preg_match( '/mail/', $names ) ) ) {
			$mark( $input, 'comment-email' );
		} elseif ( 'url' === $type || ( in_array( $type, array( '', 'text' ), true ) && preg_match( '/web|site|url|homepage/', $names ) ) ) {
			$mark( $input, 'comment-url' );
		} elseif ( in_array( $type, array( '', 'text' ), true ) ) {
			$text[] = array( $input, $names );
		}
	}
	// The name: the text field called one, else the first plain text field.
	foreach ( $text as $item ) {
		if ( preg_match( '/name|author/', $item[1] ) && $mark( $item[0], 'comment-author' ) ) {
			return;
		}
	}
	if ( $text ) {
		$mark( $text[0][0], 'comment-author' );
	}
}

/**
 * Point a card's other links where the card's post (or term) is.
 *
 * A post card usually links to the post three times — the picture, the title,
 * "Read more" — and the brief marks one. The rest pointed at the designer's
 * `blog-details.html` for every post. In a post card, a link that goes where
 * the marked title's link goes, or to what is plainly the single-post page, is
 * the post's link. In a tag or category card, every link is the term's.
 *
 * @param DOMElement $card
 * @param string     $field 'permalink' or 'term-link'.
 */
function kerf_mc_mark_card_links( $card, $field ) {
	$links = 'a' === strtolower( $card->nodeName ) ? array( $card ) : array();
	foreach ( $card->getElementsByTagName( 'a' ) as $a ) {
		$links[] = $a;
	}

	$target = null;
	if ( 'permalink' === $field ) {
		foreach ( $links as $a ) {
			$fields = kerf_mc_node_fields( $a );
			$titled = array_intersect( $fields, array( 'title', 'permalink' ) );
			if ( ! $titled ) {
				foreach ( $a->getElementsByTagName( '*' ) as $inner ) {
					if ( in_array( 'title', kerf_mc_node_fields( $inner ), true ) ) {
						$titled = true;
						break;
					}
				}
			}
			if ( $titled ) {
				$target = trim( $a->getAttribute( 'href' ) );
				break;
			}
		}
	}

	foreach ( $links as $a ) {
		if ( $a->hasAttribute( 'data-kerf-field' ) || $a->hasAttribute( 'data-kerf-auto-field' )
			|| ( $a->hasAttribute( 'data-kerf-loop' ) && $a !== $card ) ) {
			continue;
		}
		$href = trim( $a->getAttribute( 'href' ) );
		if ( 'term-link' === $field
			|| ( '' !== $href && null !== $target && $href === $target )
			|| preg_match( '#(?:^|/)(?:(?:blog|news|post|article)[-_]?(?:details?|single|post|read|view|page)|single(?:[-_]post)?|post|article)\.html?(?:[?\#].*)?$#i', $href ) ) {
			$a->setAttribute( 'data-kerf-auto-field', $field );
			$marked = isset( $marked ) ? $marked + 1 : 1;
		}
	}

	if ( ! empty( $marked ) && 'permalink' === $field ) {
		kerf_mc_warn( sprintf(
			'%1$d link(s) in %2$s that pointed at the sample post page now go to each post.',
			$marked,
			kerf_mc_describe( $card )
		), 'converted' );
	}
}

/**
 * Mark the sample post meta inside one scope — see kerf_mc_contract_prepass().
 *
 * A text-only element is marked for kerf_mc_convert_node(); text beside an
 * icon (`<li><i class="fa fa-calendar"></i> May 19, 2019</li>`) is recorded by
 * node, and bound where it is emitted as bare text (kerf_mc_bare_text_attrs()),
 * its parent converted as an element so it has somewhere to be emitted.
 *
 * @param DOMElement       $scope
 * @param SplObjectStorage $store Text nodes → field.
 */
function kerf_mc_mark_sample_meta( $scope, $store ) {
	$skip_tags = array( 'script', 'style', 'svg', 'form', 'select', 'textarea', 'button', 'noscript', 'template' );

	foreach ( iterator_to_array( $scope->childNodes ) as $child ) {
		if ( XML_ELEMENT_NODE !== $child->nodeType ) {
			continue;
		}
		// Marked by the designer, a list of its own, already decided: theirs.
		if ( $child->hasAttribute( 'data-kerf-field' ) || $child->hasAttribute( 'data-kerf-loop' )
			|| $child->hasAttribute( 'data-kerf-auto' ) || in_array( strtolower( $child->nodeName ), $skip_tags, true ) ) {
			continue;
		}

		$texts = array();
		foreach ( $child->childNodes as $grand ) {
			if ( XML_TEXT_NODE === $grand->nodeType && '' !== trim( $grand->textContent ) ) {
				$texts[] = $grand;
			}
		}

		if ( 0 === kerf_mc_element_count( $child ) ) {
			$field = kerf_mc_sample_meta( $child->textContent );
			if ( '' !== $field ) {
				$child->setAttribute( 'data-kerf-auto-field', $field );
				kerf_mc_report_sample_meta( $child, $field, $child->textContent );
			}
			continue;
		}

		foreach ( $texts as $text ) {
			$field = kerf_mc_sample_meta( $text->textContent );
			if ( '' !== $field ) {
				$store[ $text ] = $field;
				$child->setAttribute( 'data-kerf-auto-text', '1' );
				kerf_mc_report_sample_meta( $child, $field, $text->textContent );
			}
		}

		kerf_mc_mark_sample_meta( $child, $store );
	}
}

/**
 * Say what sample text was filled in, and how to keep it.
 *
 * @param DOMElement $node
 * @param string     $field
 * @param string     $text
 */
function kerf_mc_report_sample_meta( $node, $field, $text ) {
	$what = array(
		'date'           => "the post's date",
		'comments-count' => "the post's comment count",
		'author'         => "the post's author",
	);
	kerf_mc_warn( sprintf(
		'"%1$s" in %2$s looked like post meta, so it shows %3$s. To keep the text as written, mark the element data-kerf-field="none".',
		trim( preg_replace( '/\s+/u', ' ', $text ) ),
		kerf_mc_describe( $node ),
		isset( $what[ $field ] ) ? $what[ $field ] : $field
	), 'converted' );
}

/**
 * Is this text sample post meta? Which field, or ''.
 *
 * Deliberately three shapes and no more, each of which can only be post meta
 * inside a post's card or header: a full date (day AND month — "2019" alone
 * could be anything), a number of comments, and "by" a name.
 *
 * @param string $text
 * @return string 'date', 'comments-count', 'author' or ''.
 */
function kerf_mc_sample_meta( $text ) {
	$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
	if ( '' === $text || strlen( $text ) > 48 ) {
		return '';
	}
	if ( kerf_mc_count_affixes( $text ) ) {
		return 'comments-count';
	}
	if ( preg_match( '/^(?:posted\s+by|written\s+by|by)\s+\S/i', $text ) && str_word_count( $text ) <= 6 ) {
		return 'author';
	}
	$format = kerf_mc_date_format( $text );
	if ( '' !== $format && preg_match( '/[djDlS]/', $format ) && preg_match( '/[mnMF]/', $format ) ) {
		return 'date';
	}
	return '';
}

/**
 * "20 Comments" → the words around the number, so the post's own count is
 * written the designer's way: array( before, after ), or null.
 *
 * @param string $text
 * @return array|null
 */
function kerf_mc_count_affixes( $text ) {
	$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
	if ( preg_match( '/^(\d+)(\s*(?:comments?|responses?|replies|reply))$/i', $text, $m ) ) {
		return array( '', $m[2] );
	}
	if ( preg_match( '/^((?:comments?|responses?|replies)\s*[:(]?\s*)(\d+)(\s*\)?)$/i', $text, $m ) ) {
		return array( $m[1], $m[3] );
	}
	return null;
}

/**
 * The binding for a text field, with what the sample says about how the
 * designer writes it: a date's format, an excerpt's length, the words around
 * a count or a name ("20 Comments", "by Admin").
 *
 * @param string $field A text field of kerf_mc_contract_fields().
 * @param string $sample The designer's placeholder text.
 * @return array|null
 */
function kerf_mc_text_binding( $field, $sample ) {
	$contract = kerf_mc_contract_fields();
	if ( ! isset( $contract['text'][ $field ] ) ) {
		return null;
	}
	$binding = $contract['text'][ $field ];
	$sample  = trim( preg_replace( '/\s+/u', ' ', (string) $sample ) );

	if ( 'date' === $field || 'comment-date' === $field ) {
		$format = kerf_mc_date_format( $sample );
		if ( '' !== $format ) {
			$binding['args']['format'] = $format;
		}
	} elseif ( 'excerpt' === $field ) {
		$words                    = count( preg_split( '/\s+/u', $sample, -1, PREG_SPLIT_NO_EMPTY ) );
		$binding['args']['words'] = max( 5, min( 80, $words ) );
	} elseif ( 'comments-count' === $field ) {
		$affixes = kerf_mc_count_affixes( $sample );
		if ( $affixes ) {
			$binding['args']['before'] = $affixes[0];
			$binding['args']['after']  = $affixes[1];
		}
	} elseif ( 'author' === $field && preg_match( '/^((?:posted\s+by|written\s+by|by)\s+)\S/i', $sample, $m ) ) {
		$binding['args']['before'] = $m[1];
	}

	$binding['args'] = array_filter( $binding['args'], function ( $value ) {
		return '' !== $value && null !== $value;
	} );

	return $binding;
}

/**
 * A bare text block's attributes, bound when the prepass found sample post
 * meta in that text node.
 *
 * @param DOMNode $node
 * @param string  $text Trimmed.
 * @return array
 */
function kerf_mc_bare_text_attrs( $node, $text ) {
	$attrs = array( 'text' => $text, 'bare' => true );
	$ctx   = kerf_mc_context();
	if ( $ctx['auto_text'] instanceof SplObjectStorage && isset( $ctx['auto_text'][ $node ] ) ) {
		$binding = kerf_mc_text_binding( $ctx['auto_text'][ $node ], $text );
		if ( $binding ) {
			$attrs['metadata'] = array( 'bindings' => array( 'text' => $binding ) );
		}
	}
	return $attrs;
}

/**
 * The nearest element sibling, before or after, that carries an attribute.
 *
 * @param DOMElement $node
 * @param string     $attribute
 * @param string     $direction 'previous' or 'next'.
 * @return DOMElement|null
 */
function kerf_mc_marked_sibling( $node, $attribute, $direction ) {
	$property = 'previous' === $direction ? 'previousSibling' : 'nextSibling';
	for ( $sibling = $node->$property; $sibling; $sibling = $sibling->$property ) {
		if ( XML_ELEMENT_NODE !== $sibling->nodeType || ! $sibling->hasAttribute( $attribute ) ) {
			continue;
		}
		// Cards of one list look alike: the same tag and the same FIRST class.
		// gymlife's sidebar has a large featured post (`latest-large`) and small
		// ones (`latest-item`) side by side, all marked: two lists, not one.
		// Its comments are `co-item`, `co-item reply-comment`, `co-item`: one
		// list, a reply among them — the whole class list would split it.
		if ( 'data-kerf-loop' === $attribute
			&& ( strtolower( $sibling->nodeName ) !== strtolower( $node->nodeName )
				|| strtok( trim( $sibling->getAttribute( 'class' ) ) . ' ', " \t\n" ) !== strtok( trim( $node->getAttribute( 'class' ) ) . ' ', " \t\n" ) ) ) {
			continue;
		}
		return $sibling;
	}
	return null;
}

/**
 * Is this form a search box? Returns its text field if so.
 *
 * Named for search (class, id, role, aria-label, placeholder) or holding an
 * `<input type="search">`, and with exactly one field a visitor types into —
 * a newsletter form has a class like `subscribe` and is left alone.
 *
 * @param DOMElement $form
 * @return DOMElement|null
 */
function kerf_mc_is_search_form( $form ) {
	$fields = array();
	foreach ( $form->getElementsByTagName( 'input' ) as $input ) {
		$type = strtolower( $input->getAttribute( 'type' ) );
		if ( in_array( $type, array( '', 'text', 'search' ), true ) ) {
			$fields[] = $input;
		}
	}
	if ( 1 !== count( $fields ) || $form->getElementsByTagName( 'textarea' )->length ) {
		return null;
	}

	$field = $fields[0];
	$names = $form->getAttribute( 'class' ) . ' ' . $form->getAttribute( 'id' ) . ' ' . $form->getAttribute( 'role' ) . ' '
		. $form->getAttribute( 'aria-label' ) . ' ' . $field->getAttribute( 'placeholder' ) . ' ' . $field->getAttribute( 'id' ) . ' '
		. $field->getAttribute( 'class' );

	if ( 'search' === strtolower( $field->getAttribute( 'type' ) ) || preg_match( '/search/i', $names ) ) {
		return $field;
	}

	return null;
}

/**
 * The attributes a script reads an image from — `data-setbg` (every Colorlib
 * template), `data-bg`, `data-src`, `data-image-src` — as name => value.
 *
 * @param DOMElement $node
 * @return array<string,string>
 */
function kerf_mc_image_data_attributes( $node ) {
	$found = array();
	foreach ( $node->attributes as $attribute ) {
		$name = strtolower( $attribute->name );
		if ( 0 === strpos( $name, 'data-' ) && preg_match( '/\.(?:jpe?g|png|gif|webp|avif|svg)(?:[?#].*)?$/i', trim( $attribute->value ) ) ) {
			$found[ $name ] = $attribute->value;
		}
	}
	return $found;
}

/**
 * `<div class="blog-item">` → "<div> .blog-item", for the report.
 *
 * @param DOMElement $node
 * @return string
 */
function kerf_mc_describe( $node ) {
	$label = '<' . strtolower( $node->nodeName ) . '>';
	$id    = trim( $node->getAttribute( 'id' ) );
	$class = trim( $node->getAttribute( 'class' ) );
	if ( '' !== $id ) {
		return $label . ' #' . $id;
	}
	return '' !== $class ? $label . ' .' . strtok( $class, " \t\n" ) : $label;
}

/**
 * Wrap the first card of a list in kerf/loop.
 *
 * On a listing template the loop repeats over the page's own posts (the blog,
 * the archive, the search results — and their pagination). Anywhere else — a
 * home page's "Latest from our blog" — it shows the latest posts, as many as
 * the designer drew cards.
 *
 * @param DOMElement $node   The first card.
 * @param int        $depth
 * @param string     $markup The card, converted.
 * @return string
 */
function kerf_mc_wrap_loop( $node, $depth, $markup ) {
	$count = 1;
	$next  = kerf_mc_marked_sibling( $node, 'data-kerf-loop', 'next' );
	$gap   = true;

	if ( $next ) {
		// Whitespace between the first two cards is the whitespace between all
		// of them (see §5.20 — it is visible in inline layout).
		$between = '';
		for ( $n = $node->nextSibling; $n && $n !== $next; $n = $n->nextSibling ) {
			$between .= XML_TEXT_NODE === $n->nodeType ? $n->textContent : 'x';
		}
		$gap = '' !== $between && '' === trim( $between, " \t\n\r\f" );
	}
	for ( $n = $next; $n; $n = kerf_mc_marked_sibling( $n, 'data-kerf-loop', 'next' ) ) {
		$count++;
	}

	// Which posts: the designer can say (`data-kerf-loop="latest"`). Otherwise
	// the first loop on a listing page is the page's own posts, and any other
	// — a sidebar's "Recent posts" — the latest few.
	$ctx     = kerf_mc_context();
	$wanted  = strtolower( trim( $node->getAttribute( 'data-kerf-loop' ) ) );
	$listing = in_array( $ctx['template'], array( 'home', 'archive', 'search' ), true );
	$each    = 'post';
	if ( in_array( $wanted, array( 'comments', 'tags', 'categories' ), true ) ) {
		// The post's own comments, tags or categories: every one of them.
		$attrs = array( 'query' => $wanted );
		$each  = array( 'comments' => 'comment', 'tags' => 'tag', 'categories' => 'category' )[ $wanted ];
	} elseif ( 'main' === $wanted || ( '' === $wanted && $listing && empty( $ctx['main_loop'] ) ) ) {
		$attrs            = array( 'query' => 'main' );
		$ctx['main_loop'] = true;
		kerf_mc_context( $ctx );
	} else {
		$attrs = array( 'query' => 'latest', 'perPage' => $count );
	}
	if ( ! $gap ) {
		$attrs['gap'] = false;
	}

	if ( $count > 1 ) {
		kerf_mc_warn( sprintf(
			'%1$s repeats once for each %2$s; the %3$d sample card(s) after the first were placeholders and were left out.',
			kerf_mc_describe( $node ),
			$each,
			$count - 1
		), 'converted' );
	}

	$indent = str_repeat( '  ', $depth );

	return $indent . '<!-- wp:kerf/loop ' . kerf_mc_json_encode_block_attrs( $attrs ) . ' -->' . "\n"
		. $markup
		. $indent . '<!-- /wp:kerf/loop -->' . "\n";
}

/**
 * Convert an element that carries `data-kerf-field`.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @param string[]   $fields
 * @return string
 */
function kerf_mc_convert_field_node( $node, $depth, $fields ) {
	$contract = kerf_mc_contract_fields();
	$known    = array_merge( array_keys( $contract['text'] ), array_keys( $contract['url'] ), $contract['other'] );

	foreach ( array_diff( $fields, $known ) as $unknown ) {
		kerf_mc_warn( sprintf( 'data-kerf-field="%s" on %s is not a field Kerf knows; it is kept as an attribute and nothing is filled in.', $unknown, kerf_mc_describe( $node ) ), 'general' );
	}

	// Containers WordPress fills: their children are the designer's samples.
	if ( in_array( 'content', $fields, true ) ) {
		return kerf_mc_container_with( $node, $depth, '<!-- wp:kerf/post-content /-->', "the post's content" );
	}
	if ( in_array( 'comments', $fields, true ) ) {
		// The designer's comment form, or a card that repeats per comment,
		// is inside: the area stays as drawn, and those parts are filled in
		// where they stand (see kerf_mc_contract_prepass()).
		if ( kerf_mc_comment_form_in( $node ) || kerf_mc_loop_in( $node, 'comments' ) ) {
			return kerf_mc_convert_node_as_written( $node, $depth );
		}
		// Otherwise WordPress's list replaces the samples — with its own
		// form only when the page has no form of the designer's.
		$ctx  = kerf_mc_context();
		$form = empty( $ctx['comment_form'] );
		if ( in_array( strtolower( $node->nodeName ), array( 'ul', 'ol' ), true ) ) {
			// The designer's own list takes WordPress's items; a form cannot
			// sit in a list, so WordPress's (when needed) follows it.
			return kerf_mc_container_with( $node, $depth, '<!-- wp:kerf/comments {"form":false,"items":true} /-->', "the post's comments" )
				. ( $form ? str_repeat( '  ', $depth ) . '<!-- wp:kerf/comments {"list":false} /-->' . "\n" : '' );
		}
		return kerf_mc_container_with(
			$node,
			$depth,
			'<!-- wp:kerf/comments ' . kerf_mc_json_encode_block_attrs( array( 'form' => $form ) ) . ' /-->',
			"the post's comments"
		);
	}
	if ( in_array( 'comment-form', $fields, true ) && 'form' !== strtolower( $node->nodeName ) ) {
		kerf_mc_warn( sprintf( 'data-kerf-field="comment-form" belongs on a <form>, not on %s.', kerf_mc_describe( $node ) ), 'general' );
	}
	if ( in_array( 'pagination', $fields, true ) ) {
		return kerf_mc_container_with(
			$node,
			$depth,
			'<!-- wp:kerf/pagination ' . kerf_mc_json_encode_block_attrs( kerf_mc_pagination_pattern( $node ) ) . ' /-->',
			'the real page links'
		);
	}

	$tag      = strtolower( $node->nodeName );
	$markup   = kerf_mc_convert_node_as_written( $node, $depth );
	$root     = kerf_mc_root_block( $markup );
	$bindings = array();

	$text = null;
	foreach ( $fields as $field ) {
		if ( isset( $contract['text'][ $field ] ) ) {
			$text = kerf_mc_text_binding( $field, $node->textContent );
			break;
		}
	}
	$url = null;
	foreach ( $fields as $field ) {
		if ( isset( $contract['url'][ $field ] ) ) {
			$url = $contract['url'][ $field ];
			break;
		}
	}
	$post  = function ( $key ) {
		return array( 'source' => 'kerf/post', 'args' => array( 'key' => $key ) );
	};
	$image = in_array( 'image', $fields, true );

	// A person's picture: the post author's (an author box) or a comment's.
	$avatar = null;
	if ( in_array( 'author-avatar', $fields, true ) ) {
		$avatar = $post( 'author-avatar' );
	} elseif ( in_array( 'comment-avatar', $fields, true ) ) {
		$avatar = array( 'source' => 'kerf/comment', 'args' => array( 'key' => 'avatar' ) );
	}

	switch ( $root['name'] ) {
		case 'kerf/text':
			if ( $text ) {
				$bindings['text'] = $text;
			}
			break;

		case 'core/heading':
		case 'core/paragraph':
			if ( $text ) {
				$bindings['content'] = $text;
			}
			break;

		case 'kerf/link':
			if ( $text ) {
				$bindings['text'] = $text;
			}
			if ( $url ) {
				$bindings['url'] = $url;
			}
			break;

		case 'kerf/image':
			if ( $image ) {
				$bindings['src']     = $post( 'image' );
				$bindings['alt']     = $post( 'image-alt' );
				$bindings['mediaId'] = $post( 'image-id' );

				// The sample picture's own size is part of the design: a sidebar
				// thumbnail is small because the sample was. A post's picture
				// takes that slot (kerf_render_image_block()), in the nearest
				// size WordPress has.
				$sample = kerf_mc_resolve_media( $node->getAttribute( 'src' ) );
				if ( $sample && ! empty( $sample['width'] ) && ! empty( $sample['height'] ) ) {
					$bindings['src']['args']['fit'] = array( (int) $sample['width'], (int) $sample['height'] );
				}
			} elseif ( $avatar ) {
				// Gravatar is square and sized by request: the sample's width.
				$sample = kerf_mc_resolve_media( $node->getAttribute( 'src' ) );
				if ( $sample && ! empty( $sample['width'] ) ) {
					$avatar['args']['size'] = (int) $sample['width'];
				}
				$bindings['src'] = $avatar;
			}
			break;

		case 'kerf/div':
			// A background in the inline style is bound; one a script reads
			// from `data-setbg` and the like is swapped at render
			// (kerf_apply_element_fields()).
			if ( $image && ! empty( $root['attrs']['backgroundImage'] ) ) {
				$bindings['backgroundImage']   = $post( 'image' );
				$bindings['backgroundImageId'] = $post( 'image-id' );
			} elseif ( $image && ! kerf_mc_image_data_attributes( $node ) ) {
				// Its picture, if any, is the stylesheet's: on a page it is
				// replaced as the page renders (the plugin's kerf_bg_mark()),
				// by rules one per page — a card's post has none of its own.
				$in_card = false;
				for ( $up = $node; $up instanceof DOMElement; $up = $up->parentNode ) {
					$in_card = $in_card || $up->hasAttribute( 'data-kerf-loop' );
				}
				kerf_mc_warn( sprintf(
					$in_card
						? 'data-kerf-field="image" on %s: inside a card, a picture the stylesheet draws cannot change from post to post. Put the picture in its style attribute, or on an <img>.'
						: 'data-kerf-field="image" on %s: where a page or post has a featured image, it shows in place of the picture the design\'s stylesheet draws here; without one, the design\'s stays.',
					kerf_mc_describe( $node )
				), 'general' );
			}
			// A card link with children (`<a data-kerf-field="title"><h3>…`)
			// gets its href at render, from the marker; the text inside it is
			// only filled in where a child is marked too.
			if ( $text && 'a' !== $tag ) {
				kerf_mc_warn( sprintf( 'data-kerf-field on %s: the element holds other elements, so its text cannot be replaced. Put the marker on the element that holds only the text.', kerf_mc_describe( $node ) ), 'general' );
			}
			break;
	}

	if ( in_array( 'search-form', $fields, true ) && 'form' !== $tag ) {
		kerf_mc_warn( sprintf( 'data-kerf-field="search-form" belongs on a <form>, not on %s.', kerf_mc_describe( $node ) ), 'general' );
	}
	if ( in_array( 'search-input', $fields, true ) && 'input' !== $tag ) {
		kerf_mc_warn( sprintf( 'data-kerf-field="search-input" belongs on an <input>, not on %s.', kerf_mc_describe( $node ) ), 'general' );
	}

	if ( $bindings ) {
		$markup = kerf_mc_add_root_attrs( $markup, array( 'metadata' => array( 'bindings' => $bindings ) ) );
	}

	return $markup;
}

/**
 * The root block of converted markup: its name and attributes.
 *
 * @param string $markup
 * @return array{name:string,attrs:array}
 */
function kerf_mc_root_block( $markup ) {
	if ( ! preg_match( '/^\s*<!-- wp:([a-z0-9-]+\/[a-z0-9-]+|[a-z0-9-]+) (?:(\{.*?\}) )?\/?-->/s', $markup, $m ) ) {
		return array( 'name' => '', 'attrs' => array() );
	}
	$name  = false === strpos( $m[1], '/' ) ? 'core/' . $m[1] : $m[1];
	$attrs = isset( $m[2] ) && '' !== $m[2] ? json_decode( $m[2], true ) : array();
	return array( 'name' => $name, 'attrs' => is_array( $attrs ) ? $attrs : array() );
}

/**
 * The designer's element, emptied, around one block WordPress fills.
 *
 * @param DOMElement $node
 * @param int        $depth
 * @param string     $inner Block markup to put inside.
 * @param string     $what  For the report: what goes in.
 * @return string
 */
function kerf_mc_container_with( $node, $depth, $inner, $what ) {
	$samples = 0;
	while ( $node->firstChild ) {
		if ( XML_ELEMENT_NODE === $node->firstChild->nodeType ) {
			$samples += 1 + $node->firstChild->getElementsByTagName( '*' )->length;
		}
		$node->removeChild( $node->firstChild );
	}

	$tag  = strtolower( $node->nodeName );
	$root = kerf_mc_root_block( kerf_mc_convert_element( $node, $depth, $tag ) );

	// An emptied element converts as an empty text leaf; a container is wanted.
	// Its whitespace map described the samples, which are gone.
	$attrs = $root['attrs'];
	unset( $attrs['text'], $attrs['bare'], $attrs['gaps'] );
	if ( 'div' !== $tag ) {
		$attrs['tagName'] = $tag;
	} else {
		unset( $attrs['tagName'] );
	}

	if ( $samples ) {
		kerf_mc_warn( sprintf( '%s receives %s; the %d sample element(s) inside it were placeholders and were left out.', kerf_mc_describe( $node ), $what, $samples ), 'converted' );
	}

	$indent = str_repeat( '  ', $depth );
	$json   = empty( $attrs ) ? '' : ' ' . kerf_mc_json_encode_block_attrs( $attrs );

	return $indent . '<!-- wp:kerf/div' . $json . ' -->' . "\n"
		. $indent . '  ' . $inner . "\n"
		. $indent . '<!-- /wp:kerf/div -->' . "\n";
}

/**
 * The shape of the designer's page links, so the real ones can be built the
 * same way: the element around each item if there is one, the link, the
 * classes that mark the current page, and "previous" / "next".
 *
 *   <ul class="pagination"><li class="page-item active"><a class="page-link">1…
 *   <div class="blog-pagination"><a href="#">1</a><a href="#">2</a><a>Next</a>
 *
 * @param DOMElement $node The pagination container.
 * @return array{item:array,prev:array,next:array}
 */
function kerf_mc_pagination_pattern( $node ) {
	$items = array();
	foreach ( $node->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			$items[] = $child;
		}
	}

	$split = function ( $item ) {
		$tag = strtolower( $item->nodeName );
		if ( in_array( $tag, array( 'a', 'span', 'button', 'strong', 'b', 'em' ), true ) ) {
			return array( null, $item );
		}
		foreach ( $item->childNodes as $c ) {
			if ( XML_ELEMENT_NODE === $c->nodeType ) {
				return array( $item, $c );
			}
		}
		return array( null, $item );
	};
	$is_current = function ( $el ) {
		if ( ! $el ) {
			return false;
		}
		return (bool) preg_match( '/(?:^|[\s_-])(?:active|current|selected)(?:$|[\s_-])/i', $el->getAttribute( 'class' ) )
			|| '' !== $el->getAttribute( 'aria-current' );
	};
	$label = function ( $el ) {
		$icon = '';
		foreach ( $el->getElementsByTagName( 'i' ) as $i ) {
			$icon = trim( $i->getAttribute( 'class' ) );
			break;
		}
		return array_filter( array(
			'text'  => trim( preg_replace( '/\s+/', ' ', $el->textContent ) ),
			'icon'  => $icon,
			'class' => trim( $el->getAttribute( 'class' ) ),
		), 'strlen' );
	};

	$normal  = null;
	$current = null;
	$prev    = array();
	$next    = array();
	$count   = count( $items );

	foreach ( $items as $index => $item ) {
		list( $wrap, $link ) = $split( $item );
		$numeric             = (bool) preg_match( '/^\d+$/', trim( $item->textContent ) );

		if ( ! $numeric ) {
			if ( 0 === $index ) {
				$prev = $label( $link );
			} elseif ( $count - 1 === $index ) {
				$next = $label( $link );
			}
			continue;
		}
		if ( $is_current( $wrap ) || $is_current( $link ) ) {
			$current = $current ? $current : array( $wrap, $link );
		} elseif ( ! $normal ) {
			$normal = array( $wrap, $link );
		}
	}

	if ( ! $normal ) {
		$normal = $current ? $current : array( null, null );
	}

	$classes = function ( $el ) {
		return $el ? preg_split( '/\s+/', trim( $el->getAttribute( 'class' ) ), -1, PREG_SPLIT_NO_EMPTY ) : array();
	};
	$spec    = function ( $el, $current_el ) use ( $classes ) {
		if ( ! $el ) {
			return null;
		}
		$base  = $classes( $el );
		$extra = $current_el ? array_values( array_diff( $classes( $current_el ), $base ) ) : array();
		return array_filter( array(
			'tag'          => strtolower( $el->nodeName ),
			'class'        => implode( ' ', $base ),
			'currentClass' => implode( ' ', $extra ),
			'currentTag'   => $current_el ? strtolower( $current_el->nodeName ) : '',
		), 'strlen' );
	};

	$item = array();
	$wrap = $spec( $normal[0], $current ? $current[0] : null );
	$link = $spec( $normal[1], $current ? $current[1] : null );
	if ( $wrap ) {
		$item['wrap'] = $wrap;
	}
	$item['link'] = $link ? $link : array( 'tag' => 'a' );

	// A previous/next link styled like the numbers needs no class of its own.
	if ( isset( $prev['class'], $item['link']['class'] ) && $prev['class'] === $item['link']['class'] ) {
		unset( $prev['class'] );
	}
	if ( isset( $next['class'], $item['link']['class'] ) && $next['class'] === $item['link']['class'] ) {
		unset( $next['class'] );
	}

	return array_filter( array( 'item' => $item, 'prev' => $prev, 'next' => $next ) );
}

/**
 * A PHP date() format that writes a date the way the designer's placeholder
 * does: "Aug 15, 2019" → "M j, Y", "15.08.2019" → "d.m.Y", "March 12th,
 * 2026" → "F jS, Y". '' when the text is not a recognisable date.
 *
 * @param string $text
 * @return string
 */
function kerf_mc_date_format( $text ) {
	$text = trim( preg_replace( '/\s+/u', ' ', (string) $text ) );
	if ( '' === $text || strlen( $text ) > 48 ) {
		return '';
	}

	$months_full  = array( 'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december' );
	$months_short = array( 'jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'sept', 'oct', 'nov', 'dec' );
	$days_full    = array( 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' );
	$days_short   = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );

	$tokens = preg_split( '/(\d+|[A-Za-z]+)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
	$parts  = array();
	$month  = false;
	$digits = array();

	foreach ( $tokens as $token ) {
		if ( ctype_digit( $token ) ) {
			$parts[]  = array( 'digits', $token );
			$digits[] = count( $parts ) - 1;
			continue;
		}
		if ( ctype_alpha( $token ) ) {
			$lower = strtolower( $token );
			$prev  = count( $parts ) ? $parts[ count( $parts ) - 1 ] : null;
			if ( in_array( $lower, $months_full, true ) && strlen( $lower ) > 3 ) {
				$parts[] = array( 'fmt', 'F' );
				$month   = true;
			} elseif ( in_array( $lower, $months_short, true ) ) {
				$parts[] = array( 'fmt', 'M' );
				$month   = true;
			} elseif ( in_array( $lower, $days_full, true ) ) {
				$parts[] = array( 'fmt', 'l' );
			} elseif ( in_array( $lower, $days_short, true ) ) {
				$parts[] = array( 'fmt', 'D' );
			} elseif ( $prev && 'digits' === $prev[0] && in_array( $lower, array( 'st', 'nd', 'rd', 'th' ), true ) ) {
				$parts[] = array( 'fmt', 'S' );
			} else {
				return ''; // A word that is not part of a date: not a date.
			}
			continue;
		}
		$parts[] = array( 'lit', $token );
	}

	if ( empty( $digits ) ) {
		return '';
	}

	// The year: four digits.
	$roles = array();
	foreach ( $digits as $index ) {
		if ( 4 === strlen( $parts[ $index ][1] ) ) {
			$roles[ $index ] = 'Y';
		}
	}
	$year = ! empty( $roles );
	$rest = array_values( array_diff( $digits, array_keys( $roles ) ) );

	if ( $month ) {
		if ( count( $rest ) > 1 ) {
			return '';
		}
		foreach ( $rest as $index ) {
			$roles[ $index ] = ( 2 === strlen( $parts[ $index ][1] ) && '0' === $parts[ $index ][1][0] ) ? 'd' : 'j';
		}
	} elseif ( 2 === count( $rest ) && $year ) {
		list( $a, $b ) = $rest;
		$va            = (int) $parts[ $a ][1];
		$vb            = (int) $parts[ $b ][1];
		// Year first (2019-08-15) reads year, month, day. Otherwise whichever
		// number is above 12 is the day; when neither is, "/" reads month
		// first (the US order) and "." or "-" day first.
		$year_first = min( array_keys( $roles ) ) < $a;
		$slash      = false !== strpos( $text, '/' );
		if ( $va > 12 || ( $vb <= 12 && ! $year_first && ! $slash ) ) {
			$day = $a;
			$mon = $b;
		} else {
			$day = $b;
			$mon = $a;
		}
		$roles[ $day ] = 2 === strlen( $parts[ $day ][1] ) ? 'd' : 'j';
		$roles[ $mon ] = 2 === strlen( $parts[ $mon ][1] ) ? 'm' : 'n';
	} else {
		return '';
	}

	$format = '';
	foreach ( $parts as $index => $part ) {
		if ( 'fmt' === $part[0] ) {
			$format .= $part[1];
		} elseif ( 'digits' === $part[0] ) {
			if ( ! isset( $roles[ $index ] ) ) {
				return '';
			}
			$format .= $roles[ $index ];
		} else {
			// Literal text: escape anything date() would read as a format letter.
			$format .= preg_replace( '/([a-zA-Z\\\\])/', '\\\\$1', $part[1] );
		}
	}

	return $format;
}
