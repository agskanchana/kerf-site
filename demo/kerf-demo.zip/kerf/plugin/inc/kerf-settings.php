<?php
/**
 * Kerf settings.
 *
 * Deliberately short. A canvas theme that ships forty options has stopped being
 * a canvas — every toggle is a decision the mockup already made. What is here is
 * the set of things WordPress does to a page that the designer cannot see coming
 * and cannot override from their stylesheet.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Add the settings screen under the Kerf menu.
 */
function kerf_settings_menu() {
	add_submenu_page(
		'kerf',
		__( 'Kerf Settings', 'kerf-blocks' ),
		__( 'Settings', 'kerf-blocks' ),
		'edit_theme_options',
		'kerf-settings',
		'kerf_settings_render_page'
	);
}
add_action( 'admin_menu', 'kerf_settings_menu', 20 );

/**
 * Register settings, with their sanitizers.
 */
function kerf_settings_register() {
	register_setting( 'kerf_settings', KERF_CORE_CSS_OPTION, array(
		'type'              => 'string',
		'default'           => 'minimal',
		'sanitize_callback' => static function ( $value ) {
			return in_array( $value, array( 'full', 'minimal', 'none' ), true ) ? $value : 'minimal';
		},
	) );

	// The widths "Hide on mobile" and "Hide on tablet" use are the design's own
	// now (kerf_responsive_breakpoints()); the two numbers that were set here
	// are not read.
}
add_action( 'admin_init', 'kerf_settings_register' );

/**
 * Render the settings screen.
 */
function kerf_settings_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to change these settings.', 'kerf-blocks' ) );
	}

	kerf_settings_handle_asset_reset();
	kerf_settings_handle_folder_cleanup();

	$level   = get_option( KERF_CORE_CSS_OPTION, 'minimal' );
	$assets  = kerf_assets_get();
	$folders = kerf_assets_staged_folders();

	kerf_ui_open( __( 'Settings', 'kerf-blocks' ), array(
		'lede' => __( 'A short list on purpose: your design already decided everything else. What is here is what WordPress does to a page that a design cannot see coming.', 'kerf-blocks' ),
	) );

	// options.php sends us back with this; WordPress only says so on its own screens.
	if ( isset( $_GET['settings-updated'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a message, nothing changes.
		echo kerf_ui_note( __( 'Settings saved.', 'kerf-blocks' ), 'ok' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}
	?>
		<form method="post" action="options.php" class="kerf-panel">
			<?php settings_fields( 'kerf_settings' ); ?>

			<?php
			/**
			 * Settings, each a row (kerf_ui_setting_open()): where form messages
			 * go (inc/kerf-forms.php), Kerf Pro's client editing. Register their
			 * options in the `kerf_settings` group.
			 */
			do_action( 'kerf_settings_sections' );

			kerf_ui_setting_open(
				__( 'WordPress\'s own CSS', 'kerf-blocks' ),
				__( 'WordPress adds hundreds of lines of CSS after your design\'s — typography, link colours, spacing. It loads last, so it wins. This is how much of it reaches the page.', 'kerf-blocks' )
			);
			$levels = array(
				'minimal' => array(
					__( 'Minimal — recommended', 'kerf-blocks' ),
					__( 'Keeps the CSS WordPress\'s own blocks need (tables, embeds, the blog\'s lists), and drops the rest.', 'kerf-blocks' ),
				),
				'full'    => array(
					__( 'All of it', 'kerf-blocks' ),
					__( 'Right before a design is imported, and for a site that mixes your design\'s pages with ordinary WordPress pages.', 'kerf-blocks' ),
				),
				'none'    => array(
					__( 'None', 'kerf-blocks' ),
					__( 'Your design owns every pixel, the blog\'s included.', 'kerf-blocks' ),
				),
			);
			echo '<fieldset class="kerf-choices">';
			foreach ( $levels as $value => $labels ) {
				printf(
					'<label class="kerf-choice"><input type="radio" name="%s" value="%s" %s><strong>%s</strong><span>%s</span></label>',
					esc_attr( KERF_CORE_CSS_OPTION ),
					esc_attr( $value ),
					checked( $level, $value, false ),
					esc_html( $labels[0] ),
					esc_html( $labels[1] )
				);
			}
			echo '</fieldset>';
			kerf_ui_setting_close();

			?>

			<div class="kerf-panel__foot">
				<button type="submit" class="kerf-btn kerf-btn--primary"><?php esc_html_e( 'Save settings', 'kerf-blocks' ); ?></button>
			</div>
		</form>

		<?php
		/**
		 * After the settings form: forms of a setting's own, which a button in
		 * its row submits by id (`form="…"`) — "Send a test email".
		 */
		do_action( 'kerf_settings_after_form' );
		?>

		<section class="kerf-panel">
			<div class="kerf-panel__head">
				<h2><?php esc_html_e( 'Your design\'s stylesheets and scripts', 'kerf-blocks' ); ?></h2>
				<?php if ( $assets ) : ?>
					<p><?php esc_html_e( 'Loaded in exactly this order, the order your design wrote them: the sequence is part of the design.', 'kerf-blocks' ); ?></p>
				<?php endif; ?>
			</div>
			<div class="kerf-panel__body">
			<?php if ( empty( $assets ) ) : ?>
				<p class="kerf-help"><?php esc_html_e( 'Nothing imported yet. Import a design and its stylesheets and scripts are listed here, in the order they load.', 'kerf-blocks' ); ?></p>
			<?php else : ?>
				<ol class="kerf-asset-list">
					<?php foreach ( $assets as $asset ) : ?>
						<li>
							<span class="kerf-chip kerf-chip--<?php echo esc_attr( $asset['type'] ); ?>">
								<?php echo esc_html( $asset['type'] ); ?>
							</span>
							<?php if ( 'inline' === $asset['kind'] ) : ?>
								<em><?php
									printf(
										/* translators: %s: formatted byte size. */
										esc_html__( 'Written into the page (%s)', 'kerf-blocks' ),
										esc_html( size_format( strlen( $asset['content'] ) ) )
									);
								?></em>
							<?php else : ?>
								<code><?php echo esc_html( $asset['src'] ); ?></code>
							<?php endif; ?>
							<span class="kerf-pos"><?php echo esc_html( 'footer' === $asset['position'] ? __( 'end of page', 'kerf-blocks' ) : __( 'head', 'kerf-blocks' ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ol>
			<?php endif; ?>

			<?php
			// Pages with a design of their own load their own list, not this one (§5.39).
			$own = array_filter( kerf_asset_sets(), static function ( $set, $page_id ) {
				return (bool) get_post( (int) $page_id );
			}, ARRAY_FILTER_USE_BOTH );
			if ( $own ) :
				?>
				<h3><?php esc_html_e( 'Pages with a design of their own', 'kerf-blocks' ); ?></h3>
				<p class="kerf-help">
					<?php esc_html_e( 'These load their own stylesheets and scripts instead of the list above. Import a design onto one of them for the whole site, and it takes the site\'s again.', 'kerf-blocks' ); ?>
				</p>
				<ul class="kerf-asset-list">
					<?php foreach ( $own as $page_id => $set ) : ?>
						<?php $counts = array_count_values( wp_list_pluck( isset( $set['assets'] ) ? (array) $set['assets'] : array(), 'type' ) ); ?>
						<li>
							<a href="<?php echo esc_url( get_edit_post_link( (int) $page_id ) ); ?>"><?php echo esc_html( get_the_title( (int) $page_id ) ); ?></a>
							<span class="kerf-help">
								<?php
								printf(
									/* translators: 1: stylesheet count, 2: script count, 3: file name. */
									esc_html__( '%1$d stylesheets, %2$d scripts, from %3$s', 'kerf-blocks' ),
									isset( $counts['css'] ) ? (int) $counts['css'] : 0,
									isset( $counts['js'] ) ? (int) $counts['js'] : 0,
									esc_html( ! empty( $set['source'] ) ? $set['source'] : __( 'pasted HTML', 'kerf-blocks' ) )
								);
								?>
							</span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			</div>
			<?php if ( $assets ) : ?>
				<form method="post" class="kerf-panel__foot">
					<?php wp_nonce_field( 'kerf_reset_assets', 'kerf_reset_nonce' ); ?>
					<button type="submit" name="kerf_reset_assets" value="1" class="kerf-btn kerf-btn--danger kerf-btn--sm">
						<?php esc_html_e( 'Stop loading them', 'kerf-blocks' ); ?>
					</button>
					<p class="kerf-help"><?php esc_html_e( 'Clears the list; your pages then show without the design\'s styles. The files stay, so importing again is quick.', 'kerf-blocks' ); ?></p>
				</form>
			<?php endif; ?>
		</section>

		<section class="kerf-panel">
			<div class="kerf-panel__head">
				<h2><?php esc_html_e( 'Your design\'s files on the server', 'kerf-blocks' ); ?></h2>
				<?php if ( $folders ) : ?>
					<p><?php esc_html_e( 'Every import and update copies the design\'s files into a folder of its own, and keeps the older ones while something still points into them. A folder nothing uses can go; the pictures in the media library are copies and stay.', 'kerf-blocks' ); ?></p>
				<?php endif; ?>
			</div>
			<div class="kerf-panel__body">
			<?php if ( ! $folders ) : ?>
				<p class="kerf-help"><?php esc_html_e( 'None yet: a design\'s files are copied here when it is imported.', 'kerf-blocks' ); ?></p>
			<?php else : ?>
				<?php $unused = array_filter( $folders, 'kerf_settings_folder_is_free' ); ?>
				<table class="kerf-table kerf-folders">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Folder', 'kerf-blocks' ); ?></th>
							<th><?php esc_html_e( 'Copied', 'kerf-blocks' ); ?></th>
							<th><?php esc_html_e( 'Size', 'kerf-blocks' ); ?></th>
							<th><?php esc_html_e( 'Used by', 'kerf-blocks' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $folders as $folder ) : ?>
							<tr>
								<td><code class="kerf-chip"><?php echo esc_html( $folder['slug'] ); ?></code></td>
								<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $folder['time'] ) ); ?></td>
								<td><?php echo esc_html( sprintf( /* translators: 1: size, 2: number of files. */ _n( '%1$s, %2$d file', '%1$s, %2$d files', $folder['files'], 'kerf-blocks' ), size_format( $folder['bytes'] ), $folder['files'] ) ); ?></td>
								<td>
									<?php
									if ( $folder['used'] ) {
										$shown = array_slice( $folder['used'], 0, 4 );
										echo esc_html( implode( ', ', $shown ) );
										if ( count( $folder['used'] ) > 4 ) {
											echo esc_html( sprintf( /* translators: %d: number of other uses. */ __( ', and %d more', 'kerf-blocks' ), count( $folder['used'] ) - 4 ) );
										}
									} elseif ( ! kerf_settings_folder_is_free( $folder ) ) {
										echo kerf_ui_pill( __( 'Copied less than an hour ago', 'kerf-blocks' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
									} else {
										echo kerf_ui_pill( __( 'Nothing', 'kerf-blocks' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
									}
									?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
			</div>
			<?php if ( ! empty( $unused ) ) : ?>
				<form method="post" class="kerf-panel__foot kerf-folders__clean">
					<?php wp_nonce_field( 'kerf_clean_folders', 'kerf_clean_nonce' ); ?>
					<button type="submit" name="kerf_clean_folders" value="1" class="kerf-btn kerf-btn--sm">
						<?php
						echo esc_html( sprintf(
							/* translators: 1: number of folders, 2: their size. */
							_n( 'Delete the %1$d folder nothing uses (%2$s)', 'Delete the %1$d folders nothing uses (%2$s)', count( $unused ), 'kerf-blocks' ),
							count( $unused ),
							size_format( array_sum( wp_list_pluck( $unused, 'bytes' ) ) )
						) );
						?>
					</button>
					<p class="kerf-help"><?php esc_html_e( 'A page\'s older revisions are not counted: one restored after its folder was deleted shows its old pictures missing.', 'kerf-blocks' ); ?></p>
				</form>
			<?php endif; ?>
		</section>
	<?php
	kerf_ui_close();
}

/**
 * May a staged folder be deleted: nothing uses it, and it is more than an hour
 * old — an import in another tab stages its folder minutes before it writes
 * the list that would show it in use.
 *
 * @param array $folder From kerf_assets_staged_folders().
 * @return bool
 */
function kerf_settings_folder_is_free( $folder ) {
	return ! $folder['used'] && time() - (int) $folder['time'] > HOUR_IN_SECONDS;
}

/**
 * Handle "Delete the folders nothing uses".
 *
 * Which folders are free is decided again here, not taken from the form: a
 * page saved since the screen was drawn may have started using one.
 */
function kerf_settings_handle_folder_cleanup() {
	if ( empty( $_POST['kerf_clean_folders'] ) || ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	if ( ! isset( $_POST['kerf_clean_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_clean_nonce'] ) ), 'kerf_clean_folders' ) ) {
		return;
	}

	$removed = 0;
	$bytes   = 0;
	foreach ( kerf_assets_staged_folders() as $folder ) {
		if ( ! kerf_settings_folder_is_free( $folder ) ) {
			continue;
		}
		kerf_import_cleanup( $folder['path'] );
		if ( ! is_dir( $folder['path'] ) ) {
			$removed++;
			$bytes += $folder['bytes'];
		}
	}

	echo '<div class="notice notice-success"><p>' . esc_html( sprintf(
		/* translators: 1: number of folders, 2: size freed. */
		_n( 'Deleted %1$d folder (%2$s).', 'Deleted %1$d folders (%2$s).', $removed, 'kerf-blocks' ),
		$removed,
		size_format( $bytes )
	) ) . '</p></div>';
}

/**
 * Handle the "stop loading these assets" button.
 */
function kerf_settings_handle_asset_reset() {
	if ( empty( $_POST['kerf_reset_assets'] ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}
	if ( ! isset( $_POST['kerf_reset_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_reset_nonce'] ) ), 'kerf_reset_assets' ) ) {
		return;
	}

	kerf_assets_save( array() );
	delete_option( KERF_BODY_OPTION );

	echo '<div class="notice notice-success"><p>'
		. esc_html__( 'Imported assets are no longer loaded.', 'kerf-blocks' )
		. '</p></div>';
}
