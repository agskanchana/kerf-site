<?php
/**
 * When a design's script dies, show what it was going to show (§5.50).
 *
 * A design's script is written for the pages its designer drew. On a page
 * Kerf draws — the blog, a post, search results, a plain page — the header
 * and footer are the design's but its home page is not, and a script that
 * reaches for a home-only element (`document.getElementById( 'readMoreBtn' )
 * .addEventListener( … )`) throws there and stops: whatever it set up after
 * that line never runs on those pages. When that was its scroll reveal, the
 * elements it fades in stayed invisible — the Dreamtime design's map, phone,
 * address, hours and booking button in its footer, on every page but the
 * home page (scar 133). Kerf cannot make the script go on without rewriting
 * it, which it never does (§5.1); it can finish the one thing a visitor would
 * miss.
 *
 * Two pieces, only where the design has a script: a listener at the top of
 * <head>, before the design's first script, that notes a script failing — an
 * uncaught error, a promise rejected with no handler, a script file that
 * would not load (kerf_reveal_watch_js()); and kerf-reveal.js, deferred, which
 * once a failure was noted shows an element named as a scroll reveal that has
 * stayed invisible in view for a second and a half. A page whose scripts all
 * run is never touched, and nothing named a modal, a menu or a tooltip ever is.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue both pieces when the design's assets hold a script — called by
 * kerf_assets_enqueue() before the design's own, so the listener is first in
 * the queue and prints before the design's first script.
 *
 * @param array $assets The design's assets for this request.
 */
function kerf_reveal_enqueue( $assets ) {
	if ( is_admin() ) {
		return;
	}

	$scripts = false;
	foreach ( (array) $assets as $asset ) {
		if ( isset( $asset['type'] ) && 'js' === $asset['type'] && kerf_assets_applies_here( $asset ) ) {
			$scripts = true;
			break;
		}
	}
	if ( ! $scripts ) {
		return;
	}

	wp_register_script( 'kerf-reveal-watch', false, array(), KERF_VERSION, false );
	wp_enqueue_script( 'kerf-reveal-watch' );
	wp_add_inline_script( 'kerf-reveal-watch', kerf_reveal_watch_js() );

	// Deferred, in <head>: it acts after the page has loaded, and a file at the
	// end of <body> would be one more element than the design wrote there.
	wp_enqueue_script( 'kerf-reveal', kerf_plugin_url( 'assets/js/kerf-reveal.js' ), array(), KERF_VERSION, array( 'strategy' => 'defer' ) );
}

/**
 * The listener: counts, in `window.kerfScriptFailed`, every script that failed
 * on this page — an uncaught error, a promise rejected with no handler, a
 * `<script>` file that would not load (a resource's error reaches the window
 * only in the capture phase). A picture that would not load is not counted:
 * it stops no script.
 *
 * @return string
 */
function kerf_reveal_watch_js() {
	return 'window.kerfScriptFailed=0;(function(){'
		. 'function failed(){window.kerfScriptFailed++;}'
		. "window.addEventListener('error',function(e){var t=e.target;if(e instanceof ErrorEvent||(t&&'SCRIPT'===t.tagName)){failed();}},true);"
		. "window.addEventListener('unhandledrejection',failed);"
		. '})();';
}
