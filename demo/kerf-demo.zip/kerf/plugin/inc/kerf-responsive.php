<?php
/**
 * Responsive layer — per-block device visibility + configurable breakpoints.
 *
 * Adds a "Responsive visibility" control (hide on desktop / tablet / mobile)
 * to every kerf/* block. Because Kerf blocks are all server-rendered, the
 * chosen classes are injected onto the block's outermost element by a
 * render_block filter — no wrapper div, so layout (flex/grid children) is
 * never disturbed. The hide CSS is generated from the widths the design's own
 * stylesheets change layout at, and inlined once in <head>.
 *
 * Breakpoint model (three bands):
 *   mobile  = viewport <= mobile max            (without a design: 599px)
 *   tablet  = mobile max < viewport <= tablet max (600–1199px)
 *   desktop = viewport > tablet max             (1200px and up)
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The widths read from each design, kept until it changes: key => widths.
 */
const KERF_BREAKPOINTS_OPTION = 'kerf_breakpoints';

/**
 * The widths "Hide on mobile" and "Hide on tablet" stop at — the design's own.
 *
 * They were two numbers in Kerf → Settings, 599 and 1199, which the owner was
 * asked to set to match the design's media queries: a question the design
 * had already answered, and one more place for the same fact to disagree.
 * Now they are its answer — the widths its stylesheets change layout at
 * (kerf_responsive_read_breakpoints()) — so a block hidden "on mobile" is
 * hidden exactly where the design's mobile layout begins. Where a design
 * says nothing, 599 and 1199.
 *
 * @param int|null $post_id The page whose design; null for this request's.
 * @return array{tablet:int, mobile:int, design:bool}
 */
function kerf_responsive_breakpoints( $post_id = null ) {
	$design = kerf_assets_design( $post_id );
	$found  = kerf_responsive_design_breakpoints( $design );

	/**
	 * Filter the widths "Hide on mobile" and "Hide on tablet" stop at.
	 *
	 * @param array{mobile:int,tablet:int} $breakpoints Read from the design.
	 * @param array                        $design      From kerf_assets_design().
	 */
	$bp = (array) apply_filters( 'kerf_responsive_breakpoints', array( 'mobile' => (int) $found['mobile'], 'tablet' => (int) $found['tablet'] ), $design );

	// Keep them ordered and within reason: mobile < tablet.
	$tablet = max( 480, min( 1920, (int) ( isset( $bp['tablet'] ) ? $bp['tablet'] : 1199 ) ) );
	$mobile = max( 320, min( $tablet - 1, (int) ( isset( $bp['mobile'] ) ? $bp['mobile'] : 599 ) ) );

	return array(
		'tablet' => $tablet,
		'mobile' => $mobile,
		'design' => ! empty( $found['design'] ),
	);
}

/**
 * A design's widths, read once and kept until the design changes: an import
 * or an update gives it a new version, a new reading of what its scripts drew
 * a new time.
 *
 * A stylesheet on another server (Bootstrap from a CDN) is read only on an
 * admin screen, never while a visitor waits; what was read without one is
 * read again there.
 *
 * @param array $design From kerf_assets_design().
 * @return array{mobile:int,tablet:int,design:bool,partial:bool}
 */
function kerf_responsive_design_breakpoints( $design ) {
	$captured = null !== $design['captured'] ? $design['captured'] : get_option( KERF_CAPTURE_OPTION, array() );
	$captured = is_array( $captured ) ? $captured : array();
	$key      = md5( $design['page'] . '|' . $design['version'] . '|' . count( $design['assets'] ) . '|' . ( isset( $captured['at'] ) ? (int) $captured['at'] : 0 ) );
	$kept     = get_option( KERF_BREAKPOINTS_OPTION, array() );
	$kept     = is_array( $kept ) ? $kept : array();

	if ( isset( $kept[ $key ] ) && ( empty( $kept[ $key ]['partial'] ) || ! is_admin() ) ) {
		return $kept[ $key ];
	}

	$found = kerf_responsive_read_breakpoints( $design['assets'], isset( $captured['css'] ) ? (string) $captured['css'] : '', is_admin() );
	unset( $kept[ $key ] );
	update_option( KERF_BREAKPOINTS_OPTION, array( $key => $found ) + array_slice( $kept, 0, 15, true ), true );

	return $found;
}

/**
 * Read a design's widths from its stylesheets.
 *
 * Every `@media` width counts once for each rule under it, so the width the
 * design does most at is its own. Mobile is the strongest from 480 to 860 —
 * a phone up to one turned sideways — tablet the strongest above that, up to
 * 1279 (a laptop's 1280 is a desktop, and wider widths are a large screen's
 * extra room); on a tie the wider. A stylesheet on another server counts only where
 * the design's own CSS (its files, its `<style>`s, what its scripts drew)
 * says nothing: Bootstrap's widths are every framework width at once, and
 * the design's own are the ones it chose.
 *
 * @param array[] $assets   The design's assets.
 * @param string  $captured CSS its scripts made (inc/kerf-capture.php).
 * @param bool    $fetch    Whether a stylesheet on another server may be fetched.
 * @return array{mobile:int,tablet:int,design:bool,partial:bool}
 */
function kerf_responsive_read_breakpoints( $assets, $captured = '', $fetch = false ) {
	$own     = array();
	$remote  = array();
	$partial = false;
	$uploads = trailingslashit( wp_upload_dir( null, false )['baseurl'] );

	foreach ( (array) $assets as $asset ) {
		if ( 'css' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) ) {
			continue;
		}
		if ( 'inline' === ( isset( $asset['kind'] ) ? $asset['kind'] : '' ) ) {
			kerf_responsive_tally( isset( $asset['content'] ) ? (string) $asset['content'] : '', $own );
			continue;
		}

		$src = isset( $asset['src'] ) ? (string) $asset['src'] : '';
		if ( 0 === strpos( $src, $uploads ) ) {
			kerf_responsive_tally( kerf_assets_editor_css( $src ), $own );
		} elseif ( $fetch ) {
			kerf_responsive_tally( kerf_assets_editor_css( $src ), $remote );
		} else {
			// The editor's copy, if it has fetched one (kerf_assets_editor_css()).
			$copy = get_transient( 'kerf_css_' . md5( $src . '|' . get_option( 'kerf_assets_version', '1' ) ) );
			if ( false === $copy ) {
				$partial = true;
			} else {
				kerf_responsive_tally( (string) $copy, $remote );
			}
		}
	}
	kerf_responsive_tally( $captured, $own );

	$mobile = kerf_responsive_strongest( $own, 480, 860 );
	$tablet = kerf_responsive_strongest( $own, 861, 1279 );
	$mobile = null !== $mobile ? $mobile : kerf_responsive_strongest( $remote, 480, 860 );
	$tablet = null !== $tablet ? $tablet : kerf_responsive_strongest( $remote, 861, 1279 );

	return array(
		'mobile'  => null !== $mobile ? $mobile : 599,
		'tablet'  => null !== $tablet ? $tablet : 1199,
		'design'  => null !== $mobile || null !== $tablet,
		'partial' => $partial,
	);
}

/**
 * Add a stylesheet's layout widths to a tally: width => rules under it.
 *
 * @param string $css
 * @param array  $tally
 */
function kerf_responsive_tally( $css, &$tally ) {
	if ( false === stripos( (string) $css, '@media' ) ) {
		return;
	}
	kerf_css_walk( (string) $css, static function ( $rule ) use ( &$tally ) {
		foreach ( $rule['chain'] as $prelude ) {
			foreach ( kerf_responsive_widths( $prelude ) as $width ) {
				$tally[ $width ] = ( isset( $tally[ $width ] ) ? $tally[ $width ] : 0 ) + 1;
			}
		}
	} );
}

/**
 * The widths a media query changes layout at, each as the narrower layout's
 * last width: `max-width: 768px` → 768, `min-width: 768px` → 767 (Bootstrap's
 * `767.98px` → 767), `(width < 768px)` → 767, `(768px <= width)` → 767. An
 * em or rem is 16px. Print, height and the like say nothing.
 *
 * @param string $prelude "@media …".
 * @return int[]
 */
function kerf_responsive_widths( $prelude ) {
	if ( 0 !== stripos( ltrim( (string) $prelude ), '@media' ) ) {
		return array();
	}

	$px = static function ( $value, $unit ) {
		return (float) $value * ( 'px' === strtolower( $unit ) ? 1 : 16 );
	};
	// The narrower layout's last width, for `width <op> value`.
	$last = static function ( $op, $value ) {
		return in_array( $op, array( '<=', '>' ), true ) ? (int) floor( $value ) : (int) ceil( $value ) - 1;
	};
	$flip   = array( '<=' => '>=', '<' => '>', '>=' => '<=', '>' => '<' );
	$widths = array();

	if ( preg_match_all( '/\b(min|max)-width\s*:\s*([\d.]+)(px|r?em)\b/i', $prelude, $found, PREG_SET_ORDER ) ) {
		foreach ( $found as $q ) {
			$widths[] = $last( 'max' === strtolower( $q[1] ) ? '<=' : '>=', $px( $q[2], $q[3] ) );
		}
	}
	// Range syntax, either way round: (width < 768px), (768px <= width <= 1024px).
	if ( preg_match_all( '/(?<![\w-])width\s*(<=|>=|<|>)\s*([\d.]+)(px|r?em)\b/i', $prelude, $found, PREG_SET_ORDER ) ) {
		foreach ( $found as $q ) {
			$widths[] = $last( $q[1], $px( $q[2], $q[3] ) );
		}
	}
	if ( preg_match_all( '/([\d.]+)(px|r?em)\s*(<=|>=|<|>)\s*width(?![\w-])/i', $prelude, $found, PREG_SET_ORDER ) ) {
		foreach ( $found as $q ) {
			$widths[] = $last( $flip[ $q[3] ], $px( $q[1], $q[2] ) );
		}
	}

	return $widths;
}

/**
 * The strongest width in a band — the most rules — and the wider on a tie.
 *
 * @param array $tally width => rules.
 * @param int   $from
 * @param int   $to
 * @return int|null
 */
function kerf_responsive_strongest( $tally, $from, $to ) {
	$best = null;
	foreach ( $tally as $width => $rules ) {
		$width = (int) $width;
		if ( $width < $from || $width > $to ) {
			continue;
		}
		if ( null === $best || $rules > $tally[ $best ] || ( $rules === $tally[ $best ] && $width > $best ) ) {
			$best = $width;
		}
	}
	return $best;
}

/**
 * Inject one or more classes onto the first real element of a rendered block.
 *
 * Skips any leading <style>/<script>/<link>/<template>/<noscript> (kerf/div
 * prepends its own scoped <style>), then merges into an existing class
 * attribute or adds one right after the tag name.
 *
 * @param string $content Rendered block HTML.
 * @param string $classes Space-separated class list.
 * @return string
 */
function kerf_responsive_inject_classes( $content, $classes ) {
	if ( '' === $classes || '' === trim( (string) $content ) ) {
		return $content;
	}

	// First opening tag that is a genuine element (not a leading asset tag).
	if ( ! preg_match(
		'/<(?!\/)(?!(?:style|script|link|template|noscript)\b)[a-z][a-z0-9-]*\b/i',
		$content,
		$m,
		PREG_OFFSET_CAPTURE
	) ) {
		return $content;
	}

	$tag_start = $m[0][1];
	$tag_end   = strpos( $content, '>', $tag_start );
	if ( false === $tag_end ) {
		return $content;
	}

	$open_tag = substr( $content, $tag_start, $tag_end - $tag_start + 1 );

	if ( preg_match( '/\sclass\s*=\s*"([^"]*)"/i', $open_tag, $cm ) ) {
		$new_open = str_replace( $cm[0], ' class="' . $cm[1] . ' ' . $classes . '"', $open_tag );
	} elseif ( preg_match( "/\sclass\s*=\s*'([^']*)'/i", $open_tag, $cm ) ) {
		$new_open = str_replace( $cm[0], " class='" . $cm[1] . ' ' . $classes . "'", $open_tag );
	} else {
		$new_open = preg_replace( '/^(<[a-z][a-z0-9-]*)/i', '$1 class="' . $classes . '"', $open_tag, 1 );
	}

	return substr( $content, 0, $tag_start ) . $new_open . substr( $content, $tag_end + 1 );
}

/**
 * Register the visibility attributes SERVER-SIDE on every kerf/* block.
 *
 * The editor adds kerfHideDesktop/Tablet/Mobile client-side (assets/js/
 * kerf-responsive.js). Dynamic blocks preview via ServerSideRender, which
 * posts every attribute to the /block-renderer REST endpoint — and that
 * endpoint validates against the server-registered attributes with
 * additionalProperties:false. Without registering them here, those requests
 * fail with "Invalid parameter(s): attributes" and the block won't render in
 * the editor. This keeps the two schemas in sync.
 *
 * @param array  $args Block type registration args.
 * @param string $name Block name.
 * @return array
 */
function kerf_responsive_register_attributes( $args, $name ) {
	if ( 0 !== strpos( $name, 'kerf/' ) ) {
		return $args;
	}
	if ( empty( $args['attributes'] ) || ! is_array( $args['attributes'] ) ) {
		$args['attributes'] = array();
	}
	$args['attributes']['kerfHideDesktop'] = array( 'type' => 'boolean', 'default' => false );
	$args['attributes']['kerfHideTablet']  = array( 'type' => 'boolean', 'default' => false );
	$args['attributes']['kerfHideMobile']  = array( 'type' => 'boolean', 'default' => false );
	// '' = everywhere; 'front' = the imported home page only (kerf_block_is_home()).
	$args['attributes']['kerfOnly']        = array( 'type' => 'string', 'default' => '' );
	return $args;
}
add_filter( 'register_block_type_args', 'kerf_responsive_register_attributes', 10, 2 );

/**
 * render_block filter: stamp kerf-hide-* classes on Kerf blocks that opted in.
 *
 * Runs at priority 9 — before kerf_inline_block_assets (10) prepends the
 * block's CSS — so the injector sees the real block markup first.
 *
 * @param string $block_content
 * @param array  $block
 * @return string
 */
function kerf_responsive_visibility_render( $block_content, $block ) {
	if ( is_admin() ) {
		return $block_content;
	}
	$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
	if ( 0 !== strpos( $name, 'kerf/' ) ) {
		return $block_content;
	}

	$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();

	// Not a hidden element but an absent one: a home page's intro that the
	// mockup put before its navigation lives in the header part, where the home
	// page needs it, and must not follow the header onto every other page.
	if ( isset( $attrs['kerfOnly'] ) && 'front' === $attrs['kerfOnly'] && ! kerf_block_is_home() ) {
		return '';
	}

	$classes = array();
	if ( ! empty( $attrs['kerfHideDesktop'] ) ) { $classes[] = 'kerf-hide-desktop'; }
	if ( ! empty( $attrs['kerfHideTablet'] ) )  { $classes[] = 'kerf-hide-tablet'; }
	if ( ! empty( $attrs['kerfHideMobile'] ) )  { $classes[] = 'kerf-hide-mobile'; }

	if ( empty( $classes ) ) {
		return $block_content;
	}

	return kerf_responsive_inject_classes( $block_content, implode( ' ', $classes ) );
}
add_filter( 'render_block', 'kerf_responsive_visibility_render', 9, 2 );

/**
 * Build the responsive-visibility CSS from the configured breakpoints.
 *
 * @return string Minified CSS (no <style> wrapper).
 */
function kerf_responsive_visibility_css() {
	$bp          = kerf_responsive_breakpoints();
	$mobile_max  = $bp['mobile'];
	$tablet_max  = $bp['tablet'];
	$tablet_min  = $mobile_max + 1;
	$desktop_min = $tablet_max + 1;

	return
		'@media (max-width:' . $mobile_max . 'px){.kerf-hide-mobile{display:none !important}}' .
		'@media (min-width:' . $tablet_min . 'px) and (max-width:' . $tablet_max . 'px){.kerf-hide-tablet{display:none !important}}' .
		'@media (min-width:' . $desktop_min . 'px){.kerf-hide-desktop{display:none !important}}';
}

/**
 * Inline the visibility CSS in <head>.
 *
 * It is tiny (~200 bytes) and foundational (any page may hide a block), so it
 * ships in the head to avoid a flash of wrongly-shown content: a source-less
 * handle of its own, enqueued before the design's stylesheets (priority 20,
 * kerf_assets_enqueue()), so core prints it as `#kerf-responsive-inline-css`
 * ahead of them — the order the echoed tag had.
 */
function kerf_responsive_print_head_css() {
	wp_register_style( 'kerf-responsive', false, array(), KERF_VERSION );
	wp_enqueue_style( 'kerf-responsive' );
	wp_add_inline_style( 'kerf-responsive', kerf_responsive_visibility_css() );
}
add_action( 'wp_enqueue_scripts', 'kerf_responsive_print_head_css', 6 );

/**
 * Enqueue the editor script that adds the visibility control to Kerf blocks,
 * and hand it the widths of the design being edited, so each toggle says
 * where it hides.
 */
function kerf_responsive_enqueue_editor() {
	wp_enqueue_script(
		'kerf-responsive',
		kerf_plugin_url( 'assets/js/kerf-responsive.js' ),
		array( 'wp-hooks', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-compose', 'wp-i18n' ),
		filemtime( kerf_plugin_path( 'assets/js/kerf-responsive.js' ) ),
		true
	);
	wp_set_script_translations( 'kerf-responsive', 'kerf-blocks', kerf_plugin_path( 'languages' ) );

	// The page being edited may have a design of its own (§5.39); the Site
	// Editor edits the site's.
	$post = get_post();
	wp_localize_script(
		'kerf-responsive',
		'KerfResponsive',
		kerf_responsive_breakpoints( $post instanceof WP_Post ? (int) $post->ID : 0 )
	);
}
add_action( 'enqueue_block_editor_assets', 'kerf_responsive_enqueue_editor' );
