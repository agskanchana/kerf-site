<?php
/**
 * Before an import writes anything: what in this design will not work on a
 * WordPress site, said in plain words (§5.34).
 *
 * The converter's report says what it did. This says what the DESIGN does that
 * the site cannot: an app whose page is empty until a build tool runs, files
 * the design asks for that are not in the ZIP, picture placeholders, file
 * names whose capitals only a Windows or Mac machine forgives, forms that post
 * nowhere. Three levels:
 *
 *   block  importing would make a page with nothing on it. The import stops;
 *          "Import anyway" on the form overrides it.
 *   warn   something will be broken or missing on the site until it is fixed.
 *   info   how Kerf deals with something the design does, so nobody is
 *          surprised by it.
 *
 * Read-only: it looks at the documents and at the ZIP's file list
 * (`zip_files`, recorded by kerf_import_unzip() before pruning, so a React
 * project's package.json and src/ are seen even though they are never staged).
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Check a design before it is imported.
 *
 * @param string     $html    The entry document.
 * @param array|null $staging kerf_import_unzip()'s result; null for a paste.
 * @return array<int,array{level:string,message:string,items:string[]}>
 */
function kerf_preflight( $html, $staging = null ) {
	$html     = kerf_preflight_uncomment( (string) $html );
	$files    = isset( $staging['zip_files'] ) ? (array) $staging['zip_files'] : array();
	$base_rel = isset( $staging['base_rel'] ) ? (string) $staging['base_rel'] : '';
	$pages    = isset( $staging['pages'] ) ? array_map( 'kerf_preflight_uncomment', (array) $staging['pages'] ) : array();
	$entry    = isset( $staging['entry_name'] ) ? basename( (string) $staging['entry_name'] ) : 'index.html';
	$docs     = array( $entry => $html ) + $pages;
	$all      = implode( "\n", $docs );
	$found    = array();

	// ── An app, not a page.
	$app = kerf_preflight_app( $html, $files );
	if ( '' !== $app ) {
		$found[] = array(
			'level'   => 'block',
			'message' => sprintf(
				/* translators: %s: what gave it away, e.g. "an empty <div id="root"> and src/main.tsx". */
				__( 'This is an app, not a web page: its page is empty until JavaScript draws it (%s), so there is no HTML for WordPress to edit. Ask the AI tool for plain HTML and CSS — or open the app in a browser and save the page it draws (File → Save page as → Webpage, complete) — and import that.', 'kerf-blocks' ),
				$app
			),
			'items'   => array(),
		);
	}

	// ── Styles and icons a script makes in the browser.
	$runtime = array();
	if ( preg_match( '#cdn\.tailwindcss\.com|@tailwindcss/browser#i', $all ) ) {
		$runtime[] = 'Tailwind';
	}
	if ( preg_match( '#@unocss/runtime|cdn\.twind\.style#i', $all ) ) {
		$runtime[] = 'UnoCSS / Twind';
	}
	if ( $runtime ) {
		$found[] = array(
			'level'   => 'info',
			'message' => sprintf(
				/* translators: %s: library names. */
				__( 'Its styles are made in the browser by a script (%s). The script is imported and runs on the site; after the import Kerf also saves the styles it makes, so the editor shows the design too.', 'kerf-blocks' ),
				implode( ', ', $runtime )
			),
			'items'   => array(),
		);
	}

	$icons = array();
	foreach ( array(
		'Lucide'       => '#lucide\.createIcons|data-lucide=#i',
		'Feather'      => '#feather\.replace|data-feather=#i',
		'Iconify'      => '#<iconify-icon\b|class=["\'][^"\']*\biconify\b#i',
		'Font Awesome' => '#kit\.fontawesome\.com#i',
	) as $name => $pattern ) {
		if ( preg_match( $pattern, $all ) ) {
			$icons[] = $name;
		}
	}
	if ( $icons ) {
		$found[] = array(
			'level'   => 'info',
			'message' => sprintf(
				/* translators: %s: icon library names. */
				__( 'Its icons are drawn by a script (%s). They show on the site; in the editor they appear once Kerf has saved them, just after the import.', 'kerf-blocks' ),
				implode( ', ', $icons )
			),
			'items'   => array(),
		);
	}

	// ── Files it asks for.
	if ( $files ) {
		$refs = kerf_preflight_references( $docs, $files, $base_rel, isset( $staging['dir'] ) ? (string) $staging['dir'] : '' );
		if ( $refs['missing'] ) {
			$found[] = array(
				'level'   => 'warn',
				/* translators: %d: number of files. */
				'message' => sprintf( _n( '%d file the design uses is not in the ZIP, so it will be missing on the site:', '%d files the design uses are not in the ZIP, so they will be missing on the site:', count( $refs['missing'] ), 'kerf-blocks' ), count( $refs['missing'] ) ),
				'items'   => $refs['missing'],
			);
		}
		if ( $refs['case'] ) {
			$found[] = array(
				'level'   => 'warn',
				'message' => __( 'These file names differ only in capital letters from what the design asks for. Windows and Mac forgive that; most web hosts (Linux) do not, and the file goes missing. Rename the file or fix the reference:', 'kerf-blocks' ),
				'items'   => $refs['case'],
			);
		}
	}

	$page_links = kerf_preflight_missing_pages( $docs, $base_rel );
	if ( $page_links ) {
		$found[] = array(
			'level'   => 'info',
			'message' => __( 'Links to pages that are not in the ZIP. They point nowhere until a page with that name exists — Kerf → Links lists them after the import, and each link\'s sidebar can point it at any page:', 'kerf-blocks' ),
			'items'   => $page_links,
		);
	}

	// ── Pictures.
	$images = kerf_preflight_remote_images( $all );
	if ( $images['dead'] ) {
		$found[] = array(
			'level'   => 'warn',
			'message' => __( 'These pictures come from source.unsplash.com, which no longer serves pictures: they show nothing.', 'kerf-blocks' ),
			'items'   => $images['dead'],
		);
	}
	if ( $images['placeholder'] ) {
		$found[] = array(
			'level'   => 'warn',
			'message' => __( 'Placeholder pictures from a placeholder service — replace them with real ones before the site goes live:', 'kerf-blocks' ),
			'items'   => $images['placeholder'],
		);
	}
	if ( $images['remote'] ) {
		$found[] = array(
			'level'   => 'info',
			/* translators: %d: number of pictures. */
			'message' => sprintf( _n( '%d picture loads from another website, so it is not in your media library:', '%d pictures load from other websites, so they are not in your media library:', count( $images['remote'] ), 'kerf-blocks' ), count( $images['remote'] ) ),
			'items'   => array_slice( $images['remote'], 0, 8 ),
		);
	}

	// ── What runs. Inline handlers are kept from someone who may add scripts,
	// as the design's scripts are (§5.32): only for anyone else are they lost.
	$may_run = function_exists( 'kerf_user_can_add_scripts' ) && kerf_user_can_add_scripts();
	if ( ! $may_run && preg_match_all( '/\son[a-z]+\s*=/i', preg_replace( '#<(script|style)\b[^>]*>.*?</\1\s*>#is', '', $all ), $handlers ) ) {
		$found[] = array(
			'level'   => 'warn',
			/* translators: %d: number of attributes. */
			'message' => sprintf( _n( '%d inline event handler (onclick and the like) will be left out: it runs code, and only someone who may add scripts can import that. Ask an administrator who may (on a network, a super admin) to run this import.', '%d inline event handlers (onclick and the like) will be left out: they run code, and only someone who may add scripts can import that. Ask an administrator who may (on a network, a super admin) to run this import.', count( $handlers[0] ), 'kerf-blocks' ), count( $handlers[0] ) ),
			'items'   => array(),
		);
	}
	if ( function_exists( 'kerf_user_can_add_scripts' ) && ! kerf_user_can_add_scripts() && kerf_preflight_has_directives( $all ) ) {
		$found[] = array(
			'level'   => 'warn',
			'message' => __( 'The design runs code from its attributes (Alpine, htmx, Vue…), and only someone who may add scripts can import that: menus and toggles built that way will not work. Ask an administrator who may (on a network, a super admin) to run this import.', 'kerf-blocks' ),
			'items'   => array(),
		);
	}

	// ── Forms.
	$file_forms = 0;
	$dead_forms = kerf_preflight_dead_forms( $all, $file_forms );
	if ( $dead_forms ) {
		$found[] = array(
			'level'   => 'info',
			/* translators: %d: number of forms. */
			'message' => sprintf( _n( '%d form sends nowhere on its own (no address to post to, or a Netlify form). Kerf makes it send: each message is emailed to you.', '%d forms send nowhere on their own (no address to post to, or Netlify forms). Kerf makes them send: each message is emailed to you.', $dead_forms, 'kerf-blocks' ), $dead_forms ),
			'items'   => array(),
		);
	}
	if ( $file_forms && function_exists( 'kerf_forms_file_limits' ) ) {
		$limits  = kerf_forms_file_limits();
		$found[] = array(
			'level'   => 'info',
			'message' => sprintf(
				/* translators: 1: how many files, 2: a size a file, 3: a size in all. */
				__( 'A form here takes files: they are attached to the email. Up to %1$d files, %2$s each and %3$s in all — pictures, PDF, Word, Excel, PowerPoint and text files.', 'kerf-blocks' ),
				$limits['count'],
				size_format( $limits['size'] ),
				size_format( $limits['total'] )
			),
			'items'   => array(),
		);
	}

	// ── The files themselves.
	if ( preg_match( '/<meta[^>]+charset\s*=\s*["\']?\s*(?!utf-?8)([a-z0-9_-]+)/i', $html, $charset ) ) {
		$found[] = array(
			'level'   => 'warn',
			/* translators: %s: character set name. */
			'message' => sprintf( __( 'The page says it is written in %s. Kerf reads UTF-8: accented letters and symbols may come out wrong. Save the files as UTF-8 first.', 'kerf-blocks' ), $charset[1] ),
			'items'   => array(),
		);
	}
	if ( preg_match_all( '#(?:src|href)\s*=\s*["\'](file:/+[^"\']+|[a-z]:\\\\[^"\']+)#i', $all, $local ) ) {
		$found[] = array(
			'level'   => 'warn',
			'message' => __( 'These point at files on the designer\'s own computer, which no visitor can reach:', 'kerf-blocks' ),
			'items'   => array_values( array_unique( array_slice( $local[1], 0, 8 ) ) ),
		);
	}
	if ( substr_count( $html, '<' ) > 25000 ) {
		$found[] = array(
			'level'   => 'warn',
			'message' => __( 'The page is very large: Kerf stops after 25,000 elements, and the rest would be missing. Split it into several pages.', 'kerf-blocks' ),
			'items'   => array(),
		);
	}

	return $found;
}

/**
 * Does any element carry an attribute that runs code (Alpine, htmx, Vue…)?
 * Read by an HTML tokenizer, attribute by attribute: a pattern over the text
 * found `@media` in a stylesheet and `:` in a sentence.
 *
 * @param string $html
 * @return bool
 */
function kerf_preflight_has_directives( $html ) {
	$tags = new WP_HTML_Tag_Processor( (string) $html );
	while ( $tags->next_tag() ) {
		foreach ( (array) $tags->get_attribute_names_with_prefix( '' ) as $name ) {
			// Inline handlers have a finding of their own.
			if ( kerf_mc_is_directive_attribute( $name ) && ! preg_match( '/^on[a-z]+$/', $name ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * Is there a level that stops the import?
 *
 * @param array $findings From kerf_preflight().
 * @return bool
 */
function kerf_preflight_blocks( $findings ) {
	foreach ( (array) $findings as $finding ) {
		if ( 'block' === $finding['level'] ) {
			return true;
		}
	}
	return false;
}

/**
 * Why this looks like an app's source or bundle rather than a page, or ''.
 *
 * @param string   $html
 * @param string[] $files
 * @return string
 */
function kerf_preflight_app( $html, $files ) {
	$body = preg_replace( '#<(script|style|template|noscript)\b[^>]*>.*?</\1\s*>#is', '', kerf_mc_extract_body( $html ) );
	$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $body ) ) );
	if ( strlen( $text ) >= 40 ) {
		return '';
	}

	$signs = array();
	if ( preg_match( '#<div\b[^>]*\bid\s*=\s*["\'](root|app|__next|__nuxt|svelte|q-app)["\'][^>]*>\s*</div>#i', $html, $m ) ) {
		$signs[] = sprintf( '<div id="%s"></div>', $m[1] );
	}
	if ( preg_match( '#<script\b[^>]*\bsrc\s*=\s*["\']([^"\']*\.(?:tsx|jsx|ts|vue|svelte))["\']#i', $html, $m ) ) {
		$signs[] = ltrim( $m[1], '/' );
	} elseif ( preg_match( '#<script\b[^>]*type\s*=\s*["\']module["\'][^>]*>#i', $html ) ) {
		$signs[] = __( 'a JavaScript module', 'kerf-blocks' );
	}
	if ( in_array( 'package.json', array_map( 'basename', $files ), true ) ) {
		$signs[] = 'package.json';
	}

	return $signs ? implode( ', ', $signs ) : '';
}

/**
 * A document without its comments — what a browser does with it. A picture
 * or a script a designer commented out was named missing, an old Internet
 * Explorer's `<!--[if lt IE 9]>` scripts counted as the design's. What a
 * script or a style holds is left as it is: a `<!--` there is the script's.
 *
 * @param string $html
 * @return string
 */
function kerf_preflight_uncomment( $html ) {
	$html = (string) $html;
	if ( false === strpos( $html, '<!--' ) ) {
		return $html;
	}
	$out    = '';
	$offset = 0;
	while ( preg_match( '#<!--(?:>|->|.*?(?:--!?>|\z))|<(script|style)\b[^>]*>#is', $html, $m, PREG_OFFSET_CAPTURE, $offset ) ) {
		$out .= substr( $html, $offset, $m[0][1] - $offset );
		$end  = $m[0][1] + strlen( $m[0][0] );
		if ( 0 !== strpos( $m[0][0], '<!--' ) ) {
			// A script or a style: kept whole, its content unread.
			if ( preg_match( '#</' . $m[1][0] . '\s*>#i', $html, $close, PREG_OFFSET_CAPTURE, $end ) ) {
				$end = $close[0][1] + strlen( $close[0][0] );
			}
			$out .= substr( $html, $m[0][1], $end - $m[0][1] );
		}
		$offset = $end;
	}
	return $out . substr( $html, $offset );
}

/**
 * The local files the documents and their stylesheets ask for that are not in
 * the ZIP, and those whose name differs only in capitals.
 *
 * @param array<string,string> $docs     File name => HTML.
 * @param string[]             $files    Every file in the ZIP, relative to its root.
 * @param string               $base_rel The documents' folder.
 * @param string               $root     The staged folder (the ZIP's root), to read stylesheets from.
 * @return array{missing:string[],case:string[]}
 */
function kerf_preflight_references( $docs, $files, $base_rel, $root = '' ) {
	$exact = array_fill_keys( $files, true );
	$lower = array();
	foreach ( $files as $file ) {
		$lower[ strtolower( $file ) ] = $file;
	}

	$refs = array(); // Resolved path => what was written.
	foreach ( $docs as $html ) {
		$html = preg_replace( '#<(script)\b[^>]*>.*?</\1\s*>#is', '<$1>', (string) $html );
		if ( preg_match_all( '/\s(?:src|poster|data-src|data-bg|data-setbg|data-background|data-image-src)\s*=\s*["\']([^"\']+)["\']/i', $html, $m ) ) {
			foreach ( $m[1] as $ref ) {
				$refs[ kerf_mc_join_path( $base_rel, $ref ) ] = $ref;
			}
		}
		// A <link>'s href, and a link to a file (not to a page).
		if ( preg_match_all( '/<(?:link|a)\b[^>]*\shref\s*=\s*["\']([^"\']+)["\']/i', $html, $m ) ) {
			foreach ( $m[1] as $ref ) {
				if ( preg_match( '/\.(?:' . kerf_mc_asset_extensions() . '|css|js|pdf)(?:[?#].*)?$/i', $ref ) ) {
					$refs[ kerf_mc_join_path( $base_rel, $ref ) ] = $ref;
				}
			}
		}
		if ( preg_match_all( '/\ssrcset\s*=\s*["\']([^"\']+)["\']/i', $html, $m ) ) {
			foreach ( $m[1] as $set ) {
				foreach ( explode( ',', $set ) as $candidate ) {
					$ref = strtok( trim( $candidate ), " \t" );
					if ( false !== $ref && '' !== $ref ) {
						$refs[ kerf_mc_join_path( $base_rel, $ref ) ] = $ref;
					}
				}
			}
		}
		// In an attribute the quotes around an address may be entities —
		// `url(&apos;img/x.jpg&apos;)`, as WordPress's tag processor writes
		// them — and the browser reads them as quotes: so does this. Read raw,
		// the picture was named missing while the page showed it.
		if ( preg_match_all( '/url\(\s*([^)]+?)\s*\)/i', $html, $m ) ) {
			foreach ( $m[1] as $ref ) {
				$ref = trim( html_entity_decode( $ref, ENT_QUOTES | ENT_HTML5, 'UTF-8' ), " \t'\"" );
				if ( '' !== $ref ) {
					$refs[ kerf_mc_join_path( $base_rel, $ref ) ] = $ref;
				}
			}
		}
	}

	// Each stylesheet's own url()s, against its own folder.
	foreach ( $files as $file ) {
		if ( '' === $root || ! preg_match( '/\.css$/i', $file ) || ! is_file( $root . $file ) ) {
			continue;
		}
		$css = (string) file_get_contents( $root . $file );
		if ( preg_match_all( '/url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)|@import\s+[\'"]([^\'"]+)[\'"]/i', $css, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $match ) {
				$ref = '' !== $match[1] ? $match[1] : ( isset( $match[2] ) ? $match[2] : '' );
				$refs[ kerf_mc_join_path( dirname( $file ) === '.' ? '' : dirname( $file ), $ref ) ] = $ref;
			}
		}
	}

	$missing = array();
	$case    = array();
	foreach ( $refs as $path => $ref ) {
		// `url(%23n)` inside a stylesheet's SVG drawn as a data: address is
		// the drawing's own filter, not a file: read as one, a design was
		// told a file "%23n" was missing from its ZIP.
		if ( '' === $path || isset( $exact[ $path ] ) || '#' === $path[0] ) {
			continue;
		}
		if ( isset( $lower[ strtolower( $path ) ] ) ) {
			$case[] = $ref . ' → ' . $lower[ strtolower( $path ) ];
		} else {
			$missing[] = $ref;
		}
	}

	return array(
		'missing' => array_values( array_unique( array_slice( $missing, 0, 20 ) ) ),
		'case'    => array_values( array_unique( array_slice( $case, 0, 20 ) ) ),
	);
}

/**
 * `.html` links to pages that are not among the ZIP's documents.
 *
 * @param array<string,string> $docs
 * @param string               $base_rel
 * @return string[]
 */
function kerf_preflight_missing_pages( $docs, $base_rel ) {
	$have    = array_change_key_case( array_fill_keys( array_keys( $docs ), true ) );
	$missing = array();
	foreach ( $docs as $html ) {
		if ( ! preg_match_all( '/<a\b[^>]*\shref\s*=\s*["\']([^"\'#?]+\.html?)(?:[#?][^"\']*)?["\']/i', (string) $html, $m ) ) {
			continue;
		}
		foreach ( $m[1] as $ref ) {
			if ( preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//)#i', $ref ) ) {
				continue;
			}
			if ( ! isset( $have[ strtolower( basename( $ref ) ) ] ) ) {
				$missing[ $ref ] = true;
			}
		}
	}
	return array_slice( array_keys( $missing ), 0, 20 );
}

/**
 * Pictures from other websites: dead, placeholders, and the rest.
 *
 * @param string $all Every document.
 * @return array{dead:string[],placeholder:string[],remote:string[]}
 */
function kerf_preflight_remote_images( $all ) {
	$out = array( 'dead' => array(), 'placeholder' => array(), 'remote' => array() );
	if ( ! preg_match_all( '#(?:\ssrc\s*=\s*["\']|url\(\s*[\'"]?)(https?://[^"\'\s)]+)#i', $all, $m ) ) {
		return $out;
	}
	foreach ( array_unique( $m[1] ) as $url ) {
		$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
		if ( 'source.unsplash.com' === $host ) {
			$out['dead'][] = $url;
		} elseif ( preg_match( '/(?:^|\.)(?:picsum\.photos|placehold\.co|placeholder\.com|placehold\.it|dummyimage\.com|placekitten\.com|loremflickr\.com|fakeimg\.pl|lorempixel\.com)$/', $host ) ) {
			$out['placeholder'][] = $url;
		} elseif ( preg_match( '/\.(?:jpe?g|png|gif|webp|avif)(?:[?#]|$)|images\.unsplash\.com|images\.pexels\.com/i', $url ) ) {
			$out['remote'][] = $url;
		}
	}
	return $out;
}

/**
 * How many forms send nowhere by themselves: no action, `#`, a script URL, or
 * a Netlify form (which only works on Netlify). A search form is WordPress's
 * already (§5.25), and one posting to a real address is left alone.
 *
 * @param string $all
 * @param int    $files Out: how many of them take files.
 * @return int
 */
function kerf_preflight_dead_forms( $all, &$files = 0 ) {
	$count = 0;
	$files = 0;
	if ( ! preg_match_all( '#<form\b([^>]*)>(.*?)</form\s*>#is', $all, $forms, PREG_SET_ORDER ) ) {
		return 0;
	}
	foreach ( $forms as $form ) {
		$attrs = $form[1];
		$inner = $form[2];
		if ( preg_match( '/\brole\s*=\s*["\']search|type\s*=\s*["\']search|data-kerf-field\s*=\s*["\']search-form/i', $form[0] ) ) {
			continue;
		}
		if ( ! preg_match( '/<(?:input|textarea|select)\b/i', $inner ) ) {
			continue;
		}
		$action = preg_match( '/\saction\s*=\s*["\']([^"\']*)["\']/i', $attrs, $a ) ? trim( $a[1] ) : '';
		if ( '' === $action || '#' === $action || preg_match( '/^javascript:/i', $action ) || preg_match( '/\s(?:data-)?netlify\b/i', $attrs ) ) {
			$count++;
			// Read from the tags, not the text (scar 83).
			$tags = new WP_HTML_Tag_Processor( $inner );
			while ( $tags->next_tag( 'INPUT' ) ) {
				if ( 'file' === strtolower( trim( (string) $tags->get_attribute( 'type' ) ) ) ) {
					$files++;
					break;
				}
			}
		}
	}
	return $count;
}

/**
 * The findings as a checklist, worst first: in the import's check step, and
 * on an import that stopped. Nothing found says so — that is news too.
 *
 * @param array $findings From kerf_preflight().
 */
function kerf_preflight_render( $findings ) {
	$levels = array(
		'block' => array( 'stop', __( 'Stops the import', 'kerf-blocks' ) ),
		'warn'  => array( 'alert', __( 'Will be broken or missing', 'kerf-blocks' ) ),
		'info'  => array( 'info', __( 'Good to know', 'kerf-blocks' ) ),
	);

	echo '<ul class="kerf-check kerf-preflight">';
	if ( ! $findings ) {
		echo '<li class="kerf-check--ok"><span class="kerf-check__mark">' . kerf_ui_icon( 'check' ) . '</span><div class="kerf-check__text">' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG.
			. '<strong>' . esc_html__( 'Nothing that will break', 'kerf-blocks' ) . '</strong>'
			. '<p>' . esc_html__( 'Every file the design asks for is in it, its pictures are its own, and its pages need no build step to show.', 'kerf-blocks' ) . '</p>'
			. '</div></li>';
	}
	foreach ( $levels as $level => $meta ) {
		foreach ( (array) $findings as $finding ) {
			if ( $level !== $finding['level'] ) {
				continue;
			}
			echo '<li class="kerf-check--' . esc_attr( $level ) . '">';
			echo '<span class="kerf-check__mark">' . kerf_ui_icon( $meta[0] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG.
			echo '<div class="kerf-check__text"><strong>' . esc_html( $meta[1] ) . '</strong><p>' . esc_html( $finding['message'] ) . '</p>';
			if ( ! empty( $finding['items'] ) ) {
				echo '<div class="kerf-check__items">';
				foreach ( $finding['items'] as $item ) {
					echo '<code class="kerf-chip">' . esc_html( $item ) . '</code>';
				}
				echo '</div>';
			}
			echo '</div></li>';
		}
	}
	echo '</ul>';
}

/**
 * The findings as report entries (the CLI prints them; the report shows them).
 *
 * @param array $findings
 * @return array[]
 */
function kerf_preflight_report( $findings ) {
	$out = array();
	foreach ( (array) $findings as $finding ) {
		$out[] = array(
			'category' => 'preflight',
			'message'  => $finding['message'] . ( $finding['items'] ? ' ' . implode( ', ', $finding['items'] ) : '' ),
		);
	}
	return $out;
}
