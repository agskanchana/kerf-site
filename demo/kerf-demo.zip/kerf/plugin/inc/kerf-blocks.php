<?php
/**
 * Kerf blocks — registration and server-side rendering.
 *
 * Eight blocks, all dynamic, all rendering exactly one element with exactly the
 * attributes the mockup gave it. None of them emit a wrapper, a `wp-block-*`
 * class, or a layout style, because every one of those is a rule the designer
 * then has to out-specify.
 *
 * The render callbacks are the second half of a two-sided contract: the
 * attributes kerf_mc_extract_custom_attributes() collects are the attributes
 * kerf_render_attributes() prints. Both sides enforce the same security policy —
 * the converter so the loss is reported, the renderer because block attributes
 * are stored in post content and can be hand-edited afterwards by anyone who can
 * edit the page.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ─────────────────────────────────────────────────────────────────────────────
// Registration
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Every block Kerf ships, in inserter order.
 *
 * Also the list the verification pass checks the converter against: every block
 * name the converter can emit must appear here, or a conversion silently
 * produces blocks WordPress cannot render.
 *
 * @return array<string,string> block folder => render callback.
 */
function kerf_block_manifest() {
	return array(
		'kerf-div'    => 'kerf_render_div_block',
		'kerf-text'   => 'kerf_render_text_block',
		'kerf-link'   => 'kerf_render_link_block',
		'kerf-image'  => 'kerf_render_image_block',
		'kerf-figure' => 'kerf_render_figure_block',
		'kerf-icon'   => 'kerf_render_icon_block',
		'kerf-svg'    => 'kerf_render_svg_block',
		'kerf-video'  => 'kerf_render_video_block',
		'kerf-script'       => 'kerf_render_script_block',
		'kerf-frame'        => 'kerf_render_frame_block',
		'kerf-loop'         => 'kerf_render_loop_block',
		'kerf-post-content' => 'kerf_render_post_content_block',
		'kerf-pagination'   => 'kerf_render_pagination_block',
		'kerf-comments'     => 'kerf_render_comments_block',
	);
}

/**
 * Resolve a block's source directory, preferring the active child theme.
 *
 * Copying blocks/<slug>/ into a child theme makes that copy win for block.json
 * and its editor script, so a site can extend a block's attributes without
 * forking the plugin. The plugin's render_callback is always kept, so server
 * output stays Kerf-controlled.
 *
 * @param string $slug Block folder name.
 * @return string Absolute path to the block directory to register.
 */
function kerf_block_dir( $slug ) {
	if ( get_stylesheet_directory() !== get_template_directory() ) {
		$child = get_stylesheet_directory() . '/blocks/' . $slug;
		if ( file_exists( $child . '/block.json' ) ) {
			return $child;
		}
	}
	return kerf_plugin_path( 'blocks/' . $slug );
}

/**
 * Register every block and its editor script.
 */
function kerf_register_blocks() {
	foreach ( kerf_block_manifest() as $slug => $callback ) {
		$handle = $slug . '-editor';
		$rel    = 'assets/js/' . $handle . '.js';
		$path   = kerf_plugin_path( $rel );

		if ( file_exists( $path ) ) {
			wp_register_script(
				$handle,
				kerf_plugin_url( $rel ),
				// kerf-block-labels is load-bearing: its registerBlockType filter
				// only reaches blocks that register after it, so without the
				// dependency the List View goes back to "Element" on every row.
				array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n', 'wp-data', 'kerf-attributes-control', 'kerf-block-labels' ),
				filemtime( $path ),
				true
			);
			// Without this a script's __() strings are never translated, .pot or not.
			wp_set_script_translations( $handle, 'kerf-blocks', kerf_plugin_path( 'languages' ) );
		}

		register_block_type( kerf_block_dir( $slug ), array( 'render_callback' => $callback ) );
	}
}
add_action( 'init', 'kerf_register_blocks', 20 );

/**
 * Register the shared editor scripts every block depends on: the sidebar
 * controls, and the List View labels.
 *
 * Registered on their own (earlier) hook because the per-block scripts declare
 * them as dependencies — WordPress resolves dependencies by handle at enqueue
 * time, but the handle has to exist before the blocks register or the
 * dependency is silently dropped and the script never loads.
 */
function kerf_register_shared_editor_assets() {
	$rel  = 'assets/js/kerf-attributes-control.js';
	$path = kerf_plugin_path( $rel );

	if ( file_exists( $path ) ) {
		wp_register_script(
			'kerf-attributes-control',
			kerf_plugin_url( $rel ),
			// wp-data, wp-core-data, wp-compose (the search's debounce) and
			// wp-html-entities (titles) are for the link control's pickers:
			// without them a hook is undefined and every block's sidebar
			// throws on open.
			array( 'wp-components', 'wp-element', 'wp-i18n', 'wp-block-editor', 'wp-data', 'wp-core-data', 'wp-compose', 'wp-html-entities' ),
			filemtime( $path ),
			true
		);
		wp_set_script_translations( 'kerf-attributes-control', 'kerf-blocks', kerf_plugin_path( 'languages' ) );
	}

	// List View labels and tag colours. See the header of the file for why this
	// is JavaScript and not a PHP label callback.
	$rel  = 'assets/js/kerf-block-labels.js';
	$path = kerf_plugin_path( $rel );

	if ( file_exists( $path ) ) {
		wp_register_script(
			'kerf-block-labels',
			kerf_plugin_url( $rel ),
			array( 'wp-hooks', 'wp-i18n' ),
			filemtime( $path ),
			true
		);
		wp_set_script_translations( 'kerf-block-labels', 'kerf-blocks', kerf_plugin_path( 'languages' ) );
	}
}
add_action( 'init', 'kerf_register_shared_editor_assets', 5 );

// ─────────────────────────────────────────────────────────────────────────────
// Shared rendering helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Tags kerf/div is allowed to render.
 *
 * Broad on purpose — this is a canvas theme, and a mockup may legitimately use
 * any element. The list exists for one reason: `tagName` is a block attribute
 * stored in post content, so anyone who can edit a page can set it, and
 * `tagName: "script"` would otherwise be an open door. Everything absent from
 * this list falls back to `div`, which renders the children and loses only the
 * wrapper's semantics.
 *
 * `iframe` IS allowed — a Maps or YouTube embed is ordinary markup — and is
 * constrained instead by the URL policy in kerf_render_attributes().
 *
 * @return string[]
 */
function kerf_allowed_tags() {
	static $tags = null;

	if ( null === $tags ) {
		$tags = array(
			// Flow and sectioning.
			'div', 'section', 'article', 'aside', 'header', 'footer', 'main', 'nav',
			'figure', 'figcaption', 'address', 'hgroup', 'search', 'details', 'summary', 'dialog',
			// Lists.
			'ul', 'ol', 'li', 'dl', 'dt', 'dd', 'menu',
			// Headings. Most become core/heading; one holding a script or a
			// marker of the markup contract is an element (scar 44).
			'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
			// Text.
			'p', 'span', 'a', 'button', 'strong', 'b', 'em', 'i', 'u', 's', 'small',
			'mark', 'time', 'label', 'sup', 'sub', 'abbr', 'cite', 'code', 'kbd',
			'samp', 'var', 'q', 'del', 'ins', 'bdi', 'bdo', 'ruby', 'rt', 'rp',
			'data', 'output', 'pre', 'blockquote', 'dfn', 'wbr', 'br',
			// Tables.
			'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'caption', 'colgroup', 'col',
			// Forms.
			'form', 'fieldset', 'legend', 'input', 'textarea', 'select', 'option',
			'optgroup', 'datalist', 'progress', 'meter',
			// Media and embeds.
			'picture', 'source', 'track', 'canvas', 'audio', 'iframe', 'map', 'area',
			// Separators.
			'hr',
			// Inert until a script uses it: Alpine's `<template x-for>` and
			// `x-if`. Anywhere else it only hides its content.
			'template',
		);
	}

	return $tags;
}

/**
 * Tags that close themselves and never take children.
 *
 * @return string[]
 */
function kerf_void_tags() {
	return array( 'area', 'br', 'col', 'hr', 'img', 'input', 'source', 'track', 'wbr' );
}

/**
 * Normalize a block's `tagName` to something safe to print.
 *
 * @param mixed  $tag
 * @param string $fallback
 * @return string
 */
function kerf_safe_tag( $tag, $fallback = 'div' ) {
	$tag = strtolower( trim( (string) $tag ) );
	return in_array( $tag, kerf_allowed_tags(), true ) || kerf_is_custom_element( $tag ) ? $tag : $fallback;
}

/**
 * Is this a custom element's name — a web component's: `<lite-youtube>`,
 * `<model-viewer>`, `<swiper-container>`, a design's own `<x-counter>`?
 *
 * A browser gives such an element nothing but what a script defines, and the
 * scripts are the import's to allow (§5.32): the name alone runs nothing. Not
 * on the list above, one was printed as a `<div>`, which no script upgrades —
 * every web component a design used stood empty (scar 111). The names the
 * standard reserves (`font-face`, `annotation-xml`…) are SVG's and MathML's.
 *
 * @param string $tag Lowercase.
 * @return bool
 */
function kerf_is_custom_element( $tag ) {
	return (bool) preg_match( '/^[a-z][a-z0-9._]*-[a-z0-9._-]*$/', (string) $tag )
		&& ! in_array( $tag, array( 'annotation-xml', 'color-profile', 'font-face', 'font-face-src', 'font-face-uri', 'font-face-format', 'font-face-name', 'missing-glyph' ), true );
}

/**
 * Print a block's `customAttributes` map as HTML attribute markup.
 *
 * The permissive half of the contract, and the one that lets a converted mockup
 * keep a working `<input name="email" required>` or `<iframe allowfullscreen>`.
 * Everything is printed except what the policy below refuses:
 *
 *   class / id / style      owned by dedicated block attributes; printing them
 *                           here would emit the attribute twice and the second
 *                           copy wins in some parsers.
 *   srcdoc                  a whole document, script included, as one value.
 *   script-scheme URLs      in any attribute that takes a URL.
 *   malformed names         a name with a quote or a space in it escapes the
 *                           attribute and starts writing raw markup.
 *
 * Values are escaped, so the remaining risk surface is the attribute NAME, which
 * is shape-checked rather than allowlisted. An attribute that runs code — an
 * inline handler, Alpine's `@click` — prints like any other: the renderer
 * cannot tell an imported one from an injected one, so who may add one is
 * decided where content is saved (kerf-directives.php, §5.32). Until 0.9.0
 * handlers were refused here and not at the save; Kerf had not been released,
 * so no site holds one an Author typed then (scar 108).
 *
 * @param array $attrs Block attributes.
 * @param array $skip  Attribute names this block prints itself.
 * @return string Leading-space-prefixed attribute markup, or ''.
 */
function kerf_render_attributes( $attrs, $skip = array() ) {
	$out = '';

	foreach ( kerf_attribute_pairs( $attrs, $skip ) as $name => $value ) {
		$out .= true === $value ? ' ' . $name : ' ' . $name . '="' . esc_attr( $value ) . '"';
	}

	return $out;
}

/**
 * The custom attributes that pass the policy, as name => value (true for a
 * present boolean attribute). The one place the rules live: kerf_render_attributes()
 * prints these, and core/heading and core/paragraph have them set on their
 * rendered tag (kerf_core_inline_style_render()).
 *
 * @param array    $attrs Block attributes (reads `customAttributes`).
 * @param string[] $skip  Extra attribute names to leave out.
 * @return array<string,string|true>
 */
function kerf_attribute_pairs( $attrs, $skip = array() ) {
	if ( empty( $attrs['customAttributes'] ) || ! is_array( $attrs['customAttributes'] ) ) {
		return array();
	}

	$never = array_merge( array( 'class', 'id', 'style', 'srcdoc' ), array_map( 'strtolower', $skip ) );
	$urls  = function_exists( 'kerf_mc_url_attributes' )
		? kerf_mc_url_attributes()
		: array( 'href', 'src', 'poster', 'action', 'formaction', 'cite', 'data' );

	$out = array();

	foreach ( $attrs['customAttributes'] as $name => $value ) {
		$name = strtolower( (string) $name );

		if ( in_array( $name, $never, true ) ) {
			continue;
		}
		// The converter's rule, so what it stores is what prints: Alpine's
		// `@click` and `x-bind:[key]` included, nothing that ends a name early.
		// Who may ADD such an attribute is decided on save (kerf-directives.php).
		$name_ok = function_exists( 'kerf_mc_attribute_name_ok' )
			? kerf_mc_attribute_name_ok( $name )
			: (bool) preg_match( '/^[a-z_:@#][a-z0-9_.:@#\[\]-]*$/', $name );
		if ( ! $name_ok ) {
			continue;
		}

		// A boolean attribute is present or absent, never `="false"`.
		if ( is_bool( $value ) ) {
			if ( $value ) {
				$out[ $name ] = true;
			}
			continue;
		}
		if ( is_array( $value ) || is_object( $value ) || null === $value ) {
			continue;
		}

		$value = (string) $value;

		if ( in_array( $name, $urls, true )
			&& preg_match( '/^\s*(?:javascript|vbscript)\s*:/i', (string) preg_replace( '/[\x00-\x1F\x7F]/', '', $value ) )
			&& ! ( function_exists( 'kerf_mc_noop_script_url' ) && kerf_mc_noop_script_url( $value ) ) ) {
			continue;
		}

		$out[ $name ] = $value;
	}

	return $out;
}

/**
 * Escape a URL that may legitimately be relative.
 *
 * `esc_url()` cannot be used directly here. Given a relative path with no
 * leading slash it assumes a bare hostname was meant and prepends a scheme, so
 * a mockup's `images/logo.svg` becomes `http://images/logo.svg` — a request to a
 * host called "images". Nothing errors; the picture is simply gone, and the
 * markup looks almost right in view-source, which is what makes it expensive to
 * find.
 *
 * It also refuses `data:` outright, because `data` is not in
 * wp_allowed_protocols(). Inline base64 images are common in mockups (icons,
 * tiny placeholders, exported SVG), and silently blanking them is the same
 * failure in a different costume.
 *
 * So: hand anything esc_url() handles correctly to esc_url(), and escape the
 * two cases it gets wrong by hand — after refusing the schemes that matter.
 *
 * @param string $url
 * @return string Escaped URL, or '' when refused.
 */
function kerf_esc_url( $url ) {
	$url = trim( (string) $url );

	if ( '' === $url ) {
		return '';
	}

	// Strip control characters first: a newline or NUL inside a scheme is the
	// classic way to smuggle `java\nscript:` past a naive pattern.
	$url = preg_replace( '/[\x00-\x1F\x7F]/', '', $url );

	if ( preg_match( '/^\s*(?:javascript|vbscript)\s*:/i', $url ) ) {
		// `javascript:void(0)` runs nothing, and a link only a script answers
		// needs an address to stay a link (kerf_mc_noop_script_url()).
		return function_exists( 'kerf_mc_noop_script_url' ) && kerf_mc_noop_script_url( $url ) ? esc_attr( trim( $url ) ) : '';
	}

	// Inline images only — `data:text/html` is a document, and a document in an
	// iframe src or an anchor href executes. A picture's type may end at its
	// comma: `data:image/svg+xml,%3Csvg…` is how an SVG is most often written.
	if ( preg_match( '#^data:#i', $url ) ) {
		return preg_match( '#^data:image/(?:png|jpe?g|gif|webp|avif|svg\+xml)[;,]#i', $url )
			? esc_attr( $url )
			: '';
	}

	// Absolute, protocol-relative, root-relative, fragment or query: esc_url()
	// handles all of these correctly.
	if ( preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//|/|\#|\?)#i', $url ) ) {
		return esc_url( $url );
	}

	// A genuinely relative path. There is no scheme to validate, so escaping for
	// the attribute context is both necessary and sufficient.
	return esc_attr( $url );
}

/**
 * Resolve a block's link destination.
 *
 * A bound link stores WHAT it points at (`linkType` + `linkId`) rather than
 * where that thing currently lives, so the href is computed at render time and
 * survives a slug change, a move under a new parent, or a permalink-structure
 * switch. That is the difference between markup that merely looks like a menu
 * and markup that behaves like one.
 *
 * Falls back to the literal href the mockup wrote whenever the binding cannot
 * be honoured — a trashed page, a deleted post — because rendering `href=""`
 * would silently turn the link into a self-link, which is harder to notice than
 * a 404.
 *
 * `linkType`: 'home'; 'post' (any post type, by `linkId`); 'media' (a file in
 * the library, by attachment ID); '' or 'url' — the literal href ('url' when
 * someone chose it in the editor, which a re-scan respects: kerf_links_is_settled()).
 *
 * @param array  $attrs    Block attributes.
 * @param string $fallback Literal href to use when nothing is bound.
 * @return string Unescaped URL.
 */
function kerf_resolve_link_url( $attrs, $fallback = '' ) {
	$type = isset( $attrs['linkType'] ) ? (string) $attrs['linkType'] : '';
	// `index.html#services` bound to the home page goes to its Services
	// section, not its top (kerf_links_fragment(), scar 134).
	$fragment = ( 'home' === $type || 'post' === $type ) && function_exists( 'kerf_links_fragment' ) ? kerf_links_fragment( $attrs, $fallback ) : '';

	if ( 'home' === $type ) {
		return home_url( '/' ) . $fragment;
	}

	// A file, by attachment: the link follows it when it is replaced or the
	// site moves to another address.
	if ( 'media' === $type && ! empty( $attrs['linkId'] ) ) {
		$file = wp_get_attachment_url( (int) $attrs['linkId'] );
		if ( $file ) {
			return $file;
		}
	}

	if ( 'post' === $type && ! empty( $attrs['linkId'] ) ) {
		$post_id = (int) $attrs['linkId'];
		$status  = get_post_status( $post_id );

		// A draft has a permalink, and linking to one from the front end sends
		// visitors to a 404. Better the literal href, which at least matches
		// what the designer intended.
		if ( $status && in_array( $status, array( 'publish', 'private', 'inherit' ), true ) ) {
			$permalink = get_permalink( $post_id );
			if ( $permalink ) {
				return $permalink . $fragment;
			}
		}
	}

	return $fallback;
}

/**
 * A block's `inlineStyle` as clean CSS declarations ('' when unset or refused).
 *
 * @param array $attrs Block attributes.
 * @return string Declarations with no trailing semicolon.
 */
function kerf_inline_style_value( $attrs ) {
	$style = isset( $attrs['inlineStyle'] ) ? (string) $attrs['inlineStyle'] : '';
	if ( '' === $style ) {
		return '';
	}

	// WordPress kses-escapes every string block attribute on save for users
	// without `unfiltered_html`, which turns an `&` inside a url() into `&amp;`
	// and the declaration silently stops working.
	if ( function_exists( 'kerf_css_decode_entities' ) ) {
		$style = kerf_css_decode_entities( $style );
	}
	$style = trim( $style, " \t\n\r;" );

	// This string lands verbatim in a style attribute, so refuse the payloads
	// that turn CSS into script.
	if ( preg_match( '/(?:javascript|vbscript)\s*:|expression\s*\(|behaviou?r\s*:/i', $style ) ) {
		return '';
	}

	return $style;
}

/**
 * A block's `inlineStyle` as a ready-to-print ` style="…"`.
 *
 * @param array  $attrs  Block attributes.
 * @param string $prefix Declarations the block computed itself. They come first,
 *                       so a conflicting property in inlineStyle wins — last
 *                       declaration standing, which is what an author editing
 *                       the field expects.
 * @return string
 */
function kerf_render_inline_style_attr( $attrs, $prefix = '' ) {
	$parts = array();

	foreach ( array( $prefix, kerf_inline_style_value( $attrs ) ) as $chunk ) {
		$chunk = trim( (string) $chunk, " \t\n\r;" );
		if ( '' !== $chunk ) {
			$parts[] = $chunk;
		}
	}

	return $parts ? ' style="' . esc_attr( implode( ';', $parts ) ) . '"' : '';
}

/**
 * Every block that carries an `inlineStyle` attribute.
 *
 * @return string[]
 */
function kerf_inline_style_blocks() {
	$kerf = array( 'kerf/div', 'kerf/text', 'kerf/link', 'kerf/image', 'kerf/figure', 'kerf/icon', 'kerf/video' );
	$core = function_exists( 'kerf_core_inline_style_blocks' ) ? kerf_core_inline_style_blocks() : array();

	/**
	 * Filter the blocks that support the Kerf inline-style passthrough.
	 *
	 * @param string[] $blocks Block names.
	 */
	return (array) apply_filters( 'kerf_inline_style_blocks', array_merge( $kerf, $core ) );
}

/**
 * The block's class attribute, or '' when it has none.
 *
 * @param array  $attrs Block attributes.
 * @param string $extra Class to append.
 * @return string
 */
function kerf_render_class_attr( $attrs, $extra = '' ) {
	$class = isset( $attrs['className'] ) ? (string) $attrs['className'] : '';
	$class = trim( $class . ' ' . $extra );

	// Not sanitize_text_field(): a class list is not prose, and collapsing its
	// whitespace or stripping a legitimate character silently breaks a selector.
	// esc_attr() is the correct and sufficient escape for an attribute value.
	return ( '' === $class ) ? '' : ' class="' . esc_attr( $class ) . '"';
}

/**
 * The block's anchor as an id attribute, or '' when it has none.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_anchor_attr( $attrs ) {
	$anchor = isset( $attrs['anchor'] ) ? trim( (string) $attrs['anchor'] ) : '';

	// An id may not contain whitespace or a quote; everything else is legal in
	// HTML5 and mockups do use dots and colons.
	if ( '' === $anchor || preg_match( '/["\'\s<>]/', $anchor ) ) {
		return '';
	}

	return ' id="' . esc_attr( $anchor ) . '"';
}

// ─────────────────────────────────────────────────────────────────────────────
// Render callbacks
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Render kerf/div — one element, exactly as the mockup wrote it.
 *
 * @param array  $attrs   Block attributes.
 * @param string $content InnerBlocks HTML.
 * @return string
 */
function kerf_render_div_block( $attrs, $content = '', $block = null ) {
	// Live data, where the markup contract asked for it (inc/kerf-bindings.php).
	// A "next post" link on the newest post has nowhere to go, and goes.
	if ( kerf_field_is_empty( $attrs, $block ) ) {
		return '';
	}
	$attrs = kerf_apply_element_fields( $attrs, $block );
	$attrs = kerf_apply_bound_background( $attrs, $block );
	// Marked for the featured image, its picture in the stylesheet: its rules
	// print with this page's picture (inc/kerf-backgrounds.php).
	if ( function_exists( 'kerf_bg_mark' ) ) {
		kerf_bg_mark( $attrs, $block );
	}
	// A form Kerf sends, and the designer's messages for it (inc/kerf-forms.php).
	// Its fields are its content: a file field changes how it sends.
	if ( function_exists( 'kerf_forms_apply' ) ) {
		$attrs = kerf_forms_apply( $attrs, $content );
	}

	$tag      = kerf_safe_tag( isset( $attrs['tagName'] ) ? $attrs['tagName'] : 'div' );

	// A business detail held by an element: a link's address, an address's
	// lines (inc/kerf-site.php).
	if ( function_exists( 'kerf_site_apply' ) ) {
		list( $attrs, $content ) = kerf_site_apply( $attrs, $content );
	}
	$bg_raw   = isset( $attrs['backgroundImage'] ) ? (string) $attrs['backgroundImage'] : '';
	$bg_image = '' !== $bg_raw ? kerf_esc_url( $bg_raw ) : '';

	// Lazy loading is opt-in (block default false). It used to be the default,
	// and on a real template it blanked every carousel slide the slider cloned
	// after the lazy script had run — the clone carries `data-bg`, nobody ever
	// observes it — and it hid the image from any plugin that reads an element's
	// background when it initialises. A high-priority background is preloaded
	// in <head>, so it is never lazy.
	$lazy_bg = $bg_image && ! empty( $attrs['lazyBg'] ) && empty( $attrs['preloadBg'] );

	// Current conversions keep the background INSIDE inlineStyle, where the
	// mockup wrote it, so it renders in its original declaration order. Blocks
	// converted before that, or given a background in the editor, carry it only
	// in backgroundImage and get it as a leading declaration, as they always did.
	$style_attrs = $attrs;
	$in_style    = '' !== $bg_raw && false !== stripos( kerf_inline_style_value( $attrs ), $bg_raw );

	if ( $in_style ) {
		$style_prefix = '';
		if ( $lazy_bg ) {
			// The script supplies the image later; until then the declaration
			// keeps its position, size and repeat with no image in it.
			$style_attrs['inlineStyle'] = preg_replace(
				'/url\(\s*[\'"]?' . preg_quote( $bg_raw, '/' ) . '[\'"]?\s*\)/i',
				'none',
				kerf_inline_style_value( $attrs )
			);
		}
	} else {
		$style_prefix = ( $bg_image && ! $lazy_bg ) ? "background-image:url('" . $bg_image . "')" : '';
	}

	$html  = '<' . $tag;
	$html .= kerf_render_class_attr( $attrs, $lazy_bg ? 'kerf-lazy-bg' : '' );
	$html .= kerf_render_anchor_attr( $attrs );
	$html .= kerf_render_inline_style_attr( $style_attrs, $style_prefix );

	if ( $lazy_bg ) {
		$html .= ' data-bg="' . esc_attr( $bg_image ) . '"';
	}

	// A <button> inside a form defaults to type="submit". Mockup buttons are
	// almost always UI triggers (menu toggles, tab switches), and a stray submit
	// reloads the page on click.
	if ( 'button' === $tag && ! isset( $attrs['customAttributes']['type'] ) ) {
		$html .= ' type="button"';
	}

	// An anchor with element children converts to kerf/div, so its href lives in
	// customAttributes. Swap in the bound destination before printing, leaving
	// the stored literal untouched so removing the binding restores the mockup's
	// own href exactly. An <a> the mockup wrote with no href at all gets one too
	// once a destination is chosen for it in the editor.
	if ( ! empty( $attrs['linkType'] ) && ( 'a' === $tag || isset( $attrs['customAttributes']['href'] ) ) ) {
		$literal  = isset( $attrs['customAttributes']['href'] ) ? (string) $attrs['customAttributes']['href'] : '';
		$resolved = kerf_resolve_link_url( $attrs, $literal );
		if ( '' !== $resolved ) {
			if ( ! isset( $attrs['customAttributes'] ) || ! is_array( $attrs['customAttributes'] ) ) {
				$attrs['customAttributes'] = array();
			}
			$attrs['customAttributes']['href'] = $resolved;
		}
	}

	$html .= kerf_render_attributes( $attrs );

	if ( in_array( $tag, kerf_void_tags(), true ) ) {
		return $html . '>';
	}

	$html .= '>' . $content . '</' . $tag . '>';

	if ( $lazy_bg && function_exists( 'kerf_enqueue_front_script' ) ) {
		kerf_enqueue_front_script( 'kerf-lazy-bg' );
	}

	return $html;
}

/**
 * Swap a bound background into the inline style, where the mockup wrote it.
 *
 * Conversions keep a background inside `inlineStyle` (so its size, position
 * and repeat stay with it), with `backgroundImage` recording which URL it is.
 * A binding replaces `backgroundImage` only; left alone, the placeholder's
 * `url()` would still be in the style and would still win. So the URL the
 * block was saved with is replaced by the bound one — or by `none` for a post
 * without a featured image.
 *
 * @param array         $attrs Attributes, bindings applied.
 * @param WP_Block|null $block
 * @return array
 */
function kerf_apply_bound_background( $attrs, $block = null ) {
	if ( ! $block instanceof WP_Block || empty( $attrs['metadata']['bindings']['backgroundImage'] ) ) {
		return $attrs;
	}

	$stored = isset( $block->parsed_block['attrs']['backgroundImage'] ) ? (string) $block->parsed_block['attrs']['backgroundImage'] : '';
	$bound  = isset( $attrs['backgroundImage'] ) ? (string) $attrs['backgroundImage'] : '';
	$style  = isset( $attrs['inlineStyle'] ) ? (string) $attrs['inlineStyle'] : '';

	if ( '' === $stored || $stored === $bound || '' === $style || false === stripos( $style, $stored ) ) {
		return $attrs;
	}

	$attrs['inlineStyle'] = preg_replace(
		'/url\(\s*([\'"]?)' . preg_quote( $stored, '/' ) . '\1\s*\)/i',
		'' !== $bound ? "url('" . str_replace( array( "'", '\\' ), array( '%27', '' ), $bound ) . "')" : 'none',
		$style
	);

	return $attrs;
}

/**
 * Render kerf/text — a run of text in an inline element.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_text_block( $attrs, $content = '', $block = null ) {
	// A marked element (a comment form's textarea, §5.25) gets its name and
	// value from WordPress, like any other element.
	if ( function_exists( 'kerf_apply_element_fields' ) ) {
		if ( kerf_field_is_empty( $attrs, $block ) ) {
			return '';
		}
		$attrs = kerf_apply_element_fields( $attrs, $block );
	}
	if ( function_exists( 'kerf_forms_apply' ) ) {
		$attrs = kerf_forms_apply( $attrs );
	}

	// Text that sat directly beside an element in the mockup renders as that
	// text and nothing else. It is a span only in the editor, because a block
	// has to be an element there. Once someone gives it a class, an id, a style
	// or an attribute, it has become an element on purpose and renders as one.
	if ( ! empty( $attrs['bare'] )
		&& empty( $attrs['className'] )
		&& empty( $attrs['anchor'] )
		&& '' === kerf_inline_style_value( $attrs )
		&& empty( $attrs['customAttributes'] ) ) {
		return esc_html( isset( $attrs['text'] ) ? (string) $attrs['text'] : '' );
	}

	$tag = kerf_safe_tag( isset( $attrs['tagName'] ) ? $attrs['tagName'] : 'span', 'span' );

	$html  = '<' . $tag;
	$html .= kerf_render_class_attr( $attrs );
	$html .= kerf_render_anchor_attr( $attrs );
	$html .= kerf_render_inline_style_attr( $attrs );
	$html .= kerf_render_attributes( $attrs );

	if ( in_array( $tag, kerf_void_tags(), true ) ) {
		return $html . '>';
	}

	$text = isset( $attrs['text'] ) ? (string) $attrs['text'] : '';

	return $html . '>' . esc_html( $text ) . '</' . $tag . '>';
}

/**
 * Render kerf/link — a text-only anchor.
 *
 * @param array  $attrs   Block attributes.
 * @param string $content Unused; kerf/link has no InnerBlocks.
 * @return string
 */
function kerf_render_link_block( $attrs, $content = '', $block = null ) {
	// A "next post" link on the newest post has nowhere to go.
	if ( kerf_field_is_empty( $attrs, $block ) ) {
		return '';
	}

	// A bound URL is the post's; the page binding recorded at import (the
	// mockup's `blog-details.html`, bound to a page) must not override it.
	if ( ! empty( $attrs['metadata']['bindings']['url'] ) ) {
		$attrs['linkType'] = '';
	}

	$url  = isset( $attrs['url'] ) ? trim( (string) $attrs['url'] ) : '';
	$url  = kerf_resolve_link_url( $attrs, $url );
	$href = ( '' === $url ) ? '#' : kerf_esc_url( $url );

	// A refused scheme comes back as '', which would emit href="" — and an empty
	// href links to the current page rather than doing nothing, so a blocked
	// javascript: link would quietly become a self-link.
	if ( '' === $href ) {
		$href = '#';
	}

	$html  = '<a href="' . $href . '"';
	$html .= kerf_render_class_attr( $attrs );
	$html .= kerf_render_anchor_attr( $attrs );

	$rel = isset( $attrs['rel'] ) ? trim( (string) $attrs['rel'] ) : '';

	if ( ! empty( $attrs['newTab'] ) ) {
		$html .= ' target="_blank" rel="' . esc_attr( trim( 'noopener noreferrer ' . $rel ) ) . '"';
	} elseif ( '' !== $rel ) {
		$html .= ' rel="' . esc_attr( $rel ) . '"';
	}

	$html .= kerf_render_inline_style_attr( $attrs );
	$html .= kerf_render_attributes( $attrs, array( 'href', 'target', 'rel' ) );

	$text = isset( $attrs['text'] ) ? (string) $attrs['text'] : '';

	return $html . '>' . ( '' !== $content ? $content : esc_html( $text ) ) . '</a>';
}

/**
 * Render kerf/image — a bare <img>, no figure wrapper, no wp-block classes.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_image_block( $attrs ) {
	$src = isset( $attrs['src'] ) ? kerf_esc_url( $attrs['src'] ) : '';

	// An image with no source is an empty block — unless the mockup wrote it:
	// `<img :src="img">` inside Alpine's `<template x-for>` gets its source from
	// the script, and was dropped without a word (every gallery thumbnail).
	if ( '' === $src && empty( $attrs['customAttributes'] ) && empty( $attrs['className'] ) && empty( $attrs['anchor'] ) ) {
		return '';
	}

	$media_id = isset( $attrs['mediaId'] ) ? (int) $attrs['mediaId'] : 0;
	$width    = isset( $attrs['width'] ) ? (string) $attrs['width'] : '';
	$height   = isset( $attrs['height'] ) ? (string) $attrs['height'] : '';
	$hero     = ! empty( $attrs['hero'] );

	// Width and height are printed only when the block has them — which, after
	// an import, means only when the mockup wrote them. They used to be filled
	// in from the attachment "to avoid layout shift", and that was a rendering
	// change, not a hint: presentational height pins the box, so under the very
	// common `img{max-width:100%}` without `height:auto`, a narrowed image kept
	// its full height and every card holding one grew. See the converter.

	$srcset = '';
	$sizes  = '';
	if ( $media_id ) {
		$srcset = wp_get_attachment_image_srcset( $media_id, 'full' );
		if ( $srcset ) {
			// From the FILE's width, never the width attribute. With srcset
			// present, `sizes` decides the image's intrinsic width, so an image
			// shown at its natural size must be told its natural size — '100vw'
			// would stretch a 200px logo across the viewport.
			$meta    = wp_get_attachment_metadata( $media_id );
			$natural = is_array( $meta ) && ! empty( $meta['width'] ) ? (int) $meta['width'] : (int) $width;
			$sizes   = $natural > 0 ? '(max-width: ' . $natural . 'px) 100vw, ' . $natural . 'px' : '100vw';
		}
	}

	$style_prefix = '';
	if ( ! empty( $attrs['objectFit'] ) ) {
		$style_prefix = 'object-fit:' . preg_replace( '/[^a-z-]/', '', strtolower( (string) $attrs['objectFit'] ) );
	}

	// A post's picture in the designer's slot (inc/kerf-bindings.php): the slot
	// is the sample picture's size, and the post's picture is cropped to it,
	// never stretched. `sizes` says the slot's width — with srcset, that IS the
	// image's intrinsic width, and the file's 1920px made a sidebar thumbnail
	// fill its column.
	if ( ! empty( $attrs['metadata']['bindings']['src'] ) ) {
		$fit = isset( $attrs['metadata']['bindings']['src']['args']['fit'] ) ? (array) $attrs['metadata']['bindings']['src']['args']['fit'] : array();
		if ( 2 === count( $fit ) && (int) $fit[0] > 0 && (int) $fit[1] > 0 ) {
			if ( '' === $width && '' === $height ) {
				$width  = (string) (int) $fit[0];
				$height = (string) (int) $fit[1];
			}
			if ( $srcset ) {
				$sizes = (int) $fit[0] . 'px';
			}
		}
		if ( '' === $style_prefix ) {
			$style_prefix = 'object-fit:cover';
		}
	}

	$html  = '<img';
	$html .= kerf_render_class_attr( $attrs );
	if ( '' !== $src ) {
		$html .= ' src="' . $src . '"';
	}
	if ( $srcset ) { $html .= ' srcset="' . esc_attr( $srcset ) . '"'; }
	if ( $sizes )  { $html .= ' sizes="' . esc_attr( $sizes ) . '"'; }
	$html .= ' alt="' . esc_attr( isset( $attrs['alt'] ) ? $attrs['alt'] : '' ) . '"';
	if ( '' !== $width )  { $html .= ' width="' . esc_attr( $width ) . '"'; }
	if ( '' !== $height ) { $html .= ' height="' . esc_attr( $height ) . '"'; }

	if ( $hero ) {
		$html .= ' loading="eager" fetchpriority="high"';
	} else {
		$loading = isset( $attrs['loading'] ) ? strtolower( (string) $attrs['loading'] ) : '';

		// What the mockup wrote, kept. Where it wrote nothing, lazy-load only an
		// image whose box is already reserved by width AND height — WordPress
		// core's own rule. An undimensioned lazy image is a zero-height box until
		// it scrolls near the viewport, so everything below it jumps as it loads,
		// and an in-page `#anchor` lands in the wrong place.
		if ( '' === $loading && '' !== $width && '' !== $height ) {
			$loading = 'lazy';
		}
		if ( 'lazy' === $loading || 'eager' === $loading ) {
			$html .= ' loading="' . $loading . '"';
		}
	}

	$html .= ' decoding="async"';
	$html .= kerf_render_anchor_attr( $attrs );
	$html .= kerf_render_inline_style_attr( $attrs, $style_prefix );
	$html .= kerf_render_attributes( $attrs, array( 'src', 'alt', 'width', 'height', 'loading', 'srcset', 'sizes', 'decoding', 'fetchpriority' ) );
	$html .= '>';

	$link = isset( $attrs['linkUrl'] ) ? trim( (string) $attrs['linkUrl'] ) : '';
	$link = kerf_resolve_link_url( $attrs, $link );
	if ( '' !== $link ) {
		$href = kerf_esc_url( $link );
		if ( '' !== $href ) {
			$target = ! empty( $attrs['linkNewTab'] ) ? ' target="_blank" rel="noopener noreferrer"' : '';
			$html   = '<a href="' . $href . '"' . $target . '>' . $html . '</a>';
		}
	}

	return $html;
}

/**
 * Keep WordPress' `sizes="auto"` off the pictures a design draws.
 *
 * Since 6.7 core puts `auto` first in the `sizes` of every lazy-loaded picture
 * with a width, as it filters content and templates after the blocks have
 * rendered (wp_img_tag_add_auto_sizes()). Browsers answer `sizes=auto` with
 * `contain: size !important` from their own stylesheet, which no stylesheet
 * can override: the picture's own shape is ignored and its box takes the
 * width and height attributes' shape. A designer's attributes often do not
 * match the file — a clinic's 600×500 for a 700×390 photo, which the mockup
 * showed at its own shape under `height: auto` — so the photo was stretched,
 * and an award beside it squashed square. Any picture whose box the
 * attributes reserve is lazy-loaded (kerf_render_image_block()), so most get
 * `auto`: 17 on that page. All `auto` buys is a smaller file picked from
 * srcset; the `sizes` written above says the file's width.
 *
 * Off wherever the design's assets load (kerf_assets_here()): every page under
 * the Kerf theme, whose parts carry the design's pictures everywhere, and
 * under another theme a page whose content is Kerf blocks. Off, core also
 * leaves its `contain-intrinsic-size` rule out of the head. A site that wants
 * `auto` back for its posts can return true from a later filter.
 *
 * @param bool $enabled Whether core adds `auto`.
 * @return bool
 */
function kerf_image_auto_sizes( $enabled ) {
	return kerf_assets_here() ? false : $enabled;
}
add_filter( 'wp_img_tag_add_auto_sizes', 'kerf_image_auto_sizes' );

/**
 * Render kerf/figure.
 *
 * @param array  $attrs   Block attributes.
 * @param string $content InnerBlocks HTML.
 * @return string
 */
function kerf_render_figure_block( $attrs, $content = '' ) {
	$html  = '<figure';
	$html .= kerf_render_class_attr( $attrs );
	$html .= kerf_render_anchor_attr( $attrs );
	$html .= kerf_render_inline_style_attr( $attrs );
	$html .= kerf_render_attributes( $attrs );

	return $html . '>' . $content . '</figure>';
}

/**
 * Render kerf/icon.
 *
 * The class list is printed verbatim. Kerf bundles no icon font and maps
 * nothing: whatever set the mockup used came in through the asset pipeline
 * alongside it, and that stylesheet is what draws the glyph.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_icon_block( $attrs ) {
	$tag        = kerf_safe_tag( isset( $attrs['tagName'] ) ? $attrs['tagName'] : 'i', 'i' );
	$icon_class = isset( $attrs['iconClass'] ) ? trim( (string) $attrs['iconClass'] ) : '';
	$extra      = isset( $attrs['className'] ) ? trim( (string) $attrs['className'] ) : '';
	$classes    = trim( $icon_class . ' ' . $extra );

	$html = '<' . $tag;
	if ( '' !== $classes ) {
		$html .= ' class="' . esc_attr( $classes ) . '"';
	}
	$html .= kerf_render_anchor_attr( $attrs );
	$html .= kerf_render_inline_style_attr( $attrs );

	// An icon is decorative unless the author gave it a label. Without this every
	// icon in a converted nav is announced as an unlabelled graphic.
	if ( empty( $attrs['customAttributes']['aria-label'] )
		&& empty( $attrs['customAttributes']['aria-hidden'] )
		&& empty( $attrs['customAttributes']['role'] ) ) {
		$html .= ' aria-hidden="true"';
	}

	$html .= kerf_render_attributes( $attrs );

	if ( in_array( $tag, kerf_void_tags(), true ) ) {
		return $html . '>';
	}

	return $html . '></' . $tag . '>';
}

/**
 * Render kerf/svg.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_svg_block( $attrs ) {
	$raw = isset( $attrs['svg'] ) ? (string) $attrs['svg'] : '';
	$svg = function_exists( 'kerf_sanitize_svg_markup' ) ? kerf_sanitize_svg_markup( $raw ) : '';

	if ( '' === trim( $svg ) || false === stripos( $svg, '<svg' ) ) {
		return '';
	}

	$class  = isset( $attrs['className'] ) ? trim( (string) $attrs['className'] ) : '';
	$anchor = isset( $attrs['anchor'] ) ? trim( (string) $attrs['anchor'] ) : '';
	$aria   = isset( $attrs['ariaLabel'] ) ? trim( (string) $attrs['ariaLabel'] ) : '';
	$width  = isset( $attrs['width'] ) ? trim( (string) $attrs['width'] ) : '';
	$height = isset( $attrs['height'] ) ? trim( (string) $attrs['height'] ) : '';

	$style = '';
	if ( '' !== $width )  { $style .= 'width:' . $width . ';'; }
	if ( '' !== $height ) { $style .= 'height:' . $height . ';'; }

	return preg_replace_callback(
		'/<svg\b([^>]*)>/i',
		function ( $m ) use ( $class, $style, $aria, $anchor ) {
			$svg_attrs = $m[1];

			if ( '' !== $class ) {
				if ( preg_match( '/\bclass="([^"]*)"/i', $svg_attrs, $cm ) ) {
					// The converter keeps the svg's own markup AND records its
					// class as the block's className, so the two usually say the
					// same thing. Appending blindly printed every class twice —
					// `class="bi me-2 bi me-2"` — which breaks any
					// `[class="…"]` selector and every DOM comparison.
					$merged = array_unique( array_merge(
						preg_split( '/\s+/', trim( $cm[1] ), -1, PREG_SPLIT_NO_EMPTY ),
						preg_split( '/\s+/', $class, -1, PREG_SPLIT_NO_EMPTY )
					) );
					$svg_attrs = str_replace(
						$cm[0],
						'class="' . esc_attr( implode( ' ', $merged ) ) . '"',
						$svg_attrs
					);
				} else {
					$svg_attrs .= ' class="' . esc_attr( $class ) . '"';
				}
			}

			if ( '' !== $style ) {
				// An author-set size wins over the mockup's own inline style.
				$svg_attrs  = preg_replace( '/\sstyle="[^"]*"/i', '', $svg_attrs );
				$svg_attrs .= ' style="' . esc_attr( $style ) . '"';
			}

			if ( '' !== $anchor ) {
				$svg_attrs  = preg_replace( '/\sid="[^"]*"/i', '', $svg_attrs );
				$svg_attrs .= ' id="' . esc_attr( $anchor ) . '"';
			}

			if ( '' !== $aria ) {
				$svg_attrs .= ' role="img" aria-label="' . esc_attr( $aria ) . '"';
			} elseif ( false === stripos( $svg_attrs, 'aria-' ) && false === stripos( $svg_attrs, 'role=' ) ) {
				$svg_attrs .= ' aria-hidden="true"';
			}

			return '<svg' . $svg_attrs . '>';
		},
		$svg,
		1
	);
}

/**
 * Strip the wrapper WordPress puts around a rendered template part.
 *
 * `render_block_core_template_part()` always emits
 * `<header class="wp-block-template-part">…</header>` (the tag comes from the
 * part's area) and offers no way to opt out. For an ordinary theme that is
 * helpful. For Kerf it is a structural change to markup the designer wrote:
 *
 *     body > header        becomes  body > div > header     — stops matching
 *     header + main        becomes  div + main              — stops matching
 *     .site-header         unaffected
 *
 * Class-based rules survive; every direct-child and adjacent-sibling rule
 * involving the header or footer does not. Those are not exotic — they are how
 * sticky headers, full-bleed heroes and "first section sits under the header"
 * spacing are normally written.
 *
 * The wrapper is also a second banner landmark, because the converted part
 * already contains the mockup's own `<header>`.
 *
 * Removing it leaves the part's content exactly where the template says it goes.
 * Nothing else about template parts changes: they are still separate records,
 * still editable in the Site Editor, still cached the same way.
 *
 * @param string $block_content Rendered block HTML.
 * @param array  $block         Parsed block.
 * @return string
 */
function kerf_unwrap_template_part( $block_content, $block ) {
	if ( empty( $block['blockName'] ) || 'core/template-part' !== $block['blockName'] ) {
		return $block_content;
	}

	// Another theme's parts keep the wrapper its CSS was written against.
	if ( ! kerf_theme_active() ) {
		return $block_content;
	}

	/**
	 * Filter whether the template-part wrapper is removed.
	 *
	 * Return false to keep WordPress' wrapper — worth doing if a site's CSS was
	 * written against `.wp-block-template-part` rather than against the mockup.
	 *
	 * @param bool  $unwrap Whether to strip the wrapper.
	 * @param array $block  Parsed block.
	 */
	if ( ! apply_filters( 'kerf_unwrap_template_part', true, $block ) ) {
		return $block_content;
	}

	// Anchored at both ends and matching the LAST closing tag, so a part whose
	// content happens to contain a nested <header> is not truncated.
	$pattern = '#^\s*<(header|footer|div|aside|main|section|nav)\b[^>]*\bclass="[^"]*\bwp-block-template-part\b[^"]*"[^>]*>(.*)</\1>\s*$#is';

	if ( preg_match( $pattern, $block_content, $m ) ) {
		return $m[2];
	}

	return $block_content;
}
add_filter( 'render_block', 'kerf_unwrap_template_part', 20, 2 );

/**
 * Put back the whitespace the mockup had between a container's children.
 *
 * The converter records it in `gaps` (see kerf_mc_convert_children_spaced()):
 * one '1' or '0' per gap, before the first child, between each pair, after the
 * last. Block markup itself cannot carry it — every save puts a newline between
 * inner blocks — so it is applied here, to the whitespace-only chunks of
 * `innerContent`, before the children are joined.
 *
 * Applied only while the structure is the one that was recorded. Once someone
 * adds or removes a child in the editor the map no longer lines up, and the
 * container falls back to the whitespace block markup gives everywhere.
 *
 * @param array $parsed_block Parsed block.
 * @return array
 */
function kerf_apply_gaps( $parsed_block ) {
	$name = isset( $parsed_block['blockName'] ) ? $parsed_block['blockName'] : '';

	if ( 'kerf/div' !== $name && 'kerf/figure' !== $name ) {
		return $parsed_block;
	}

	$gaps  = isset( $parsed_block['attrs']['gaps'] ) ? (string) $parsed_block['attrs']['gaps'] : '';
	$count = isset( $parsed_block['innerBlocks'] ) ? count( $parsed_block['innerBlocks'] ) : 0;

	if ( '' === $gaps || strlen( $gaps ) !== $count + 1 || preg_match( '/[^01]/', $gaps ) ) {
		return $parsed_block;
	}

	// Anything but whitespace between the children is content, and not ours.
	foreach ( (array) $parsed_block['innerContent'] as $chunk ) {
		if ( is_string( $chunk ) && '' !== trim( $chunk, " \t\n\r\f" ) ) {
			return $parsed_block;
		}
	}

	$inner = array();
	for ( $i = 0; $i <= $count; $i++ ) {
		if ( '1' === $gaps[ $i ] ) {
			$inner[] = "\n";
		}
		if ( $i < $count ) {
			$inner[] = null;
		}
	}

	$parsed_block['innerContent'] = $inner;

	return $parsed_block;
}
add_filter( 'render_block_data', 'kerf_apply_gaps' );

/**
 * Strip core/post-content's wrapper on a page built from a mockup.
 *
 * `render_block_core_post_content()` always emits
 * `<div class="entry-content wp-block-post-content …">` around the page. On a
 * converted page that is an element the designer never wrote, sitting between
 * the header part and the mockup's own `<main>`: `header + main` stops
 * matching, and so does every rule that counts on `<main>` being a flex item of
 * the body. It was documented as "unavoidable in a block theme"; it is a
 * `render_block` filter, the same as the template-part wrapper above.
 *
 * Only on content that contains Kerf blocks. A post written in the editor with
 * core blocks relies on that wrapper for its layout, and keeps it.
 *
 * @param string        $block_content Rendered block HTML.
 * @param array         $block         Parsed block.
 * @param WP_Block|null $instance      Block instance, for the post context.
 * @return string
 */
function kerf_unwrap_post_content( $block_content, $block, $instance = null ) {
	if ( empty( $block['blockName'] ) || 'core/post-content' !== $block['blockName'] ) {
		return $block_content;
	}

	// Under another theme a Kerf page sits inside that theme's content
	// wrapper, which gives it its width.
	if ( ! kerf_theme_active() ) {
		return $block_content;
	}

	$post_id = ( $instance instanceof WP_Block && ! empty( $instance->context['postId'] ) )
		? (int) $instance->context['postId']
		: (int) get_the_ID();
	$post    = $post_id ? get_post( $post_id ) : null;

	if ( ! $post || false === strpos( $post->post_content, '<!-- wp:kerf/' ) ) {
		return $block_content;
	}

	/**
	 * Filter whether core/post-content's wrapper is removed on a Kerf page.
	 *
	 * @param bool    $unwrap Whether to strip the wrapper.
	 * @param WP_Post $post   The post being rendered.
	 */
	if ( ! apply_filters( 'kerf_unwrap_post_content', true, $post ) ) {
		return $block_content;
	}

	$pattern = '#^\s*<(div|main|section|article)\b[^>]*\bclass="[^"]*\bwp-block-post-content\b[^"]*"[^>]*>(.*)</\1>\s*$#is';

	if ( preg_match( $pattern, $block_content, $m ) ) {
		return $m[2];
	}

	return $block_content;
}
add_filter( 'render_block', 'kerf_unwrap_post_content', 20, 3 );

/**
 * Render kerf/script — an imported script, where the mockup wrote it.
 *
 * The block carries only `ref`. The code comes from the imported asset list,
 * which only an administrator can change (see kerf_assets_scan()), so this block
 * can print exactly the scripts the mockup brought and nothing anyone typed into
 * a page. A ref that matches nothing renders nothing.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_script_block( $attrs ) {
	$ref = isset( $attrs['ref'] ) ? (string) $attrs['ref'] : '';

	if ( '' === $ref || is_admin() ) {
		return '';
	}

	// This page's design first (kerf_assets_design()), then the site's: a
	// page of its own still shows the site's parts nowhere, but a ref is a ref.
	$design = kerf_assets_design();
	$lists  = $design['page'] ? array( $design['assets'], kerf_assets_get() ) : array( $design['assets'] );
	foreach ( array_merge( ...$lists ) as $asset ) {
		if ( 'inplace' === ( isset( $asset['position'] ) ? $asset['position'] : '' )
			&& isset( $asset['attrs']['ref'] )
			&& hash_equals( (string) $asset['attrs']['ref'], $ref ) ) {
			// The tag's own attributes (its id, data-*), and a data block's
			// type — a JSON block, a template — which keeps it from running.
			$attributes = function_exists( 'kerf_assets_tag_attributes' ) ? kerf_assets_tag_attributes( $asset ) : array();
			if ( 'data' === ( isset( $asset['type'] ) ? $asset['type'] : '' ) ) {
				$type = isset( $asset['attrs']['type'] ) ? (string) $asset['attrs']['type'] : '';
				if ( ! kerf_mc_is_kept_data_script( $type ) ) {
					return '';
				}
				$attributes = array( 'type' => $type ) + $attributes;
			}
			// Core's tag builder: it refuses content that cannot be embedded
			// safely and runs `wp_inline_script_attributes`, so a CSP plugin
			// can add its nonce. Its trailing newline is dropped — right after
			// the tag it would be a rendered space the mockup did not have.
			return rtrim( wp_get_inline_script_tag( (string) $asset['content'], $attributes ), "\n" );
		}
	}

	return '';
}

/**
 * Render kerf/video — a bare <video>, no wrapper, no wp-block classes.
 *
 * @param array $attrs Block attributes.
 * @return string
 */
function kerf_render_video_block( $attrs ) {
	$src = isset( $attrs['src'] ) ? kerf_esc_url( $attrs['src'] ) : '';
	// A video with no source is an empty block — unless the mockup wrote it,
	// as an image (kerf_render_image_block()): `<video id="stagevid" controls>`
	// is the player a design's script gives a source when a story is picked.
	// Dropped, the script stopped at `null` before wiring anything else (scar 115).
	if ( '' === $src && empty( $attrs['customAttributes'] ) && empty( $attrs['className'] ) && empty( $attrs['anchor'] ) ) {
		return '';
	}

	$html  = '<video';
	$html .= kerf_render_class_attr( $attrs );
	$html .= kerf_render_anchor_attr( $attrs );
	$html .= kerf_render_inline_style_attr( $attrs );
	if ( '' !== $src ) {
		$html .= ' src="' . $src . '"';
	}

	foreach ( array( 'autoplay', 'loop', 'muted', 'playsinline', 'controls' ) as $flag ) {
		if ( ! empty( $attrs[ $flag ] ) ) {
			$html .= ' ' . $flag;
		}
	}

	// An autoplaying video must be muted or the browser refuses to start it, and
	// a silently-not-playing hero reads as a broken page.
	if ( ! empty( $attrs['autoplay'] ) && empty( $attrs['muted'] ) ) {
		$html .= ' muted';
	}

	if ( ! empty( $attrs['poster'] ) ) {
		$poster = kerf_esc_url( $attrs['poster'] );
		if ( '' !== $poster ) {
			$html .= ' poster="' . $poster . '"';
		}
	}

	$preload = isset( $attrs['preload'] ) ? strtolower( trim( (string) $attrs['preload'] ) ) : '';
	if ( in_array( $preload, array( 'none', 'metadata', 'auto' ), true ) ) {
		$html .= ' preload="' . $preload . '"';
	} elseif ( empty( $attrs['autoplay'] ) ) {
		$html .= ' preload="metadata"';
	}

	$html .= kerf_render_attributes(
		$attrs,
		array( 'src', 'poster', 'autoplay', 'loop', 'muted', 'playsinline', 'controls', 'preload' )
	);

	return $html . '></video>';
}
