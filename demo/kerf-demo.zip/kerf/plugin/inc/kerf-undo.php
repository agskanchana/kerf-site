<?php
/**
 * Undo the last import or update (§5.40).
 *
 * An import writes in a dozen places — the page, the header and footer parts,
 * the frame, templates for the blog and the 404, the other pages, draft pages
 * for links, the asset list, the <html> and <body> attributes, the front page,
 * the business's details — and the next feature will write in one more. So it
 * is not snapshotted from a list. While an import or an update writes, a
 * recorder notes the first value of every option, post and post meta it
 * touches, and every post it creates; undo puts them back:
 *
 *   - options and changed posts get their earlier values (meta too);
 *   - pages and posts it made go to the trash (they can come back);
 *     templates and parts it made are deleted (they were only its output);
 *   - pictures stay in the media library: content may use them by now, and
 *     the next import reuses them by their hash (§5.22).
 *
 * Only the last one is kept. Anything edited since — a page, a part, the site
 * details — is listed first, and undo asks before overwriting it.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_UNDO_OPTION = 'kerf_undo';

/**
 * Stands for "this option did not exist" — a value get_option() can only
 * return as the default it was given.
 */
const KERF_UNDO_ABSENT = "\0kerf-undo-absent";

/**
 * The recording, while one runs; null when none does.
 *
 * @param array|null|false $set A new state (null stops), or false to read.
 * @return array|null
 */
function kerf_undo_recording( $set = false ) {
	static $state = null;
	if ( false !== $set ) {
		$state = $set;
	}
	return $state;
}

/**
 * Start recording what is written.
 */
function kerf_undo_begin() {
	global $wpdb;

	kerf_undo_recording( array(
		// A post above this ID was made while recording: its meta is its own,
		// not something to restore, and it is undone by removing the post.
		'mark'    => (int) $wpdb->get_var( "SELECT MAX(ID) FROM {$wpdb->posts}" ), // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- the highest post ID at this moment, uncached on purpose.
		'options' => array(),
		'posts'   => array(),
		'meta'    => array(),
		'created' => array(),
	) );

	add_filter( 'pre_update_option', 'kerf_undo_on_update_option', 1, 3 );
	add_action( 'add_option', 'kerf_undo_note_option', 1 );
	add_action( 'delete_option', 'kerf_undo_note_option', 1 );
	add_action( 'pre_post_update', 'kerf_undo_note_post', 1 );
	add_action( 'wp_insert_post', 'kerf_undo_note_created', 1, 3 );
	add_action( 'add_attachment', 'kerf_undo_note_attachment', 1 );
	foreach ( array( 'add', 'update', 'delete' ) as $op ) {
		add_filter( $op . '_post_metadata', 'kerf_undo_note_meta', 1, 3 );
	}
}

/**
 * Stop recording, and keep what was recorded as the one thing to undo — if
 * anything was written. A dry run, a review step or a refused import writes
 * nothing, and leaves the previous import undoable.
 *
 * @param string $label What it was, for the screen: "Import into “Home”".
 * @return bool Whether an undo was kept.
 */
function kerf_undo_finish( $label ) {
	$state = kerf_undo_recording();
	kerf_undo_recording( null );

	remove_filter( 'pre_update_option', 'kerf_undo_on_update_option', 1 );
	remove_action( 'add_option', 'kerf_undo_note_option', 1 );
	remove_action( 'delete_option', 'kerf_undo_note_option', 1 );
	remove_action( 'pre_post_update', 'kerf_undo_note_post', 1 );
	remove_action( 'wp_insert_post', 'kerf_undo_note_created', 1 );
	remove_action( 'add_attachment', 'kerf_undo_note_attachment', 1 );
	foreach ( array( 'add', 'update', 'delete' ) as $op ) {
		remove_filter( $op . '_post_metadata', 'kerf_undo_note_meta', 1 );
	}

	if ( ! $state || ( ! $state['options'] && ! $state['posts'] && ! $state['meta'] && ! $state['created'] ) ) {
		return false;
	}

	// How everything looked when it was done, to tell later edits from it.
	$after = array( 'posts' => array(), 'options' => array() );
	foreach ( array_keys( $state['posts'] + $state['created'] ) as $id ) {
		$after['posts'][ $id ] = (string) get_post_field( 'post_modified_gmt', $id );
	}
	foreach ( array_keys( $state['options'] ) as $option ) {
		$after['options'][ $option ] = md5( maybe_serialize( get_option( $option, KERF_UNDO_ABSENT ) ) );
	}

	update_option( KERF_UNDO_OPTION, array(
		'label'   => (string) $label,
		'at'      => time(),
		'user'    => get_current_user_id(),
		'options' => $state['options'],
		'posts'   => $state['posts'],
		'meta'    => $state['meta'],
		'created' => $state['created'],
		'after'   => $after,
	), false );

	return true;
}

/**
 * Options the recorder leaves alone: caches, the queue, its own record, and
 * an import checked and not yet finished (its own life cycle).
 *
 * @param string $option
 * @return bool
 */
function kerf_undo_skips_option( $option ) {
	return 0 === strpos( $option, '_transient_' ) || 0 === strpos( $option, '_site_transient_' )
		|| in_array( $option, array( KERF_UNDO_OPTION, 'kerf_import_pending', 'cron', 'rewrite_rules' ), true );
}

/**
 * Note an option's value before its first change.
 *
 * @param string $option
 */
function kerf_undo_note_option( $option ) {
	$state = kerf_undo_recording();
	if ( null === $state || isset( $state['options'][ $option ] ) || kerf_undo_skips_option( (string) $option ) ) {
		return;
	}
	$value = get_option( $option, KERF_UNDO_ABSENT );
	$state['options'][ $option ] = KERF_UNDO_ABSENT === $value ? array( 'absent' => true ) : array( 'absent' => false, 'value' => $value );
	kerf_undo_recording( $state );
}

/**
 * pre_update_option: runs before every update_option(), with the value it
 * replaces still readable.
 *
 * @param mixed  $value
 * @param string $option
 * @return mixed Unchanged.
 */
function kerf_undo_on_update_option( $value, $option ) {
	kerf_undo_note_option( $option );
	return $value;
}

/**
 * Note a post's fields before its first change — a post that was there
 * before the recording began.
 *
 * @param int $post_id
 */
function kerf_undo_note_post( $post_id ) {
	$state = kerf_undo_recording();
	if ( null === $state || (int) $post_id > $state['mark'] || isset( $state['posts'][ $post_id ] ) ) {
		return;
	}
	$post = get_post( $post_id );
	if ( ! $post || 'revision' === $post->post_type ) {
		return;
	}
	$state['posts'][ $post_id ] = array(
		'post_type'    => $post->post_type,
		'post_title'   => $post->post_title,
		'post_name'    => $post->post_name,
		'post_status'  => $post->post_status,
		'post_content' => $post->post_content,
		'post_excerpt' => $post->post_excerpt,
	);
	kerf_undo_recording( $state );
}

/**
 * Note a post made while recording. (Revisions are WordPress's own record.)
 *
 * @param int     $post_id
 * @param WP_Post $post
 * @param bool    $update
 */
function kerf_undo_note_created( $post_id, $post, $update ) {
	$state = kerf_undo_recording();
	if ( null === $state || $update || (int) $post_id <= $state['mark'] || 'revision' === $post->post_type ) {
		return;
	}
	$state['created'][ $post_id ] = $post->post_type;
	kerf_undo_recording( $state );
}

/**
 * A picture added to the library — wp_insert_attachment() fires no
 * wp_insert_post. Counted, not removed (see the file's docblock).
 *
 * @param int $post_id
 */
function kerf_undo_note_attachment( $post_id ) {
	$state = kerf_undo_recording();
	if ( null === $state ) {
		return;
	}
	$state['created'][ $post_id ] = 'attachment';
	kerf_undo_recording( $state );
}

/**
 * Note a meta key's values before its first change — on a post that was there
 * before the recording began. A short-circuit filter that never short-circuits.
 *
 * @param mixed  $check
 * @param int    $object_id
 * @param string $meta_key
 * @return mixed Unchanged.
 */
function kerf_undo_note_meta( $check, $object_id, $meta_key ) {
	$state = kerf_undo_recording();
	if ( null === $state || (int) $object_id > $state['mark'] || isset( $state['meta'][ $object_id ][ $meta_key ] )
		|| in_array( $meta_key, array( '_edit_lock', '_edit_last' ), true ) ) {
		return $check;
	}
	$state['meta'][ $object_id ][ $meta_key ] = get_post_meta( $object_id, $meta_key, false );
	kerf_undo_recording( $state );
	return $check;
}

/**
 * The last import or update, if it can be undone.
 *
 * @return array|null
 */
function kerf_undo_get() {
	$undo = get_option( KERF_UNDO_OPTION, null );
	return is_array( $undo ) && isset( $undo['options'], $undo['posts'], $undo['created'] ) ? $undo : null;
}

/**
 * What changed since it was done, by name: pages and parts edited, settings
 * changed. Undo overwrites these, so they are shown before it runs.
 *
 * @param array $undo
 * @return string[]
 */
function kerf_undo_changed_since( $undo ) {
	$changed = array();
	foreach ( (array) $undo['after']['posts'] as $id => $modified ) {
		$now = get_post_field( 'post_modified_gmt', (int) $id );
		if ( '' !== (string) $now && (string) $now !== (string) $modified && 'attachment' !== get_post_type( (int) $id ) ) {
			$changed[] = kerf_undo_post_name( (int) $id );
		}
	}
	foreach ( (array) $undo['after']['options'] as $option => $hash ) {
		if ( md5( maybe_serialize( get_option( $option, KERF_UNDO_ABSENT ) ) ) !== $hash ) {
			$changed[] = kerf_undo_option_name( $option );
		}
	}
	return array_values( array_unique( $changed ) );
}

/**
 * "Page “About”", "Template part “header”".
 *
 * @param int $id
 * @return string
 */
function kerf_undo_post_name( $id ) {
	$type  = get_post_type_object( (string) get_post_type( $id ) );
	$title = get_the_title( $id );
	return sprintf(
		/* translators: 1: post type, e.g. "Page", 2: its title. */
		__( '%1$s “%2$s”', 'kerf-blocks' ),
		$type ? $type->labels->singular_name : __( 'Post', 'kerf-blocks' ),
		'' !== $title ? $title : (string) get_post_field( 'post_name', $id )
	);
}

/**
 * An option, named as the owner knows it.
 *
 * @param string $option
 * @return string
 */
function kerf_undo_option_name( $option ) {
	$names = array(
		'kerf_site_details'  => __( 'Site details', 'kerf-blocks' ),
		'kerf_shell_tokens'  => __( 'the inner pages\' style', 'kerf-blocks' ),
		'kerf_forms_to'      => __( 'where form messages go', 'kerf-blocks' ),
		'show_on_front'      => __( 'the front page setting', 'kerf-blocks' ),
		'page_on_front'      => __( 'the front page setting', 'kerf-blocks' ),
		'kerf_links_report'  => __( 'Kerf → Links', 'kerf-blocks' ),
		KERF_ASSETS_OPTION   => __( 'the stylesheets and scripts', 'kerf-blocks' ),
	);
	return isset( $names[ $option ] ) ? $names[ $option ] : sprintf(
		/* translators: %s: an option name. */
		__( 'the setting %s', 'kerf-blocks' ),
		$option
	);
}

/**
 * Put the site back as it was before the last import or update.
 *
 * @return array{done:bool,lines:string[]}
 */
function kerf_undo_run() {
	$undo = kerf_undo_get();
	if ( ! $undo ) {
		return array( 'done' => false, 'lines' => array( __( 'There is nothing to undo.', 'kerf-blocks' ) ) );
	}

	$theme    = get_stylesheet();
	$trashed  = array();
	$deleted  = 0;
	$pictures = 0;
	$restored = array();

	// What it made: pages to the trash, its own output deleted.
	foreach ( $undo['created'] as $id => $type ) {
		$id = (int) $id;
		if ( 'attachment' === $type ) {
			$pictures++;
			continue;
		}
		$post = get_post( $id );
		if ( ! $post ) {
			continue;
		}
		if ( in_array( $post->post_type, array( 'wp_template', 'wp_template_part', 'wp_global_styles' ), true ) ) {
			wp_delete_post( $id, true );
			$deleted++;
		} elseif ( 'trash' !== $post->post_status ) {
			$trashed[] = '' !== $post->post_title ? $post->post_title : $post->post_name;
			wp_trash_post( $id );
		}
		kerf_undo_flush_template_cache( $post, $theme );
	}

	// What it changed: back to how it was. wp_update_post() unslashes what
	// it is given (scar 1) — every field goes in slashed.
	foreach ( $undo['posts'] as $id => $fields ) {
		$post = get_post( (int) $id );
		if ( ! $post ) {
			continue;
		}
		unset( $fields['post_type'] );
		wp_update_post( wp_slash( array( 'ID' => (int) $id ) + $fields ) );
		$restored[] = kerf_undo_post_name( (int) $id );
		kerf_undo_flush_template_cache( $post, $theme );
	}
	foreach ( (array) $undo['meta'] as $id => $keys ) {
		if ( ! get_post( (int) $id ) ) {
			continue;
		}
		foreach ( $keys as $key => $values ) {
			delete_post_meta( (int) $id, $key );
			foreach ( (array) $values as $value ) {
				add_post_meta( (int) $id, $key, wp_slash( $value ) );
			}
		}
	}

	foreach ( $undo['options'] as $option => $was ) {
		if ( ! empty( $was['absent'] ) ) {
			delete_option( $option );
		} else {
			update_option( $option, $was['value'] );
		}
	}

	delete_option( KERF_UNDO_OPTION );

	$lines = array(
		sprintf(
			/* translators: %s: what was undone, e.g. Import into "Home". */
			__( 'Undone: %s.', 'kerf-blocks' ),
			$undo['label']
		),
	);
	if ( $restored ) {
		$lines[] = sprintf(
			/* translators: %s: list of pages and parts. */
			__( 'Put back as they were: %s.', 'kerf-blocks' ),
			implode( ', ', array_unique( $restored ) )
		);
	}
	if ( $trashed ) {
		$lines[] = sprintf(
			/* translators: %s: list of page titles. */
			__( 'Moved to the trash, where they can be restored: %s.', 'kerf-blocks' ),
			implode( ', ', $trashed )
		);
	}
	if ( $deleted ) {
		$lines[] = sprintf(
			/* translators: %d: number of templates and template parts. */
			_n( 'Removed %d template it had made.', 'Removed %d templates and template parts it had made.', $deleted, 'kerf-blocks' ),
			$deleted
		);
	}
	if ( $undo['options'] ) {
		$lines[] = __( 'The stylesheets, scripts, front page and other settings are as they were before.', 'kerf-blocks' );
	}
	if ( $pictures ) {
		$lines[] = sprintf(
			/* translators: %d: number of pictures. */
			_n( '%d picture it added stays in the media library.', '%d pictures it added stay in the media library.', $pictures, 'kerf-blocks' ),
			$pictures
		);
	}

	return array( 'done' => true, 'lines' => $lines );
}

/**
 * A template or part is cached by core under its slug; a restored or removed
 * one must not be served from the cache (see kerf_import_write_template_part()).
 *
 * @param WP_Post $post
 * @param string  $theme
 */
function kerf_undo_flush_template_cache( $post, $theme ) {
	clean_post_cache( $post->ID );
	if ( 'wp_template_part' === $post->post_type || 'wp_template' === $post->post_type ) {
		wp_cache_delete( $post->post_type . '_' . $theme . '_' . $post->post_name, 'posts' );
	}
}

/**
 * The undo card, and its form: on the import screen and the update screen.
 * Handles its own submission, and says what an undo just did.
 */
function kerf_undo_render() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return;
	}

	if ( isset( $_POST['kerf_undo'] ) ) {
		if ( ! isset( $_POST['kerf_undo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_undo_nonce'] ) ), 'kerf_undo' ) ) {
			echo kerf_ui_note( __( 'Security check failed. Reload the page and try again.', 'kerf-blocks' ), 'bad' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		} else {
			$undo    = kerf_undo_get();
			$changed = $undo ? kerf_undo_changed_since( $undo ) : array();
			if ( $changed && empty( $_POST['kerf_undo_anyway'] ) ) {
				echo kerf_ui_note( __( 'Nothing was undone: switch on "Undo anyway" to confirm that the changes made since are lost.', 'kerf-blocks' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			} else {
				$result = kerf_undo_run();
				echo '<div class="kerf-note kerf-note--' . ( $result['done'] ? 'ok' : 'info' ) . '" role="status">' . kerf_ui_icon( $result['done'] ? 'check' : 'info' ) . '<ul class="kerf-actions">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG.
				foreach ( $result['lines'] as $line ) {
					echo '<li>' . esc_html( $line ) . '</li>';
				}
				echo '</ul></div>';
				return;
			}
		}
	}

	$undo = kerf_undo_get();
	if ( ! $undo ) {
		return;
	}
	$changed = kerf_undo_changed_since( $undo );
	$made    = count( array_filter( $undo['created'], static function ( $type ) {
		return 'attachment' !== $type;
	} ) );
	$put     = count( $undo['posts'] );
	?>
	<form method="post" class="kerf-undo">
		<?php wp_nonce_field( 'kerf_undo', 'kerf_undo_nonce' ); ?>
		<?php echo kerf_ui_icon( 'undo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?>
		<div class="kerf-undo__what">
			<strong><?php echo esc_html( $undo['label'] ); ?></strong>,
			<?php
			printf(
				/* translators: %s: how long ago, e.g. "5 mins". */
				esc_html__( '%s ago', 'kerf-blocks' ),
				esc_html( human_time_diff( (int) $undo['at'] ) )
			);
			?>
			<p>
				<?php
				$what = array();
				if ( $put ) {
					/* translators: %d: number of pages and parts. */
					$what[] = sprintf( _n( 'puts back the %d page or part it changed', 'puts back the %d pages and parts it changed', $put, 'kerf-blocks' ), $put );
				}
				if ( $made ) {
					/* translators: %d: number of pages and parts. */
					$what[] = sprintf( _n( 'removes the %d it made', 'removes the %d it made', $made, 'kerf-blocks' ), $made );
				}
				$what[] = __( 'restores the settings it changed', 'kerf-blocks' );
				/* translators: %s: what undo does, e.g. "puts back the 2 pages it changed, removes the 3 it made". */
				echo esc_html( sprintf( __( 'Undo %s. Pictures it added stay in the media library.', 'kerf-blocks' ), implode( ', ', $what ) ) );
				?>
			</p>
		</div>
		<button type="submit" name="kerf_undo" value="1" class="kerf-btn kerf-btn--sm"><?php esc_html_e( 'Undo it', 'kerf-blocks' ); ?></button>
		<?php if ( $changed ) : ?>
			<div class="kerf-undo__confirm">
				<p class="kerf-help kerf-undo__changed">
					<?php esc_html_e( 'Changed since, and undone with it:', 'kerf-blocks' ); ?>
					<?php echo esc_html( implode( ', ', $changed ) ); ?>
				</p>
				<label class="kerf-switch">
					<input type="checkbox" name="kerf_undo_anyway" value="1">
					<span class="kerf-switch__text"><strong><?php esc_html_e( 'Undo anyway', 'kerf-blocks' ); ?></strong><span><?php esc_html_e( 'Those changes are lost.', 'kerf-blocks' ); ?></span></span>
				</label>
			</div>
		<?php endif; ?>
	</form>
	<?php
}
