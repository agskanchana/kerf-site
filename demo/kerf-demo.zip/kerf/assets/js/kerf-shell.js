/**
 * Keep the title band clear of a header that floats over the page.
 *
 * Designers float the header over the home page's hero — `position: absolute`
 * or `fixed`, transparent, light links — and every other page inherits that
 * header without the hero under it. The shell's band takes its place: this
 * measures how far the floating header reaches past where the shell starts and
 * hands it to the band as `--kerf-header-overlap`, and, when the floating bar
 * is see-through with light links, marks the shell `data-kerf-overlap` so the
 * band turns dark enough to read them. The server already printed both from
 * the home page's measurement (the Kerf plugin's inc/kerf-shell.php), so this only corrects
 * them — after fonts load, on resize, and for sites never measured at all.
 *
 * The floating bar is not always the header: cozastore keeps a 40px top bar in
 * the flow and fixes its menu under it, three levels down. So the search goes
 * a few levels into whatever sits before the shell, and the overlap is counted
 * from the shell's top, not the page's.
 *
 * Deliberately narrow: only what sits before the shell, no lower than where it
 * starts, wide and not too tall. An off-canvas menu, a preloader, a
 * back-to-top button and a cookie bar are all absolute or fixed too, and none
 * of them is a header.
 *
 * @package kerf
 */

( function () {
	'use strict';

	var shell = document.querySelector( '.kerf-shell' );
	if ( ! shell ) {
		return;
	}

	function candidates() {
		var list = [];
		function collect( node, depth ) {
			list.push( node );
			if ( depth < 3 ) {
				for ( var i = 0; i < node.children.length && i < 24 && list.length < 400; i++ ) {
					collect( node.children[ i ], depth + 1 );
				}
			}
		}
		for ( var node = shell.previousElementSibling; node && list.length < 400; node = node.previousElementSibling ) {
			collect( node, 0 );
		}
		return list;
	}

	function rgb( color ) {
		var m = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/.exec( color || '' );
		if ( ! m ) {
			return null;
		}
		var alpha = undefined === m[ 4 ] ? 1 : ( '%' === m[ 4 ].slice( -1 ) ? parseFloat( m[ 4 ] ) / 100 : parseFloat( m[ 4 ] ) );
		return [ +m[ 1 ], +m[ 2 ], +m[ 3 ], alpha ];
	}

	function luminance( c ) {
		var ch = function ( v ) {
			v /= 255;
			return v <= 0.03928 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 );
		};
		return 0.2126 * ch( c[ 0 ] ) + 0.7152 * ch( c[ 1 ] ) + 0.0722 * ch( c[ 2 ] );
	}

	// See-through, with the links most of it carries light: designed over a
	// dark hero, so the band has to be dark. Most of the links, not the first
	// — that one is usually "Home" in the active colour.
	function needsDarkBand( bar ) {
		var style = window.getComputedStyle( bar );
		var bg = rgb( style.backgroundColor );
		if ( ( bg && bg[ 3 ] >= 0.1 ) || 'none' !== style.backgroundImage ) {
			return false;
		}
		var light = 0;
		var dark = 0;
		var links = bar.querySelectorAll( 'a' );
		for ( var i = 0; i < links.length && i < 80; i++ ) {
			var visible = links[ i ].checkVisibility ?
				links[ i ].checkVisibility( { opacityProperty: true, visibilityProperty: true } ) :
				links[ i ].offsetWidth > 0;
			var color = visible && links[ i ].textContent.trim() ? rgb( window.getComputedStyle( links[ i ] ).color ) : null;
			if ( color ) {
				if ( luminance( color ) > 0.55 ) {
					light++;
				} else {
					dark++;
				}
			}
		}
		return light > dark;
	}

	function measure() {
		// A header that changes when the page scrolls (fixed to 0, solid
		// background) measures differently; the band only matters at the top.
		if ( window.pageYOffset > 4 ) {
			return;
		}

		var viewWidth = document.documentElement.clientWidth;
		var viewHeight = window.innerHeight;
		var shellTop = shell.getBoundingClientRect().top + window.pageYOffset;
		var reach = shellTop;
		var bar = null;

		candidates().forEach( function ( el ) {
			var style = window.getComputedStyle( el );
			if ( 'absolute' !== style.position && 'fixed' !== style.position ) {
				return;
			}
			if ( 'none' === style.display || 'hidden' === style.visibility || 0 === parseFloat( style.opacity ) ) {
				return;
			}

			var rect = el.getBoundingClientRect();
			var top = rect.top + ( 'fixed' === style.position ? 0 : window.pageYOffset );

			if ( top > shellTop + 8 || rect.height < 24 || rect.height > viewHeight * 0.45 || rect.width < viewWidth * 0.6 ) {
				return;
			}

			if ( top + rect.height > reach ) {
				reach = top + rect.height;
				bar = el;
			}
		} );

		shell.style.setProperty( '--kerf-header-overlap', Math.round( reach - shellTop ) + 'px' );

		if ( bar && needsDarkBand( bar ) ) {
			shell.setAttribute( 'data-kerf-overlap', '' );
		} else {
			shell.removeAttribute( 'data-kerf-overlap' );
		}
	}

	var timer = 0;
	function later() {
		window.clearTimeout( timer );
		timer = window.setTimeout( measure, 120 );
	}

	measure();
	window.addEventListener( 'load', measure );
	window.addEventListener( 'resize', later );
	if ( document.fonts && document.fonts.ready ) {
		document.fonts.ready.then( measure );
	}
}() );
