<?php
/**
 * Kerf theme bootstrap.
 *
 * Kerf is one product since 1.1.0 (CLAUDE.md §5.49): this theme, the engine
 * in plugin/ (the converter, the blocks, the design's assets, the document
 * shell) and Kerf Pro in pro/, both loaded at the end of this file. The
 * templates and parts are still WordPress' own blocks, so before a design is
 * imported the theme is a plain, tidy blog in its own look. This file declares
 * what the theme supports, loads its two stylesheets where they belong, and
 * loads the engine and Pro.
 *
 * Function names are shared with the engine's global namespace: everything
 * here is kerf_setup() or kerf_theme_*().
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Declare theme support.
 */
function kerf_setup() {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'custom-logo', array(
		'height'      => 100,
		'width'       => 400,
		'flex-height' => true,
		'flex-width'  => true,
	) );
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script',
	) );

	load_theme_textdomain( 'kerf', get_template_directory() . '/languages' );

	// The Site Editor draws the default style as the page does: the shell's
	// sheet always (it touches nothing outside `.kerf-shell`), the base only
	// while no design owns the look.
	$editor = array( 'assets/css/kerf-shell.css' );
	if ( kerf_theme_base_styles() ) {
		array_unshift( $editor, 'assets/css/kerf-base.css' );
	}
	add_editor_style( $editor );
}
add_action( 'after_setup_theme', 'kerf_setup' );

/**
 * Does the theme's own base look apply — no design imported yet?
 *
 * @return bool
 */
function kerf_theme_base_styles() {
	/**
	 * Filter whether the Kerf theme's own base look (assets/css/kerf-base.css)
	 * loads. The engine returns false once a design is imported: from then on
	 * the design's CSS owns every pixel.
	 *
	 * @param bool $load Whether to load the base look.
	 */
	return (bool) apply_filters( 'kerf_theme_base_styles', true );
}

/**
 * The version a theme file is served with: its modification time, as the
 * plugin's files are — a changed file is a changed URL.
 *
 * @param string $rel Path relative to the theme.
 * @return string|false
 */
function kerf_theme_file_version( $rel ) {
	$path = get_theme_file_path( $rel );
	return file_exists( $path ) ? (string) filemtime( $path ) : false;
}

/**
 * Register the shell's sheet and script.
 *
 * Registered early because a block template renders before `wp_head`: a shell
 * found while it renders enqueues them by name (kerf_theme_shell_assets()),
 * and the plugin adds its measured tokens to the same handle.
 */
function kerf_theme_register_shell() {
	if ( is_admin() ) {
		return;
	}
	wp_register_style( 'kerf-shell', get_theme_file_uri( 'assets/css/kerf-shell.css' ), array(), kerf_theme_file_version( 'assets/css/kerf-shell.css' ) );
	wp_register_script( 'kerf-shell', get_theme_file_uri( 'assets/js/kerf-shell.js' ), array(), kerf_theme_file_version( 'assets/js/kerf-shell.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
}
add_action( 'init', 'kerf_theme_register_shell' );

/**
 * Load the base look while no design owns the page.
 */
function kerf_theme_base_assets() {
	if ( kerf_theme_base_styles() ) {
		wp_enqueue_style( 'kerf-base', get_theme_file_uri( 'assets/css/kerf-base.css' ), array(), kerf_theme_file_version( 'assets/css/kerf-base.css' ) );
	}
}
add_action( 'wp_enqueue_scripts', 'kerf_theme_base_assets' );

/**
 * Load the shell's sheet and script on a page that renders one — keyed on the
 * class, so a template rebuilt in the Site Editor keeps its style while it
 * keeps the shell.
 *
 * @param string $block_content
 * @param array  $block
 * @return string
 */
function kerf_theme_shell_assets( $block_content, $block ) {
	$class = isset( $block['attrs']['className'] ) ? (string) $block['attrs']['className'] : '';
	if ( '' !== $class && preg_match( '/(?:^|\s)kerf-shell(?:\s|$)/', $class ) && ! is_admin() ) {
		wp_enqueue_style( 'kerf-shell' );
		wp_enqueue_script( 'kerf-shell' );
	}
	return $block_content;
}
add_filter( 'render_block', 'kerf_theme_shell_assets', 10, 2 );

/**
 * Keep classic nextpage content navigable in a block template.
 *
 * Core handles the Page Break block itself, but classic nextpage markers need
 * links here. The singular template's loop has already set the page globals;
 * checking the block's post keeps a nested query from borrowing those links.
 *
 * @param string   $block_content Rendered post content.
 * @param array    $block         Parsed post-content block.
 * @param WP_Block $instance      Block instance with the post being rendered.
 * @return string
 */
function kerf_theme_page_links( $block_content, $block, $instance ) {
	if ( ! is_singular()
		|| empty( $GLOBALS['multipage'] )
		|| empty( $instance->context['postId'] )
		|| (int) $instance->context['postId'] !== get_queried_object_id()
		|| has_block( 'core/nextpage' )
	) {
		return $block_content;
	}

	return $block_content . wp_link_pages( array(
		'before'         => '<nav class="kerf-page-links" aria-label="' . esc_attr__( 'Post pages', 'kerf' ) . '"><span class="kerf-page-links__label">' . esc_html__( 'Pages:', 'kerf' ) . '</span>',
		'after'          => '</nav>',
		'next_or_number' => 'number',
		'echo'           => 0,
	) );
}
add_filter( 'render_block_core/post-content', 'kerf_theme_page_links', 10, 3 );

/**
 * Say so when the old Kerf Blocks or Kerf Pro plugin is still active.
 *
 * Until 1.1.0 they were plugins beside the theme; the theme now carries both.
 * While either plugin is active it has loaded first and defined the engine,
 * so the theme loads neither copy (two copies would declare every function
 * twice) and asks for the plugins to be deactivated. Nothing is lost:
 * options, blocks and pages are the same.
 */
function kerf_theme_old_plugins_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		// Kerf Pro first: WordPress will not deactivate a plugin another active
		// plugin requires, and the old Kerf Pro requires Kerf Blocks.
		esc_html__( 'The Kerf theme now includes Kerf Blocks and Kerf Pro. Under Plugins, deactivate Kerf Pro, then Kerf Blocks, and delete both: your design, pages and settings stay as they are.', 'kerf' )
	);
}

// The live demo's copy: Kerf runs only in WordPress Playground (kerf-demo.php).
require_once get_template_directory() . '/kerf-demo.php';
if ( ! kerf_demo_allowed() ) {
	add_action( 'admin_notices', 'kerf_demo_notice' );
	return;
}

if ( defined( 'KERF_VERSION' ) || defined( 'KERF_PRO_VERSION' ) ) {
	add_action( 'admin_notices', 'kerf_theme_old_plugins_notice' );
} else {
	require_once get_template_directory() . '/plugin/kerf.php';
	/**
	 * Filter whether Kerf Pro loads with the theme. The test suite answers
	 * false to run the engine alone (KERF_TEST_FREE).
	 *
	 * @param bool $load Whether to load Kerf Pro.
	 */
	if ( apply_filters( 'kerf_theme_load_pro', true ) ) {
		require_once get_template_directory() . '/pro/kerf-pro.php';
	}
}
