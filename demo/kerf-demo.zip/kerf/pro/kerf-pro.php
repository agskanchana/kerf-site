<?php
/**
 * Kerf Pro: the tools for building sites for a living — update a site from a
 * newer version of its design, client mode, every page of a design, live
 * content in the design's own cards, AI, and more.
 *
 * Loaded by the theme after the engine (`plugin/kerf.php`, CLAUDE.md §5.49);
 * it was an add-on plugin until 1.1.0 and carries no plugin header now. The
 * engine holds everything that draws a site; this adds the screens, panels,
 * import steps and converter options — so whatever Pro made keeps showing
 * when a licence lapses. Pro's entry points ask kerf_pro_licensed(); nothing
 * that renders a page does.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'KERF_PRO_VERSION', '1.1.1' );
define( 'KERF_PRO_FILE', __FILE__ );
define( 'KERF_PRO_DIR', trailingslashit( __DIR__ ) );
define( 'KERF_PRO_URL', trailingslashit( get_template_directory_uri() ) . 'pro/' );

/**
 * The engine version Pro needs. Since 1.1.0 they ship in one theme with one
 * version, and release.php writes this with the others; it still guards an
 * old Kerf Blocks plugin left active beside this code. Before 1.1.0 it named
 * the free plugin whose functions Pro called — 1.0.1's: who may
 * import or update a design (kerf_user_can_import()) and the staged folder a
 * URL is in, old or new (kerf_assets_storage_for_url()). Before them 0.10.0's:
 * a stylesheet as the editor takes it (kerf_assets_editor_entry()), and what
 * was added to a page kept through a new asset list
 * (kerf_assets_carry_added()). Before them, 0.8.0's hooks: the Background
 * picture panel's `kerf.backgroundPanel.element` filter, the rules for each
 * page's featured image, the forms' `kerf_form_kept` and `kerf_form_mailed`.
 */
const KERF_PRO_NEEDS = '1.1.1';

/**
 * Absolute path to a file in the add-on.
 *
 * @param string $rel Path relative to the add-on's root.
 * @return string
 */
function kerf_pro_path( $rel = '' ) {
	return KERF_PRO_DIR . ltrim( (string) $rel, '/' );
}

/**
 * URL of a file in the add-on.
 *
 * @param string $rel Path relative to the add-on's root.
 * @return string
 */
function kerf_pro_url( $rel = '' ) {
	return KERF_PRO_URL . ltrim( (string) $rel, '/' );
}

/**
 * Load Pro's modules, once the engine has loaded — or not at all, with a
 * notice, when it is missing or too old for the functions they call.
 */
function kerf_pro_boot() {
	static $booted = false;
	if ( $booted ) {
		return;
	}
	$booted = true;

	if ( ! defined( 'KERF_VERSION' ) || version_compare( KERF_VERSION, KERF_PRO_NEEDS, '<' ) ) {
		add_action( 'admin_notices', 'kerf_pro_needs_notice' );
		return;
	}

	// Pro keeps its own text domain, loaded from its languages/ folder.
	load_textdomain( 'kerf-pro', KERF_PRO_DIR . 'languages/kerf-pro-' . determine_locale() . '.mo' );

	require_once KERF_PRO_DIR . 'inc/kerf-pro-license.php';
	// Update from a newer version of the design (§5.28), and its check of the
	// owner's background pictures (§5.41).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-sync.php';
	require_once KERF_PRO_DIR . 'inc/kerf-pro-sync-backgrounds.php';
	// Client mode: the design locked for Editors and Authors (§5.38).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-client-mode.php';
	// "Show my latest posts here": a section of sample cards made live (§5.42).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-latest-posts.php';
	// A background picture replaced everywhere its style draws it (§5.41).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-backgrounds.php';
	// What one page loads of its own, added in WordPress: a pasted section's
	// styles, the CSS AI wrote for a page.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-page-assets.php';
	// Convert HTML in the editor's Kerf sidebar: insert, or replace a block.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-convert.php';
	// Form entries: every message the design's forms send, kept (§5.35).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-forms.php';
	// The business's details: found at import, changed once (§5.36).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-site-details.php';
	// Posts, comments and their details where the design marks them (§5.25).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-dynamic.php';
	// Every page of a design: the other pages, and what each becomes, asked in
	// the import's check step (§5.31).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-pages.php';
	// A page with a design of its own (§5.39).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-own-page.php';
	// The blog and the other undrawn pages in the design's look: the
	// measurement, Kerf → Inner pages and its prompts (§5.24).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-inner-pages.php';
	// AI, with the customer's own key: the one way out to a model, and who may
	// use it (§5.46).
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai.php';
	// An import's report in plain words, and the message for the AI tool that
	// made the design.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-explain.php';
	// A designer's blog, post or 404 page marked for WordPress in the import's
	// check step.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-prepare.php';
	// AI work longer than a web request, done a step at a time.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-jobs.php';
	// A whole design written from the owner's brief and pictures, staged for
	// the import's check step.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-design.php';
	// Kerf → Build with AI: the screen on the design generator.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-build.php';
	// A page made in the imported design: in the editor (Kerf → Make a page
	// opens it there), or as a draft from the command line.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-page.php';
	// A page's words from Word, Google Docs, a web page or Markdown, as Markdown.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-words.php';
	// A page, or one of its sections, changed as the owner asks.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-edit.php';
	// Kerf AI in the editor: its sidebar, its window, a block's button.
	require_once KERF_PRO_DIR . 'inc/kerf-pro-ai-editor.php';
}
// The theme requires this file after the engine, once plugins have loaded.
kerf_pro_boot();

/**
 * Say why nothing of Pro is there.
 */
function kerf_pro_needs_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: %s: the Kerf engine version Kerf Pro needs. */
				__( 'Kerf Pro needs the Kerf engine, version %s or later; the Kerf theme ships both together.', 'kerf-pro' ),
				KERF_PRO_NEEDS
			)
		)
	);
}
