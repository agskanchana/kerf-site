/**
 * Measure the home page's style, the way a visitor sees it (§5.24).
 *
 * Kerf's default inner pages take their fonts and colours from the home page
 * (the free plugin's inc/kerf-shell.php). Reading them from the stylesheets
 * does not work: on gymlife the CSS says links are Bootstrap's blue #007bff
 * and the page is white, and what a visitor sees is an orange accent on dark
 * sections; on cozastore the CSS says Arial and the text is Poppins, set
 * through classes. So the rendered page is measured instead — computed
 * styles, weighted by how much text or area each value covers — in the
 * same-origin frame the free plugin's kerf-design-read.js loads, after an
 * import or when asked (Kerf → Inner pages). This gives that reader its
 * `measure`.
 *
 * The measurement is data. Everything that decides something from it —
 * which colour the title band is, whether the header floats — is in PHP,
 * where it is tested (kerf_shell_tokens_from_measurement()).
 *
 * The small pure functions below are named on purpose: tests/js/design-read
 * .test.js lifts them out of this file by name.
 *
 * @package kerf-pro
 */

( function () {
	'use strict';

	var api = window.kerfDesignRead;
	if ( ! api ) {
		return;
	}

	/**
	 * A CSS colour → [r, g, b, a], or null. Handles what getComputedStyle
	 * returns (rgb/rgba) and hex.
	 *
	 * @param {string} value
	 * @return {number[]|null}
	 */
	function parseColor( value ) {
		var v = String( value || '' ).trim().toLowerCase();
		var m = v.match( /^rgba?\(([^)]*)\)$/ );
		if ( m ) {
			var p = m[ 1 ].split( /[\s,\/]+/ ).filter( Boolean ).map( parseFloat );
			if ( p.length < 3 ) {
				return null;
			}
			return [ p[ 0 ], p[ 1 ], p[ 2 ], p.length > 3 ? p[ 3 ] : 1 ];
		}
		m = v.match( /^#([0-9a-f]{3,8})$/ );
		if ( m ) {
			var h = m[ 1 ];
			if ( h.length < 6 ) {
				h = h.split( '' ).map( function ( c ) {
					return c + c;
				} ).join( '' );
			}
			return [
				parseInt( h.slice( 0, 2 ), 16 ),
				parseInt( h.slice( 2, 4 ), 16 ),
				parseInt( h.slice( 4, 6 ), 16 ),
				h.length >= 8 ? parseInt( h.slice( 6, 8 ), 16 ) / 255 : 1
			];
		}
		if ( 'transparent' === v ) {
			return [ 0, 0, 0, 0 ];
		}
		return null;
	}

	/**
	 * Is the colour opaque enough to count as a background?
	 *
	 * @param {string} value
	 * @return {boolean}
	 */
	function isOpaque( value ) {
		var c = parseColor( value );
		return !! c && c[ 3 ] > 0.5;
	}

	/**
	 * How colourful: the spread between the strongest and weakest channel.
	 * Greys, black and white score near zero.
	 *
	 * @param {string} value
	 * @return {number} 0–255
	 */
	function saturation( value ) {
		var c = parseColor( value );
		if ( ! c || c[ 3 ] < 0.5 ) {
			return 0;
		}
		return Math.max( c[ 0 ], c[ 1 ], c[ 2 ] ) - Math.min( c[ 0 ], c[ 1 ], c[ 2 ] );
	}

	/**
	 * Relative luminance, 0–1.
	 *
	 * @param {string} value
	 * @return {number}
	 */
	function luminance( value ) {
		var c = parseColor( value );
		if ( ! c ) {
			return 0.5;
		}
		var ch = c.slice( 0, 3 ).map( function ( x ) {
			x /= 255;
			return x <= 0.03928 ? x / 12.92 : Math.pow( ( x + 0.055 ) / 1.055, 2.4 );
		} );
		return 0.2126 * ch[ 0 ] + 0.7152 * ch[ 1 ] + 0.0722 * ch[ 2 ];
	}

	/**
	 * The colours a browser or a framework uses when the designer set none —
	 * a link that is this blue says nothing about the design.
	 *
	 * @param {string} value
	 * @return {boolean}
	 */
	function isDefaultLinkBlue( value ) {
		var c = parseColor( value );
		if ( ! c ) {
			return false;
		}
		var key = c.slice( 0, 3 ).map( Math.round ).join( ',' );
		// UA default, Bootstrap 4 #007bff, Bootstrap 5 #0d6efd, and their
		// hover shades.
		return -1 !== [ '0,0,238', '0,123,255', '13,110,253', '0,86,179', '10,88,202' ].indexOf( key );
	}

	/**
	 * A weighted tally: add(key, weight), then top(n).
	 *
	 * @return {{add: Function, top: Function}}
	 */
	function tally() {
		var map = Object.create( null );
		return {
			add: function ( key, weight ) {
				if ( ! key ) {
					return;
				}
				map[ key ] = ( map[ key ] || 0 ) + ( weight || 1 );
			},
			top: function ( n ) {
				return Object.keys( map ).sort( function ( a, b ) {
					return map[ b ] - map[ a ];
				} ).slice( 0, n || 1 );
			}
		};
	}

	/**
	 * A computed font-family, trimmed of the emoji and system fallbacks
	 * frameworks append: `"Roboto Slab", -apple-system, …, "Noto Color Emoji"`
	 * becomes `"Roboto Slab", serif`-like — the family and one generic.
	 *
	 * @param {string} stack
	 * @return {string}
	 */
	function cleanFont( stack ) {
		var families = String( stack || '' ).split( ',' ).map( function ( f ) {
			return f.trim();
		} ).filter( Boolean );
		var generics = [ 'serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui' ];
		var kept = [];
		var generic = '';

		families.forEach( function ( family ) {
			var bare = family.replace( /^["']|["']$/g, '' ).toLowerCase();
			if ( -1 !== generics.indexOf( bare ) ) {
				generic = generic || bare;
				return;
			}
			if ( /emoji|symbol|^-apple-system$|^blinkmacsystemfont$/.test( bare ) ) {
				return;
			}
			if ( kept.length < 2 ) {
				kept.push( family );
			}
		} );

		if ( generic ) {
			kept.push( generic );
		}
		return kept.join( ', ' );
	}

	/**
	 * Measure a rendered page.
	 *
	 * @param {Document} doc
	 * @param {Window}   win
	 * @return {Object}
	 */
	function measure( doc, win ) {
		var cs = function ( el ) {
			return win.getComputedStyle( el );
		};
		var viewWidth = doc.documentElement.clientWidth || win.innerWidth;
		var viewHeight = win.innerHeight;

		// Laid out and not hidden. Opacity is deliberately ignored: reveal-on-
		// scroll content rests at opacity 0 until a visitor scrolls to it, and
		// it is exactly the content whose style matters.
		function shown( el ) {
			var r = el.getBoundingClientRect();
			var s = cs( el );
			return r.width > 0 && r.height > 0 && 'hidden' !== s.visibility && 'none' !== s.display;
		}

		function backgroundBehind( el ) {
			for ( var e = el; e && 1 === e.nodeType; e = e.parentElement ) {
				var s = cs( e );
				if ( isOpaque( s.backgroundColor ) ) {
					return s.backgroundColor;
				}
				if ( 'none' !== s.backgroundImage && ! /gradient/.test( s.backgroundImage ) ) {
					return 'image';
				}
				// A see-through tint is an overlay, and an overlay is there for
				// a picture behind it — often an <img> beside it, not above it,
				// which walking up the tree never meets (plumberz's hero slides:
				// rgba(0,0,0,.4) over a photograph).
				var tint = parseColor( s.backgroundColor );
				if ( tint && tint[ 3 ] >= 0.15 ) {
					return 'image';
				}
			}
			var root = cs( doc.documentElement ).backgroundColor;
			return isOpaque( root ) ? root : 'rgb(255, 255, 255)';
		}

		// The header: whatever holds the navigation at the top of the page.
		function findHeader() {
			var found = null;
			var candidates = doc.querySelectorAll( 'header, nav, [class*="header"], [class*="navbar"], [id*="header"]' );
			for ( var i = 0; i < candidates.length && ! found; i++ ) {
				var el = candidates[ i ];
				if ( ! shown( el ) ) {
					continue;
				}
				var r = el.getBoundingClientRect();
				if ( r.top + win.pageYOffset <= 8 && r.width >= viewWidth * 0.6 && r.height >= 24 && r.height <= viewHeight * 0.5 ) {
					found = el;
				}
			}
			if ( ! found ) {
				return null;
			}
			// A static wrapper round a floating bar: the bar decides.
			while ( found.parentElement && found.parentElement !== doc.body && 'static' === cs( found ).position ) {
				var parent = found.parentElement;
				var pr = parent.getBoundingClientRect();
				if ( pr.top + win.pageYOffset > 8 || pr.height > viewHeight * 0.5 ) {
					break;
				}
				found = parent;
			}
			return found;
		}

		function findFooter() {
			var footers = doc.querySelectorAll( 'footer, [class*="footer"], [id*="footer"]' );
			for ( var i = footers.length - 1; i >= 0; i-- ) {
				if ( shown( footers[ i ] ) && footers[ i ].getBoundingClientRect().height > 40 ) {
					return footers[ i ];
				}
			}
			return null;
		}

		var header = findHeader();
		var footer = findFooter();
		function chrome( el ) {
			return ( header && header.contains( el ) ) || ( footer && footer.contains( el ) );
		}

		// ── Body text: what most of the words are set in, and sit on.
		//
		// Two passes. First the SURFACE — the background behind most of the
		// words. Then text and heading colours from what sits on that surface
		// only: plumberz alternates white sections with photo-backed and dark
		// ones, and counted together its white hero and fact counters outweighed
		// the navy text on white that the rest of the site is made of.
		var surface = tally();
		var samples = [];
		var walker = doc.createTreeWalker( doc.body, 4 /* NodeFilter.SHOW_TEXT */ );
		var node;
		while ( ( node = walker.nextNode() ) ) {
			var text = node.textContent.replace( /\s+/g, ' ' ).trim();
			var parent = node.parentElement;
			if ( text.length < 20 || ! parent || ! shown( parent ) || chrome( parent ) ) {
				continue;
			}
			// A carousel's clones repeat its slides; counted, every slide's
			// caption would weigh five or six times what it does on the page.
			if ( parent.closest( 'h1, h2, h3, h4, h5, h6, a, button, label, nav, script, style, noscript, template, select, option, [aria-hidden="true"], .cloned, .slick-cloned, .swiper-slide-duplicate' ) ) {
				continue;
			}
			var ps = cs( parent );
			var bg = backgroundBehind( parent );
			surface.add( bg, text.length );
			samples.push( { bg: bg, weight: text.length, font: ps.fontFamily, color: ps.color } );
		}

		var mainSurface = surface.top( 3 ).filter( function ( s ) {
			return 'image' !== s;
		} )[ 0 ] || '';

		function onSurface( list ) {
			var mine = list.filter( function ( s ) {
				return s.bg === mainSurface;
			} );
			return mine.length ? mine : list;
		}

		var bodyFont = tally();
		var bodyColor = tally();
		onSurface( samples ).forEach( function ( s ) {
			bodyFont.add( s.font, s.weight );
			bodyColor.add( s.color, s.weight );
		} );

		// ── Headings: counted per heading, by level — not by length. On
		// Start Bootstrap's Agency the long italic h3 subheadings outweighed the
		// short h2 section titles by characters, and the page's heading font
		// came out as the subheadings'. A headline on a photograph is white for
		// the photograph's sake and is not counted at all.
		var headings = [];
		Array.prototype.forEach.call( doc.querySelectorAll( 'h1, h2, h3' ), function ( h ) {
			if ( ! shown( h ) || chrome( h ) || ! h.textContent.trim() ) {
				return;
			}
			var bg = backgroundBehind( h );
			if ( 'image' === bg ) {
				return;
			}
			var s = cs( h );
			headings.push( { bg: bg, weight: 'H1' === h.tagName ? 6 : ( 'H2' === h.tagName ? 3 : 1 ), font: s.fontFamily, color: s.color } );
		} );

		var headFont = tally();
		var headColor = tally();
		onSurface( headings ).forEach( function ( s ) {
			headFont.add( s.font, s.weight );
			headColor.add( s.color, s.weight );
		} );

		// ── Accent: the colour that is not grey, where designers put brand.
		var accent = tally();
		Array.prototype.forEach.call( doc.querySelectorAll( 'a, button, input[type="submit"], [class*="btn"], [class*="button"], i, svg, [class*="icon"], [class*="badge"], [class*="tag"]' ), function ( el ) {
			if ( ! shown( el ) ) {
				return;
			}
			var s = cs( el );
			var r = el.getBoundingClientRect();
			if ( isOpaque( s.backgroundColor ) && saturation( s.backgroundColor ) > 60 ) {
				// Filled buttons are the strongest statement, scaled by size.
				accent.add( s.backgroundColor, 4 + Math.min( 6, ( r.width * r.height ) / 8000 ) );
			}
			if ( saturation( s.color ) > 60 ) {
				// A framework's default link blue is what a designer did NOT
				// choose; it only wins when nothing else is colourful.
				accent.add( s.color, isDefaultLinkBlue( s.color ) ? 0.02 : 1 );
			}
			if ( saturation( s.borderTopColor ) > 60 && parseFloat( s.borderTopWidth ) > 0 ) {
				accent.add( s.borderTopColor, 1 );
			}
		} );

		// ── The designer's primary button, outside the header and footer.
		var button = null;
		var buttons = doc.querySelectorAll( 'a[class*="btn"], a[class*="button"], button, .btn, input[type="submit"]' );
		for ( var b = 0; b < buttons.length && ! button; b++ ) {
			var bs = cs( buttons[ b ] );
			if ( shown( buttons[ b ] ) && ! chrome( buttons[ b ] ) && isOpaque( bs.backgroundColor ) && saturation( bs.backgroundColor ) > 60 ) {
				button = {
					bg: bs.backgroundColor,
					color: bs.color,
					radius: bs.borderTopLeftRadius,
					transform: bs.textTransform
				};
			}
		}

		// ── Content width: the usual width of a centred container.
		var widths = [];
		Array.prototype.forEach.call( doc.querySelectorAll( '[class*="container"], [class*="wrapper"], [class*="inner"], main > *, section > *' ), function ( el ) {
			var r = el.getBoundingClientRect();
			if ( r.width < 480 || r.width > viewWidth - 10 || ! shown( el ) ) {
				return;
			}
			if ( Math.abs( r.left - ( viewWidth - r.right ) ) <= 4 ) {
				widths.push( Math.round( r.width ) );
			}
		} );
		widths.sort( function ( x, y ) {
			return x - y;
		} );

		// ── The hero under the header: the band can wear it.
		var heroImage = '';
		var headerBottom = header ? header.getBoundingClientRect().bottom : 0;
		var probe = doc.elementFromPoint( viewWidth / 2, Math.min( viewHeight - 10, headerBottom + 80 ) );
		for ( var e = probe; e && 1 === e.nodeType && ! heroImage; e = e.parentElement ) {
			var es = cs( e );
			var url = es.backgroundImage.match( /url\(["']?([^"')]+)["']?\)/ );
			if ( url ) {
				heroImage = url[ 1 ];
			} else if ( 'IMG' === e.tagName && e.getBoundingClientRect().width >= viewWidth * 0.6 ) {
				heroImage = e.currentSrc || e.src;
			}
		}

		// ── What floats over the top of the page, and how far past where the
		// page starts. The header itself when it is absolute or fixed
		// (gymlife), or a bar inside a header that stays in the flow:
		// cozastore keeps a 40px top bar in the flow and fixes the menu under
		// it, so its pages start at 40 and the menu covers them to 124. Only
		// the floating part needs clearing — the flow already pushed the page
		// down past the rest. Opacity counts here, unlike for text: a dropdown
		// resting at opacity 0 floats too, and is not a header.
		var bar = null;
		var overlap = 0;
		if ( header ) {
			var floats = /^(absolute|fixed)$/.test( cs( header ).position );
			var flowBottom = floats ? 0 : header.getBoundingClientRect().bottom + win.pageYOffset;
			var reach = flowBottom;
			var inside = [ header ].concat( Array.prototype.slice.call( header.querySelectorAll( '*' ), 0, 400 ) );
			inside.forEach( function ( el ) {
				var s = cs( el );
				if ( ! /^(absolute|fixed)$/.test( s.position ) || ! shown( el ) || 0 === parseFloat( s.opacity ) ) {
					return;
				}
				var r = el.getBoundingClientRect();
				var top = r.top + ( 'fixed' === s.position ? 0 : win.pageYOffset );
				if ( top > flowBottom + 8 || r.width < viewWidth * 0.6 || r.height < 24 || r.height > viewHeight * 0.45 ) {
					return;
				}
				if ( top + r.height > reach ) {
					reach = top + r.height;
					bar = el;
				}
			} );
			overlap = Math.round( reach - flowBottom );
		}

		// The colour most of the header's links are — not the first one's,
		// which is usually "Home" in the active colour. Links inside a closed
		// dropdown do not count: they are not what floats over the band.
		var linkColor = tally();
		var linkRoot = bar || header;
		if ( linkRoot ) {
			var links = linkRoot.querySelectorAll( 'a' );
			for ( var l = 0; l < links.length && l < 80; l++ ) {
				var visible = links[ l ].checkVisibility ?
					links[ l ].checkVisibility( { opacityProperty: true, visibilityProperty: true } ) :
					shown( links[ l ] );
				if ( visible && links[ l ].textContent.trim() ) {
					linkColor.add( cs( links[ l ] ).color, 1 );
				}
			}
		}

		var hs = header ? cs( header ) : null;
		var bodyBg = cs( doc.body ).backgroundColor;

		return {
			version: 1,
			viewport: [ viewWidth, viewHeight ],
			fontBody: cleanFont( bodyFont.top()[ 0 ] || cs( doc.body ).fontFamily ),
			fontHeading: cleanFont( headFont.top()[ 0 ] || '' ),
			text: bodyColor.top()[ 0 ] || cs( doc.body ).color,
			heading: headColor.top()[ 0 ] || '',
			surface: mainSurface || surface.top()[ 0 ] || '',
			bodyBg: isOpaque( bodyBg ) ? bodyBg : cs( doc.documentElement ).backgroundColor,
			accent: accent.top()[ 0 ] || '',
			button: button,
			container: widths.length ? widths[ Math.floor( widths.length / 2 ) ] : 0,
			header: header ? {
				position: hs.position,
				height: Math.round( header.getBoundingClientRect().height ),
				overlap: overlap,
				// What the band sits behind: the floating bar's own background.
				bg: bar ? cs( bar ).backgroundColor : hs.backgroundColor,
				link: linkColor.top()[ 0 ] || ''
			} : null,
			footer: footer ? {
				bg: backgroundBehind( footer ),
				color: cs( footer ).color
			} : null,
			heroImage: /^https?:/.test( heroImage ) ? heroImage : ''
		};
	}

	api.measure = measure;
	api.helpers = Object.assign( api.helpers || {}, {
		parseColor: parseColor,
		saturation: saturation,
		luminance: luminance,
		isDefaultLinkBlue: isDefaultLinkBlue,
		cleanFont: cleanFont,
		tally: tally
	} );
}() );
