/**
 * Kerf → Build with AI: the screen follows a design job, then shows its pages
 * before the owner continues to the import's check step.
 *
 * The panel's markup is PHP's; answers go in as text. A design's HTML goes
 * only into the preview's sandboxed frame, which runs nothing (§5.46).
 *
 * @package kerf-pro
 */
( function ( wp ) {
	'use strict';

	var root = document.querySelector( '[data-kerf-build]' );
	if ( ! root ) {
		return;
	}

	var __ = wp.i18n.__;
	var form = root.querySelector( '[data-kerf-build-form]' );
	var pictures = root.querySelector( '[data-kerf-build-pictures]' );
	var picture = root.querySelector( 'template[data-kerf-build-picture]' );
	var maximum = parseInt( root.getAttribute( 'data-max-pictures' ), 10 ) || 0;
	var progress = root.querySelector( '[data-kerf-build-progress]' );
	var steps = root.querySelector( '[data-kerf-build-steps]' );
	var note = root.querySelector( '[data-kerf-build-note]' );
	var plan = root.querySelector( '[data-kerf-build-plan]' );
	var colors = root.querySelector( '[data-kerf-build-colors]' );
	var cancel = root.querySelector( '[data-kerf-build-cancel]' );
	var result = root.querySelector( '[data-kerf-build-result]' );
	var tabs = root.querySelector( '[data-kerf-build-tabs]' );
	var preview = root.querySelector( '[data-kerf-build-preview]' );
	var frame = root.querySelector( 'iframe[data-kerf-build-frame]' );
	var width = parseInt( preview.getAttribute( 'data-width' ), 10 ) || 1440;
	var notes = root.querySelector( '[data-kerf-build-notes]' );
	var noteItem = root.querySelector( 'template[data-kerf-build-note-item]' );
	var fail = root.querySelector( '[data-kerf-ai-error]' );
	var currentJob = '';
	var currentStatus = '';
	var working = false;
	var stopping = false;
	var lastRequest = null;
	var token = '';
	var previewRequest = 0;
	var frameRequest = 0;

	function showError( text ) {
		fail.querySelector( 'p' ).textContent = text;
		fail.hidden = false;
	}

	function pictureIds() {
		var ids = [];
		pictures.querySelectorAll( 'li[data-kerf-build-picture-id]' ).forEach( function ( item ) {
			var id = Number( item.getAttribute( 'data-kerf-build-picture-id' ) );
			if ( Number.isInteger( id ) && id > 0 ) {
				ids.push( id );
			}
		} );
		return ids;
	}

	root.querySelector( '[data-kerf-build-choose]' ).addEventListener( 'click', function () {
		var media = wp.media( {
			title: __( 'Choose your pictures', 'kerf-pro' ),
			button: { text: __( 'Use these pictures', 'kerf-pro' ) },
			library: { type: 'image' },
			multiple: true
		} );
		media.on( 'select', function () {
			var ids = pictureIds();
			var count = pictures.querySelectorAll( 'li[data-kerf-build-picture-id]' ).length;
			media.state().get( 'selection' ).each( function ( chosen ) {
				var attachment = chosen.toJSON();
				var id = Number( attachment.id );
				if ( ! Number.isInteger( id ) || id <= 0 || ids.indexOf( id ) !== -1 || count >= maximum ) {
					return;
				}
				var item = picture.content.firstElementChild.cloneNode( true );
				var image = item.querySelector( 'img' );
				var thumbnail = attachment.sizes && attachment.sizes.thumbnail;
				item.setAttribute( 'data-kerf-build-picture-id', id );
				image.src = thumbnail && thumbnail.url ? thumbnail.url : attachment.url;
				image.alt = attachment.alt || attachment.title || '';
				pictures.appendChild( item );
				ids.push( id );
				count++;
			} );
		} );
		media.open();
	} );

	pictures.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '[data-kerf-build-remove]' );
		var item = button ? button.closest( 'li[data-kerf-build-picture-id]' ) : null;
		if ( item && pictures.contains( item ) ) {
			item.remove();
		}
	} );

	function gather() {
		var details = {};
		form.querySelectorAll( 'input[data-kerf-build-detail]' ).forEach( function ( input ) {
			details[ input.getAttribute( 'data-kerf-build-detail' ) ] = input.value.trim();
		} );
		return {
			brief: root.querySelector( '[data-kerf-build-brief]' ).value.trim(),
			pictures: pictureIds(),
			details: details
		};
	}

	// No veil: the owner may leave a job that takes minutes and come back.
	function begin() {
		working = true;
		stopping = false;
		currentJob = '';
		currentStatus = 'working';
		previewRequest++;
		fail.hidden = true;
		form.hidden = true;
		result.hidden = true;
		steps.textContent = '';
		note.textContent = '';
		plan.textContent = '';
		plan.hidden = true;
		colors.textContent = '';
		colors.hidden = true;
		cancel.disabled = true;
		progress.hidden = false;
	}

	function rejected( message ) {
		if ( 'cancelled' === currentStatus || message === __( 'The AI work stopped.', 'kerf-pro' ) ) {
			message = __( 'Stopped. Change what you asked, or build it again.', 'kerf-pro' );
		}
		working = false;
		currentJob = '';
		cancel.disabled = true;
		progress.hidden = true;
		form.hidden = false;
		showError( message );
	}

	function start( request ) {
		if ( working ) {
			return;
		}
		if ( request.brief.length < 20 ) {
			showError( __( 'Say a little more about the business and the site you want — a few sentences.', 'kerf-pro' ) );
			return;
		}
		lastRequest = request;
		begin();
		window.kerfAI.job( 'design', request, render ).then( showResult, rejected );
	}

	// Validate the trimmed brief here, including an empty one, with one message.
	form.noValidate = true;
	form.addEventListener( 'submit', function ( event ) {
		event.preventDefault();
		start( gather() );
	} );

	function render( view ) {
		currentJob = view.id;
		currentStatus = view.status;
		cancel.disabled = ! currentJob || stopping || 'working' !== currentStatus;
		steps.textContent = '';
		( view.steps || [] ).forEach( function ( step ) {
			var item = document.createElement( 'li' );
			item.textContent = step.label;
			item.className = 'is-' + step.state;
			steps.appendChild( item );
		} );
		note.textContent = view.note || '';
		var planned = view.result && view.result.plan;
		if ( planned ) {
			/* translators: 1: the site's name, 2: its tagline. */
			plan.textContent = planned.tagline ? wp.i18n.sprintf( wp.i18n._x( '%1$s — %2$s', 'site name and tagline', 'kerf-pro' ), planned.site_name, planned.tagline ) : planned.site_name;
			plan.hidden = false;
			colors.textContent = '';
			( planned.colors || [] ).forEach( function ( color ) {
				if ( ! /^#[0-9a-f]{6}$/i.test( color ) ) {
					return;
				}
				var item = document.createElement( 'li' );
				item.style.backgroundColor = color;
				item.setAttribute( 'title', color );
				colors.appendChild( item );
			} );
			colors.hidden = false;
		}
	}

	cancel.addEventListener( 'click', function () {
		if ( ! currentJob || ! working || stopping ) {
			return;
		}
		var id = currentJob;
		stopping = true;
		cancel.disabled = true;
		wp.apiFetch( { path: '/kerf/v1/ai/jobs/' + encodeURIComponent( id ) + '/cancel', method: 'POST' } ).then( function ( view ) {
			if ( working && currentJob === id ) {
				render( view );
			}
		}, function ( error ) {
			if ( ! working || currentJob !== id ) {
				return;
			}
			stopping = false;
			cancel.disabled = 'working' !== currentStatus;
			showError( error && error.message ? error.message : __( 'The AI work could not be stopped. Try again.', 'kerf-pro' ) );
		} );
	} );

	function fit() {
		var scale = preview.clientWidth / width;
		if ( ! scale ) {
			return;
		}
		frame.style.width = width + 'px';
		frame.style.height = Math.ceil( preview.clientHeight / scale ) + 'px';
		frame.style.transform = 'scale(' + scale + ')';
	}

	function load( file ) {
		var request = ++previewRequest;
		fail.hidden = true;
		preview.classList.add( 'is-loading' );
		wp.apiFetch( { path: '/kerf/v1/ai/design/preview?token=' + encodeURIComponent( token ) + '&file=' + encodeURIComponent( file ) } ).then( function ( answer ) {
			// A slower tab's answer must not replace the page chosen after it.
			if ( request !== previewRequest || result.hidden ) {
				return;
			}
			frameRequest = request;
			frame.srcdoc = answer.html;
			fit();
		}, function ( error ) {
			if ( request !== previewRequest || result.hidden ) {
				return;
			}
			preview.classList.remove( 'is-loading' );
			showError( error && error.message ? error.message : __( 'That page could not be previewed. Try again.', 'kerf-pro' ) );
		} );
	}

	frame.addEventListener( 'load', function () {
		fit();
		if ( frameRequest === previewRequest ) {
			preview.classList.remove( 'is-loading' );
		}
	} );
	window.addEventListener( 'resize', fit );

	function pick( chosen ) {
		tabs.querySelectorAll( '[role="tab"]' ).forEach( function ( button ) {
			var on = button === chosen;
			button.setAttribute( 'aria-selected', on ? 'true' : 'false' );
			button.tabIndex = on ? 0 : -1;
		} );
		load( chosen.getAttribute( 'data-file' ) );
	}

	tabs.addEventListener( 'click', function ( event ) {
		var button = event.target.closest( '[role="tab"]' );
		if ( button && tabs.contains( button ) ) {
			pick( button );
		}
	} );
	tabs.addEventListener( 'keydown', function ( event ) {
		if ( 'ArrowLeft' !== event.key && 'ArrowRight' !== event.key ) {
			return;
		}
		var button = event.target.closest( '[role="tab"]' );
		var buttons = tabs.querySelectorAll( '[role="tab"]' );
		var at = Array.prototype.indexOf.call( buttons, button );
		if ( at < 0 ) {
			return;
		}
		event.preventDefault();
		var direction = 'ArrowRight' === event.key ? 1 : -1;
		if ( 'rtl' === window.getComputedStyle( tabs ).direction ) {
			direction *= -1;
		}
		var next = buttons[ ( at + direction + buttons.length ) % buttons.length ];
		next.focus();
		pick( next );
	} );

	function showResult( view ) {
		var answer = view.result || {};
		working = false;
		cancel.disabled = true;
		progress.hidden = true;
		form.hidden = true;
		result.hidden = false;
		token = answer.token || '';
		tabs.textContent = '';
		( answer.pages || [] ).forEach( function ( page ) {
			var button = document.createElement( 'button' );
			button.type = 'button';
			button.setAttribute( 'role', 'tab' );
			button.setAttribute( 'data-file', page.file );
			button.setAttribute( 'aria-selected', 'false' );
			button.tabIndex = -1;
			button.textContent = page.label;
			tabs.appendChild( button );
		} );
		notes.textContent = '';
		( answer.notes || [] ).forEach( function ( text ) {
			var item = noteItem.content.firstElementChild.cloneNode( true );
			item.querySelector( 'p' ).textContent = text;
			notes.appendChild( item );
		} );
		notes.hidden = ! notes.children.length;
		root.querySelector( '[data-kerf-build-continue]' ).href = answer.check_url;
		fit();
		if ( tabs.firstElementChild ) {
			pick( tabs.firstElementChild );
		}
	}

	root.querySelector( '[data-kerf-build-again]' ).addEventListener( 'click', function () {
		start( lastRequest || gather() );
	} );
	root.querySelector( '[data-kerf-build-new]' ).addEventListener( 'click', function () {
		previewRequest++;
		result.hidden = true;
		fail.hidden = true;
		form.hidden = false;
	} );

	var job = root.getAttribute( 'data-job' );
	if ( job ) {
		begin();
		currentJob = job;
		cancel.disabled = false;
		window.kerfAI.follow( job, render ).then( showResult, rejected );
	}
}( window.wp ) );
