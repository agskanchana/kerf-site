/**
 * Update from mockup: the background pictures the owner changed, checked
 * against the new version's stylesheets (§5.41, inc/kerf-backgrounds.php).
 *
 * The browser reads the new CSS the way the editor's canvas read the old one,
 * so a rule is found by the same selector text the owner's change recorded —
 * no CSS parsing in PHP to disagree with it. For each picture:
 *
 *   same       the design kept its picture there: the owner's stays, and the
 *              rest of the value (a gradient over it) comes from the new
 *              version — a refreshed value, sent with the form.
 *   changed    the design changed that picture too: said, with a box to take
 *              the design's new one. Unticked, the owner's stays.
 *   gone       the new version has no such style: said. An "everywhere"
 *              change can then be removed; one on a block stays on it.
 *
 * Nothing here can tick anything for the owner: if it fails, the form goes
 * without it and every picture of theirs stays as it is.
 *
 * @package kerf
 */

( function () {
	'use strict';

	var box = document.querySelector( '.kerf-bg-check' );
	var core = window.kerfBackgroundCore;
	var strings = window.kerfSyncBackgrounds || {};
	if ( ! box || ! core || ! window.CSSStyleSheet ) {
		return;
	}

	var data;
	try {
		data = JSON.parse( box.getAttribute( 'data-kerf-bg-check' ) || '{}' );
	} catch ( e ) {
		return;
	}

	function text( key, fallback ) {
		return strings[ key ] || fallback;
	}

	/**
	 * Every url() layer of a value made absolute against its stylesheet.
	 *
	 * @param {string} value
	 * @param {string} base
	 * @return {string}
	 */
	function absolute( value, base ) {
		return core.splitTopLevel( value ).map( function ( layer ) {
			var url = core.layerUrl( layer );
			if ( ! url ) {
				return layer;
			}
			try {
				return 'url("' + new URL( url, base ).href.replace( /"/g, '%22' ) + '")';
			} catch ( e ) {
				return layer;
			}
		} ).join( ', ' );
	}

	/**
	 * The new version's rules that draw a picture: selector (one per selector
	 * in a list), media, value with absolute urls.
	 *
	 * @param {Object[]} sheets { text, base }.
	 * @return {Object[]}
	 */
	function newRules( sheets ) {
		var found = [];
		function walk( list, media, base ) {
			Array.prototype.forEach.call( list || [], function ( rule ) {
				if ( rule.cssRules && ! rule.selectorText ) {
					var condition = rule.media && rule.media.mediaText ? rule.media.mediaText : '';
					walk( rule.cssRules, condition ? media.concat( condition ) : media, base );
					return;
				}
				if ( ! rule.selectorText || ! rule.style ) {
					return;
				}
				var value = rule.style.getPropertyValue( 'background-image' );
				if ( ! value || -1 === value.indexOf( 'url(' ) ) {
					return;
				}
				core.splitTopLevel( rule.selectorText ).forEach( function ( part ) {
					found.push( { selector: part, media: media.join( ' and ' ), value: absolute( value, base ) } );
				} );
			} );
		}
		sheets.forEach( function ( sheet ) {
			var parsed = new window.CSSStyleSheet();
			try {
				parsed.replaceSync( sheet.text );
			} catch ( e ) {
				return;
			}
			walk( parsed.cssRules, [], sheet.base );
		} );
		return found;
	}

	/**
	 * The new version's text of each stylesheet.
	 *
	 * @return {Promise<Object[]>}
	 */
	function loadSheets() {
		return Promise.all( ( data.sheets || [] ).map( function ( sheet ) {
			if ( ! sheet.url ) {
				return Promise.resolve( { text: sheet.text || '', base: sheet.base || window.location.href } );
			}
			return window.fetch( sheet.url, { credentials: 'same-origin' } ).then( function ( response ) {
				return response.ok ? response.text() : '';
			} ).catch( function () {
				return '';
			} ).then( function ( css ) {
				return { text: css, base: sheet.url };
			} );
		} ) );
	}

	function hidden( name, value ) {
		var input = document.createElement( 'input' );
		input.type = 'hidden';
		input.name = name;
		input.value = value;
		return input;
	}

	function row( item, status, rule ) {
		var li = document.createElement( 'li' );
		var where = item.where + ' — ' + item.selector + ( item.media ? ' (' + item.media + ')' : '' );
		var line = document.createElement( 'span' );
		line.textContent = where + ': ';
		li.appendChild( line );

		var says = document.createElement( 'span' );
		// Each page's featured image: nothing to choose while the style is
		// there — a page without one shows whatever picture the design has.
		var featured = !! item.featured && 'gone' !== status;
		if ( featured ) {
			says.textContent = text( 'featured', 'each page keeps showing its featured image here; a page without one shows the new version\'s picture.' );
		} else if ( 'same' === status ) {
			says.textContent = text( 'same', 'the new version keeps the design\'s picture here; yours stays.' );
		} else if ( 'changed' === status ) {
			says.textContent = text( 'changed', 'the new version changes this picture too; yours stays unless you tick the box.' );
		} else {
			says.textContent = 'everywhere' === item.scope
				? text( 'goneRule', 'the new version no longer has this style, so your change does nothing there.' )
				: text( 'goneBlock', 'the new version no longer has this style; your picture stays on the element.' );
		}
		li.appendChild( says );

		var takeLabel = 'changed' === status && ! featured
			? text( 'take', 'Use the design\'s new picture' )
			: ( 'gone' === status && 'everywhere' === item.scope ? text( 'remove', 'Remove my change' ) : '' );
		if ( takeLabel ) {
			var label = document.createElement( 'label' );
			label.className = 'kerf-bg-check__take';
			var box2 = document.createElement( 'input' );
			box2.type = 'checkbox';
			box2.name = 'kerf_bg_take[]';
			box2.value = item.id;
			label.appendChild( box2 );
			label.appendChild( document.createTextNode( ' ' + takeLabel ) );
			li.appendChild( label );
		}

		// Kept: the owner's picture inside the new version's value, and where
		// the design's own picture is now, for the next update to compare with.
		if ( rule && ( 'same' === status || 'changed' === status ) ) {
			// A featured-image rule keeps the design's own value: the page's
			// picture takes the photo's place as it prints.
			var refreshed = featured ? rule.value : core.swapLayer( rule.value, item.layer, item.url );
			var newUrl = core.layerUrl( core.splitTopLevel( rule.value )[ item.layer ] || '' );
			li.appendChild( hidden( 'kerf_bg_refresh[' + item.id + ']', refreshed ) );
			li.appendChild( hidden( 'kerf_bg_design[' + item.id + ']', core.designPath( newUrl ) ) );
		}
		return li;
	}

	loadSheets().then( function ( sheets ) {
		var rules = newRules( sheets );
		var list = document.createElement( 'ul' );
		list.className = 'kerf-bg-check__list';

		( data.overrides || [] ).forEach( function ( item ) {
			var matches = rules.filter( function ( rule ) {
				return rule.selector === item.selector && rule.media === ( item.media || '' );
			} );
			var rule = matches.length ? matches[ matches.length - 1 ] : null;
			var layer = rule ? core.splitTopLevel( rule.value )[ item.layer ] : '';
			var url = layer ? core.layerUrl( layer ) : '';
			var status = ! url ? 'gone' : ( core.designPath( url ) === item.design ? 'same' : 'changed' );
			list.appendChild( row( item, status, url ? rule : null ) );
		} );

		box.innerHTML = '';
		box.appendChild( list );
	} ).catch( function () {
		box.querySelector( 'p' ).textContent = text( 'failed', 'Could not check them against the new version. Your pictures will stay as they are.' );
	} );
}() );
