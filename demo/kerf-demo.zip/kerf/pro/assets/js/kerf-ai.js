/**
 * Kerf Pro's AI, in the browser: one way to ask, one way to wait, one way to
 * say what went wrong. Every AI screen and panel uses window.kerfAI.
 *
 * The key never comes here; the browser asks Kerf (kerf/v1/ai/*), and Kerf
 * asks the model (inc/kerf-pro-ai.php).
 *
 * @package kerf-pro
 */
( function ( wp ) {
	'use strict';

	var __ = wp.i18n.__;

	function veil( text ) {
		var box = document.querySelector( '.kerf-working' );
		if ( ! box ) {
			return function () {};
		}
		box.querySelector( '.kerf-working__text' ).textContent = text;
		box.classList.add( 'is-on' );
		box.setAttribute( 'aria-hidden', 'false' );
		return function () {
			box.classList.remove( 'is-on' );
			box.setAttribute( 'aria-hidden', 'true' );
		};
	}

	/**
	 * Ask one of Kerf's AI routes.
	 *
	 * @param {string} route   After kerf/v1/ai/, e.g. "explain".
	 * @param {Object} data    What to send.
	 * @param {string} waiting The line shown while the AI works; none for no veil.
	 * @return {Promise<Object>} The answer; rejected with a plain message.
	 */
	function call( route, data, waiting ) {
		var lift = waiting ? veil( waiting ) : function () {};
		return wp.apiFetch( {
			path: '/kerf/v1/ai/' + route,
			method: 'POST',
			data: data || {}
		} ).then( function ( answer ) {
			lift();
			return answer;
		}, function ( error ) {
			lift();
			throw ( error && error.message ) ? error.message : __( 'The AI request did not go through. Try again.', 'kerf-pro' );
		} );
	}

	/**
	 * Start AI work longer than a request — a job (inc/kerf-pro-ai-jobs.php) —
	 * and follow it to its end. Each answer about it comes at once while the
	 * server works on the next step; an answer that fails (a gateway that gave
	 * up while a step ran) is asked again: the job goes on regardless.
	 *
	 * @param {string}   route    After kerf/v1/ai/, the route that starts it.
	 * @param {Object}   data     What to send.
	 * @param {Function} progress Called with the job as it goes ({status, steps, done, total, note}).
	 * @return {Promise<Object>} The finished job; rejected with a plain message.
	 */
	function job( route, data, progress ) {
		return wp.apiFetch( {
			path: '/kerf/v1/ai/' + route,
			method: 'POST',
			data: data || {}
		} ).then( function ( started ) {
			return follow( started, progress );
		}, function ( error ) {
			throw ( error && error.message ) ? error.message : __( 'The AI request did not go through. Try again.', 'kerf-pro' );
		} );
	}

	/**
	 * Follow a job already started — this page's, or one the page was
	 * reloaded in the middle of — to its end.
	 *
	 * @param {Object|string} started  The job as its start answered, or its id.
	 * @param {Function}      progress As for job().
	 * @return {Promise<Object>} The finished job; rejected with a plain message.
	 */
	function follow( started, progress ) {
		var told = progress || function () {};
		var id = 'string' === typeof started ? started : started.id;
		return new Promise( function ( resolve, reject ) {
			var misses = 0;
			var settle = function ( now ) {
				told( now );
				if ( 'done' === now.status ) {
					resolve( now );
				} else if ( 'failed' === now.status || 'cancelled' === now.status ) {
					reject( now.error || __( 'The AI work stopped.', 'kerf-pro' ) );
				} else {
					setTimeout( ask, 2500 );
				}
			};
			var ask = function () {
				wp.apiFetch( { path: '/kerf/v1/ai/jobs/' + id + '?t=' + Date.now() } ).then( function ( now ) {
					misses = 0;
					settle( now );
				}, function ( error ) {
					// No job, or no permission: said. Anything else — a
					// gateway's timeout, a dropped connection — asked again.
					if ( error && error.code && 0 === String( error.code ).indexOf( 'kerf_ai' ) ) {
						reject( error.message );
					} else if ( ++misses > 60 ) {
						reject( __( 'Kerf lost touch with the AI work. Reload the page to see how far it got.', 'kerf-pro' ) );
					} else {
						setTimeout( ask, 4000 );
					}
				} );
			};
			if ( 'string' === typeof started ) {
				ask();
			} else {
				settle( started );
			}
		} );
	}

	window.kerfAI = { call: call, job: job, follow: follow, veil: veil };

	// The import's Done step: "In plain words" (inc/kerf-pro-ai-explain.php).
	// The panel's markup is drawn by PHP; the answer goes in as text only.
	var explain = document.querySelector( '[data-kerf-ai-explain]' );
	if ( explain ) {
		var out = explain.querySelector( '[data-kerf-ai-explain-out]' );
		var start = explain.querySelector( '[data-kerf-ai-explain-start]' );
		var go = explain.querySelector( '[data-kerf-ai-explain-go]' );
		var fail = explain.querySelector( '[data-kerf-ai-error]' );
		var problem = explain.querySelector( 'template[data-kerf-ai-problem]' );

		var show = function ( answer ) {
			var problems = ( answer && answer.problems ) || [];
			var list = out.querySelector( '[data-problems]' );
			var tool = out.querySelector( '[data-for-tool]' );
			var message = tool.querySelector( 'textarea' );

			out.querySelector( '[data-summary]' ).textContent = answer.summary || '';
			list.textContent = '';
			problems.forEach( function ( item ) {
				var row = problem.content.firstElementChild.cloneNode( true );
				var fix = row.querySelector( '[data-fix]' );
				row.querySelector( '[data-what]' ).textContent = item.what || '';
				row.querySelector( '[data-why]' ).textContent = item.why || '';
				fix.querySelector( 'span' ).textContent = item.fix || '';
				fix.hidden = ! item.fix;
				list.appendChild( row );
			} );
			list.hidden = ! problems.length;
			message.value = answer.for_your_ai_tool || '';
			tool.hidden = ! message.value;
			out.hidden = false;
			if ( start ) {
				start.hidden = true;
			}
		};

		var explained = explain.getAttribute( 'data-explained' );
		if ( explained ) {
			try {
				show( JSON.parse( explained ) );
			} catch ( e ) {}
		}

		if ( go ) {
			go.addEventListener( 'click', function () {
				fail.hidden = true;
				go.disabled = true;
				call( 'explain', {}, __( 'Gemini is reading the report…', 'kerf-pro' ) ).then( show, function ( text ) {
					fail.querySelector( 'p' ).textContent = text;
					fail.hidden = false;
				} ).then( function () {
					go.disabled = false;
				} );
			} );
		}
	}

	// The import's check step: "Mark it with AI" beside a blog, post or 404
	// page that is not marked (inc/kerf-pro-ai-prepare.php). Kerf marks the
	// page in the paused import and answers with what it marked — said here as
	// text — and the choices the page has now that WordPress can use it.
	document.querySelectorAll( '[data-kerf-ai-mark]' ).forEach( function ( box ) {
		var go = box.querySelector( '[data-kerf-ai-mark-go]' );
		var about = box.querySelector( '[data-kerf-ai-mark-about]' );
		var done = box.querySelector( '[data-kerf-ai-mark-done]' );
		var fail = box.querySelector( '[data-kerf-ai-error]' );
		var form = box.closest( 'form' );
		var row = box.closest( 'tr' );
		var file = box.getAttribute( 'data-kerf-ai-mark' );

		go.addEventListener( 'click', function () {
			var token = form ? form.querySelector( 'input[name="kerf_pending"]' ) : null;
			/* translators: %s: file name. */
			var lift = veil( wp.i18n.sprintf( __( 'Gemini is reading %s — this can take a minute…', 'kerf-pro' ), file ) );
			fail.hidden = true;
			go.disabled = true;
			// A job, so a slow model outlasts no host's gateway (§9.28).
			job( 'prepare', { token: token ? token.value : '', file: file } ).then( function ( finished ) {
				var answer = finished.result || {};
				var select = row ? row.querySelector( 'select' ) : null;
				lift();
				if ( select ) {
					select.textContent = '';
					( answer.options || [] ).forEach( function ( option ) {
						select.appendChild( new Option( option.label, option.value, false, option.value === answer.selected ) );
					} );
					select.value = answer.selected;
				}
				done.textContent = '';
				( answer.summary || [] ).forEach( function ( line ) {
					var item = document.createElement( 'li' );
					item.textContent = line;
					done.appendChild( item );
				} );
				done.hidden = false;
				go.hidden = true;
				if ( about ) {
					about.hidden = true;
				}
			}, function ( text ) {
				lift();
				fail.textContent = text;
				fail.hidden = false;
			} ).then( function () {
				go.disabled = false;
			} );
		} );
	} );

	// Kerf → Settings: "Check the key".
	var check = document.querySelector( '[data-kerf-ai-check]' );
	if ( check ) {
		check.addEventListener( 'click', function () {
			var out = document.querySelector( '[data-kerf-ai-check-result]' );
			out.textContent = __( 'Checking…', 'kerf-pro' );
			check.disabled = true;
			call( 'check-key', {} ).then( function ( answer ) {
				out.textContent = answer.message;
			}, function ( message ) {
				out.textContent = message;
			} ).then( function () {
				check.disabled = false;
			} );
		} );
	}
}( window.wp ) );
