/**
 * Convert HTML, in the Kerf sidebar (inc/kerf-pro-convert.php).
 *
 * Paste a chunk of HTML, get blocks. The whole-mockup import (Kerf → Import
 * Mockup) is for standing a site up; this is for the rest of the project, when
 * a designer sends over one new section and re-importing the site would be
 * absurd. Insert it, or replace the selected block with it.
 *
 * Both call the same engine, so a section converted here is identical to the
 * same markup converted there.
 *
 * A section comes with the styles that draw it — a `<style>`, a stylesheet's
 * `<link>`, a script. They are given to what is edited (inc/kerf-pro-page-
 * assets.php): this page; in the Site Editor, this template, or — for a header
 * or footer — every page. The page's own styles are listed below, each
 * removable.
 *
 * The free plugin draws the Kerf sidebar (kerf-editor-ux.js) with a slot,
 * `KerfSidebar`, which this fills.
 *
 * @package kerf-pro
 */

( function ( wp ) {
	'use strict';

	if ( ! wp.plugins || ! wp.components || ! wp.components.Fill ) {
		return;
	}

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var components = wp.components;
	var Fill = components.Fill;
	var PanelBody = components.PanelBody;
	var TextareaControl = components.TextareaControl;
	var CheckboxControl = components.CheckboxControl;
	var Button = components.Button;
	var Notice = components.Notice;
	var Spinner = components.Spinner;

	/**
	 * What is edited: a post (its id), a template (its slug), or a template
	 * part (every page).
	 *
	 * @return {{post:number, template:string, part:boolean}}
	 */
	function edited() {
		var editor = wp.data.select( 'core/editor' );
		var type = editor && editor.getCurrentPostType ? editor.getCurrentPostType() : '';
		var id = editor && editor.getCurrentPostId ? editor.getCurrentPostId() : 0;
		if ( 'wp_template' === type ) {
			var slug = String( id || '' );
			return { post: 0, template: slug.indexOf( '//' ) >= 0 ? slug.slice( slug.indexOf( '//' ) + 2 ) : slug, part: false };
		}
		if ( 'wp_template_part' === type || 'wp_navigation' === type ) {
			return { post: 0, template: '', part: true };
		}
		return { post: parseInt( id, 10 ) || 0, template: '', part: false };
	}

	/**
	 * Draw the page's stylesheets added or taken off at once, as the editor's
	 * next load would (inc/kerf-assets.php).
	 *
	 * @param {Object[]} added
	 * @param {Object[]} removed
	 */
	function restyle( added, removed ) {
		if ( ! ( added && added.length ) && ! ( removed && removed.length ) ) {
			return;
		}
		var gone = ( removed || [] ).map( function ( style ) {
			return style && style.css;
		} );
		var keep = function ( list ) {
			return ( list || [] ).filter( function ( style ) {
				return ! style || gone.indexOf( style.css ) < 0;
			} ).concat( added || [] );
		};
		var editor = wp.data.dispatch( 'core/editor' );
		if ( editor && editor.updateEditorSettings ) {
			editor.updateEditorSettings( { styles: keep( wp.data.select( 'core/editor' ).getEditorSettings().styles ) } );
		}
		wp.data.dispatch( 'core/block-editor' ).updateSettings( { styles: keep( wp.data.select( 'core/block-editor' ).getSettings().styles ) } );
	}

	/**
	 * Where a section's own files went, in words.
	 *
	 * @param {Object} where From edited().
	 * @param {string} files Their names.
	 * @return {string}
	 */
	function addedLine( where, files ) {
		if ( where.template ) {
			/* translators: %s: list of files. */
			return sprintf( __( 'Added to this template: %s.', 'kerf-pro' ), files );
		}
		if ( where.part ) {
			/* translators: %s: list of files. */
			return sprintf( __( 'Added to every page: %s.', 'kerf-pro' ), files );
		}
		/* translators: %s: list of files. */
		return sprintf( __( 'Added to this page: %s. Only it loads them.', 'kerf-pro' ), files );
	}

	function ConverterPanel( props ) {
		var htmlState = useState( '' );
		var html = htmlState[ 0 ];
		var setHtml = htmlState[ 1 ];

		var busyState = useState( false );
		var busy = busyState[ 0 ];
		var setBusy = busyState[ 1 ];

		var resultState = useState( null );
		var result = resultState[ 0 ];
		var setResult = resultState[ 1 ];

		var errorState = useState( '' );
		var error = errorState[ 0 ];
		var setError = errorState[ 1 ];

		var where = edited();
		// Every page, for a header or footer: asked, not assumed.
		var addState = useState( ! where.part );
		var add = addState[ 0 ];

		// The block a replace would replace: the selected one.
		var selectedId = wp.data.useSelect( function ( select ) {
			return select( 'core/block-editor' ).getSelectedBlockClientId();
		}, [] );

		// A lapsed Kerf Pro licence: what was converted stays, the tool waits
		// for a renewal.
		if ( window.kerfProConvert && false === window.kerfProConvert.licensed ) {
			return el( PanelBody, { title: __( 'Convert HTML', 'kerf-pro' ), initialOpen: true },
				el( 'p', { className: 'kerf-help' }, __( 'Your Kerf Pro licence has expired: renew to convert HTML here again.', 'kerf-pro' ) )
			);
		}

		function convert( replace ) {
			if ( ! html.trim() ) {
				return;
			}

			setBusy( true );
			setError( '' );
			setResult( null );

			wp.apiFetch( {
				path: '/kerf/v1/convert',
				method: 'POST',
				// The page's own design's files, when it has one (the free plugin's
				// inc/kerf-assets.php); and where the section's own styles go.
				data: {
					html: html,
					post_id: where.post,
					add_assets: add && !! ( where.post || where.template || where.part ),
					template: where.template,
					everywhere: where.part
				}
			} ).then( function ( response ) {
				var blocks = wp.blocks.parse( response.markup );
				var editor = wp.data.dispatch( 'core/block-editor' );
				var current = replace && selectedId ? wp.data.select( 'core/block-editor' ).getBlock( selectedId ) : null;

				if ( current && blocks.length ) {
					// The designer's new version of one section, in its place —
					// undoable like any edit. It keeps the section's stamp, marked
					// as replaced here, so an update from the mockup later finds
					// it and knows not to overwrite it unasked (inc/kerf-pro-sync.php).
					var stamp = current.attributes && current.attributes.kerfSource;
					if ( stamp && stamp.key ) {
						blocks[ 0 ].attributes.kerfSource = Object.assign( {}, stamp, { out: 'replaced' } );
					}
					editor.replaceBlocks( selectedId, blocks );
				} else {
					// Otherwise insert: silently discarding what was already
					// there would be unrecoverable.
					editor.insertBlocks( blocks );
				}

				restyle( response.styles, [] );
				if ( response.added && response.added.length && props.onAdded ) {
					props.onAdded();
				}
				setResult( response );
				setBusy( false );
			} ).catch( function ( err ) {
				setError( err.message || __( 'Conversion failed.', 'kerf-pro' ) );
				setBusy( false );
			} );
		}

		var missing = result && result.audit ? result.audit.missing : [];
		var assets = result && result.assets ? result.assets : [];
		var added = result && result.added ? result.added : [];
		var skipped = result && result.skipped ? result.skipped : [];
		var addLabel = where.template
			? __( 'Add its own styles to this template', 'kerf-pro' )
			: ( where.part ? __( 'Add its own styles to every page', 'kerf-pro' ) : __( 'Add its own styles to this page', 'kerf-pro' ) );

		return el( PanelBody, { title: __( 'Convert HTML', 'kerf-pro' ), initialOpen: true },
			el( TextareaControl, {
				label: __( 'Markup', 'kerf-pro' ),
				value: html,
				onChange: setHtml,
				rows: 10,
				placeholder: '<section class="hero">…</section>',
				__nextHasNoMarginBottom: true
			} ),
			el( CheckboxControl, {
				label: addLabel,
				help: __( 'A <style>, a stylesheet\'s <link> or a script in what you paste. The site\'s own stylesheets are never changed.', 'kerf-pro' ),
				checked: add,
				onChange: addState[ 1 ],
				__nextHasNoMarginBottom: true
			} ),
			el( 'div', { className: 'kerf-converter-buttons' },
				el( Button, {
					variant: 'primary',
					onClick: function () {
						convert( false );
					},
					disabled: busy || ! html.trim()
				}, busy ? __( 'Converting…', 'kerf-pro' ) : __( 'Convert and insert', 'kerf-pro' ) ),
				el( Button, {
					variant: 'secondary',
					onClick: function () {
						convert( true );
					},
					disabled: busy || ! html.trim() || ! selectedId,
					title: selectedId ? '' : __( 'Select the block to replace first.', 'kerf-pro' )
				}, __( 'Replace the selected block', 'kerf-pro' ) )
			),
			el( 'p', { className: 'kerf-help' },
				__( 'Your designer changed one section? Select it, paste its new HTML and replace it. Its pictures and links resolve as they did at import. A whole new version of the mockup goes through Kerf → Update from mockup.', 'kerf-pro' )
			),

			busy && el( Spinner ),

			error && el( Notice, { status: 'error', isDismissible: false }, error ),

			result && el( Fragment, null,
				el( Notice, { status: 'success', isDismissible: false },
					sprintf(
						/* translators: 1: element count, 2: fidelity percentage. */
						__( '%1$d elements converted. %2$d%% of your selectors survived.', 'kerf-pro' ),
						result.elements,
						result.audit.score
					)
				),

				result.truncated && el( Notice, { status: 'warning', isDismissible: false },
					__( 'Output is incomplete — a size limit was reached. Convert this in smaller pieces.', 'kerf-pro' )
				),

				missing.length > 0 && el( 'div', { className: 'kerf-editor-missing' },
					el( 'strong', null, __( 'CSS rules for these will no longer match:', 'kerf-pro' ) ),
					el( 'p', null, missing.map( function ( name ) {
						return el( 'code', { key: name }, name );
					} ) )
				),

				added.length > 0 && el( Notice, { status: 'info', isDismissible: false, className: 'kerf-converter-assets' }, addedLine( where, added.join( ', ' ) ) ),

				skipped.length > 0 && el( Notice, { status: 'warning', isDismissible: false, className: 'kerf-converter-assets' },
					sprintf(
						/* translators: %s: list of files. */
						__( 'Left out: %s — a file your design\'s folder does not have, or a script, which only someone who may add scripts can add.', 'kerf-pro' ),
						skipped.join( ', ' )
					)
				),

				assets.length > 0 && ! added.length && ! skipped.length && ! add && el( Notice, { status: 'info', isDismissible: false, className: 'kerf-converter-assets' },
					sprintf(
						/* translators: %d: number of assets. */
						__( 'This markup has %d stylesheets or scripts of its own. They were not added: tick the box above to add them.', 'kerf-pro' ),
						assets.length
					)
				)
			)
		);
	}

	/**
	 * The styles and scripts this page loads of its own — added in WordPress
	 * (removable here) or brought by the design's page it is.
	 *
	 * @param {Object} props { post, version }.
	 * @return {Object|null}
	 */
	function PageAssetsPanel( props ) {
		var listState = useState( null );
		var list = listState[ 0 ];
		var setList = listState[ 1 ];
		var errorState = useState( '' );

		useEffect( function () {
			if ( ! props.post ) {
				return;
			}
			wp.apiFetch( { path: '/kerf/v1/page-assets?post_id=' + props.post } ).then( setList, function () {
				setList( [] );
			} );
		}, [ props.post, props.version ] );

		if ( ! props.post || ! list || ! list.length ) {
			return null;
		}

		function remove( key ) {
			errorState[ 1 ]( '' );
			wp.apiFetch( { path: '/kerf/v1/page-assets/remove', method: 'POST', data: { post_id: props.post, key: key } } ).then( function ( answer ) {
				restyle( [], answer.removed && answer.removed.css ? [ answer.removed ] : [] );
				setList( answer.assets || [] );
			}, function ( err ) {
				errorState[ 1 ]( err.message || __( 'That could not be taken off.', 'kerf-pro' ) );
			} );
		}

		return el( PanelBody, { title: __( 'This page\'s own styles', 'kerf-pro' ), initialOpen: false },
			el( 'p', { className: 'kerf-help' }, __( 'What only this page loads, besides your design\'s stylesheets.', 'kerf-pro' ) ),
			el( 'ul', { className: 'kerf-page-assets' }, list.map( function ( item ) {
				var from = 'design' === item.by
					? __( 'From your design', 'kerf-pro' )
					: ( 'ai' === item.by ? __( 'Written by Gemini', 'kerf-pro' ) : __( 'Pasted with a section', 'kerf-pro' ) );
				return el( 'li', { key: item.key },
					el( 'span', null, item.label, el( 'small', null, from ) ),
					item.removable && el( Button, {
						variant: 'tertiary',
						isDestructive: true,
						size: 'small',
						onClick: function () {
							remove( item.key );
						}
					}, __( 'Remove', 'kerf-pro' ) )
				);
			} ) ),
			errorState[ 0 ] && el( Notice, { status: 'error', isDismissible: false }, errorState[ 0 ] )
		);
	}

	function KerfSidebarPanels() {
		var versionState = useState( 0 );
		var where = edited();
		return el( Fragment, null,
			el( ConverterPanel, {
				onAdded: function () {
					versionState[ 1 ]( versionState[ 0 ] + 1 );
				}
			} ),
			el( PageAssetsPanel, { post: where.post, version: versionState[ 0 ] } )
		);
	}

	wp.plugins.registerPlugin( 'kerf-pro-convert', {
		render: function () {
			return el( Fill, { name: 'KerfSidebar' }, el( KerfSidebarPanels ) );
		}
	} );
}( window.wp ) );
