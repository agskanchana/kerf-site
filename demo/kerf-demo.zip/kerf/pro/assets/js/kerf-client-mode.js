/**
 * Client mode: the design locked, the words and pictures open (§5.38).
 *
 * A page built from a design is a deep tree of the designer's elements, and
 * one drag in the List View breaks a layout someone paid for. In client mode
 * every element is locked (`disabled`: not selectable, not movable, nothing
 * inserted into it) and only the content blocks are open (`contentOnly`):
 * headings and paragraphs, text, links — their words and where they go — and
 * pictures. Kerf's own advanced panels (CSS, HTML attributes, the tag) hide
 * themselves in that mode.
 *
 * Only on a page built from a design (it has Kerf blocks): a post written in
 * WordPress is edited as WordPress edits it.
 *
 * On for whoever may not change the theme (Editors, Authors), unless the site
 * turned it off; and for an administrator who asked for it (the editor's
 * More menu, "Lock the design").
 *
 * @package kerf
 */

( function ( wp ) {
	'use strict';

	var config = window.kerfClientMode || {};
	var __ = wp.i18n.__;

	// What a client may change: text, links and pictures. Everything else in
	// a design is structure.
	var CONTENT = [ 'kerf/text', 'kerf/link', 'kerf/image', 'core/paragraph', 'core/heading' ];

	if ( config.active ) {
		var set = {};
		var noticed = false;
		// Which elements show a background picture: a client may change the
		// photo (kerf-background-panel.js) and nothing else about them. Read
		// once the canvas has drawn each one, then kept.
		var picture = {};
		var showsPicture = function ( editor, id ) {
			if ( undefined === picture[ id ] ) {
				var api = window.kerfBackground;
				if ( ! api ) {
					return false;
				}
				var shows = api.hasPicture( id, editor.getBlockAttributes( id ) || {} );
				// Null: not drawn yet — ask again on the next pass.
				if ( null !== shows ) {
					picture[ id ] = shows;
				}
				return !! shows;
			}
			return picture[ id ];
		};

		var apply = function () {
			var editor = wp.data.select( 'core/block-editor' );
			if ( ! editor ) {
				return;
			}
			var ids = editor.getClientIdsWithDescendants();
			var designed = ids.some( function ( id ) {
				return 0 === String( editor.getBlockName( id ) || '' ).indexOf( 'kerf/' );
			} );
			if ( ! designed ) {
				return;
			}

			var dispatch = wp.data.dispatch( 'core/block-editor' );
			ids.forEach( function ( id ) {
				var name = editor.getBlockName( id );
				var mode = -1 !== CONTENT.indexOf( name ) || ( 'kerf/div' === name && showsPicture( editor, id ) ) ? 'contentOnly' : 'disabled';
				if ( set[ id ] !== mode ) {
					set[ id ] = mode;
					dispatch.setBlockEditingMode( id, mode );
				}
			} );
			// Nothing is added at the top level either.
			if ( 'disabled' !== set[ '' ] ) {
				set[ '' ] = 'disabled';
				dispatch.setBlockEditingMode( '', 'disabled' );
			}

			if ( ! noticed && wp.data.dispatch( 'core/notices' ) ) {
				noticed = true;
				wp.data.dispatch( 'core/notices' ).createNotice( 'info',
					__( 'The design is locked: change the words, pictures and links. Ask an administrator to change the layout.', 'kerf-pro' ),
					{ id: 'kerf-client-mode', isDismissible: true }
				);
			}
		};

		// Blocks arrive after the editor starts, and again when a template loads.
		var pending = null;
		wp.data.subscribe( function () {
			if ( pending ) {
				return;
			}
			pending = window.setTimeout( function () {
				pending = null;
				apply();
			}, 150 );
		} );
	}

	// "Lock the design", for an administrator: see what a client sees.
	if ( config.canChoose && wp.plugins && wp.editor && wp.editor.PluginMoreMenuItem ) {
		wp.plugins.registerPlugin( 'kerf-design-lock', {
			render: function () {
				return wp.element.createElement( wp.editor.PluginMoreMenuItem, {
					icon: config.mine ? 'unlock' : 'lock',
					onClick: function () {
						wp.apiFetch( { path: '/wp/v2/users/me', method: 'POST', data: { meta: { kerf_design_lock: ! config.mine } } } ).then( function () {
							window.location.reload();
						} );
					}
				}, config.mine ? __( 'Unlock the design', 'kerf-pro' ) : __( 'Lock the design (as a client sees it)', 'kerf-pro' ) );
			}
		} );
	}
}( window.wp ) );
