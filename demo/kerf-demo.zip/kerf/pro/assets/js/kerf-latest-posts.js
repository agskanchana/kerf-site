/**
 * "Show my latest posts here" (§5.42, inc/kerf-latest-posts.php).
 *
 * On a selected section that holds two or more cards of one kind, each with a
 * heading — the designer's sample posts — this panel asks the server what each
 * part of a card is, shows it for the owner to confirm, and replaces the
 * section with one whose first card repeats for the latest posts. Undoable
 * like any edit until the page is saved. Full editing only: it changes the
 * design's structure.
 *
 * @package kerf-pro
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var PanelBody = wp.components.PanelBody;
	var Button = wp.components.Button;
	var CheckboxControl = wp.components.CheckboxControl;

	var LABELS = {
		title: __( 'Title', 'kerf-pro' ),
		image: __( 'Picture', 'kerf-pro' ),
		permalink: __( 'Link to the post', 'kerf-pro' ),
		date: __( 'Date', 'kerf-pro' ),
		excerpt: __( 'Summary', 'kerf-pro' ),
		category: __( 'Category', 'kerf-pro' ),
		author: __( 'Author', 'kerf-pro' ),
		'comments-count': __( 'Number of comments', 'kerf-pro' )
	};

	/**
	 * A block's kind, as one list's cards share it (the server's rule).
	 *
	 * @param {Object} block
	 * @return {string}
	 */
	function kind( block ) {
		var a = block.attributes || {};
		return block.name + '|' + String( a.tagName || '' ).toLowerCase() + '|' + String( a.className || '' ).trim().split( /\s+/ )[ 0 ];
	}

	function hasHeading( block ) {
		var a = block.attributes || {};
		if ( 'core/heading' === block.name || ( /^h[1-6]$/i.test( String( a.tagName || '' ) ) && ( 'kerf/text' === block.name || 'kerf/div' === block.name ) ) ) {
			return true;
		}
		return ( block.innerBlocks || [] ).some( hasHeading );
	}

	/**
	 * Does the section hold sample cards: two or more consecutive siblings of
	 * one kind, the first with a heading? A quick look before asking the
	 * server.
	 *
	 * @param {Object} block
	 * @param {number} depth
	 * @return {boolean}
	 */
	function holdsCards( block, depth ) {
		var children = block.innerBlocks || [];
		for ( var i = 0; i < children.length; i++ ) {
			if ( 'kerf/loop' === children[ i ].name ) {
				continue;
			}
			if ( i + 1 < children.length && kind( children[ i ] ) === kind( children[ i + 1 ] ) && hasHeading( children[ i ] ) ) {
				return true;
			}
		}
		return depth > 0 && children.some( function ( child ) {
			return 'kerf/loop' !== child.name && holdsCards( child, depth - 1 );
		} );
	}

	function LatestPanel( props ) {
		var block = wp.data.useSelect( function ( select ) {
			return select( 'core/block-editor' ).getBlock( props.clientId );
		}, [ props.clientId ] );
		var proposal = useState( null );
		var chosen = useState( {} );
		var busy = useState( '' );

		if ( ! block || ! holdsCards( block, 6 ) ) {
			return null;
		}

		function ask( apply ) {
			busy[ 1 ]( __( 'Working…', 'kerf-pro' ) );
			wp.apiFetch( {
				path: '/kerf/v1/latest-posts',
				method: 'POST',
				data: {
					markup: wp.blocks.serialize( block ),
					apply: !! apply,
					roles: Object.keys( chosen[ 0 ] ).filter( function ( role ) {
						return chosen[ 0 ][ role ];
					} )
				}
			} ).then( function ( response ) {
				busy[ 1 ]( '' );
				if ( ! response.found ) {
					busy[ 1 ]( __( 'No sample posts found in this section.', 'kerf-pro' ) );
					return;
				}
				if ( ! apply ) {
					var all = {};
					response.roles.forEach( function ( role ) {
						all[ role.role ] = true;
					} );
					chosen[ 1 ]( all );
					proposal[ 1 ]( response );
					return;
				}
				var made = wp.blocks.parse( response.markup );
				if ( made.length ) {
					wp.data.dispatch( 'core/block-editor' ).replaceBlock( props.clientId, made[ 0 ] );
				}
			} ).catch( function ( error ) {
				busy[ 1 ]( ( error && error.message ) || __( 'That did not work.', 'kerf-pro' ) );
			} );
		}

		var found = proposal[ 0 ];

		// A lapsed Kerf Pro licence: what the tool made keeps showing, the tool
		// waits for a renewal (inc/kerf-pro-latest-posts.php).
		if ( window.kerfLatestPosts && false === window.kerfLatestPosts.licensed ) {
			return el( InspectorControls, null,
				el( PanelBody, { title: __( 'Latest posts', 'kerf-pro' ), initialOpen: false, className: 'kerf-latest-panel' },
					el( 'p', { className: 'kerf-help' }, __( 'Your Kerf Pro licence has expired: renew to use Latest posts again.', 'kerf-pro' ) )
				)
			);
		}

		return el( InspectorControls, null,
			el( PanelBody, { title: __( 'Latest posts', 'kerf-pro' ), initialOpen: false, className: 'kerf-latest-panel' },
				! found && el( Fragment, null,
					el( 'p', { className: 'kerf-help' },
						__( 'This section seems to show sample posts. Kerf can make it show your latest posts instead, in the same cards.', 'kerf-pro' ) ),
					el( Button, { variant: 'secondary', onClick: function () {
						ask( false );
					} }, __( 'Find the post cards', 'kerf-pro' ) )
				),
				found && el( Fragment, null,
					el( 'p', { className: 'kerf-help' },
						/* translators: 1: number of cards, 2: the card, e.g. <div> .card. */
						sprintf( __( '%1$d sample cards (%2$s) become your latest %1$d posts. The first card is kept as the design; check what each part shows:', 'kerf-pro' ), found.count, found.card ) ),
					found.roles.map( function ( role ) {
						return el( CheckboxControl, {
							key: role.role,
							label: ( LABELS[ role.role ] || role.role ) + ( role.sample ? ' — “' + String( role.sample ).slice( 0, 60 ) + '”' : '' ),
							checked: !! chosen[ 0 ][ role.role ],
							onChange: function ( next ) {
								var copy = Object.assign( {}, chosen[ 0 ] );
								copy[ role.role ] = next;
								chosen[ 1 ]( copy );
							},
							__nextHasNoMarginBottom: true
						} );
					} ),
					el( 'div', { className: 'kerf-bg-actions' },
						el( Button, { variant: 'primary', onClick: function () {
							ask( true );
						} }, __( 'Show my latest posts here', 'kerf-pro' ) ),
						el( Button, { variant: 'tertiary', onClick: function () {
							proposal[ 1 ]( null );
						} }, __( 'Cancel', 'kerf-pro' ) )
					),
					el( 'p', { className: 'kerf-help' },
						__( 'Unticked parts keep the sample\'s words on every card. Undo works as usual until you save.', 'kerf-pro' ) )
				),
				busy[ 0 ] && el( 'p', { className: 'kerf-help' }, busy[ 0 ] )
			)
		);
	}

	wp.hooks.addFilter( 'editor.BlockEdit', 'kerf/latest-posts', wp.compose.createHigherOrderComponent( function ( BlockEdit ) {
		return function ( props ) {
			// A hook, called first on every render: full editing only.
			var full = window.kerf && window.kerf.fullEditing ? window.kerf.fullEditing() : true;
			var relevant = full && props.isSelected && 'kerf/div' === props.name;
			return el( Fragment, null,
				el( BlockEdit, props ),
				relevant ? el( LatestPanel, { clientId: props.clientId } ) : null
			);
		};
	}, 'withKerfLatestPosts' ) );
}( window.wp ) );
