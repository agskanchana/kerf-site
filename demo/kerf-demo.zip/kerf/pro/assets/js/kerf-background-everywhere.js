/**
 * "Replace everywhere" in the Background picture panel (§5.41,
 * inc/kerf-pro-backgrounds.php), and "each page's featured image".
 *
 * The free plugin's panel (kerf-background-panel.js) asks the
 * `kerf.backgroundPanel.rule` filter what else may change a picture the
 * design's stylesheet draws. This answers: replace it in the rule itself,
 * everywhere that style draws it — the designer's value with only the photo
 * swapped, so an overlay gradient stays — stored apart from the stylesheet
 * and printed after it. The only way to reach a picture on a ::before/::after
 * layer or one for other screen sizes. Or make that rule show each page's own
 * featured image (`featured`): an inner pages' banner drawn by one rule then
 * follows every page's picture, and a page without one keeps the design's.
 *
 * The `kerf.backgroundPanel.element` filter asks the same of a picture in the
 * element's own style or in an attribute its script reads: "Use this page's
 * featured image" binds the style to the post's image (as an import binds a
 * banner the design marked) or marks the element for its script.
 *
 * A lapsed licence leaves the pictures already changed as they are and says
 * so.
 *
 * @package kerf-pro
 */

( function ( wp ) {
	'use strict';

	var el = wp.element.createElement;
	var __ = wp.i18n.__;
	var core = window.kerfBackgroundCore;

	function save( context, rule ) {
		context.setBusy( __( 'Saving…', 'kerf-pro' ) );
		wp.apiFetch( {
			path: '/kerf/v1/backgrounds',
			method: 'POST',
			data: { post: context.post, rule: rule }
		} ).then( function ( response ) {
			context.setBusy( '' );
			context.setRules( response.rules );
		} ).catch( function ( error ) {
			context.setBusy( ( error && error.message ) || __( 'That background could not be saved.', 'kerf-pro' ) );
		} );
	}

	wp.hooks.addFilter( 'kerf.backgroundPanel.rule', 'kerf-pro/background-everywhere', function ( more, context ) {
		var item = context.item;
		var settings = window.kerfProBackgrounds || {};

		if ( false === settings.licensed ) {
			// Said only where it matters: a picture changed everywhere, or one
			// nothing else reaches.
			if ( context.stored || ! context.canHere ) {
				more.notes.push( el( 'p', { key: 'kerf-pro-renew', className: 'kerf-help' },
					__( 'Your Kerf Pro licence has expired: renew to change pictures everywhere.', 'kerf-pro' ) ) );
			}
			return more;
		}

		// Changed only here, the element shows the owner's picture whatever the
		// style says: nothing to offer until that is put back.
		if ( context.isHere ) {
			return more;
		}

		more.actions.push( context.pick( __( 'Replace everywhere', 'kerf-pro' ), function ( media ) {
			save( context, {
				selector: item.rule.selector,
				media: item.rule.media,
				value: core.swapLayer( item.rule.value, item.layer, media.url ),
				important: item.rule.important,
				layer: item.layer,
				design: core.designPath( item.url ),
				id: media.id,
				url: media.url
			} );
		}, context.canHere ? 'tertiary' : 'secondary' ) );

		// The rule keeps the designer's value; each page's picture takes the
		// photo's place as it prints.
		if ( ! ( context.stored && context.stored.featured ) ) {
			more.actions.push( el( wp.components.Button, {
				key: 'kerf-pro-featured',
				variant: 'tertiary',
				onClick: function () {
					save( context, {
						selector: item.rule.selector,
						media: item.rule.media,
						value: item.rule.value,
						important: item.rule.important,
						layer: item.layer,
						design: core.designPath( item.url ),
						featured: true
					} );
				}
			}, __( 'Use each page\'s featured image', 'kerf-pro' ) ) );
		}

		more.notes.push( el( 'p', { key: 'kerf-pro-where', className: 'kerf-help' },
			context.canHere
				? __( '"Here" changes this element only. "Everywhere" changes every element this style draws, on every page; "each page\'s featured image" shows every page its own, and the design\'s picture where a page has none.', 'kerf-pro' )
				: __( '"Each page\'s featured image" shows every page its own, and the design\'s picture where a page has none.', 'kerf-pro' ) ) );
		return more;
	} );

	wp.hooks.addFilter( 'kerf.backgroundPanel.element', 'kerf-pro/background-featured', function ( more, context ) {
		var settings = window.kerfProBackgrounds || {};
		if ( false === settings.licensed || context.follows || ! context.full ) {
			return more;
		}
		var attributes = context.attributes;

		more.actions.push( el( wp.components.Button, {
			key: 'kerf-pro-featured',
			variant: 'tertiary',
			onClick: function () {
				if ( 'style' === context.item.kind ) {
					// As an import binds a banner the design marked: the picture
					// in the style becomes the post's, the design's where there is
					// none (inc/kerf-bindings.php).
					var metadata = Object.assign( {}, attributes.metadata || {} );
					metadata.bindings = Object.assign( {}, metadata.bindings || {}, {
						backgroundImage: { source: 'kerf/post', args: { key: 'image' } },
						backgroundImageId: { source: 'kerf/post', args: { key: 'image-id' } }
					} );
					context.setAttributes( { metadata: metadata } );
				} else {
					var fields = String( attributes.kerfFields || '' ).split( /\s+/ ).filter( Boolean );
					fields.push( 'image' );
					context.setAttributes( { kerfFields: fields.join( ' ' ) } );
				}
			}
		}, __( 'Use this page\'s featured image', 'kerf-pro' ) ) );
		return more;
	} );
}( window.wp ) );
