/**
 * Kerf AI, in the editor (inc/kerf-pro-ai-editor.php): this page made from
 * the owner's words, or changed — the whole page or one section — as they
 * ask, in the site's design.
 *
 * - The Kerf AI sidebar (its icon in the editor's header): what can be done
 *   here, the work under way, and what Gemini said about the last answer.
 * - Its window: make the page (its kind, title, words, pictures), or change
 *   it (what should change, new words, new pictures; the selected section or
 *   the whole page).
 * - "Change with AI" in the toolbar of the selected block.
 * - On an empty page, a notice offering to make it with AI.
 *
 * A page's words are read for what they are: pasted from Word, Google Docs or
 * a web page, or HTML markup pasted as text, they are sent to Kerf
 * (POST kerf/v1/ai/words) and come back as Markdown — headings, lists, tables
 * kept — and so does a Word, Markdown, HTML or text file added.
 *
 * The answer goes into the editor, never saved: the owner looks it over, then
 * saves, or undoes it (Ctrl+Z). The work is a job (inc/kerf-pro-ai-jobs.php)
 * this page follows; reopened, the page finds its job again.
 *
 * @package kerf-pro
 */

( function ( wp ) {
	'use strict';

	var host = ( wp.editor && wp.editor.PluginSidebar ) ? wp.editor : wp.editPost;
	var state = window.kerfAiEditor;

	if ( ! wp.plugins || ! host || ! host.PluginSidebar || ! state ) {
		return;
	}

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var useRef = wp.element.useRef;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var C = wp.components;
	var select = wp.data.select;
	var dispatch = wp.data.dispatch;
	var useSelect = wp.data.useSelect;

	var SIDEBAR = 'kerf-ai/kerf-ai';
	var OPEN = 'kerf-ai-open';
	var NOTICE = 'kerf-ai-empty';

	// Markup pasted as text: a design's section copied from a code editor.
	var MARKUP = /^\s*(?:<!doctype\s+html|<(?:html|head|body|main|section|article|header|footer|div|h[1-6]|p|ul|ol|table|nav|aside|span|a|figure|blockquote)\b[^>]*>)/i;
	var CLOSES = /<\/(?:html|body|main|section|article|div|h[1-6]|p|ul|ol|table|li|span|a)>/i;
	// What Word, Google Docs or a page put on the clipboard with a shape worth keeping.
	var SHAPED = /<(?:h[1-6]|ul|ol|li|table|strong|b|em|i|a|blockquote)\b|mso-list|docs-internal-guid/i;

	var icon = el( 'svg', { viewBox: '0 0 24 24', width: 24, height: 24, fill: 'none', stroke: 'currentColor', strokeWidth: 1.75, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, focusable: false },
		el( 'path', { d: 'M11 5c.6 4.6 3.4 7.4 8 8-4.6.6-7.4 3.4-8 8-.6-4.6-3.4-7.4-8-8 4.6-.6 7.4-3.4 8-8z' } ),
		el( 'path', { d: 'M18.5 3v4M16.5 5h4' } )
	);

	// ─────────────────────────────────────────────────────────────────────────
	// The page
	// ─────────────────────────────────────────────────────────────────────────

	function postId() {
		var editor = select( 'core/editor' );
		return editor ? editor.getCurrentPostId() : 0;
	}

	function topBlocks() {
		return select( 'core/block-editor' ).getBlocks();
	}

	/**
	 * Is the page empty — nothing, or one empty paragraph?
	 *
	 * @return {boolean}
	 */
	function isEmpty() {
		var list = topBlocks();
		if ( ! list.length ) {
			return true;
		}
		return 1 === list.length && 'core/paragraph' === list[ 0 ].name && ! String( list[ 0 ].attributes.content || '' ).replace( /<[^>]*>/g, '' ).trim();
	}

	/**
	 * A block's name as the List View shows it (kerf-block-labels.js).
	 *
	 * @param {string} clientId
	 * @return {string}
	 */
	function blockLabel( clientId ) {
		var block = clientId ? select( 'core/block-editor' ).getBlock( clientId ) : null;
		if ( ! block ) {
			return '';
		}
		var type = wp.blocks.getBlockType( block.name );
		var name = type && wp.blocks.__experimentalGetBlockLabel ? wp.blocks.__experimentalGetBlockLabel( type, block.attributes, 'list-view' ) : '';
		return String( name || ( type && type.title ) || block.name ).replace( /<[^>]*>/g, '' );
	}

	/**
	 * Where a block stands: its index, and its parents'.
	 *
	 * @param {string} clientId
	 * @return {number[]}
	 */
	function blockPath( clientId ) {
		var store = select( 'core/block-editor' );
		var path = [];
		var id = clientId;
		while ( id ) {
			var parent = store.getBlockRootClientId( id ) || '';
			path.unshift( store.getBlockOrder( parent ).indexOf( id ) );
			id = parent;
		}
		return path;
	}

	/**
	 * The block at a path, if it is still there.
	 *
	 * @param {number[]} path
	 * @return {string|null}
	 */
	function blockAt( path ) {
		var store = select( 'core/block-editor' );
		var parent = '';
		var id = null;
		( path || [] ).forEach( function ( index ) {
			if ( null === parent ) {
				return;
			}
			id = store.getBlockOrder( parent )[ index ] || null;
			parent = id;
		} );
		return id;
	}

	function message( error ) {
		if ( 'string' === typeof error ) {
			return error;
		}
		return ( error && error.message ) || __( 'The AI request did not go through. Try again.', 'kerf-pro' );
	}

	function openWindow( detail ) {
		window.dispatchEvent( new window.CustomEvent( OPEN, { detail: detail || {} } ) );
	}

	function openSidebar() {
		try {
			dispatch( 'core/interface' ).enableComplementaryArea( 'core', SIDEBAR );
		} catch ( error ) {
			// An older editor keeps its sidebars under its own scope.
			try {
				dispatch( 'core/edit-post' ).openGeneralSidebar( SIDEBAR );
			} catch ( ignore ) {}
		}
	}

	// ─────────────────────────────────────────────────────────────────────────
	// The work
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Follow a job to its end, asking after it every few seconds; a failed
	 * answer (a gateway that gave up while a step ran) is asked again — as
	 * window.kerfAI.follow() does on Kerf's screens.
	 *
	 * @param {Object|string} started  The job as its start answered, or its id.
	 * @param {Function}      progress Called with the job as it goes.
	 * @return {Promise<Object>}
	 */
	function follow( started, progress ) {
		var id = 'string' === typeof started ? started : started.id;
		return new Promise( function ( resolve, reject ) {
			var misses = 0;
			var settle = function ( now ) {
				progress( now );
				if ( 'done' === now.status ) {
					resolve( now );
				} else if ( 'failed' === now.status || 'cancelled' === now.status ) {
					reject( now.error || ( 'cancelled' === now.status ? __( 'Stopped. Nothing was changed.', 'kerf-pro' ) : __( 'The AI work stopped.', 'kerf-pro' ) ) );
				} else {
					setTimeout( ask, 2500 );
				}
			};
			var ask = function () {
				wp.apiFetch( { path: '/kerf/v1/ai/jobs/' + id + '?t=' + Date.now() } ).then( function ( now ) {
					misses = 0;
					settle( now );
				}, function ( error ) {
					if ( error && error.code && 0 === String( error.code ).indexOf( 'kerf_ai' ) ) {
						reject( error.message );
					} else if ( ++misses > 60 ) {
						reject( __( 'Kerf lost touch with the AI work. Reload the page to see how far it got.', 'kerf-pro' ) );
					} else {
						setTimeout( ask, 4000 );
					}
				} );
			};
			if ( 'string' === typeof started ) {
				ask();
			} else {
				settle( started );
			}
		} );
	}

	/**
	 * The editor's styles changed: the page's own stylesheets a result added,
	 * and those it took off — drawn at once, as the next load of the editor
	 * would draw them (inc/kerf-assets.php).
	 *
	 * @param {Object[]} added
	 * @param {Object[]} removed
	 */
	function restyle( added, removed ) {
		if ( ! ( added && added.length ) && ! ( removed && removed.length ) ) {
			return;
		}
		var gone = ( removed || [] ).map( function ( style ) {
			return style && style.css;
		} );
		var current = select( 'core/block-editor' ).getSettings().styles || [];
		var styles = current.filter( function ( style ) {
			return ! style || gone.indexOf( style.css ) < 0;
		} ).concat( added || [] );
		// The editor's settings are where the canvas's styles come from; the
		// block editor's, what it draws now.
		if ( dispatch( 'core/editor' ) && dispatch( 'core/editor' ).updateEditorSettings ) {
			var editorStyles = ( select( 'core/editor' ).getEditorSettings().styles || [] ).filter( function ( style ) {
				return ! style || gone.indexOf( style.css ) < 0;
			} ).concat( added || [] );
			dispatch( 'core/editor' ).updateEditorSettings( { styles: editorStyles } );
		}
		dispatch( 'core/block-editor' ).updateSettings( { styles: styles } );
	}

	/**
	 * Put a finished job's blocks in the editor.
	 *
	 * @param {Object}      result  The job's result.
	 * @param {string|null} target  The block a change of one section replaces.
	 * @return {string|null} What happened, for a notice; null when nothing did.
	 */
	function apply( result, target ) {
		// Gemini changed nothing: the editor is left as it is (no undo step
		// for nothing), and its notes say why.
		if ( result.same ) {
			return null;
		}
		var parsed = wp.blocks.parse( result.markup || '' );
		var store = select( 'core/block-editor' );
		var editor = select( 'core/editor' );
		if ( ! parsed.length ) {
			throw new Error( __( 'Gemini\'s answer came back empty. Ask again.', 'kerf-pro' ) );
		}
		var blocks = dispatch( 'core/block-editor' );
		var said;
		if ( 'block' === result.scope ) {
			var id = target && store.getBlock( target ) ? target : blockAt( result.path );
			if ( id ) {
				blocks.replaceBlocks( id, parsed );
				said = __( 'Gemini changed the section. Look it over, then save — or undo it (Ctrl+Z).', 'kerf-pro' );
			} else {
				blocks.insertBlocks( parsed );
				said = __( 'The section was not there any more, so Gemini\'s version was added at the end of the page. Look it over, then save — or undo it (Ctrl+Z).', 'kerf-pro' );
			}
		} else {
			var order = store.getBlockOrder();
			if ( order.length ) {
				blocks.replaceBlocks( order, parsed );
			} else {
				blocks.insertBlocks( parsed, 0 );
			}
			said = result.title
				? __( 'Gemini made this page in your design. Look it over, then save — or undo it (Ctrl+Z).', 'kerf-pro' )
				: __( 'Gemini changed the page. Look it over, then save — or undo it (Ctrl+Z).', 'kerf-pro' );
		}
		var edits = {};
		if ( result.title && ! String( editor.getEditedPostAttribute( 'title' ) || '' ).trim() ) {
			edits.title = result.title;
		}
		if ( result.featured && ! editor.getEditedPostAttribute( 'featured_media' ) ) {
			edits.featured_media = result.featured;
		}
		if ( Object.keys( edits ).length ) {
			dispatch( 'core/editor' ).editPost( edits );
		}
		restyle( result.styles, result.removed );
		blocks.selectBlock( parsed[ 0 ].clientId );
		return said;
	}

	// ─────────────────────────────────────────────────────────────────────────
	// The owner's words, and pictures
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * A box for words that reads what is pasted or added for its shape.
	 *
	 * @param {Object} props { id, label, help, value, onChange, rows, placeholder }.
	 * @return {Object}
	 */
	function WordsField( props ) {
		var readingState = useState( false );
		var reading = readingState[ 0 ];
		var setReading = readingState[ 1 ];
		var errorState = useState( '' );
		var error = errorState[ 0 ];
		var setError = errorState[ 1 ];
		var latest = useRef( props.value );
		var file = useRef();
		latest.current = props.value;

		// Words read from a paste or a file are blocks of their own: a blank
		// line keeps them apart from what is before and after them, or a
		// heading pasted after a table would be read as its last row.
		function put( text, at ) {
			var value = latest.current || '';
			var start = at ? at[ 0 ] : value.length;
			var end = at ? at[ 1 ] : value.length;
			var before = value.slice( 0, start );
			var after = value.slice( end );
			if ( before.trim() ) {
				before = before.replace( /[ \t]*\n?[ \t]*$/, '' ).replace( /\n*$/, '' ) + '\n\n';
			}
			if ( after.trim() ) {
				after = '\n\n' + after.replace( /^\s*/, '' );
			}
			props.onChange( before + text + after );
		}

		function read( data, at, fallback ) {
			setReading( true );
			setError( '' );
			var request = data instanceof window.FormData
				? { path: '/kerf/v1/ai/words', method: 'POST', body: data }
				: { path: '/kerf/v1/ai/words', method: 'POST', data: data };
			wp.apiFetch( request ).then( function ( answer ) {
				put( answer.words, at );
			}, function ( failed ) {
				setError( message( failed ) );
				if ( fallback ) {
					put( fallback, at );
				}
			} ).then( function () {
				setReading( false );
			} );
		}

		function onPaste( event ) {
			var clip = event.clipboardData;
			if ( ! clip ) {
				return;
			}
			var html = clip.getData( 'text/html' );
			var text = clip.getData( 'text/plain' );
			var markup = MARKUP.test( text ) && CLOSES.test( text );
			if ( ! markup && ! ( html && SHAPED.test( html ) ) ) {
				return;
			}
			event.preventDefault();
			read( markup ? { text: text } : { html: html }, [ event.target.selectionStart, event.target.selectionEnd ], text );
		}

		return el( C.BaseControl, { id: props.id, label: props.label, help: props.help, __nextHasNoMarginBottom: true },
			el( 'textarea', {
				id: props.id,
				className: 'components-textarea-control__input kerf-ai-words',
				rows: props.rows || 8,
				value: props.value,
				placeholder: props.placeholder,
				readOnly: reading,
				onChange: function ( event ) {
					props.onChange( event.target.value );
				},
				onPaste: onPaste
			} ),
			el( 'div', { className: 'kerf-ai-words__tools' },
				el( C.Button, {
					variant: 'secondary',
					size: 'compact',
					disabled: reading,
					onClick: function () {
						file.current.click();
					}
				}, __( 'Add from a file', 'kerf-pro' ) ),
				reading && el( C.Spinner ),
				reading && el( 'span', null, __( 'Reading it…', 'kerf-pro' ) )
			),
			el( 'input', {
				ref: file,
				type: 'file',
				hidden: true,
				accept: '.docx,.md,.markdown,.txt,.html,.htm',
				onChange: function ( event ) {
					var chosen = event.target.files && event.target.files[ 0 ];
					event.target.value = '';
					if ( chosen ) {
						var data = new window.FormData();
						data.append( 'file', chosen, chosen.name );
						read( data, null, '' );
					}
				}
			} ),
			error && el( C.Notice, { status: 'warning', isDismissible: false, className: 'kerf-ai-notice' }, error )
		);
	}

	/**
	 * Pictures from the media library.
	 *
	 * @param {Object} props { label, help, value: Object[], onChange }.
	 * @return {Object}
	 */
	function Pictures( props ) {
		var MediaUpload = wp.blockEditor.MediaUpload;
		var Check = wp.blockEditor.MediaUploadCheck || Fragment;
		var value = props.value || [];
		return el( C.BaseControl, { label: props.label, help: props.help, __nextHasNoMarginBottom: true },
			value.length > 0 && el( 'ul', { className: 'kerf-ai-pictures' }, value.map( function ( picture ) {
				return el( 'li', { key: picture.id },
					el( 'img', { src: picture.url, alt: picture.alt } ),
					el( C.Button, {
						icon: 'no-alt',
						size: 'small',
						label: __( 'Take this picture out', 'kerf-pro' ),
						onClick: function () {
							props.onChange( value.filter( function ( other ) {
								return other.id !== picture.id;
							} ) );
						}
					} )
				);
			} ) ),
			el( Check, null, el( MediaUpload, {
				multiple: true,
				allowedTypes: [ 'image' ],
				value: value.map( function ( picture ) {
					return picture.id;
				} ),
				onSelect: function ( media ) {
					props.onChange( ( Array.isArray( media ) ? media : [ media ] ).slice( 0, state.pictures ).map( function ( item ) {
						var sizes = item.sizes || {};
						return { id: item.id, url: ( sizes.thumbnail || sizes.medium || item ).url, alt: item.alt || item.title || '' };
					} ) );
				},
				render: function ( media ) {
					return el( C.Button, { variant: 'secondary', onClick: media.open }, value.length ? __( 'Change the pictures', 'kerf-pro' ) : __( 'Choose pictures', 'kerf-pro' ) );
				}
			} ) )
		);
	}

	/**
	 * A job's steps, as they go.
	 *
	 * @param {Object} props { job, onStop }.
	 * @return {Object}
	 */
	function Progress( props ) {
		var job = props.job || {};
		return el( 'div', { className: 'kerf-ai-progress', 'aria-live': 'polite' },
			el( 'ol', null, ( job.steps || [] ).map( function ( step, i ) {
				return el( 'li', { key: i, className: 'is-' + step.state },
					'now' === step.state ? el( C.Spinner ) : null,
					el( 'span', null, step.label )
				);
			} ) ),
			job.note && el( 'p', { className: 'kerf-help' }, job.note ),
			el( 'p', { className: 'kerf-help' }, __( 'A minute or two. You can close this and keep working: the answer goes into the page when it is ready, as long as this page stays open.', 'kerf-pro' ) ),
			props.onStop && el( C.Button, { variant: 'tertiary', onClick: props.onStop }, __( 'Stop', 'kerf-pro' ) )
		);
	}

	// ─────────────────────────────────────────────────────────────────────────
	// The window
	// ─────────────────────────────────────────────────────────────────────────

	/**
	 * Make this page, or change it.
	 *
	 * @param {Object} props { mode, clientId, busy, job, error, onStart, onStop, onClose }.
	 * @return {Object}
	 */
	function AiWindow( props ) {
		var make = 'make' === props.mode;
		var editor = select( 'core/editor' );
		var kindState = useState( 'about' );
		var titleState = useState( String( editor.getEditedPostAttribute( 'title' ) || '' ) );
		var wordsState = useState( '' );
		var notesState = useState( '' );
		var askState = useState( '' );
		var picturesState = useState( [] );
		var scopeState = useState( props.clientId ? 'block' : 'page' );
		var empty = isEmpty();
		var scope = props.clientId ? scopeState[ 0 ] : 'page';
		var section = props.clientId ? blockLabel( props.clientId ) : '';

		function start() {
			var ids = picturesState[ 0 ].map( function ( picture ) {
				return picture.id;
			} );
			if ( make ) {
				props.onStart( 'page', {
					kind: kindState[ 0 ],
					title: titleState[ 0 ],
					words: wordsState[ 0 ],
					notes: notesState[ 0 ],
					pictures: ids,
					post_id: postId()
				}, null );
				return;
			}
			var target = 'block' === scope ? props.clientId : null;
			var list = target ? [ select( 'core/block-editor' ).getBlock( target ) ] : topBlocks();
			props.onStart( 'edit', {
				post_id: postId(),
				scope: scope,
				markup: wp.blocks.serialize( list ),
				ask: askState[ 0 ],
				words: wordsState[ 0 ],
				pictures: ids,
				path: target ? blockPath( target ) : []
			}, target );
		}

		var canGo = make
			? titleState[ 0 ].trim() && ( wordsState[ 0 ] + notesState[ 0 ] ).trim().length >= 20
			: askState[ 0 ].trim().length >= 4;

		var body;
		if ( props.busy ) {
			body = el( Progress, { job: props.job, onStop: props.onStop } );
		} else if ( make ) {
			body = el( Fragment, null,
				el( 'p', { className: 'kerf-ai-lead' }, __( 'Gemini reads how your site\'s pages are written — its home page and its stylesheet — and makes this one the same way, from your words and pictures. It adds no facts: prices, reviews and numbers are only those you give.', 'kerf-pro' ) ),
				el( 'div', { className: 'kerf-ai-row' },
					el( C.SelectControl, {
						label: __( 'What kind of page', 'kerf-pro' ),
						value: kindState[ 0 ],
						options: state.kinds,
						onChange: function ( kind ) {
							kindState[ 1 ]( kind );
							var chosen = state.kinds.filter( function ( item ) {
								return item.value === kind;
							} )[ 0 ];
							if ( chosen && 'other' !== kind && ! titleState[ 0 ].trim() ) {
								titleState[ 1 ]( chosen.label );
							}
						},
						__nextHasNoMarginBottom: true
					} ),
					el( C.TextControl, {
						label: __( 'Its title', 'kerf-pro' ),
						value: titleState[ 0 ],
						maxLength: 120,
						onChange: titleState[ 1 ],
						__nextHasNoMarginBottom: true
					} )
				),
				el( WordsField, {
					id: 'kerf-ai-words',
					label: __( 'What it should say', 'kerf-pro' ),
					help: __( 'Paste from Word, Google Docs, a web page or Markdown — headings, lists and tables are kept — or add a Word (.docx), Markdown, HTML or text file. Notes are fine too.', 'kerf-pro' ),
					rows: 12,
					value: wordsState[ 0 ],
					onChange: wordsState[ 1 ],
					placeholder: __( 'The page\'s text, or notes: who we are, what we offer, how to reach us…', 'kerf-pro' )
				} ),
				el( Pictures, {
					label: __( 'Its pictures', 'kerf-pro' ),
					help: sprintf(
						/* translators: %d: how many pictures at most. */
						__( 'Up to %d, from your media library. The page shows only these.', 'kerf-pro' ),
						state.pictures
					),
					value: picturesState[ 0 ],
					onChange: picturesState[ 1 ]
				} ),
				el( C.TextareaControl, {
					label: __( 'Anything else (optional)', 'kerf-pro' ),
					value: notesState[ 0 ],
					rows: 2,
					placeholder: __( 'Put the opening hours first. Keep it short.', 'kerf-pro' ),
					onChange: notesState[ 1 ],
					__nextHasNoMarginBottom: true
				} ),
				! empty && el( C.Notice, { status: 'warning', isDismissible: false, className: 'kerf-ai-notice' }, __( 'What is on this page now is replaced. Undo (Ctrl+Z) brings it back until you save.', 'kerf-pro' ) )
			);
		} else {
			body = el( Fragment, null,
				el( 'p', { className: 'kerf-ai-lead' }, __( 'Say what should change. Gemini changes only that, in your design; the rest stays exactly as it is.', 'kerf-pro' ) ),
				props.clientId && el( C.RadioControl, {
					label: __( 'Change', 'kerf-pro' ),
					selected: scope,
					options: [
						/* translators: %s: the selected block's name, such as "section.hero". */
						{ value: 'block', label: sprintf( __( 'The selected section: %s', 'kerf-pro' ), section ) },
						{ value: 'page', label: __( 'The whole page', 'kerf-pro' ) }
					],
					onChange: scopeState[ 1 ]
				} ),
				el( C.TextareaControl, {
					label: __( 'What should change', 'kerf-pro' ),
					value: askState[ 0 ],
					rows: 4,
					placeholder: __( 'Add a question about parking. Make these three cards a list. Use the new opening hours below. Make the heading shorter.', 'kerf-pro' ),
					onChange: askState[ 1 ],
					__nextHasNoMarginBottom: true
				} ),
				el( WordsField, {
					id: 'kerf-ai-change-words',
					label: __( 'New words for it (optional)', 'kerf-pro' ),
					help: __( 'Paste from Word, Google Docs, a web page or Markdown, or add a file: headings, lists and tables are kept.', 'kerf-pro' ),
					rows: 6,
					value: wordsState[ 0 ],
					onChange: wordsState[ 1 ]
				} ),
				el( Pictures, {
					label: __( 'New pictures (optional)', 'kerf-pro' ),
					help: __( 'The pictures already there stay available to it.', 'kerf-pro' ),
					value: picturesState[ 0 ],
					onChange: picturesState[ 1 ]
				} )
			);
		}

		return el( C.Modal, {
			title: make ? __( 'Make this page with AI', 'kerf-pro' ) : __( 'Change it with AI', 'kerf-pro' ),
			icon: icon,
			className: 'kerf-ai-window',
			size: 'large',
			onRequestClose: props.onClose,
			shouldCloseOnClickOutside: false
		},
			props.error && el( C.Notice, { status: 'error', isDismissible: false, className: 'kerf-ai-notice' }, props.error ),
			body,
			! props.busy && el( 'div', { className: 'kerf-ai-window__foot' },
				el( C.Button, { variant: 'tertiary', onClick: props.onClose }, __( 'Cancel', 'kerf-pro' ) ),
				el( C.Button, { variant: 'primary', icon: icon, disabled: ! canGo, onClick: start },
					make ? ( empty ? __( 'Make the page', 'kerf-pro' ) : __( 'Make it again', 'kerf-pro' ) ) : __( 'Change it', 'kerf-pro' )
				)
			)
		);
	}

	// ─────────────────────────────────────────────────────────────────────────
	// The sidebar
	// ─────────────────────────────────────────────────────────────────────────

	function AiPanel( props ) {
		var selected = useSelect( function ( pick ) {
			return pick( 'core/block-editor' ).getSelectedBlockClientId();
		}, [] );
		var empty = useSelect( function () {
			return isEmpty();
		}, [] );

		if ( ! state.ready ) {
			return el( C.PanelBody, null,
				el( C.Notice, { status: 'warning', isDismissible: false, className: 'kerf-ai-notice' }, state.why ),
				state.fix && state.fix.url && el( C.Button, { variant: 'secondary', href: state.fix.url }, state.fix.label )
			);
		}

		return el( Fragment, null,
			el( C.PanelBody, null,
				el( 'p', { className: 'kerf-help' }, __( 'Gemini writes in your design — the same sections, classes, colours and fonts as your home page. What it writes goes into the editor: look it over, then save, or undo it.', 'kerf-pro' ) ),
				props.busy
					? el( Fragment, null,
						el( Progress, { job: props.job, onStop: props.onStop } ),
						el( C.Button, { variant: 'secondary', onClick: props.onShow }, __( 'Show the window', 'kerf-pro' ) )
					)
					: el( 'div', { className: 'kerf-ai-actions' },
						el( C.Button, {
							variant: empty ? 'primary' : 'secondary',
							icon: icon,
							onClick: function () {
								openWindow( { mode: 'make' } );
							}
						}, empty ? __( 'Make this page with AI', 'kerf-pro' ) : __( 'Make this page again', 'kerf-pro' ) ),
						! empty && el( C.Button, {
							variant: 'primary',
							icon: icon,
							onClick: function () {
								openWindow( { mode: 'change', clientId: selected } );
							}
						}, selected ? __( 'Change the selected section', 'kerf-pro' ) : __( 'Change this page', 'kerf-pro' ) )
					),
				props.error && ! props.busy && el( C.Notice, { status: 'error', isDismissible: true, onRemove: props.onClearError, className: 'kerf-ai-notice' }, props.error )
			),
			props.notes && props.notes.length > 0 && el( C.PanelBody, { title: __( 'What Gemini said', 'kerf-pro' ), initialOpen: true },
				el( 'ul', { className: 'kerf-ai-said' }, props.notes.map( function ( note, i ) {
					return el( 'li', { key: i }, note );
				} ) )
			)
		);
	}

	// ─────────────────────────────────────────────────────────────────────────
	// Everything, together
	// ─────────────────────────────────────────────────────────────────────────

	function KerfAi() {
		var windowState = useState( null ); // { mode, clientId } while open
		var jobState = useState( null );
		var busyState = useState( false );
		var errorState = useState( '' );
		var notesState = useState( [] );
		var target = useRef( null );
		var current = useRef( null );
		var win = windowState[ 0 ];

		function finish( done ) {
			var result = done.result || {};
			var said;
			try {
				said = apply( result, target.current );
			} catch ( failed ) {
				errorState[ 1 ]( message( failed ) );
				busyState[ 1 ]( false );
				return;
			}
			wp.apiFetch( { path: '/kerf/v1/ai/jobs/' + done.id + '/taken', method: 'POST' } ).catch( function () {} );
			notesState[ 1 ]( result.notes || [] );
			busyState[ 1 ]( false );
			jobState[ 1 ]( null );
			windowState[ 1 ]( null );
			dispatch( 'core/notices' ).createNotice(
				said ? 'success' : 'info',
				said || __( 'Gemini changed nothing here. Its notes are in the Kerf AI sidebar: say more precisely what should change, and ask again.', 'kerf-pro' ),
				{ type: 'snackbar', id: 'kerf-ai-done' }
			);
			if ( ! said || ( result.notes && result.notes.length ) ) {
				openSidebar();
			}
		}

		function run( promise ) {
			busyState[ 1 ]( true );
			errorState[ 1 ]( '' );
			promise.then( finish, function ( failed ) {
				errorState[ 1 ]( message( failed ) );
				busyState[ 1 ]( false );
				jobState[ 1 ]( null );
			} );
		}

		function start( route, data, clientId ) {
			target.current = clientId;
			run( wp.apiFetch( { path: '/kerf/v1/ai/' + route, method: 'POST', data: data } ).then( function ( started ) {
				current.current = started.id;
				jobState[ 1 ]( started );
				return follow( started, jobState[ 1 ] );
			} ) );
		}

		function stop() {
			if ( current.current ) {
				wp.apiFetch( { path: '/kerf/v1/ai/jobs/' + current.current + '/cancel', method: 'POST' } ).catch( function () {} );
			}
		}

		// Opened from anywhere: the sidebar, a block's toolbar, the notice.
		useEffect( function () {
			var open = function ( event ) {
				if ( ! state.ready ) {
					openSidebar();
					return;
				}
				var detail = event.detail || {};
				errorState[ 1 ]( '' );
				windowState[ 1 ]( { mode: detail.mode || 'make', clientId: detail.clientId || null } );
			};
			window.addEventListener( OPEN, open );
			return function () {
				window.removeEventListener( OPEN, open );
			};
		}, [] );

		// On the way in: Kerf → Make a page sent the owner here; or AI work for
		// this page was left running, or finished while the page was closed.
		useEffect( function () {
			if ( ! state.ready ) {
				return;
			}
			if ( state.open ) {
				windowState[ 1 ]( { mode: 'make', clientId: null } );
			}
			var id = postId();
			if ( ! id ) {
				return;
			}
			wp.apiFetch( { path: '/kerf/v1/ai/editor?post_id=' + id } ).then( function ( answer ) {
				var job = answer && answer.job;
				if ( ! job ) {
					return;
				}
				current.current = job.id;
				target.current = null;
				if ( 'working' === job.status ) {
					jobState[ 1 ]( job );
					openSidebar();
					run( follow( job.id, jobState[ 1 ] ) );
					return;
				}
				dispatch( 'core/notices' ).createInfoNotice( __( 'Gemini finished the work you asked for on this page while it was closed.', 'kerf-pro' ), {
					id: 'kerf-ai-waiting',
					isDismissible: true,
					actions: [ {
						label: __( 'Put it in the editor', 'kerf-pro' ),
						onClick: function () {
							dispatch( 'core/notices' ).removeNotice( 'kerf-ai-waiting' );
							finish( job );
						}
					} ]
				} );
			} ).catch( function () {} );
		}, [] );

		// An empty page: offered at once.
		var empty = useSelect( function () {
			return isEmpty();
		}, [] );
		useEffect( function () {
			var notices = dispatch( 'core/notices' );
			if ( ! state.ready || ! empty ) {
				notices.removeNotice( NOTICE );
				return;
			}
			notices.createInfoNotice( __( 'Make this page with AI: paste your words — from Word, Google Docs or anywhere — choose pictures, and Gemini writes it in your site\'s design.', 'kerf-pro' ), {
				id: NOTICE,
				isDismissible: true,
				actions: [ {
					label: __( 'Make it with AI', 'kerf-pro' ),
					onClick: function () {
						openWindow( { mode: 'make' } );
					}
				} ]
			} );
		}, [ empty ] );

		return el( Fragment, null,
			host.PluginSidebarMoreMenuItem && el( host.PluginSidebarMoreMenuItem, { target: 'kerf-ai', icon: icon }, __( 'Kerf AI', 'kerf-pro' ) ),
			el( host.PluginSidebar, { name: 'kerf-ai', title: __( 'Kerf AI', 'kerf-pro' ), icon: icon },
				el( AiPanel, {
					busy: busyState[ 0 ],
					job: jobState[ 0 ],
					error: errorState[ 0 ],
					notes: notesState[ 0 ],
					onStop: stop,
					onClearError: function () {
						errorState[ 1 ]( '' );
					},
					onShow: function () {
						windowState[ 1 ]( { mode: 'change', clientId: target.current } );
					}
				} )
			),
			win && el( AiWindow, {
				mode: win.mode,
				clientId: win.clientId,
				busy: busyState[ 0 ],
				job: jobState[ 0 ],
				error: errorState[ 0 ],
				onStart: start,
				onStop: stop,
				onClose: function () {
					windowState[ 1 ]( null );
				}
			} )
		);
	}

	wp.plugins.registerPlugin( 'kerf-ai', { icon: icon, render: KerfAi } );

	// "Change with AI" in the selected block's toolbar — where the owner may
	// change it at all (not a block client mode locks, §5.38).
	if ( state.ready && wp.hooks && wp.compose && wp.blockEditor && wp.blockEditor.BlockControls && C.ToolbarButton ) {
		var withButton = wp.compose.createHigherOrderComponent( function ( BlockEdit ) {
			return function ( props ) {
				if ( ! props.isSelected ) {
					return el( BlockEdit, props );
				}
				var store = select( 'core/block-editor' );
				var mode = store.getBlockEditingMode ? store.getBlockEditingMode( props.clientId ) : 'default';
				if ( 'default' !== mode ) {
					return el( BlockEdit, props );
				}
				return el( Fragment, null,
					el( BlockEdit, props ),
					el( wp.blockEditor.BlockControls, { group: 'other' },
						el( C.ToolbarButton, {
							icon: icon,
							label: __( 'Change with AI', 'kerf-pro' ),
							onClick: function () {
								openWindow( { mode: 'change', clientId: props.clientId } );
							}
						} )
					)
				);
			};
		}, 'withKerfAiButton' );
		wp.hooks.addFilter( 'editor.BlockEdit', 'kerf-pro/ai-button', withButton );
	}
}( window.wp ) );
