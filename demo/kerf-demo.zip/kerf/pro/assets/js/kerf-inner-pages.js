/**
 * Kerf → Inner pages: the live preview, "Read from home page", and the
 * copy buttons — and, on the import's report, the home page's measurement
 * from the free plugin's reading of it (kerf-import-report.js).
 *
 * The preview is the real page in a same-origin frame. Typing a colour or a
 * font sets the matching `--kerf-*` property on the frame's `.kerf-shell`
 * directly, and the layout switches set its `data-kerf-*` attributes, so what
 * you see is exactly what saving will produce — without saving.
 *
 * @package kerf-pro
 */

( function () {
	'use strict';

	var data = window.KerfShellAdmin || {};
	var form = document.getElementById( 'kerf-shell-form' );
	var frame = document.querySelector( '.kerf-shell-preview iframe' );

	// ── Live preview ────────────────────────────────────────────────────────

	function shellInFrame() {
		try {
			return frame && frame.contentDocument ? frame.contentDocument.querySelector( '.kerf-shell' ) : null;
		} catch ( e ) {
			return null;
		}
	}

	function applyAll() {
		var shell = shellInFrame();
		if ( ! shell || ! form ) {
			return;
		}
		Array.prototype.forEach.call( form.querySelectorAll( '[data-token]' ), function ( input ) {
			var value = input.value.trim();
			var name = '--kerf-' + input.getAttribute( 'data-token' );
			if ( value ) {
				shell.style.setProperty( name, value );
			} else {
				shell.style.removeProperty( name );
			}
		} );
		Array.prototype.forEach.call( form.querySelectorAll( '[data-layout]' ), function ( input ) {
			var value = 'checkbox' === input.type ? ( input.checked ? '1' : '0' ) : input.value;
			shell.setAttribute( 'data-kerf-' + input.getAttribute( 'data-layout' ), value );
		} );
	}

	if ( form ) {
		form.addEventListener( 'input', function ( event ) {
			var target = event.target;
			// A colour swatch writes its hex into the text field beside it.
			if ( target.hasAttribute( 'data-swatch' ) ) {
				var field = form.querySelector( '[data-token="' + target.getAttribute( 'data-swatch' ) + '"]' );
				if ( field ) {
					field.value = target.value;
				}
			}
			applyAll();
		} );
		form.addEventListener( 'change', applyAll );
	}

	if ( frame ) {
		frame.addEventListener( 'load', applyAll );
		Array.prototype.forEach.call( document.querySelectorAll( '[data-preview]' ), function ( button ) {
			button.addEventListener( 'click', function () {
				Array.prototype.forEach.call( document.querySelectorAll( '[data-preview]' ), function ( other ) {
					other.classList.toggle( 'is-pressed', other === button );
				} );
				frame.src = button.getAttribute( 'data-preview' );
			} );
		} );
	}

	// Scale the 1280px-wide page into the column, as a thumbnail of the real width.
	function fit() {
		if ( ! frame ) {
			return;
		}
		var box = frame.parentNode;
		var scale = Math.min( 1, box.clientWidth / 1280 );
		frame.style.width = '1280px';
		frame.style.height = Math.round( box.clientHeight / scale ) + 'px';
		frame.style.transform = 'scale(' + scale + ')';
	}
	window.addEventListener( 'resize', fit );
	fit();

	// ── Read from home page ─────────────────────────────────────────────────

	var readButton = document.getElementById( 'kerf-shell-read' );
	var status = document.querySelector( '.kerf-shell-measure__status' );

	function say( text ) {
		if ( status ) {
			status.textContent = text;
		}
	}

	function readHome() {
		if ( ! window.kerfDesignRead || ! window.wp || ! window.wp.apiFetch ) {
			return Promise.reject( new Error( 'missing scripts' ) );
		}
		say( data.strings.reading );
		return window.kerfDesignRead.read( data.measureUrl ).then( function ( measurement ) {
			// What scripts made, for the editor (inc/kerf-capture.php): saved
			// apart from the measurement.
			var captured = measurement.captured;
			delete measurement.captured;
			if ( captured ) {
				window.wp.apiFetch( { path: '/kerf/v1/captured', method: 'POST', data: captured } ).catch( function () {} );
			}
			return window.wp.apiFetch( { path: data.restPath, method: 'POST', data: measurement } );
		} );
	}

	if ( readButton ) {
		readButton.addEventListener( 'click', function () {
			readButton.disabled = true;
			readHome().then( function () {
				say( data.strings.done );
				window.location.reload();
			} ).catch( function ( error ) {
				readButton.disabled = false;
				say( data.strings.failed + ' ' + ( error && error.message ? error.message : '' ) );
			} );
		} );
	}

	// The import's report: the free plugin reads the home page for its editor
	// (kerf-import-report.js) and says what it read; its measurement is kept
	// here, so the page is loaded once.
	var afterImport = document.querySelector( '.kerf-measure-after-import' );
	if ( afterImport ) {
		document.addEventListener( 'kerf-page-read', function ( event ) {
			var detail = event.detail || {};
			if ( 0 !== detail.page ) {
				return;
			}
			if ( detail.failed || ! detail.result || ! window.wp || ! window.wp.apiFetch ) {
				afterImport.textContent = afterImport.getAttribute( 'data-failed' );
				return;
			}
			window.wp.apiFetch( { path: data.restPath, method: 'POST', data: detail.result } ).then( function () {
				afterImport.textContent = afterImport.getAttribute( 'data-done' );
			} ).catch( function () {
				afterImport.textContent = afterImport.getAttribute( 'data-failed' );
			} );
		} );
	}

	// Copy buttons are the free plugin's, on every Kerf screen (assets/js/kerf-admin.js).
}() );
