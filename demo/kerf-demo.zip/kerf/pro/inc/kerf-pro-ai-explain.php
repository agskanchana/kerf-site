<?php
/**
 * AI, phase 1: an import's report in plain words.
 *
 * "87%, 14 selectors no longer in the markup" means little to a site owner.
 * After an import, Gemini reads the report and says what carried over, what
 * did not and whether it shows — and writes the message to paste into the AI
 * tool that made the design, so the next import is clean. Prose only: it
 * reads the report and changes nothing (.github/AI-PLAN.md, §5.46).
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The last import's report, kept for its explanation (and the explanation, once made). */
const KERF_PRO_AI_REPORT_OPTION = 'kerf_pro_ai_report';

/**
 * Keep an import's report, so it can be explained — and keep its explanation
 * when the report is the same one.
 *
 * @param array $result The import's result.
 * @return array What was kept.
 */
function kerf_pro_ai_keep_report( $result ) {
	// The same note is often made once per element; the model needs it once.
	$report = array();
	foreach ( isset( $result['report'] ) ? (array) $result['report'] : array() as $entry ) {
		if ( isset( $entry['category'], $entry['message'] ) ) {
			$report[ $entry['category'] . '|' . $entry['message'] ] = array( 'category' => (string) $entry['category'], 'message' => (string) $entry['message'] );
		}
	}

	$keep = array(
		'score'   => isset( $result['audit']['score'] ) ? (int) $result['audit']['score'] : 0,
		'missing' => array_slice( array_map( 'strval', isset( $result['audit']['missing'] ) ? (array) $result['audit']['missing'] : array() ), 0, 80 ),
		'actions' => array_slice( array_map( 'strval', isset( $result['actions'] ) ? (array) $result['actions'] : array() ), 0, 60 ),
		'report'  => array_slice( array_values( $report ), 0, 120 ),
		'dry'     => ! empty( $result['dry_run'] ),
	);
	$keep['hash'] = md5( wp_json_encode( $keep ) );

	$kept = get_option( KERF_PRO_AI_REPORT_OPTION, array() );
	if ( is_array( $kept ) && isset( $kept['hash'], $kept['explained'] ) && $kept['hash'] === $keep['hash'] ) {
		$keep['explained'] = $kept['explained'];
	}
	update_option( KERF_PRO_AI_REPORT_OPTION, $keep, false );

	return $keep;
}

/**
 * After an import's report: keep it, and offer the explanation — or show it,
 * when this very report was explained before.
 *
 * The answer is drawn here and filled in by the script as text
 * (assets/js/kerf-ai.js): nothing the model writes is ever markup.
 *
 * @param array $result
 */
function kerf_pro_ai_explain_panel( $result ) {
	if ( ! kerf_pro_licensed() || empty( $result['audit'] ) ) {
		return;
	}
	$kept = kerf_pro_ai_keep_report( $result );
	?>
	<section class="kerf-panel kerf-ai kerf-ai-explain" data-kerf-ai-explain<?php echo ! empty( $kept['explained'] ) ? ' data-explained="' . esc_attr( (string) wp_json_encode( $kept['explained'] ) ) . '"' : ''; ?>>
		<div class="kerf-panel__head">
			<h2><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'In plain words', 'kerf-pro' ); ?></h2>
			<p><?php esc_html_e( 'Gemini reads this report and says what carried over, what did not and whether a visitor would notice — and writes the message to give the AI tool that made your design, so the next import is clean.', 'kerf-pro' ); ?></p>
		</div>
		<div class="kerf-panel__body">
			<?php if ( kerf_pro_ai_available() ) : ?>
				<p data-kerf-ai-explain-start><button type="button" class="kerf-btn kerf-btn--primary" data-kerf-ai-explain-go><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Explain it', 'kerf-pro' ); ?></button></p>
			<?php elseif ( '' === kerf_pro_ai_key() && current_user_can( 'edit_theme_options' ) ) : ?>
				<p class="kerf-help">
					<?php
					printf(
						/* translators: %s: link to Kerf → Settings. */
						esc_html__( 'Add your Gemini key under %s to have it explained.', 'kerf-pro' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=kerf-settings' ) ) . '">' . esc_html__( 'Kerf → Settings', 'kerf-pro' ) . '</a>'
					);
					?>
				</p>
			<?php else : ?>
				<p class="kerf-help"><?php esc_html_e( 'AI is not on for your account on this site.', 'kerf-pro' ); ?></p>
			<?php endif; ?>

			<div class="kerf-note kerf-note--bad" role="alert" data-kerf-ai-error hidden><?php echo kerf_ui_icon( 'stop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><p></p></div>

			<div class="kerf-ai-explain__out" data-kerf-ai-explain-out hidden>
				<p class="kerf-ai-explain__summary" data-summary></p>
				<ul class="kerf-check" data-problems hidden></ul>
				<div class="kerf-ai-explain__tool" data-for-tool hidden>
					<h3><?php esc_html_e( 'For the AI tool that made your design', 'kerf-pro' ); ?></h3>
					<p class="kerf-help"><?php esc_html_e( 'Paste this into it, then import the files it gives back.', 'kerf-pro' ); ?></p>
					<textarea readonly rows="7" id="kerf-ai-explain-message" aria-label="<?php esc_attr_e( 'The message for your AI tool', 'kerf-pro' ); ?>"></textarea>
					<p><button type="button" class="kerf-btn kerf-copy" data-copy="kerf-ai-explain-message"><?php echo kerf_ui_icon( 'copy' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Copy the message', 'kerf-pro' ); ?></button></p>
				</div>
			</div>

			<template data-kerf-ai-problem>
				<li class="kerf-check--warn">
					<span class="kerf-check__mark"><?php echo kerf_ui_icon( 'alert' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
					<div class="kerf-check__text">
						<strong data-what></strong>
						<p data-why></p>
						<p class="kerf-ai-explain__fix" data-fix><b><?php esc_html_e( 'What to do:', 'kerf-pro' ); ?></b> <span></span></p>
					</div>
				</li>
			</template>
		</div>
	</section>
	<?php
}
add_action( 'kerf_import_report_after', 'kerf_pro_ai_explain_panel' );

/**
 * The route.
 */
function kerf_pro_ai_explain_routes() {
	register_rest_route( 'kerf/v1', '/ai/explain', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_explain',
		'permission_callback' => 'kerf_pro_ai_rest_permission',
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_explain_routes' );

/**
 * Explain the last import.
 *
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_ai_rest_explain() {
	$explained = kerf_pro_ai_explain();
	return is_wp_error( $explained ) ? $explained : rest_ensure_response( $explained );
}

/**
 * The last import, explained — once per report; asked again, the same answer.
 *
 * @return array{summary:string,problems:array[],for_your_ai_tool:string}|WP_Error
 */
function kerf_pro_ai_explain() {
	$report = get_option( KERF_PRO_AI_REPORT_OPTION, array() );
	if ( ! is_array( $report ) || empty( $report['hash'] ) ) {
		return new WP_Error( 'kerf_ai_nothing', __( 'There is no import to explain yet.', 'kerf-pro' ), array( 'status' => 404 ) );
	}
	if ( ! empty( $report['explained'] ) ) {
		return $report['explained'];
	}

	$answer = kerf_pro_ai_request(
		'explain',
		kerf_pro_ai_explain_instructions(),
		array( array( 'text' => kerf_pro_ai_explain_input( $report ) ) ),
		array(
			'tier'        => 'flash',
			'json'        => true,
			'temperature' => 0.3,
			'schema'      => array(
				'type'       => 'OBJECT',
				'properties' => array(
					'summary'          => array( 'type' => 'STRING' ),
					'problems'         => array(
						'type'  => 'ARRAY',
						'items' => array(
							'type'       => 'OBJECT',
							'properties' => array(
								'what' => array( 'type' => 'STRING' ),
								'why'  => array( 'type' => 'STRING' ),
								'fix'  => array( 'type' => 'STRING' ),
							),
							'required'   => array( 'what', 'why', 'fix' ),
						),
					),
					'for_your_ai_tool' => array( 'type' => 'STRING' ),
				),
				'required'   => array( 'summary', 'problems', 'for_your_ai_tool' ),
			),
		)
	);
	if ( is_wp_error( $answer ) ) {
		return $answer;
	}

	$clean = kerf_pro_ai_explain_clean( $answer['json'] );
	if ( '' === $clean['summary'] ) {
		return new WP_Error( 'kerf_ai_unreadable', __( 'The AI\'s answer could not be read. Try again.', 'kerf-pro' ) );
	}

	// Kept with the report it explains — read again: another import may have
	// finished while the model wrote, and its report is not this one.
	$now = kerf_pro_ai_fresh_option( KERF_PRO_AI_REPORT_OPTION );
	if ( is_array( $now ) && isset( $now['hash'] ) && $now['hash'] === $report['hash'] ) {
		$now['explained'] = $clean;
		update_option( KERF_PRO_AI_REPORT_OPTION, $now, false );
	}
	return $clean;
}

/**
 * The answer, as plain text of sensible length: the model is not trusted to
 * send markup, or a novel.
 *
 * @param mixed $json
 * @return array{summary:string,problems:array[],for_your_ai_tool:string}
 */
function kerf_pro_ai_explain_clean( $json ) {
	$text = static function ( $value, $max ) {
		$value = trim( wp_strip_all_tags( is_scalar( $value ) ? (string) $value : '' ) );
		return mb_strlen( $value ) > $max ? rtrim( mb_substr( $value, 0, $max - 1 ) ) . '…' : $value;
	};
	$json     = is_array( $json ) ? $json : array();
	$problems = array();
	// Five, as asked: the ones that matter most come first.
	foreach ( isset( $json['problems'] ) && is_array( $json['problems'] ) ? array_slice( $json['problems'], 0, 20 ) : array() as $problem ) {
		$what = is_array( $problem ) ? $text( isset( $problem['what'] ) ? $problem['what'] : '', 200 ) : '';
		if ( '' === $what ) {
			continue;
		}
		$problems[] = array(
			'what' => $what,
			'why'  => $text( isset( $problem['why'] ) ? $problem['why'] : '', 400 ),
			'fix'  => $text( isset( $problem['fix'] ) ? $problem['fix'] : '', 400 ),
		);
		if ( 5 === count( $problems ) ) {
			break;
		}
	}
	return array(
		'summary'          => $text( isset( $json['summary'] ) ? $json['summary'] : '', 1200 ),
		'problems'         => $problems,
		'for_your_ai_tool' => $text( isset( $json['for_your_ai_tool'] ) ? $json['for_your_ai_tool'] : '', 4000 ),
	);
}

/**
 * What the model is told.
 *
 * @return string
 */
function kerf_pro_ai_explain_instructions() {
	return implode( "\n", array(
		'You explain a website import to its owner, who is not a developer.',
		'Kerf turned a website design — HTML and CSS made by an AI tool or a designer — into a WordPress site, keeping the design\'s markup exactly as written. Its report lists what it did, what it could not keep, and a score: the share of the design\'s CSS selectors that still match the markup on the site.',
		'Answer in the language of this locale: ' . get_user_locale() . '. Plain, short sentences; no jargon; never blame the owner.',
		'summary: two to five sentences — how faithful the site is, and whether anything a visitor would notice was lost.',
		'problems: at most five, the ones that matter most; for each, what is wrong, why (in plain words), and the fix. Leave out what does not show on the page. Do not invent problems the report does not show.',
		'for_your_ai_tool: a message the owner pastes into the AI tool that made the design, asking it to change the design\'s files so that the next import is clean. Name the files and elements concretely, ask for nothing else to change, and ask for the complete files back. If nothing important was lost, keep it to one or two sentences.',
	) );
}

/**
 * The report, as the model reads it.
 *
 * @param array $report From kerf_pro_ai_keep_report().
 * @return string
 */
function kerf_pro_ai_explain_input( $report ) {
	$lines   = array();
	$lines[] = 'Score: ' . (int) $report['score'] . '%' . ( ! empty( $report['dry'] ) ? ' (a preview: nothing was written)' : '' );
	$lines[] = '';
	$lines[] = 'What Kerf did:';
	foreach ( $report['actions'] as $action ) {
		$lines[] = '- ' . $action;
	}
	if ( $report['report'] ) {
		$lines[] = '';
		$lines[] = 'Notes, by kind (preflight = checked before importing; dropped = left out; media = pictures not found; converted = changed form; asset = moved into the site\'s styles and scripts, not a loss; limit = output incomplete; general = other notes):';
		foreach ( $report['report'] as $entry ) {
			$lines[] = '- [' . $entry['category'] . '] ' . $entry['message'];
		}
	}
	if ( $report['missing'] ) {
		$lines[] = '';
		$lines[] = 'CSS selectors no longer in the markup, so rules written for them do not apply: ' . implode( ', ', $report['missing'] );
	}
	return implode( "\n", $lines );
}
