<?php
/**
 * "Replace everywhere" for background pictures (§5.41).
 *
 * The free plugin's Background picture panel lists every picture an element
 * shows and changes one "only here"; it prints the "everywhere" changes after
 * the design's CSS, draws them in the editor and puts the design's picture
 * back (inc/kerf-backgrounds.php). Making such a change is this: a rule stored
 * apart from the stylesheet with the designer's own selector — what editing
 * that one line of the file would do — saved here, and offered in the panel
 * by assets/js/kerf-background-everywhere.js through its
 * `kerf.backgroundPanel.rule` filter. A rule marked `featured` keeps the
 * designer's value, and prints with each page's featured image in the photo's
 * place (the free plugin's kerf_bg_rules_css()); the same script binds an
 * element's own picture to it (`kerf.backgroundPanel.element`).
 *
 * Kerf Pro's (§8.14). What it changed keeps showing without it, and can be
 * put back without it; a lapsed licence stops it changing more.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST: change a picture everywhere its style draws it. The same route's
 * DELETE, putting the design's picture back, is the free plugin's.
 */
function kerf_bg_everywhere_routes() {
	register_rest_route( 'kerf/v1', '/backgrounds', array(
		'methods'             => 'POST',
		'permission_callback' => static function () {
			if ( ! current_user_can( 'edit_theme_options' ) ) {
				return false;
			}
			return kerf_pro_licensed() ? true : new WP_Error( 'kerf_pro_expired', __( 'Your Kerf Pro licence has expired: renew to change pictures everywhere.', 'kerf-pro' ), array( 'status' => 403 ) );
		},
		'callback'            => static function ( $request ) {
			$post = (int) $request->get_param( 'post' );
			$rule = kerf_bg_sanitize_rule( (array) $request->get_param( 'rule' ) );
			if ( ! $rule ) {
				return new WP_Error( 'kerf_bg_invalid', __( 'That background could not be saved.', 'kerf-pro' ), array( 'status' => 400 ) );
			}
			$rules = kerf_bg_rules( $post );
			$rules[ kerf_bg_key( $rule['selector'], $rule['media'] ) ] = $rule;
			kerf_bg_rules_save( $post, $rules );
			return rest_ensure_response( array( 'rules' => $rules ) );
		},
	) );
}
add_action( 'rest_api_init', 'kerf_bg_everywhere_routes' );

/**
 * The panel's "Replace everywhere", for whoever may change the design — and
 * whether the licence lets it act. Loaded after the free panel, which it
 * extends (and without which it has nothing to extend).
 */
function kerf_bg_everywhere_assets() {
	$rel = 'assets/js/kerf-background-everywhere.js';
	if ( ! current_user_can( 'edit_theme_options' ) || ! file_exists( kerf_pro_path( $rel ) ) ) {
		return;
	}
	wp_enqueue_script( 'kerf-background-everywhere', kerf_pro_url( $rel ), array( 'kerf-background-panel', 'kerf-background-core', 'wp-hooks', 'wp-element', 'wp-components', 'wp-i18n', 'wp-api-fetch' ), filemtime( kerf_pro_path( $rel ) ), true );
	wp_set_script_translations( 'kerf-background-everywhere', 'kerf-pro', kerf_pro_path( 'languages' ) );
	wp_add_inline_script( 'kerf-background-everywhere', 'window.kerfProBackgrounds = ' . wp_json_encode( array( 'licensed' => kerf_pro_licensed() ) ) . ';', 'before' );
}
add_action( 'enqueue_block_editor_assets', 'kerf_bg_everywhere_assets' );
