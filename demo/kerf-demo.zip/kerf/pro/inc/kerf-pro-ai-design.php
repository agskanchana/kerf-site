<?php
/**
 * AI, phase 3: the design generator — a whole design, written by Gemini from
 * the owner's brief and pictures, staged like an uploaded ZIP and handed to
 * the import's check step.
 *
 * The rule of AI in Kerf (§5.4, §5.46): AI may write design files, never
 * block markup. What Gemini writes here is plain HTML and CSS, treated as a
 * stranger's mockup — checked, then converted by the same converter as any
 * design. So the import, its check step, its report and its undo are the
 * same as for a ZIP; this only makes the ZIP.
 *
 * Built in steps, each one request, so no answer is too long and none
 * outlasts a host (kerf-pro-ai-jobs.php): (1) a plan — the pages, colours,
 * fonts, tone, where each picture goes; (2) the home page and the design
 * system, `index.html` + `css/style.css` (+ the menu's `js/main.js` for
 * someone who may add scripts, §5.32); (3) each other page and the blog's
 * three templates — only their `<main>`: Kerf puts it inside the home page's
 * own head, header and footer, so every page has the same chrome by
 * construction, not by asking; (4) staging (kerf_import_stage_files()).
 *
 * Every file is checked before it is staged. Pictures are the owner's only:
 * any other picture — a placeholder service, stock, an invented path — is
 * taken out and said. No script but the menu's; no frames, embeds or
 * handlers; links and forms as the converter expects them. The templates
 * must carry the markup contract (§5.25); one that does not is marked by
 * phase 2's engine (kerf_pro_ai_prepare()), or left out and said.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The design projects, by id — the newest three: what was asked, the plan, the files. */
const KERF_PRO_AI_DESIGNS_OPTION = 'kerf_pro_ai_designs';

/** At most this many pictures go to the model with a brief. */
const KERF_PRO_AI_DESIGN_PICTURES = 12;

/** At most this many pages beside the home page and the blog's three. */
const KERF_PRO_AI_DESIGN_PAGES = 5;

/**
 * The blog's three templates: the file, its kind, and what it is.
 *
 * @return array<string,array{kind:string,label:string}>
 */
function kerf_pro_ai_design_templates() {
	return array(
		'blog.html'      => array( 'kind' => 'home', 'label' => __( 'The blog', 'kerf-pro' ) ),
		'blog-post.html' => array( 'kind' => 'single', 'label' => __( 'A blog post', 'kerf-pro' ) ),
		'404.html'       => array( 'kind' => '404', 'label' => __( 'Page not found', 'kerf-pro' ) ),
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// STARTING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Start a design: the brief and the pictures checked, a project kept, and a
 * job to make it (kerf_pro_ai_job_create()).
 *
 * The business's details are what the owner confirms (the screen shows them,
 * phase 4) — else the site's own (Kerf → Site details). Those can be a
 * template's samples a design brought in and nobody changed: in the lab a
 * gym was given a dental clinic's phone that way. So whatever starts a
 * design should show them first.
 *
 * @param array $input { brief: string, pictures: int[], details?: array<string,string> }.
 * @return array|WP_Error The job.
 */
function kerf_pro_ai_design_start( $input ) {
	$brief = trim( sanitize_textarea_field( isset( $input['brief'] ) ? (string) $input['brief'] : '' ) );
	if ( mb_strlen( $brief ) < 20 ) {
		return new WP_Error( 'kerf_ai_brief', __( 'Say a little more about the business and the site you want — a few sentences.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	$pictures = kerf_pro_ai_design_pictures( isset( $input['pictures'] ) ? (array) $input['pictures'] : array() );
	if ( is_wp_error( $pictures ) ) {
		return $pictures;
	}

	$job     = kerf_pro_ai_job_create(
		'design',
		array(
			array( 'key' => 'plan', 'label' => __( 'Planning the site', 'kerf-pro' ) ),
			array( 'key' => 'home', 'label' => __( 'Designing the home page', 'kerf-pro' ) ),
			array( 'key' => 'stage', 'label' => __( 'Checking every file', 'kerf-pro' ) ),
		)
	);
	$project = array(
		'id'       => $job['id'],
		'created'  => time(),
		'user'     => get_current_user_id(),
		'brief'    => mb_substr( $brief, 0, 4000 ),
		'pictures' => $pictures,
		'details'  => kerf_pro_ai_design_details( isset( $input['details'] ) ? $input['details'] : null ),
		// Fixed when it starts: a step done later runs as whoever asks after it.
		'scripts'  => kerf_user_can_add_scripts(),
		'plan'     => null,
		'files'    => array(),
		'notes'    => array(),
		'token'    => '',
	);
	kerf_pro_ai_design_save( $project );
	$job['data'] = array( 'project' => $project['id'] );
	kerf_pro_ai_job_save( $job );
	return $job;
}

/**
 * The owner's pictures, as the design uses them: each library picture the
 * person may see, by a plain name in `img/`.
 *
 * @param int[] $ids Attachment ids.
 * @return array[]|WP_Error Each { id, path, width, height, alt, mime }.
 */
function kerf_pro_ai_design_pictures( $ids ) {
	$out   = array();
	$taken = array();
	$bytes = 0;
	foreach ( array_slice( array_unique( array_map( 'absint', $ids ) ), 0, KERF_PRO_AI_DESIGN_PICTURES ) as $id ) {
		$file = $id ? get_attached_file( $id ) : '';
		if ( ! $id || ! wp_attachment_is_image( $id ) || ! current_user_can( 'read_post', $id ) || ! $file || ! is_readable( $file ) ) {
			return new WP_Error( 'kerf_ai_picture', __( 'One of the pictures is not in your media library any more. Choose them again.', 'kerf-pro' ), array( 'status' => 400 ) );
		}
		$ext = strtolower( pathinfo( $file, PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png', 'webp', 'gif', 'avif' ), true ) || filesize( $file ) > 10 * MB_IN_BYTES ) {
			return new WP_Error( 'kerf_ai_picture', __( 'Pictures must be JPG, PNG, WebP, GIF or AVIF files of 10 MB or less.', 'kerf-pro' ), array( 'status' => 400 ) );
		}
		// Staged like a ZIP (64 MB at most), and read whole to be staged: said
		// now, not after ten minutes of the model's work.
		$bytes += filesize( $file );
		if ( $bytes > 40 * MB_IN_BYTES ) {
			return new WP_Error( 'kerf_ai_picture', __( 'The pictures come to more than 40 MB together. Choose fewer, or smaller ones.', 'kerf-pro' ), array( 'status' => 400 ) );
		}
		// A plain name: the converter finds the picture again by it, and the
		// model writes it into the design as it is given.
		$name = sanitize_title( pathinfo( $file, PATHINFO_FILENAME ) );
		$name = '' !== $name ? substr( $name, 0, 40 ) : 'picture';
		$path = 'img/' . $name . '.' . $ext;
		for ( $n = 2; isset( $taken[ $path ] ); $n++ ) {
			$path = 'img/' . $name . '-' . $n . '.' . $ext;
		}
		$taken[ $path ] = true;
		$meta           = wp_get_attachment_metadata( $id );
		$out[]          = array(
			'id'     => $id,
			'path'   => $path,
			'width'  => isset( $meta['width'] ) ? (int) $meta['width'] : 0,
			'height' => isset( $meta['height'] ) ? (int) $meta['height'] : 0,
			'alt'    => trim( wp_strip_all_tags( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) . ' ' . get_the_title( $id ) ) ),
			'mime'   => (string) get_post_mime_type( $id ),
		);
	}
	return $out;
}

/**
 * The business's details a design uses: those given, cleaned — key (phone,
 * email, address, hours, a social network…) => text — else the site's own.
 *
 * @param array|null $given
 * @return array<string,string>
 */
function kerf_pro_ai_design_details( $given ) {
	$out = array();
	if ( null === $given ) {
		foreach ( kerf_site_details() as $key => $detail ) {
			if ( is_array( $detail ) && isset( $detail['text'] ) && '' !== trim( (string) $detail['text'] ) ) {
				$out[ $key ] = (string) $detail['text'];
			}
		}
	} else {
		$out = is_array( $given ) ? $given : array();
	}
	$clean = array();
	foreach ( array_slice( $out, 0, 20, true ) as $key => $text ) {
		$key  = sanitize_key( (string) $key );
		$text = mb_substr( trim( sanitize_text_field( is_scalar( $text ) ? (string) $text : '' ) ), 0, 200 );
		if ( '' !== $key && '' !== $text ) {
			$clean[ $key ] = $text;
		}
	}
	return $clean;
}

/**
 * A project, by id.
 *
 * @param string $id
 * @return array|null
 */
function kerf_pro_ai_design_get( $id ) {
	$all = kerf_pro_ai_fresh_option( KERF_PRO_AI_DESIGNS_OPTION );
	return is_array( $all ) && isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : null;
}

/**
 * Keep a project — the newest three. The others as the database has them: a
 * step saves after minutes of the model's work, and another person's design
 * may have been saved meanwhile.
 *
 * @param array $project
 */
function kerf_pro_ai_design_save( $project ) {
	$all = kerf_pro_ai_fresh_option( KERF_PRO_AI_DESIGNS_OPTION );
	$all = is_array( $all ) ? $all : array();
	$all[ $project['id'] ] = $project;
	uasort( $all, static function ( $a, $b ) {
		return ( isset( $b['created'] ) ? (int) $b['created'] : 0 ) <=> ( isset( $a['created'] ) ? (int) $a['created'] : 0 );
	} );
	update_option( KERF_PRO_AI_DESIGNS_OPTION, array_slice( $all, 0, 3, true ), false );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE STEPS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Do one step of a design job.
 *
 * @param array $job  By reference: the plan adds the pages' steps.
 * @param array $step { key, label }.
 * @return true|WP_Error
 */
function kerf_pro_ai_design_step( &$job, $step ) {
	$project = kerf_pro_ai_design_get( isset( $job['data']['project'] ) ? (string) $job['data']['project'] : '' );
	if ( ! $project ) {
		return new WP_Error( 'kerf_ai_design_gone', __( 'This design is not kept any more. Start it again.', 'kerf-pro' ) );
	}

	if ( 'plan' === $step['key'] ) {
		$done = kerf_pro_ai_design_plan( $project );
		if ( true === $done ) {
			// The pages the plan names, then the blog's three, before staging.
			$steps = array();
			foreach ( $project['plan']['pages'] as $page ) {
				/* translators: %s: a page's title. */
				$steps[] = array( 'key' => 'page:' . $page['file'], 'label' => sprintf( __( 'Writing “%s”', 'kerf-pro' ), $page['title'] ) );
			}
			foreach ( kerf_pro_ai_design_templates() as $file => $template ) {
				/* translators: %s: a kind of page, as "The blog". */
				$steps[] = array( 'key' => 'page:' . $file, 'label' => sprintf( __( 'Writing %s', 'kerf-pro' ), mb_strtolower( $template['label'] ) ) );
			}
			array_splice( $job['steps'], 2, 0, $steps );
			// Shown while the rest is made (the build screen).
			$job['result']['plan'] = kerf_pro_ai_design_plan_summary( $project['plan'] );
		}
	} elseif ( 'home' === $step['key'] ) {
		$done = kerf_pro_ai_design_home( $project );
	} elseif ( 0 === strpos( $step['key'], 'page:' ) ) {
		$done = kerf_pro_ai_design_page( $project, substr( $step['key'], 5 ) );
	} elseif ( 'stage' === $step['key'] ) {
		$done = kerf_pro_ai_design_stage( $project );
		if ( true === $done ) {
			$job['result'] = array_merge( (array) $job['result'], array(
				'token'     => $project['token'],
				'check_url' => kerf_import_check_url( $project['token'] ),
				'files'     => array_keys( $project['files'] ),
				'pages'     => kerf_pro_ai_design_page_list( $project ),
				'notes'     => $project['notes'],
			) );
		}
	} else {
		$done = new WP_Error( 'kerf_ai_job_step', __( 'Kerf Pro does not know that step. Start the design again.', 'kerf-pro' ) );
	}

	kerf_pro_ai_design_save( $project );
	return $done;
}

/**
 * The plan as the build screen shows it while the pages are made.
 *
 * @param array $plan From kerf_pro_ai_design_clean_plan().
 * @return array{site_name:string,tagline:string,colors:string[],fonts:string[],pages:string[]}
 */
function kerf_pro_ai_design_plan_summary( $plan ) {
	return array(
		'site_name' => (string) $plan['site_name'],
		'tagline'   => (string) $plan['tagline'],
		'colors'    => array_values( $plan['colors'] ),
		'fonts'     => array_values( array_filter( $plan['fonts'] ) ),
		'pages'     => wp_list_pluck( $plan['pages'], 'title' ),
	);
}

/**
 * The design's pages, in the order the build screen shows them: the home
 * page, the plan's pages, the blog's three — each by its file and its name.
 *
 * @param array $project
 * @return array[] Each { file, label }.
 */
function kerf_pro_ai_design_page_list( $project ) {
	$list = array( array( 'file' => 'index.html', 'label' => __( 'Home', 'kerf-pro' ) ) );
	foreach ( $project['plan']['pages'] as $page ) {
		if ( isset( $project['files'][ $page['file'] ] ) ) {
			$list[] = array( 'file' => $page['file'], 'label' => $page['title'] );
		}
	}
	foreach ( kerf_pro_ai_design_templates() as $file => $template ) {
		if ( isset( $project['files'][ $file ] ) ) {
			$list[] = array( 'file' => $file, 'label' => $template['label'] );
		}
	}
	return $list;
}

/**
 * The job handler for designs.
 *
 * @param array $handlers
 * @return array
 */
function kerf_pro_ai_design_handler( $handlers ) {
	$handlers['design'] = 'kerf_pro_ai_design_step';
	return $handlers;
}
add_filter( 'kerf_pro_ai_job_handlers', 'kerf_pro_ai_design_handler' );

/**
 * Step one: the plan.
 *
 * @param array $project By reference.
 * @return true|WP_Error
 */
function kerf_pro_ai_design_plan( &$project ) {
	$answer = kerf_pro_ai_request(
		'design-plan',
		implode( "\n", array(
			'You plan a small website for a business, which a web designer will then build as plain HTML and CSS. The owner will see your plan before anything is built.',
			'Plan from what the owner tells you and from their pictures, which you are shown. Invent no facts: no prices, awards, reviews, years or numbers you were not given.',
			'pages: the pages beside the home page and the blog — from one to ' . KERF_PRO_AI_DESIGN_PAGES . ', the ones this business needs (an about page, its services, a contact page…). Each file is a short name in lower case with dashes, ending .html. Not index.html, blog.html, blog-post.html or 404.html: those are made anyway.',
			'colors: six colours as #rrggbb that suit the business and its pictures, with enough contrast for text. fonts: two Google Fonts families (heading, body) that suit it.',
			'pictures: for each picture, by its path, where it goes and why.',
			'Write in the language the owner writes in.',
		) ),
		array_merge(
			array( array( 'text' => kerf_pro_ai_design_about( $project ) ) ),
			kerf_pro_ai_design_picture_parts( $project )
		),
		array(
			'tier'        => 'pro',
			'json'        => true,
			'temperature' => 0.6,
			'schema'      => array(
				'type'       => 'OBJECT',
				'properties' => array(
					'site_name' => array( 'type' => 'STRING' ),
					'tagline'   => array( 'type' => 'STRING' ),
					'tone'      => array( 'type' => 'STRING' ),
					'colors'    => array(
						'type'       => 'OBJECT',
						'properties' => array_fill_keys( array( 'background', 'surface', 'text', 'muted', 'accent', 'accent_text' ), array( 'type' => 'STRING' ) ),
						'required'   => array( 'background', 'surface', 'text', 'muted', 'accent', 'accent_text' ),
					),
					'fonts'     => array(
						'type'       => 'OBJECT',
						'properties' => array( 'heading' => array( 'type' => 'STRING' ), 'body' => array( 'type' => 'STRING' ) ),
						'required'   => array( 'heading', 'body' ),
					),
					'home'      => array(
						'type'       => 'OBJECT',
						'properties' => array( 'sections' => array( 'type' => 'ARRAY', 'items' => array( 'type' => 'STRING' ) ) ),
						'required'   => array( 'sections' ),
					),
					'pages'     => array(
						'type'  => 'ARRAY',
						'items' => array(
							'type'       => 'OBJECT',
							'properties' => array(
								'file'     => array( 'type' => 'STRING' ),
								'title'    => array( 'type' => 'STRING' ),
								'purpose'  => array( 'type' => 'STRING' ),
								'sections' => array( 'type' => 'ARRAY', 'items' => array( 'type' => 'STRING' ) ),
							),
							'required'   => array( 'file', 'title', 'purpose', 'sections' ),
						),
					),
					'pictures'  => array(
						'type'  => 'ARRAY',
						'items' => array(
							'type'       => 'OBJECT',
							'properties' => array( 'path' => array( 'type' => 'STRING' ), 'use' => array( 'type' => 'STRING' ) ),
							'required'   => array( 'path', 'use' ),
						),
					),
				),
				'required'   => array( 'site_name', 'colors', 'fonts', 'home', 'pages' ),
			),
		)
	);
	if ( is_wp_error( $answer ) ) {
		return $answer;
	}
	$project['plan'] = kerf_pro_ai_design_clean_plan( $answer['json'], $project );
	return true;
}

/**
 * The plan as Kerf will use it: names it can stage, colours and fonts it can
 * write, pictures the owner gave.
 *
 * @param mixed $json
 * @param array $project
 * @return array
 */
function kerf_pro_ai_design_clean_plan( $json, $project ) {
	$json  = is_array( $json ) ? $json : array();
	$text  = static function ( $value, $max ) {
		$value = trim( wp_strip_all_tags( is_scalar( $value ) ? (string) $value : '' ) );
		return mb_substr( $value, 0, $max );
	};
	$list  = static function ( $value, $max ) use ( $text ) {
		$out = array();
		foreach ( is_array( $value ) ? array_slice( $value, 0, 12 ) : array() as $item ) {
			$item = $text( $item, $max );
			if ( '' !== $item ) {
				$out[] = $item;
			}
		}
		return $out;
	};
	$plan = array(
		'site_name' => $text( isset( $json['site_name'] ) ? $json['site_name'] : '', 80 ),
		'tagline'   => $text( isset( $json['tagline'] ) ? $json['tagline'] : '', 160 ),
		'tone'      => $text( isset( $json['tone'] ) ? $json['tone'] : '', 300 ),
		'colors'    => array(),
		'fonts'     => array(),
		'home'      => array( 'sections' => $list( isset( $json['home']['sections'] ) ? $json['home']['sections'] : array(), 300 ) ),
		'pages'     => array(),
		'pictures'  => array(),
	);
	if ( '' === $plan['site_name'] ) {
		$plan['site_name'] = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	}
	$defaults = array( 'background' => '#ffffff', 'surface' => '#f5f5f4', 'text' => '#1c1917', 'muted' => '#57534e', 'accent' => '#1f4e43', 'accent_text' => '#ffffff' );
	foreach ( $defaults as $key => $default ) {
		$value                    = isset( $json['colors'][ $key ] ) && is_string( $json['colors'][ $key ] ) ? trim( $json['colors'][ $key ] ) : '';
		$plan['colors'][ $key ] = preg_match( '/^#[0-9a-fA-F]{6}$/', $value ) ? strtolower( $value ) : $default;
	}
	foreach ( array( 'heading', 'body' ) as $key ) {
		$value                   = isset( $json['fonts'][ $key ] ) && is_string( $json['fonts'][ $key ] ) ? trim( $json['fonts'][ $key ] ) : '';
		$plan['fonts'][ $key ] = preg_match( '/^[A-Za-z][A-Za-z0-9 ]{1,39}$/', $value ) ? $value : '';
	}

	$reserved = array_merge( array( 'index.html' ), array_keys( kerf_pro_ai_design_templates() ) );
	foreach ( isset( $json['pages'] ) && is_array( $json['pages'] ) ? $json['pages'] : array() as $page ) {
		$file = is_array( $page ) && isset( $page['file'] ) && is_string( $page['file'] ) ? strtolower( trim( $page['file'] ) ) : '';
		$file = preg_match( '/\.html$/', $file ) ? $file : $file . '.html';
		if ( ! preg_match( '/^[a-z0-9][a-z0-9-]{0,40}\.html$/', $file ) || in_array( $file, $reserved, true ) || isset( $plan['pages'][ $file ] ) ) {
			continue;
		}
		$title = $text( isset( $page['title'] ) ? $page['title'] : '', 60 );
		$plan['pages'][ $file ] = array(
			'file'     => $file,
			'title'    => '' !== $title ? $title : ucwords( str_replace( '-', ' ', substr( $file, 0, -5 ) ) ),
			'purpose'  => $text( isset( $page['purpose'] ) ? $page['purpose'] : '', 400 ),
			'sections' => $list( isset( $page['sections'] ) ? $page['sections'] : array(), 300 ),
		);
		if ( count( $plan['pages'] ) >= KERF_PRO_AI_DESIGN_PAGES ) {
			break;
		}
	}
	$plan['pages'] = array_values( $plan['pages'] );

	$paths = wp_list_pluck( $project['pictures'], 'path' );
	foreach ( isset( $json['pictures'] ) && is_array( $json['pictures'] ) ? $json['pictures'] : array() as $picture ) {
		if ( is_array( $picture ) && isset( $picture['path'] ) && in_array( $picture['path'], $paths, true ) ) {
			$plan['pictures'][] = array( 'path' => $picture['path'], 'use' => $text( isset( $picture['use'] ) ? $picture['use'] : '', 300 ) );
		}
	}
	return $plan;
}

/**
 * Step two: the home page and the design system.
 *
 * @param array $project By reference.
 * @return true|WP_Error
 */
function kerf_pro_ai_design_home( &$project ) {
	$scripts = ! empty( $project['scripts'] );
	$answer  = kerf_pro_ai_request(
		'design-home',
		kerf_pro_ai_design_rules( $project, 'index' ),
		array_merge(
			array( array( 'text' => kerf_pro_ai_design_about( $project ) . "\n\nThe plan:\n" . wp_json_encode( $project['plan'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) ),
			kerf_pro_ai_design_picture_parts( $project )
		),
		array(
			'tier'        => 'pro',
			'json'        => true,
			'temperature' => 0.7,
			'schema'      => array(
				'type'       => 'OBJECT',
				'properties' => array(
					'index_html' => array( 'type' => 'STRING' ),
					'style_css'  => array( 'type' => 'STRING' ),
					'main_js'    => array( 'type' => 'STRING' ),
				),
				'required'   => array( 'index_html', 'style_css' ),
			),
		)
	);
	if ( is_wp_error( $answer ) ) {
		return $answer;
	}

	$html = isset( $answer['json']['index_html'] ) && is_string( $answer['json']['index_html'] ) ? $answer['json']['index_html'] : '';
	$css  = isset( $answer['json']['style_css'] ) && is_string( $answer['json']['style_css'] ) ? $answer['json']['style_css'] : '';
	$js   = $scripts && isset( $answer['json']['main_js'] ) && is_string( $answer['json']['main_js'] ) ? $answer['json']['main_js'] : '';
	if ( strlen( $html ) > 400000 || strlen( $css ) > 400000 || strlen( $js ) > 50000 ) {
		return new WP_Error( 'kerf_ai_retry', __( 'The home page Gemini wrote was too long. Writing it again…', 'kerf-pro' ) );
	}

	$notes = array();
	$html  = kerf_pro_ai_design_clean_html( $html, '', $project, $notes );
	$css   = kerf_pro_ai_design_clean_css( $css, 'css', $project, $notes );
	$shape = kerf_pro_ai_design_shape( $html );
	if ( true !== $shape ) {
		// A model's slip, not the owner's: the step asks again (the job's tries).
		return new WP_Error( 'kerf_ai_retry', $shape );
	}
	if ( '' === trim( $js ) ) {
		$html = kerf_pro_ai_design_strip_elements( $html, array( 'script' ), $notes );
	}

	$project['files']['index.html']    = $html;
	$project['files']['css/style.css'] = $css;
	if ( '' !== trim( $js ) ) {
		$project['files']['js/main.js'] = $js;
	}
	$project['notes'] = array_values( array_unique( array_merge( $project['notes'], $notes ) ) );
	return true;
}

/**
 * Step three, for each other page and template: its `<main>`, put inside the
 * home page's own document.
 *
 * @param array  $project By reference.
 * @param string $file
 * @return true|WP_Error
 */
function kerf_pro_ai_design_page( &$project, $file ) {
	if ( empty( $project['files']['index.html'] ) ) {
		return new WP_Error( 'kerf_ai_design_order', __( 'The home page is missing, so this page cannot be written. Start the design again.', 'kerf-pro' ) );
	}
	$templates = kerf_pro_ai_design_templates();
	$kind      = isset( $templates[ $file ] ) ? $templates[ $file ]['kind'] : 'page';
	$page      = null;
	foreach ( $project['plan']['pages'] as $planned ) {
		if ( $planned['file'] === $file ) {
			$page = $planned;
		}
	}
	if ( 'page' === $kind && ! $page ) {
		return true; // Not in the plan any more.
	}

	$answer = kerf_pro_ai_request(
		'design-page',
		kerf_pro_ai_design_rules( $project, $kind ),
		array( array( 'text' => implode( "\n\n", array(
			kerf_pro_ai_design_about( $project ),
			'The plan:' . "\n" . wp_json_encode( $project['plan'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			$page
				? 'Write the <main> of ' . $file . ' — “' . $page['title'] . '”: ' . $page['purpose'] . ( $page['sections'] ? "\nIts sections:\n- " . implode( "\n- ", $page['sections'] ) : '' )
				: 'Write the <main> of ' . $file . '.',
			'The home page, index.html — its head, header and footer are every page\'s:' . "\n" . $project['files']['index.html'],
			'The design system, css/style.css:' . "\n" . $project['files']['css/style.css'],
			! empty( $project['files']['css/pages.css'] ) ? 'What the other pages added so far, css/pages.css:' . "\n" . $project['files']['css/pages.css'] : '',
		) ) ) ),
		array(
			'tier'        => 'pro',
			'json'        => true,
			'temperature' => 0.6,
			'schema'      => array(
				'type'       => 'OBJECT',
				'properties' => array(
					'title'       => array( 'type' => 'STRING' ),
					'description' => array( 'type' => 'STRING' ),
					'main_html'   => array( 'type' => 'STRING' ),
					'css'         => array( 'type' => 'STRING' ),
				),
				'required'   => array( 'title', 'main_html' ),
			),
		)
	);
	if ( is_wp_error( $answer ) ) {
		return $answer;
	}

	$main = isset( $answer['json']['main_html'] ) && is_string( $answer['json']['main_html'] ) ? trim( $answer['json']['main_html'] ) : '';
	$css  = isset( $answer['json']['css'] ) && is_string( $answer['json']['css'] ) ? $answer['json']['css'] : '';
	if ( '' === $main || strlen( $main ) > 300000 || strlen( $css ) > 100000 ) {
		return new WP_Error( 'kerf_ai_retry', __( 'Gemini\'s page was empty or too long. Writing it again…', 'kerf-pro' ) );
	}
	if ( ! preg_match( '/^<main\b/i', $main ) ) {
		$main = '<main>' . $main . '</main>';
	}
	$title = trim( wp_strip_all_tags( isset( $answer['json']['title'] ) && is_scalar( $answer['json']['title'] ) ? (string) $answer['json']['title'] : '' ) );
	$desc  = trim( wp_strip_all_tags( isset( $answer['json']['description'] ) && is_scalar( $answer['json']['description'] ) ? (string) $answer['json']['description'] : '' ) );

	$notes = array();
	$html  = kerf_pro_ai_design_assemble( $project['files']['index.html'], $main, '' !== $title ? $title : ( $page ? $page['title'] : '' ), $desc, 'page' === $kind ? '' : $kind );
	$html  = kerf_pro_ai_design_clean_html( $html, '', $project, $notes );
	if ( '' !== trim( $css ) ) {
		$css = kerf_pro_ai_design_clean_css( $css, 'css', $project, $notes );
		$project['files']['css/pages.css'] = ( isset( $project['files']['css/pages.css'] ) ? $project['files']['css/pages.css'] . "\n\n" : '' )
			. '/* ' . $file . " */\n" . trim( $css ) . "\n";
	}

	if ( 'page' !== $kind ) {
		$html = kerf_pro_ai_design_ensure_marked( $html, $file, $kind, $notes );
		if ( '' === $html ) {
			unset( $project['files'][ $file ] );
			$project['notes'] = array_values( array_unique( array_merge( $project['notes'], $notes ) ) );
			return true;
		}
	}
	$project['files'][ $file ] = $html;
	$project['notes']          = array_values( array_unique( array_merge( $project['notes'], $notes ) ) );
	return true;
}

/**
 * Step four: stage every file and the owner's pictures as an uploaded ZIP is
 * staged, and park it for the import's check step.
 *
 * @param array $project By reference.
 * @return true|WP_Error
 */
function kerf_pro_ai_design_stage( &$project ) {
	if ( empty( $project['files']['index.html'] ) ) {
		return new WP_Error( 'kerf_ai_design_order', __( 'The home page is missing, so there is nothing to import. Start the design again.', 'kerf-pro' ) );
	}
	$files = $project['files'];
	foreach ( $project['pictures'] as $picture ) {
		$source = get_attached_file( $picture['id'] );
		if ( ! $source || ! is_readable( $source ) ) {
			continue;
		}
		$files[ $picture['path'] ] = (string) file_get_contents( $source );
		// The import reuses a library picture with the same bytes
		// (kerf_import_find_attachment_by_hash()): the owner's own, not a copy.
		if ( '' === (string) get_post_meta( $picture['id'], KERF_IMPORT_HASH_META, true ) ) {
			update_post_meta( $picture['id'], KERF_IMPORT_HASH_META, md5_file( $source ) );
		}
	}

	$staging = kerf_import_stage_files( $files );
	if ( ! empty( $staging['error'] ) ) {
		return new WP_Error( 'kerf_ai_stage', $staging['error'] );
	}
	// The details the design was made with become the site's when it is
	// imported (kerf_site_confirm()): the site's own kept ones would win.
	$staging['site_details'] = isset( $project['details'] ) ? (array) $project['details'] : array();

	$pages   = array_diff( array_keys( $project['files'] ), array( 'index.html', 'css/style.css', 'css/pages.css', 'js/main.js' ) );
	$actions = array(
		sprintf(
			/* translators: 1: number of pages, 2: list of files. */
			_n( 'Gemini wrote %1$d page: %2$s.', 'Gemini wrote %1$d pages: %2$s.', 1 + count( $pages ), 'kerf-pro' ),
			1 + count( $pages ),
			implode( ', ', array_merge( array( 'index.html' ), $pages ) )
		),
	);
	foreach ( $project['notes'] as $note ) {
		$actions[] = $note;
	}

	$project['token'] = kerf_import_check_staged(
		$staging,
		/* translators: %s: the site's name. */
		sprintf( __( 'the design Gemini made for %s', 'kerf-pro' ), $project['plan']['site_name'] ),
		$actions
	);
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHAT THE MODEL IS TOLD
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The business, as the model reads it: the owner's brief, "About your
 * business", the details the site keeps, and the pictures by path.
 *
 * @param array $project
 * @return string
 */
function kerf_pro_ai_design_about( $project ) {
	$lines   = array( 'What the owner asks for:', $project['brief'] );
	$about   = trim( (string) get_option( KERF_PRO_AI_ABOUT_OPTION, '' ) );
	$name    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$details = array();
	foreach ( isset( $project['details'] ) ? (array) $project['details'] : array() as $key => $text ) {
		$details[] = '- ' . $key . ': ' . $text;
	}
	if ( '' !== $about ) {
		$lines[] = '';
		$lines[] = 'About the business, in the owner\'s words:';
		$lines[] = $about;
	}
	if ( '' !== $name ) {
		// Told as what it is: the lab's "Field Notes" became a gym's name.
		$lines[] = '';
		$lines[] = 'The WordPress site\'s current title, which may be a placeholder: ' . $name . '. When the owner names the business, use the owner\'s name.';
	}
	if ( $details ) {
		$lines[] = '';
		$lines[] = 'The business\'s details — use them exactly as given, and invent no others:';
		$lines   = array_merge( $lines, $details );
	}
	$lines[] = '';
	if ( $project['pictures'] ) {
		$lines[] = 'The owner\'s pictures — the only pictures the site may show, by these paths:';
		foreach ( $project['pictures'] as $picture ) {
			$lines[] = '- ' . $picture['path'] . ( $picture['width'] ? ' (' . $picture['width'] . '×' . $picture['height'] . ')' : '' ) . ( '' !== $picture['alt'] ? ' — ' . $picture['alt'] : '' );
		}
	} else {
		$lines[] = 'The owner gave no pictures: the site shows none. Use colour, type, shapes and inline SVG.';
	}
	return implode( "\n", $lines );
}

/**
 * The owner's pictures as the model sees them: each a small copy, after its
 * path. Shown so the plan and the home page can put each where it belongs.
 *
 * @param array $project
 * @return array[] Parts for kerf_pro_ai_request().
 */
function kerf_pro_ai_design_picture_parts( $project ) {
	$parts = array();
	// Gemini takes 20 MB a request in all; the pictures' copies get 12.
	$room = 12 * MB_IN_BYTES;
	foreach ( $project['pictures'] as $picture ) {
		$file = get_attached_file( $picture['id'] );
		$meta = wp_get_attachment_metadata( $picture['id'] );
		$mime = $picture['mime'];
		foreach ( array( 'medium_large', 'large', 'medium' ) as $size ) {
			if ( ! empty( $meta['sizes'][ $size ]['file'] ) && $file && is_readable( dirname( $file ) . '/' . $meta['sizes'][ $size ]['file'] ) ) {
				$mime = ! empty( $meta['sizes'][ $size ]['mime-type'] ) ? $meta['sizes'][ $size ]['mime-type'] : $mime;
				$file = dirname( $file ) . '/' . $meta['sizes'][ $size ]['file'];
				break;
			}
		}
		if ( ! $file || ! is_readable( $file ) || filesize( $file ) > 4 * MB_IN_BYTES || ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ) {
			continue;
		}
		$room -= (int) ceil( filesize( $file ) * 4 / 3 );
		if ( $room < 0 ) {
			break;
		}
		$parts[] = array( 'text' => 'Picture ' . $picture['path'] . ':' );
		$parts[] = array( 'image' => array( 'mime' => $mime, 'data' => base64_encode( (string) file_get_contents( $file ) ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- the API takes a picture as base64.
	}
	return $parts;
}

/**
 * The rules for writing a file of the design.
 *
 * @param array  $project
 * @param string $kind 'index' for the home page and the design system; a
 *                     template's page type (home — the blog —, single, 404);
 *                     or 'page'.
 * @return string
 */
function kerf_pro_ai_design_rules( $project, $kind ) {
	$scripts = ! empty( $project['scripts'] );
	$plan    = $project['plan'];
	$pages   = array_merge( array( 'index.html' ), wp_list_pluck( $plan['pages'], 'file' ), array( 'blog.html' ) );
	$lines   = array(
		'You are a web designer. You write a business\'s website as plain HTML and CSS files, which Kerf turns into a WordPress site keeping every tag, class and style exactly as you write them — so write them exactly as they should look, finished: no placeholders, no TODOs.',
		'',
		'The site: ' . $plan['site_name'] . ( '' !== $plan['tagline'] ? ' — ' . $plan['tagline'] : '' ) . '. Tone: ' . ( '' !== $plan['tone'] ? $plan['tone'] : 'as the business needs' ) . '.',
		'Colours: ' . implode( ', ', array_map( static function ( $key, $value ) {
			return $key . ' ' . $value;
		}, array_keys( $plan['colors'] ), $plan['colors'] ) ) . '.',
		'Fonts: ' . ( '' !== $plan['fonts']['heading'] ? $plan['fonts']['heading'] . ' for headings, ' . ( '' !== $plan['fonts']['body'] ? $plan['fonts']['body'] : 'a system font' ) . ' for text (Google Fonts)' : 'a system font stack' ) . '.',
		'The pages, and the menu\'s links between them: ' . implode( ', ', $pages ) . '.',
		'',
		'Rules:',
		'- Pictures: only the owner\'s, by the paths you are given (from css/ they are ../img/…). Never any other picture: no placeholder or stock services, no other addresses, no invented paths. Where a section has no picture, use colour, type, shapes and inline SVG icons.',
		'- Text: real, specific text for this business, from what you are told, in the owner\'s language. No lorem ipsum. Invent no facts: no prices, awards, reviews, quotes, years or numbers you were not given; no business details beyond those given. The year is ' . wp_date( 'Y' ) . ' (for a copyright line).',
		'- No frameworks and no files from other sites: no Bootstrap, Tailwind or icon fonts — only Google Fonts. No iframes, embeds, maps or videos.',
		'- Accessible: one <h1> per page, alt text on every picture, a label on every field, enough contrast, visible focus.',
		'- The business\'s details wherever they appear: data-kerf-site="phone" on each tel: link, "email" on each mailto: link, "address" on the element holding the address, "hours" on the opening hours, and "facebook", "instagram", "x", "linkedin", "youtube", "tiktok" or "whatsapp" on each social link.',
		'- Every form: <form data-kerf-form="contact"> (or "booking", "quote", "newsletter") with no action attribute, every field with a name and a <label>, and inside it a thank-you <div data-kerf-form-success hidden>…</div> and an error <div data-kerf-form-error hidden>…</div>.',
		$scripts
			? '- Behaviour: only the mobile menu, in js/main.js — plain JavaScript, no libraries — linked at the end of <body> as <script src="js/main.js" defer></script>. It runs on every page, so check that each element exists before using it. No other script, no inline script, no on… attributes.'
			: '- No JavaScript at all: the mobile menu opens with CSS only (a <details> element, or a checkbox and its label). No script, no on… attributes.',
	);

	if ( 'index' === $kind ) {
		$lines[] = '';
		$lines[] = 'Write index.html and css/style.css' . ( $scripts ? ' and js/main.js' : '' ) . ':';
		$lines[] = '- index.html is a complete HTML5 document. In <head>: <meta charset="utf-8">, the viewport meta, <title>, <meta name="description">, the Google Fonts link (and its preconnects), and <link rel="stylesheet" href="css/style.css">.';
		$lines[] = '- In <body>, directly and in this order: one <header> with the logo (the business name as text, or inline SVG) and the menu in a <nav> linking the pages above; one <main> with the home page\'s sections, from the plan; one <footer>. Nothing else at the top level but a skip link. The header and footer are every page\'s — make them complete.';
		$lines[] = '- css/style.css is the whole design system: colours and fonts as custom properties on :root, a container, the sections, headings, buttons, cards, forms, the header and its mobile menu, the footer — responsive from 360px up. Also style plain content inside any element with class "prose" — h2, h3, p, a, ul, ol, blockquote, img, figure, figcaption, table, code — for WordPress posts arrive as plain HTML.';
		$lines[] = 'Answer with JSON: index_html, style_css' . ( $scripts ? ', main_js' : '' ) . '.';
	} else {
		$lines[] = '';
		$lines[] = 'Write only the page\'s <main> element. Kerf puts it in place of the home page\'s <main>, inside the home page\'s own <head>, header and footer — do not write those. Build it from index.html\'s and css/style.css\'s classes and components; add CSS only for what they do not have, in css (it goes in css/pages.css, which every page but the home page loads). Give the page a <title> text (title) and a meta description (description).';
		if ( 'page' === $kind ) {
			// The banner follows each page's featured image once imported.
			$lines[] = '- If the page opens with a banner — its title over a photo — put data-kerf-field="image" on the element that shows the photo: WordPress then shows the page\'s featured image there, and this photo until one is chosen.';
		}
		if ( 'page' !== $kind ) {
			$lines[] = '';
			$lines[] = array(
				'home'   => 'This page is the blog: a page heading, then a list of post cards (picture, category, title, date, a short excerpt, a "read more" link) and page links (1, 2, 3, Next). Draw three sample posts. It is also used for a category\'s posts and for search results.',
				'single' => 'This page is one blog post: its title, date, author, category, featured picture, the article\'s text (a few paragraphs, a subheading, a list), its tags, links to the previous and next post, and a comments area with two sample comments and a form to leave one.',
				'404'    => 'This page says a page was not found: a short, friendly message, a link home, and a search form (role="search", one <input type="search" name="s">).',
			)[ $kind ];
			$lines[] = 'WordPress fills this page with the site\'s own posts where it is marked. Mark it:';
			foreach ( kerf_shell_contract_lines() as $line ) {
				if ( false === strpos( $line, 'data-kerf-template' ) ) {
					$lines[] = $line;
				}
			}
			$lines[] = '(The <body> is marked by Kerf: write nothing outside <main>.)';
		}
		$lines[] = 'Answer with JSON: title, description, main_html (the whole <main> element), css.';
	}
	return implode( "\n", $lines );
}

// ═══════════════════════════════════════════════════════════════════════════════
// CHECKING WHAT WAS WRITTEN
// ═══════════════════════════════════════════════════════════════════════════════
//
// What the model writes is a stranger's mockup (§6): the import's converter and
// staging are its security. These checks hold it to what was asked — the
// owner's pictures only, no script but the menu's, nothing from other sites —
// and say what they took out. They change the markup only by removing:
// libxml's serializer would lower-case an SVG's viewBox (scar 3), so nothing
// here re-serializes a document.

/** An attribute value that is a whole tag's worth: quoted, or plain. */
const KERF_PRO_AI_DESIGN_TAG = '(?:[^>"\']|"[^"]*"|\'[^\']*\')*';

/**
 * A file of HTML held to the rules.
 *
 * @param string $html
 * @param string $base    The file's folder, relative to the design's root.
 * @param array  $project
 * @param array  $notes   By reference: what was taken out, in plain words.
 * @return string
 */
function kerf_pro_ai_design_clean_html( $html, $base, $project, &$notes ) {
	$scripts = ! empty( $project['scripts'] );

	// Whole elements that may not be: what runs, frames, embeds, media from
	// elsewhere. The menu's script, for someone who may add scripts, stays.
	$html = kerf_pro_ai_design_strip_elements( $html, array( 'iframe', 'object', 'embed', 'applet', 'frame', 'frameset', 'base', 'video', 'audio', 'noscript' ), $notes );
	$html = (string) preg_replace_callback(
		'#<script\b(' . KERF_PRO_AI_DESIGN_TAG . ')>(.*?)</script\s*>#is',
		static function ( $m ) use ( $scripts, &$notes ) {
			if ( $scripts && '' === trim( $m[2] ) && preg_match( '/\bsrc\s*=\s*(["\']?)js\/main\.js\1/i', $m[1] ) && ! preg_match( '/\btype\s*=/i', $m[1] ) ) {
				return $m[0];
			}
			$notes['script'] = __( 'Kerf took out the scripts Gemini wrote besides the menu\'s.', 'kerf-pro' );
			return '';
		},
		$html
	);
	$html = (string) preg_replace_callback(
		'#<(meta|link)\b(' . KERF_PRO_AI_DESIGN_TAG . ')>#i',
		static function ( $m ) use ( &$notes ) {
			$tag = new WP_HTML_Tag_Processor( $m[0] );
			$tag->next_tag();
			if ( 'META' === $tag->get_tag() ) {
				return null === $tag->get_attribute( 'http-equiv' ) ? $m[0] : '';
			}
			$rel  = strtolower( (string) $tag->get_attribute( 'rel' ) );
			$href = (string) $tag->get_attribute( 'href' );
			if ( 'stylesheet' === $rel && ( preg_match( '#^css/(?:style|pages)\.css$#', $href ) || preg_match( '#^https://fonts\.googleapis\.com/#', $href ) ) ) {
				return $m[0];
			}
			if ( 'preconnect' === $rel && preg_match( '#^https://fonts\.(?:googleapis|gstatic)\.com/?$#', $href ) ) {
				return $m[0];
			}
			// Anything else from elsewhere is said; a link to a file the
			// design does not have (an invented icon) just goes.
			if ( preg_match( '#^(?:[a-z]+:)?//#i', $href ) ) {
				$notes['link'] = __( 'Kerf took out files Gemini linked from other sites.', 'kerf-pro' );
			}
			return '';
		},
		$html
	);

	// Pictures: the owner's, or none.
	$html = (string) preg_replace_callback(
		'#<(img|source)\b(' . KERF_PRO_AI_DESIGN_TAG . ')>#i',
		static function ( $m ) use ( $base, $project, &$notes ) {
			$tag = new WP_HTML_Tag_Processor( $m[0] );
			$tag->next_tag();
			// A <picture>'s other sources go: the converter keeps its <img>
			// (§6.1), and the library makes the sizes.
			if ( 'SOURCE' === $tag->get_tag() ) {
				return '';
			}
			if ( ! kerf_pro_ai_design_picture_ok( (string) $tag->get_attribute( 'src' ), $base, $project ) ) {
				$notes['picture'] = __( 'Kerf took out pictures Gemini used that are not yours.', 'kerf-pro' );
				return '';
			}
			return $m[0];
		},
		$html
	);

	// Attributes: handlers, addresses that run, `srcset` (the library makes
	// its own sizes), a form's address (Kerf makes forms send, §5.35), and a
	// style's pictures.
	$tags = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		foreach ( (array) $tags->get_attribute_names_with_prefix( 'on' ) as $name ) {
			$tags->remove_attribute( $name );
			$notes['handler'] = __( 'Kerf took out the on… attributes Gemini wrote.', 'kerf-pro' );
		}
		foreach ( array( 'href', 'src', 'action', 'formaction', 'xlink:href', 'poster', 'data' ) as $name ) {
			$value = $tags->get_attribute( $name );
			if ( is_string( $value ) && preg_match( '/^\s*(?:javascript|vbscript|data:(?!image\/svg\+xml))/i', $value ) ) {
				$tags->remove_attribute( $name );
			}
		}
		$tags->remove_attribute( 'srcset' );
		if ( 'FORM' === $tags->get_tag() ) {
			$tags->remove_attribute( 'action' );
		}
		// Written back only when something was taken out: set_attribute()
		// encodes the quotes (`url(&apos;img/x.jpg&apos;)`), which a browser
		// reads fine and a plain reading of the file does not.
		$style = $tags->get_attribute( 'style' );
		if ( is_string( $style ) && false !== stripos( $style, 'url(' ) ) {
			$clean = kerf_pro_ai_design_clean_css( $style, $base, $project, $notes );
			if ( $clean !== $style ) {
				$tags->set_attribute( 'style', $clean );
			}
		}
	}
	return $tags->get_updated_html();
}

/**
 * A stylesheet held to the rules: its pictures the owner's, fonts from Google
 * Fonts, nothing else from elsewhere.
 *
 * @param string $css
 * @param string $base    Its folder, relative to the design's root.
 * @param array  $project
 * @param array  $notes   By reference.
 * @return string
 */
function kerf_pro_ai_design_clean_css( $css, $base, $project, &$notes ) {
	$css = (string) preg_replace_callback(
		'/@import\s+(?:url\(\s*)?([\'"]?)([^\'")\s;]+)\1\s*\)?[^;]*;/i',
		static function ( $m ) use ( &$notes ) {
			if ( preg_match( '#^https://fonts\.googleapis\.com/#', $m[2] ) ) {
				return $m[0];
			}
			$notes['link'] = __( 'Kerf took out files Gemini linked from other sites.', 'kerf-pro' );
			return '';
		},
		(string) $css
	);
	return (string) preg_replace_callback(
		'/url\(\s*([\'"]?)([^\'")]*)\1\s*\)/i',
		static function ( $m ) use ( $base, $project, &$notes ) {
			$ref = trim( $m[2] );
			// Google Fonts (the stylesheet an @import above kept, and its font
			// files), an inline drawing, or the owner's picture.
			if ( preg_match( '#^https://fonts\.(?:googleapis|gstatic)\.com/#', $ref ) || preg_match( '#^data:image/svg\+xml#i', $ref ) || kerf_pro_ai_design_picture_ok( $ref, $base, $project ) ) {
				return $m[0];
			}
			$notes['picture'] = __( 'Kerf took out pictures Gemini used that are not yours.', 'kerf-pro' );
			return 'none';
		},
		$css
	);
}

/**
 * Is this one of the owner's pictures, as the file at $base refers to it?
 *
 * @param string $ref
 * @param string $base
 * @param array  $project
 * @return bool
 */
function kerf_pro_ai_design_picture_ok( $ref, $base, $project ) {
	$ref = trim( (string) strtok( (string) $ref, '?#' ) );
	if ( '' === $ref || preg_match( '#^(?:[a-z]+:|//)#i', $ref ) ) {
		return false;
	}
	return in_array( kerf_mc_join_path( $base, $ref ), wp_list_pluck( $project['pictures'], 'path' ), true );
}

/**
 * Take whole elements out — open tag, content and close — and say so.
 *
 * @param string   $html
 * @param string[] $names
 * @param array    $notes By reference.
 * @return string
 */
function kerf_pro_ai_design_strip_elements( $html, $names, &$notes ) {
	$names = implode( '|', array_map( 'preg_quote', $names ) );
	$count = 0;
	$html  = (string) preg_replace( '#<(' . $names . ')\b' . KERF_PRO_AI_DESIGN_TAG . '>.*?</\1\s*>#is', '', (string) $html, -1, $found );
	$count += $found;
	$html   = (string) preg_replace( '#<(' . $names . ')\b' . KERF_PRO_AI_DESIGN_TAG . '/?>#i', '', $html, -1, $found );
	$count += $found;
	if ( $count ) {
		$notes['element'] = __( 'Kerf took out frames, embeds, videos and scripts Gemini wrote: the design may not load anything from other sites.', 'kerf-pro' );
	}
	return $html;
}

/**
 * Is the home page made the way every page is built from it: one `<header>`,
 * one `<main>`, one `<footer>`, a title?
 *
 * @param string $html
 * @return true|string What is wrong, in plain words.
 */
function kerf_pro_ai_design_shape( $html ) {
	if ( 1 !== preg_match_all( '#<main\b#i', $html ) ) {
		return __( 'The home page Gemini wrote did not have one <main>. Writing it again…', 'kerf-pro' );
	}
	if ( ! preg_match( '#<header\b#i', $html ) || ! preg_match( '#<footer\b#i', $html ) || ! preg_match( '#<nav\b#i', $html ) ) {
		return __( 'The home page Gemini wrote had no header, menu or footer. Writing it again…', 'kerf-pro' );
	}
	if ( ! preg_match( '#<title\b[^>]*>[^<]+</title>#i', $html ) || ! preg_match( '#<body\b#i', $html ) ) {
		return __( 'The home page Gemini wrote was not a whole page. Writing it again…', 'kerf-pro' );
	}
	return true;
}

/**
 * A page of the design: the home page, its `<main>` replaced, its title and
 * description the page's, `css/pages.css` after the design system, and — for
 * a template — its kind on `<body>`.
 *
 * @param string $index       The home page.
 * @param string $main        The page's `<main>` element.
 * @param string $title
 * @param string $description
 * @param string $kind        A template's page type, or ''.
 * @return string
 */
function kerf_pro_ai_design_assemble( $index, $main, $title, $description, $kind ) {
	$html = (string) preg_replace_callback(
		'#<main\b' . KERF_PRO_AI_DESIGN_TAG . '>.*</main\s*>#is',
		static function () use ( $main ) {
			return $main;
		},
		$index,
		1
	);
	if ( '' !== $title ) {
		// A callback, not a replacement string: "Save $10" is no backreference.
		$html = (string) preg_replace_callback(
			'#<title\b([^>]*)>.*?</title>#is',
			static function ( $m ) use ( $title ) {
				return '<title' . $m[1] . '>' . esc_html( $title ) . '</title>';
			},
			$html,
			1
		);
	}
	$html = (string) preg_replace_callback(
		'#<link\b' . KERF_PRO_AI_DESIGN_TAG . 'href\s*=\s*(["\']?)css/style\.css\1' . KERF_PRO_AI_DESIGN_TAG . '>#i',
		static function ( $m ) {
			return $m[0] . "\n" . '<link rel="stylesheet" href="css/pages.css">';
		},
		$html,
		1
	);

	$tags = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		if ( 'META' === $tags->get_tag() && 'description' === strtolower( (string) $tags->get_attribute( 'name' ) ) && '' !== $description ) {
			$tags->set_attribute( 'content', mb_substr( $description, 0, 300 ) );
		}
		if ( 'BODY' === $tags->get_tag() && '' !== $kind ) {
			$tags->set_attribute( 'data-kerf-template', $kind );
		}
	}
	return $tags->get_updated_html();
}

/**
 * A template the converter can fill: the list's card and its title on the
 * blog, the post's text on a post. One that is not is marked by phase 2's
 * engine; one that cannot be is left out — the blog keeps its plain look.
 *
 * @param string $html
 * @param string $file
 * @param string $kind
 * @param array  $notes By reference.
 * @return string The template, or '' when it is left out.
 */
function kerf_pro_ai_design_ensure_marked( $html, $file, $kind, &$notes ) {
	// Gemini's own markers, held to what its placements are held to.
	$normal = kerf_pro_ai_design_normalize_markers( $html, $file, $kind );
	if ( ! is_wp_error( $normal ) && kerf_pro_ai_design_marked_ok( $normal['html'], $kind ) ) {
		if ( $normal['refused'] ) {
			/* translators: 1: how many markers, 2: file name. */
			$notes[ 'markers:' . $file ] = sprintf( _n( 'Kerf left out %1$d marker in %2$s that WordPress could not fill.', 'Kerf left out %1$d markers in %2$s that WordPress could not fill.', $normal['refused'], 'kerf-pro' ), $normal['refused'], $file );
		}
		return $normal['html'];
	}
	// Its own markers out, then placed again, by the engine that checks them.
	$tags = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		$tags->remove_attribute( 'data-kerf-loop' );
		$tags->remove_attribute( 'data-kerf-field' );
	}
	$marked = kerf_pro_ai_prepare( $file, $tags->get_updated_html(), $kind );
	if ( ! is_wp_error( $marked ) && kerf_pro_ai_design_marked_ok( $marked['html'], $kind ) ) {
		return $marked['html'];
	}
	/* translators: %s: file name. */
	$notes[ 'template:' . $file ] = sprintf( __( '%s was left out: it could not be marked for WordPress. The blog keeps its plain look there.', 'kerf-pro' ), $file );
	return '';
}

/**
 * A template's own markers, held to what phase 2 holds Gemini's placements to
 * (kerf_pro_ai_prepare_check()): each read as a placement on its numbered
 * element, checked and corrected — a title on an `<h3>` moved to its link, a
 * card on an `<article>` moved to the grid column that repeats, a text marker
 * on a box of elements left out (the converter could not fill it) — and
 * written back on the same tags, proved like a page Gemini marked.
 *
 * @param string $html
 * @param string $file
 * @param string $kind
 * @return array{html:string,refused:int}|WP_Error
 */
function kerf_pro_ai_design_normalize_markers( $html, $file, $kind ) {
	$tree       = kerf_pro_ai_prepare_tree( kerf_pro_ai_prepare_number( $html ) );
	$placements = array();
	foreach ( $tree['nodes'] as $node => $el ) {
		foreach ( array( 'data-kerf-loop', 'data-kerf-field' ) as $attribute ) {
			if ( $el->hasAttribute( $attribute ) ) {
				$placements[] = array( 'node' => $node, 'attribute' => $attribute, 'value' => $el->getAttribute( $attribute ) );
			}
		}
	}
	$checked = kerf_pro_ai_prepare_check( $placements, $tree, $kind, $file );
	if ( is_wp_error( $checked ) ) {
		return $checked;
	}

	$tags = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		$tags->remove_attribute( 'data-kerf-loop' );
		$tags->remove_attribute( 'data-kerf-field' );
	}
	$marked = kerf_pro_ai_prepare_apply( $tags->get_updated_html(), $checked['marks'], $kind );
	$proved = kerf_pro_ai_prepare_prove( $html, $marked, $file, $kind );
	return is_wp_error( $proved ) ? $proved : array( 'html' => $marked, 'refused' => count( $checked['refused'] ) );
}

/**
 * Does a template carry what its kind needs?
 *
 * @param string $html
 * @param string $kind
 * @return bool
 */
function kerf_pro_ai_design_marked_ok( $html, $kind ) {
	if ( '404' === $kind ) {
		return kerf_import_page_is_marked( $html );
	}
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . kerf_mc_extract_body( $html ) . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();
	$xpath = new DOMXPath( $doc );
	$field = static function ( $name ) {
		return '[contains(concat(" ", normalize-space(@data-kerf-field), " "), " ' . $name . ' ")]';
	};
	if ( 'single' === $kind || 'page' === $kind ) {
		return $xpath->query( '//*' . $field( 'content' ) )->length > 0;
	}
	$loop = $xpath->query( '//*[@data-kerf-loop]' )->item( 0 );
	return $loop && ( $xpath->query( 'descendant-or-self::*' . $field( 'title' ), $loop )->length || $xpath->query( 'descendant-or-self::*' . $field( 'permalink' ), $loop )->length );
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * POST kerf/v1/ai/design — start; GET kerf/v1/ai/design/preview — a staged
 * page, to look at before the check step.
 */
function kerf_pro_ai_design_routes() {
	register_rest_route( 'kerf/v1', '/ai/design', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_design',
		'permission_callback' => 'kerf_pro_ai_design_permission',
		'args'                => array(
			'brief'    => array( 'type' => 'string', 'required' => true ),
			'pictures' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ), 'default' => array() ),
			'details'  => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'string' ) ),
		),
	) );
	register_rest_route( 'kerf/v1', '/ai/design/preview', array(
		'methods'             => 'GET',
		'callback'            => 'kerf_pro_ai_rest_design_preview',
		'permission_callback' => static function () {
			return current_user_can( 'edit_theme_options' ) && kerf_pro_licensed();
		},
		'args'                => array(
			'token' => array( 'type' => 'string', 'required' => true ),
			'file'  => array( 'type' => 'string', 'required' => true ),
		),
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_design_routes' );

/**
 * Who may have a design made: whoever may import one, and use AI.
 *
 * @param WP_REST_Request $request
 * @return true|WP_Error
 */
function kerf_pro_ai_design_permission( $request ) {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return new WP_Error( 'kerf_ai_forbidden', __( 'Only someone who may import a design can have one made.', 'kerf-pro' ), array( 'status' => 403 ) );
	}
	return kerf_pro_ai_rest_permission( $request );
}

/**
 * Start a design.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_ai_rest_design( $request ) {
	$job = kerf_pro_ai_design_start( array(
		'brief'    => (string) $request['brief'],
		'pictures' => (array) $request['pictures'],
		// The details the owner confirmed on the screen; none sent, the site's.
		'details'  => $request->has_param( 'details' ) ? (array) $request['details'] : null,
	) );
	return is_wp_error( $job ) ? $job : rest_ensure_response( kerf_pro_ai_job_view( $job ) );
}

/**
 * A staged page of a design, as HTML to show in a frame that runs nothing
 * (`<iframe sandbox srcdoc>`): its relative files load from where they were
 * staged (`<base>`). The HTML itself never sits in uploads (scar 10), so a
 * link followed in the frame would show a page not found there: the base's
 * `target="_blank"` makes every link a new window, which the sandbox refuses —
 * the preview stays on its page.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_ai_rest_design_preview( $request ) {
	$pending = kerf_import_pending_peek( sanitize_key( (string) $request['token'] ) );
	$file    = (string) $request['file'];
	if ( ! $pending || empty( $pending['staging'] ) ) {
		return new WP_Error( 'kerf_ai_expired', __( 'That design has expired or was already imported.', 'kerf-pro' ), array( 'status' => 404 ) );
	}
	$staging = $pending['staging'];
	$html    = $file === $staging['entry_name'] ? $staging['html'] : ( isset( $staging['pages'][ $file ] ) ? $staging['pages'][ $file ] : null );
	if ( null === $html ) {
		return new WP_Error( 'kerf_ai_no_page', __( 'That page is not in this design.', 'kerf-pro' ), array( 'status' => 404 ) );
	}
	$base = '<base href="' . esc_url( $staging['base_url'] ) . '" target="_blank">';
	// A callback: a `$` in the address is not a backreference.
	$html = preg_match( '#<head\b[^>]*>#i', $html ) ? (string) preg_replace_callback( '#<head\b[^>]*>#i', static function ( $m ) use ( $base ) {
		return $m[0] . $base;
	}, $html, 1 ) : $base . $html;
	return rest_ensure_response( array( 'file' => $file, 'html' => $html ) );
}
