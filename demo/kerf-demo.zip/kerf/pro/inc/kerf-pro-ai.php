<?php
/**
 * AI in Kerf Pro: the key, the one way out to a model, and who may use it.
 *
 * Kerf's core is deterministic — the same design in, the same site out (§5.4)
 * — and stays so. AI is Kerf Pro's, opt-in and on demand: it writes prose,
 * text, design files or attribute placements, never block markup, and what it
 * writes is checked and then converted by the same converter as any design
 * (§5.46). Nothing that renders a page asks a model; a site keeps working
 * when the key or the licence goes.
 *
 * The customer's own key (the owner's decision, 2026-10-05), Gemini first.
 * Every feature asks kerf_pro_ai_request(), so another provider — Claude,
 * OpenAI, a server of the vendor's — is one more answer to
 * `kerf_pro_ai_provider`. Every AI route shares kerf_pro_ai_rest_permission():
 * who may, how often, how much, and the licence, in one place — without it,
 * anyone who can open the editor could spend the site owner's quota.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The Gemini key, when wp-config does not set KERF_GEMINI_API_KEY. Not autoloaded. */
const KERF_PRO_AI_KEY_OPTION = 'kerf_pro_ai_key';

/** "About your business", for the features that write words. */
const KERF_PRO_AI_ABOUT_OPTION = 'kerf_pro_ai_about';

/** Who may use AI: a capability. */
const KERF_PRO_AI_WHO_OPTION = 'kerf_pro_ai_who';

/** Requests a person may make a day. */
const KERF_PRO_AI_LIMIT_OPTION = 'kerf_pro_ai_daily_limit';

/** The site's use today: { day, calls, tokens }. */
const KERF_PRO_AI_USAGE_OPTION = 'kerf_pro_ai_usage';

/** The models this key can call, cached. */
const KERF_PRO_AI_MODELS_TRANSIENT = 'kerf_pro_ai_models';

/** The model chosen under Kerf → Settings; empty for Automatic. */
const KERF_PRO_AI_MODEL_OPTION = 'kerf_pro_ai_model';

/** Models Google listed for this key but would not run — gone, or none of its plan's quota — kept a day. */
const KERF_PRO_AI_REFUSED_TRANSIENT = 'kerf_pro_ai_refused';

// ═══════════════════════════════════════════════════════════════════════════════
// THE KEY, AND WHO MAY USE IT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The Gemini key: wp-config's KERF_GEMINI_API_KEY, else the one saved under
 * Kerf → Settings. Never sent to the browser.
 *
 * @return string
 */
function kerf_pro_ai_key() {
	if ( defined( 'KERF_GEMINI_API_KEY' ) && is_string( KERF_GEMINI_API_KEY ) && '' !== trim( KERF_GEMINI_API_KEY ) ) {
		return trim( KERF_GEMINI_API_KEY );
	}
	return trim( (string) get_option( KERF_PRO_AI_KEY_OPTION, '' ) );
}

/**
 * The key as the screen shows it: its last four characters.
 *
 * @param string $key
 * @return string
 */
function kerf_pro_ai_mask( $key ) {
	return '' === $key ? '' : str_repeat( '•', 8 ) . substr( $key, -4 );
}

/**
 * The capabilities "Who may use AI" offers: capability => who has it.
 *
 * @return array<string,string>
 */
function kerf_pro_ai_who_choices() {
	return array(
		'edit_theme_options' => __( 'Administrators', 'kerf-pro' ),
		'edit_others_pages'  => __( 'Administrators and Editors', 'kerf-pro' ),
		'edit_pages'         => __( 'Anyone who can edit pages', 'kerf-pro' ),
	);
}

/**
 * Who may use AI now.
 *
 * @return string A capability.
 */
function kerf_pro_ai_capability() {
	$who = (string) get_option( KERF_PRO_AI_WHO_OPTION, 'edit_theme_options' );
	return isset( kerf_pro_ai_who_choices()[ $who ] ) ? $who : 'edit_theme_options';
}

/**
 * Requests a person may make in a day.
 *
 * @return int
 */
function kerf_pro_ai_daily_limit() {
	$limit = (int) get_option( KERF_PRO_AI_LIMIT_OPTION, 60 );
	return $limit > 0 ? $limit : 60;
}

/**
 * Is AI on for this person: licensed, a key, and the capability?
 *
 * @return bool
 */
function kerf_pro_ai_available() {
	return kerf_pro_licensed() && '' !== kerf_pro_ai_key() && current_user_can( kerf_pro_ai_capability() );
}

/**
 * A person's requests today.
 *
 * @param int $user_id
 * @return int
 */
function kerf_pro_ai_calls_today( $user_id ) {
	$usage = get_user_meta( (int) $user_id, KERF_PRO_AI_USAGE_OPTION, true );
	return is_array( $usage ) && isset( $usage['day'] ) && wp_date( 'Y-m-d' ) === $usage['day'] ? (int) $usage['calls'] : 0;
}

/**
 * The site's use today.
 *
 * @return array{day:string,calls:int,tokens:int}
 */
function kerf_pro_ai_site_usage() {
	$usage = get_option( KERF_PRO_AI_USAGE_OPTION, array() );
	if ( ! is_array( $usage ) || ! isset( $usage['day'] ) || wp_date( 'Y-m-d' ) !== $usage['day'] ) {
		return array( 'day' => wp_date( 'Y-m-d' ), 'calls' => 0, 'tokens' => 0 );
	}
	return array( 'day' => $usage['day'], 'calls' => (int) $usage['calls'], 'tokens' => (int) $usage['tokens'] );
}

/**
 * An option as the database has it now, not as this PHP process read it
 * earlier. AI work waits minutes on the model; whatever it writes after that
 * wait is read again here first, or get_option() answers with the value from
 * before the wait and the write puts it back over what other requests wrote
 * meanwhile (scar 100).
 *
 * @param string $name
 * @param mixed  $default
 * @return mixed
 */
function kerf_pro_ai_fresh_option( $name, $default = array() ) {
	wp_cache_delete( $name, 'options' );
	return get_option( $name, $default );
}

/**
 * Count a request against the person and the site — after the model's wait,
 * so both counts are read again first: another job's requests count too.
 *
 * @param int $tokens What the model reported.
 */
function kerf_pro_ai_record_usage( $tokens ) {
	$day     = wp_date( 'Y-m-d' );
	$user_id = get_current_user_id();
	wp_cache_delete( KERF_PRO_AI_USAGE_OPTION, 'options' );
	if ( $user_id ) {
		wp_cache_delete( $user_id, 'user_meta' );
		update_user_meta( $user_id, KERF_PRO_AI_USAGE_OPTION, array(
			'day'   => $day,
			'calls' => kerf_pro_ai_calls_today( $user_id ) + 1,
		) );
	}
	$site = kerf_pro_ai_site_usage();
	update_option( KERF_PRO_AI_USAGE_OPTION, array(
		'day'    => $day,
		'calls'  => $site['calls'] + 1,
		'tokens' => $site['tokens'] + max( 0, (int) $tokens ),
	), false );
}

/**
 * Why AI is not on for this person now, in plain words — or null when it is.
 *
 * @return WP_Error|null
 */
function kerf_pro_ai_refusal() {
	if ( ! kerf_pro_licensed() ) {
		return new WP_Error( 'kerf_ai_licence', __( 'Your Kerf Pro licence has expired. Renew it to use AI again; everything it made keeps working.', 'kerf-pro' ), array( 'status' => 403 ) );
	}
	if ( ! current_user_can( kerf_pro_ai_capability() ) ) {
		return new WP_Error( 'kerf_ai_forbidden', __( 'Your account is not one of those allowed to use AI on this site (Kerf → Settings).', 'kerf-pro' ), array( 'status' => 403 ) );
	}
	if ( '' === kerf_pro_ai_key() ) {
		return new WP_Error( 'kerf_ai_no_key', __( 'Add your Gemini key under Kerf → Settings to use AI.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	if ( kerf_pro_ai_calls_today( get_current_user_id() ) >= kerf_pro_ai_daily_limit() ) {
		return new WP_Error( 'kerf_ai_limit', sprintf(
			/* translators: %d: requests a day. */
			__( 'You have used today\'s %d AI requests on this site. The limit is under Kerf → Settings.', 'kerf-pro' ),
			kerf_pro_ai_daily_limit()
		), array( 'status' => 429 ) );
	}
	return null;
}

/**
 * The permission callback every `kerf/v1/ai/*` route shares: the person, the
 * licence, the key, today's limit, and how much is sent.
 *
 * @param WP_REST_Request $request
 * @return true|WP_Error
 */
function kerf_pro_ai_rest_permission( $request ) {
	$refusal = kerf_pro_ai_refusal();
	if ( $refusal ) {
		return $refusal;
	}
	// A design and its pictures are big; past this, a request is a mistake.
	if ( strlen( (string) $request->get_body() ) > 12 * MB_IN_BYTES ) {
		return new WP_Error( 'kerf_ai_too_large', __( 'That is too much to send to the AI at once.', 'kerf-pro' ), array( 'status' => 413 ) );
	}
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE ONE WAY OUT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Ask the model. Every AI feature comes through here.
 *
 * @param string $task   What it is for, for the log: explain, prepare, design…
 * @param string $system The instructions.
 * @param array  $parts  The request: each { text: string } or { image: { mime, data (base64) } }.
 * @param array  $args   {
 *     @type string $tier        pro (best) or flash (fast). Default pro.
 *     @type bool   $json        Reply as JSON (decoded into `json`).
 *     @type array  $schema      The JSON reply's schema (OpenAPI subset), when `json`.
 *     @type float  $temperature Default 0.4.
 *     @type int    $max_tokens  Output cap; 0 for the model's own.
 *     @type int    $timeout     Seconds; default 180.
 * }
 * @return array{text:string,json:mixed,tokens:int,model:string}|WP_Error
 */
function kerf_pro_ai_request( $task, $system, $parts, $args = array() ) {
	$refusal = kerf_pro_ai_refusal();
	if ( $refusal ) {
		return $refusal;
	}

	$request = array(
		'task'   => (string) $task,
		'system' => (string) $system,
		'parts'  => (array) $parts,
		'args'   => wp_parse_args( $args, array(
			'tier'        => 'pro',
			'json'        => false,
			'schema'      => array(),
			'temperature' => 0.4,
			'max_tokens'  => 0,
			'timeout'     => 180,
		) ),
	);

	// A design takes a while to write; a host's 30 s default would end it.
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( (int) $request['args']['timeout'] + 30 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- disabled on some hosts; the request still runs.
	}

	/**
	 * Answer a request with another provider — Claude, OpenAI, a vendor's
	 * server. Return the result array (or a WP_Error) to answer it; null to let
	 * Gemini answer.
	 *
	 * @param array|WP_Error|null $result
	 * @param array               $request { task, system, parts, args }.
	 */
	$result = apply_filters( 'kerf_pro_ai_provider', null, $request );
	if ( null === $result ) {
		$result = kerf_pro_ai_gemini( $request );
	}
	if ( is_wp_error( $result ) ) {
		return $result;
	}

	kerf_pro_ai_record_usage( isset( $result['tokens'] ) ? (int) $result['tokens'] : 0 );

	if ( ! empty( $request['args']['json'] ) ) {
		$result['json'] = kerf_pro_ai_decode_json( $result['text'] );
		if ( null === $result['json'] ) {
			return new WP_Error( 'kerf_ai_unreadable', __( 'The AI\'s answer could not be read. Try again.', 'kerf-pro' ) );
		}
	} else {
		$result['json'] = null;
	}
	return $result;
}

/**
 * A model's JSON answer, read even with a code fence or a sentence around it.
 *
 * @param string $text
 * @return mixed Null when it is not JSON.
 */
function kerf_pro_ai_decode_json( $text ) {
	$text = trim( (string) $text );
	$text = (string) preg_replace( '/^```(?:json)?\s*|\s*```$/i', '', $text );
	$data = json_decode( $text, true );
	if ( null !== $data ) {
		return $data;
	}
	// The outermost object or list, whatever surrounds it.
	$first = strcspn( $text, '{[' );
	$last  = max( strrpos( $text, '}' ), strrpos( $text, ']' ) );
	if ( $first < strlen( $text ) && false !== $last && $last > $first ) {
		return json_decode( substr( $text, $first, $last - $first + 1 ), true );
	}
	return null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// GEMINI
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Answer a request with Gemini.
 *
 * Google lists models for a key that it will not run for it: a preview it has
 * since retired, or one the key's plan has no quota for — a free key and a new
 * Pro model. Kerf notes such a model for a day and asks the next one once, in
 * the same request, so the owner gets an answer rather than a setting to
 * change; another failure is said as it is.
 *
 * @param array $request { task, system, parts, args }.
 * @return array{text:string,tokens:int,model:string}|WP_Error
 */
function kerf_pro_ai_gemini( $request ) {
	$model  = kerf_pro_ai_model( $request['args']['tier'] );
	$result = kerf_pro_ai_gemini_call( $model, $request );

	if ( is_wp_error( $result ) && in_array( $result->get_error_code(), array( 'kerf_ai_model', 'kerf_ai_no_quota' ), true ) ) {
		kerf_pro_ai_refuse_model( $model );
		$next = kerf_pro_ai_model( $request['args']['tier'] );
		if ( $next !== $model ) {
			$result = kerf_pro_ai_gemini_call( $next, $request );
		}
	}
	return $result;
}

/**
 * Ask one Gemini model.
 *
 * Ported from the parent theme's Gemini caller, with the key in the
 * `x-goog-api-key` header, never the address — a key in a URL ends up in
 * proxies' and servers' logs.
 *
 * @param string $model   A model id.
 * @param array  $request { task, system, parts, args }.
 * @return array{text:string,tokens:int,model:string}|WP_Error
 */
function kerf_pro_ai_gemini_call( $model, $request ) {
	$args  = $request['args'];
	$parts = array();
	foreach ( $request['parts'] as $part ) {
		if ( isset( $part['text'] ) ) {
			$parts[] = array( 'text' => (string) $part['text'] );
		} elseif ( isset( $part['image']['mime'], $part['image']['data'] ) ) {
			$parts[] = array( 'inline_data' => array( 'mime_type' => (string) $part['image']['mime'], 'data' => (string) $part['image']['data'] ) );
		}
	}

	$config = array( 'temperature' => (float) $args['temperature'] );
	// Leaving the cap out is what "the model's own maximum" means to the API.
	if ( ! empty( $args['max_tokens'] ) ) {
		$config['maxOutputTokens'] = (int) $args['max_tokens'];
	}
	if ( ! empty( $args['json'] ) ) {
		$config['responseMimeType'] = 'application/json';
		if ( ! empty( $args['schema'] ) ) {
			$config['responseSchema'] = $args['schema'];
		}
	}

	$response = wp_remote_post(
		'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent',
		array(
			'headers' => array(
				'Content-Type'   => 'application/json',
				'x-goog-api-key' => kerf_pro_ai_key(),
			),
			'body'    => wp_json_encode( array(
				'system_instruction' => array( 'parts' => array( array( 'text' => $request['system'] ) ) ),
				'contents'           => array( array( 'role' => 'user', 'parts' => $parts ) ),
				'generationConfig'   => $config,
			) ),
			'timeout' => (int) $args['timeout'],
		)
	);

	if ( is_wp_error( $response ) ) {
		$raw = $response->get_error_message();
		if ( false !== stripos( $raw, 'timed out' ) || false !== stripos( $raw, 'timeout' ) ) {
			return new WP_Error( 'kerf_ai_timeout', __( 'The AI was still working when Kerf stopped waiting. Try again; a smaller request answers sooner.', 'kerf-pro' ) );
		}
		return new WP_Error( 'kerf_ai_network', sprintf(
			/* translators: %s: the error the server gave. */
			__( 'Kerf could not reach Gemini: %s', 'kerf-pro' ),
			$raw
		) );
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );

	if ( 200 !== $code ) {
		return kerf_pro_ai_gemini_error( $code, is_array( $data ) ? $data : array() );
	}

	$candidate = isset( $data['candidates'][0] ) && is_array( $data['candidates'][0] ) ? $data['candidates'][0] : array();
	$finish    = isset( $candidate['finishReason'] ) ? (string) $candidate['finishReason'] : '';
	$text      = '';
	foreach ( isset( $candidate['content']['parts'] ) ? (array) $candidate['content']['parts'] : array() as $part ) {
		if ( isset( $part['text'] ) && empty( $part['thought'] ) ) {
			$text .= (string) $part['text'];
		}
	}

	if ( '' === trim( $text ) ) {
		if ( isset( $data['promptFeedback']['blockReason'] ) || 'SAFETY' === $finish ) {
			return new WP_Error( 'kerf_ai_refused', __( 'Gemini would not answer this request. Reword it and try again.', 'kerf-pro' ) );
		}
		return new WP_Error( 'kerf_ai_empty', 'MAX_TOKENS' === $finish
			? __( 'The AI ran out of room before it answered. Ask for less at once.', 'kerf-pro' )
			: __( 'The AI gave no answer. Try again.', 'kerf-pro' ) );
	}
	if ( 'MAX_TOKENS' === $finish ) {
		return new WP_Error( 'kerf_ai_cut', __( 'The AI\'s answer was cut off before it finished. Ask for less at once.', 'kerf-pro' ) );
	}

	return array(
		'text'   => $text,
		'tokens' => isset( $data['usageMetadata']['totalTokenCount'] ) ? (int) $data['usageMetadata']['totalTokenCount'] : 0,
		'model'  => $model,
	);
}

/**
 * Gemini's error, in plain words.
 *
 * @param int   $code HTTP status.
 * @param array $data Its body.
 * @return WP_Error
 */
function kerf_pro_ai_gemini_error( $code, $data ) {
	$status  = isset( $data['error']['status'] ) ? (string) $data['error']['status'] : '';
	$message = isset( $data['error']['message'] ) ? (string) $data['error']['message'] : '';

	if ( ( 400 === $code && false !== stripos( $message, 'API key' ) ) || 'PERMISSION_DENIED' === $status || 401 === $code || 403 === $code ) {
		return new WP_Error( 'kerf_ai_bad_key', __( 'Gemini did not accept the key. Check it under Kerf → Settings.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	// "limit: 0" is not a busy minute: the key's plan has no quota for this
	// model at all — a free key and a model only paid plans may call.
	if ( ( 429 === $code || 'RESOURCE_EXHAUSTED' === $status ) && preg_match( '/\blimit:\s*0\b/', $message ) ) {
		return new WP_Error( 'kerf_ai_no_quota', __( 'Your Gemini plan cannot use this model. Choose another under Kerf → Settings, or leave it on Automatic.', 'kerf-pro' ), array( 'status' => 429 ) );
	}
	if ( 429 === $code || 'RESOURCE_EXHAUSTED' === $status ) {
		return new WP_Error( 'kerf_ai_quota', __( 'Google\'s limit for your key was reached. Wait a minute and try again, or check your Gemini plan.', 'kerf-pro' ), array( 'status' => 429 ) );
	}
	if ( 413 === $code || false !== stripos( $message, 'too large' ) || false !== stripos( $message, 'exceeds' ) ) {
		return new WP_Error( 'kerf_ai_too_large', __( 'That was too much for the AI to read at once.', 'kerf-pro' ), array( 'status' => 413 ) );
	}
	if ( 404 === $code ) {
		delete_transient( KERF_PRO_AI_MODELS_TRANSIENT );
		return new WP_Error( 'kerf_ai_model', __( 'Gemini no longer offers that model. Try again — Kerf picks another.', 'kerf-pro' ) );
	}
	if ( $code >= 500 ) {
		return new WP_Error( 'kerf_ai_down', __( 'Gemini is having trouble right now. Try again in a moment.', 'kerf-pro' ) );
	}
	return new WP_Error( 'kerf_ai_error', '' !== $message ? $message : sprintf(
		/* translators: %d: HTTP status. */
		__( 'Gemini answered with an error (%d).', 'kerf-pro' ),
		$code
	) );
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHICH MODEL
// ═══════════════════════════════════════════════════════════════════════════════
//
// Read from Google's list for this key, not hard-coded: Google retires model
// ids on a rolling basis, and only the API knows what a key can call. The
// fallback is the long-standing 2.5 family, used only when the list cannot be
// read (as the parent theme did).
//
// Automatic gives each tier the newest model the key can call, a preview
// included — `pro` for careful work, `flash` for quick answers. Stable models
// only, as it was, gave a key that has Gemini 3.1 Pro Preview the older 2.5
// Pro (the owner's call, 2026-10-06). Kerf → Settings can choose one model for
// everything instead; a model Google will not run for the key is passed over
// (kerf_pro_ai_gemini()), the chosen one too.

/**
 * A model id as a tier and version, or null for anything but a general Gemini
 * text model (image, speech, Gemma… are left out).
 *
 * @param string $id
 * @return array{id:string,tier:string,major:int,minor:int,preview:bool}|null
 */
function kerf_pro_ai_parse_model( $id ) {
	if ( ! preg_match( '/^gemini-(\d+)(?:\.(\d+))?-(flash-lite|flash|pro)(-preview)?$/', (string) $id, $m ) ) {
		return null;
	}
	return array(
		'id'      => (string) $id,
		'tier'    => $m[3],
		'major'   => (int) $m[1],
		'minor'   => isset( $m[2] ) && '' !== $m[2] ? (int) $m[2] : 0,
		'preview' => ! empty( $m[4] ),
	);
}

/**
 * The models this key can call, newest first in each tier.
 *
 * Asked of Google where a moment's wait is expected — Kerf → Settings, "Check
 * the key", WP-CLI — and before a request when nothing is kept for this key:
 * a model picked from no list would be the fallback's 2.5, whatever the key
 * can call. Kept twelve hours; when the list cannot be read, the fallback is
 * kept ten minutes, so requests do not each wait on Google for it.
 *
 * @param bool|string $fetch true: ask Google now; 'missing': only when nothing
 *                           is kept for this key; false: what is kept, else the fallback.
 * @return array[]
 */
function kerf_pro_ai_models( $fetch = false ) {
	$key    = kerf_pro_ai_key();
	$cached = get_transient( KERF_PRO_AI_MODELS_TRANSIENT );
	if ( true !== $fetch && is_array( $cached ) && isset( $cached['key'] ) && md5( $key ) === $cached['key'] && ! empty( $cached['models'] ) ) {
		return $cached['models'];
	}

	$fallback = array_values( array_filter( array_map( 'kerf_pro_ai_parse_model', array( 'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.5-flash-lite' ) ) ) );
	usort( $fallback, 'kerf_pro_ai_compare_models' );
	if ( ! $fetch || '' === $key ) {
		return $fallback;
	}

	$models   = array();
	$response = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', array(
		'headers' => array( 'x-goog-api-key' => $key ),
		'timeout' => 10,
	) );
	$body = is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ? array() : json_decode( (string) wp_remote_retrieve_body( $response ), true );
	foreach ( isset( $body['models'] ) && is_array( $body['models'] ) ? $body['models'] : array() as $model ) {
		if ( ! in_array( 'generateContent', isset( $model['supportedGenerationMethods'] ) ? (array) $model['supportedGenerationMethods'] : array(), true ) ) {
			continue;
		}
		$parsed = kerf_pro_ai_parse_model( preg_replace( '#^models/#', '', isset( $model['name'] ) ? (string) $model['name'] : '' ) );
		if ( $parsed ) {
			$models[] = $parsed;
		}
	}
	if ( $models ) {
		usort( $models, 'kerf_pro_ai_compare_models' );
		set_transient( KERF_PRO_AI_MODELS_TRANSIENT, array( 'key' => md5( $key ), 'models' => $models ), 12 * HOUR_IN_SECONDS );
		return $models;
	}
	set_transient( KERF_PRO_AI_MODELS_TRANSIENT, array( 'key' => md5( $key ), 'models' => $fallback, 'fallback' => true ), 10 * MINUTE_IN_SECONDS );
	return $fallback;
}

/**
 * Newest first, a stable release ahead of a preview of the same version.
 *
 * @param array $a
 * @param array $b
 * @return int
 */
function kerf_pro_ai_compare_models( $a, $b ) {
	if ( $a['major'] !== $b['major'] ) {
		return $b['major'] <=> $a['major'];
	}
	if ( $a['minor'] !== $b['minor'] ) {
		return $b['minor'] <=> $a['minor'];
	}
	return (int) $a['preview'] <=> (int) $b['preview'];
}

/**
 * The model a request uses: the one chosen under Kerf → Settings while the
 * key can call it, else Automatic's for the tier.
 *
 * @param string $tier pro (careful work) or flash (quick answers).
 * @return string
 */
function kerf_pro_ai_model( $tier ) {
	$chosen = kerf_pro_ai_chosen_model();
	/**
	 * Filter the model a tier uses.
	 *
	 * @param string $id
	 * @param string $tier
	 */
	return (string) apply_filters( 'kerf_pro_ai_model', '' !== $chosen && kerf_pro_ai_can_use( $chosen ) ? $chosen : kerf_pro_ai_auto_model( $tier ), $tier );
}

/**
 * Automatic's model for a tier: the newest this key can call — a stable
 * release ahead of a preview of the same version — that Google has not
 * refused lately; else the closest tier.
 *
 * @param string $tier pro or flash.
 * @return string
 */
function kerf_pro_ai_auto_model( $tier ) {
	$refused = kerf_pro_ai_refused_models();
	foreach ( array( $tier, 'pro', 'flash', 'flash-lite' ) as $want ) {
		foreach ( kerf_pro_ai_models( 'missing' ) as $model ) {
			if ( $want === $model['tier'] && ! isset( $refused[ $model['id'] ] ) ) {
				return $model['id'];
			}
		}
	}
	return 'gemini-2.5-flash';
}

/**
 * The model chosen under Kerf → Settings, or '' for Automatic.
 *
 * @return string
 */
function kerf_pro_ai_chosen_model() {
	$chosen = (string) get_option( KERF_PRO_AI_MODEL_OPTION, '' );
	return kerf_pro_ai_parse_model( $chosen ) ? $chosen : '';
}

/**
 * Can this key call that model now: Google lists it for the key, and has not
 * refused it lately?
 *
 * @param string $id
 * @return bool
 */
function kerf_pro_ai_can_use( $id ) {
	return in_array( (string) $id, wp_list_pluck( kerf_pro_ai_models( 'missing' ), 'id' ), true )
		&& ! isset( kerf_pro_ai_refused_models()[ (string) $id ] );
}

/**
 * The models Google would not run for this key lately: id => when.
 *
 * @return array<string,int>
 */
function kerf_pro_ai_refused_models() {
	$refused = get_transient( KERF_PRO_AI_REFUSED_TRANSIENT );
	return is_array( $refused ) && isset( $refused['key'], $refused['models'] ) && md5( kerf_pro_ai_key() ) === $refused['key']
		? (array) $refused['models']
		: array();
}

/**
 * Pass a model over for a day: Google would not run it for this key. A day,
 * not for good — a plan gains quota, a model comes back.
 *
 * @param string $id
 */
function kerf_pro_ai_refuse_model( $id ) {
	$models                 = kerf_pro_ai_refused_models();
	$models[ (string) $id ] = time();
	set_transient( KERF_PRO_AI_REFUSED_TRANSIENT, array( 'key' => md5( kerf_pro_ai_key() ), 'models' => $models ), DAY_IN_SECONDS );
}

/**
 * A model as the settings name it: gemini-3.1-pro-preview → "Gemini 3.1 Pro Preview".
 *
 * @param string $id
 * @return string
 */
function kerf_pro_ai_model_label( $id ) {
	return ucwords( str_replace( '-', ' ', (string) $id ) );
}

// ═══════════════════════════════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The AI settings, in the Kerf settings group.
 */
function kerf_pro_ai_register_settings() {
	register_setting( 'kerf_settings', KERF_PRO_AI_KEY_OPTION, array(
		'type'              => 'string',
		'sanitize_callback' => 'kerf_pro_ai_sanitize_key',
		'default'           => '',
	) );
	register_setting( 'kerf_settings', KERF_PRO_AI_MODEL_OPTION, array(
		'type'              => 'string',
		'sanitize_callback' => static function ( $value ) {
			// A Gemini text model's id, or Automatic: the list itself is Google's.
			return kerf_pro_ai_parse_model( (string) $value ) ? (string) $value : '';
		},
		'default'           => '',
	) );
	register_setting( 'kerf_settings', KERF_PRO_AI_ABOUT_OPTION, array(
		'type'              => 'string',
		'sanitize_callback' => static function ( $value ) {
			return mb_substr( sanitize_textarea_field( (string) $value ), 0, 2000 );
		},
		'default'           => '',
	) );
	register_setting( 'kerf_settings', KERF_PRO_AI_WHO_OPTION, array(
		'type'              => 'string',
		'sanitize_callback' => static function ( $value ) {
			return isset( kerf_pro_ai_who_choices()[ (string) $value ] ) ? (string) $value : 'edit_theme_options';
		},
		'default'           => 'edit_theme_options',
	) );
	register_setting( 'kerf_settings', KERF_PRO_AI_LIMIT_OPTION, array(
		'type'              => 'integer',
		'sanitize_callback' => static function ( $value ) {
			return max( 1, min( 1000, (int) $value ) );
		},
		'default'           => 60,
	) );
}
add_action( 'admin_init', 'kerf_pro_ai_register_settings' );

/**
 * A key typed in replaces the saved one; an empty field keeps it (the screen
 * never shows a saved key back); "Remove the key" clears it.
 *
 * @param mixed $value
 * @return string
 */
function kerf_pro_ai_sanitize_key( $value ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Missing -- options.php checked the settings nonce.
	if ( ! empty( $_POST['kerf_pro_ai_remove_key'] ) ) {
		return '';
	}
	$value = trim( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value ) );
	return '' !== $value ? $value : (string) get_option( KERF_PRO_AI_KEY_OPTION, '' );
}

/**
 * The AI rows on Kerf → Settings.
 */
function kerf_pro_ai_settings_section() {
	$key      = kerf_pro_ai_key();
	$constant = defined( 'KERF_GEMINI_API_KEY' ) && '' !== trim( (string) KERF_GEMINI_API_KEY );
	$usage    = kerf_pro_ai_site_usage();

	kerf_ui_setting_open(
		__( 'AI: your Gemini key', 'kerf-pro' ),
		__( 'Kerf Pro\'s AI uses your own Google Gemini key — a free one works. What you ask it for (your design\'s HTML and CSS, the text and pictures you give it) is sent to Google with that key, under your Google account\'s terms. Nothing is sent until you press an AI button.', 'kerf-pro' )
	);
	?>
	<div class="kerf-field">
		<?php if ( $constant ) : ?>
			<p class="kerf-help"><?php esc_html_e( 'Set in wp-config.php (KERF_GEMINI_API_KEY).', 'kerf-pro' ); ?> <code><?php echo esc_html( kerf_pro_ai_mask( $key ) ); ?></code></p>
		<?php else : ?>
			<label class="screen-reader-text" for="kerf_pro_ai_key"><?php esc_html_e( 'Gemini API key', 'kerf-pro' ); ?></label>
			<input type="password" name="<?php echo esc_attr( KERF_PRO_AI_KEY_OPTION ); ?>" id="kerf_pro_ai_key" autocomplete="off" value="" placeholder="<?php echo esc_attr( '' !== $key ? kerf_pro_ai_mask( $key ) : __( 'Paste your key', 'kerf-pro' ) ); ?>">
			<p class="kerf-help">
				<?php
				printf(
					/* translators: %s: link to Google AI Studio. */
					esc_html__( 'Get one at %s. Left empty, the saved key stays.', 'kerf-pro' ),
					'<a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a>'
				);
				?>
			</p>
			<?php if ( '' !== $key ) : ?>
				<label class="kerf-switch">
					<input type="checkbox" name="kerf_pro_ai_remove_key" value="1">
					<span class="kerf-switch__text"><strong><?php esc_html_e( 'Remove the key', 'kerf-pro' ); ?></strong></span>
				</label>
			<?php endif; ?>
		<?php endif; ?>
		<?php if ( '' !== $key ) : ?>
			<p class="kerf-row">
				<button type="button" class="kerf-btn kerf-btn--sm" data-kerf-ai-check><?php esc_html_e( 'Check the key', 'kerf-pro' ); ?></button>
				<span class="kerf-help" data-kerf-ai-check-result role="status"></span>
			</p>
		<?php endif; ?>
	</div>
	<?php
	kerf_ui_setting_close();

	if ( '' !== $key ) {
		kerf_pro_ai_model_setting();
	}

	kerf_ui_setting_open(
		__( 'AI: about your business', 'kerf-pro' ),
		__( 'A few sentences the AI writes from when it makes pages or words for you: what you do, for whom, where, and how you like to sound.', 'kerf-pro' )
	);
	?>
	<label class="screen-reader-text" for="kerf_pro_ai_about"><?php esc_html_e( 'About your business', 'kerf-pro' ); ?></label>
	<textarea name="<?php echo esc_attr( KERF_PRO_AI_ABOUT_OPTION ); ?>" id="kerf_pro_ai_about" rows="4" placeholder="<?php esc_attr_e( 'A family dental practice in Austin since 1987: check-ups, implants, same-day crowns. Warm and plain-spoken.', 'kerf-pro' ); ?>"><?php echo esc_textarea( (string) get_option( KERF_PRO_AI_ABOUT_OPTION, '' ) ); ?></textarea>
	<?php
	kerf_ui_setting_close();

	kerf_ui_setting_open(
		__( 'AI: who may use it', 'kerf-pro' ),
		__( 'Every request uses your key, so your quota.', 'kerf-pro' )
	);
	?>
	<div class="kerf-row">
		<label class="screen-reader-text" for="kerf_pro_ai_who"><?php esc_html_e( 'Who may use AI', 'kerf-pro' ); ?></label>
		<select name="<?php echo esc_attr( KERF_PRO_AI_WHO_OPTION ); ?>" id="kerf_pro_ai_who">
			<?php foreach ( kerf_pro_ai_who_choices() as $cap => $label ) : ?>
				<option value="<?php echo esc_attr( $cap ); ?>" <?php selected( kerf_pro_ai_capability(), $cap ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
		<label for="kerf_pro_ai_limit"><?php esc_html_e( 'up to', 'kerf-pro' ); ?></label>
		<input type="number" name="<?php echo esc_attr( KERF_PRO_AI_LIMIT_OPTION ); ?>" id="kerf_pro_ai_limit" min="1" max="1000" value="<?php echo esc_attr( (string) kerf_pro_ai_daily_limit() ); ?>">
		<span><?php esc_html_e( 'requests each a day', 'kerf-pro' ); ?></span>
	</div>
	<p class="kerf-help">
		<?php
		printf(
			/* translators: 1: requests today, 2: tokens today. */
			esc_html__( 'Today on this site: %1$d requests, %2$s tokens.', 'kerf-pro' ),
			(int) $usage['calls'],
			esc_html( number_format_i18n( $usage['tokens'] ) )
		);
		?>
	</p>
	<?php
	kerf_ui_setting_close();
}
add_action( 'kerf_settings_sections', 'kerf_pro_ai_settings_section', 20 );

/**
 * The model row on Kerf → Settings: Automatic, or one of the Gemini text
 * models this key can call, previews included, for everything.
 */
function kerf_pro_ai_model_setting() {
	$models = kerf_pro_ai_models( 'missing' );
	$chosen = kerf_pro_ai_chosen_model();
	$tiers  = array(
		'pro'        => __( 'Pro — careful work, slower', 'kerf-pro' ),
		'flash'      => __( 'Flash — quick answers', 'kerf-pro' ),
		'flash-lite' => __( 'Flash-Lite — the quickest', 'kerf-pro' ),
	);

	kerf_ui_setting_open(
		__( 'AI: the model', 'kerf-pro' ),
		__( 'Automatic gives careful work — marking pages, making designs — the most capable Gemini your key can use, previews included, and quick answers a fast one. Or choose one model for everything.', 'kerf-pro' )
	);
	?>
	<label class="screen-reader-text" for="kerf_pro_ai_model"><?php esc_html_e( 'Gemini model', 'kerf-pro' ); ?></label>
	<select name="<?php echo esc_attr( KERF_PRO_AI_MODEL_OPTION ); ?>" id="kerf_pro_ai_model">
		<option value="" <?php selected( '', $chosen ); ?>><?php esc_html_e( 'Automatic — recommended', 'kerf-pro' ); ?></option>
		<?php if ( '' !== $chosen && ! in_array( $chosen, wp_list_pluck( $models, 'id' ), true ) ) : ?>
			<?php // Kept as chosen while Google's list is out of reach or the model is gone: saving the screen must not choose for the owner. ?>
			<option value="<?php echo esc_attr( $chosen ); ?>" selected>
				<?php
				/* translators: %s: a model's name. */
				printf( esc_html__( '%s — not offered to this key now', 'kerf-pro' ), esc_html( kerf_pro_ai_model_label( $chosen ) ) );
				?>
			</option>
		<?php endif; ?>
		<?php foreach ( $tiers as $tier => $label ) : ?>
			<?php $in_tier = wp_list_filter( $models, array( 'tier' => $tier ) ); ?>
			<?php if ( $in_tier ) : ?>
				<optgroup label="<?php echo esc_attr( $label ); ?>">
					<?php foreach ( $in_tier as $model ) : ?>
						<option value="<?php echo esc_attr( $model['id'] ); ?>" <?php selected( $chosen, $model['id'] ); ?>><?php echo esc_html( kerf_pro_ai_model_label( $model['id'] ) ); ?></option>
					<?php endforeach; ?>
				</optgroup>
			<?php endif; ?>
		<?php endforeach; ?>
	</select>
	<p class="kerf-help">
		<?php
		printf(
			/* translators: 1: a model for careful work, 2: a model for quick answers. */
			esc_html__( 'Automatic now uses %1$s for careful work and %2$s for quick answers.', 'kerf-pro' ),
			esc_html( kerf_pro_ai_model_label( kerf_pro_ai_auto_model( 'pro' ) ) ),
			esc_html( kerf_pro_ai_model_label( kerf_pro_ai_auto_model( 'flash' ) ) )
		);
		?>
	</p>
	<?php if ( '' !== $chosen && ! kerf_pro_ai_can_use( $chosen ) ) : ?>
		<p class="kerf-help">
			<?php
			printf(
				/* translators: 1: the chosen model, 2: the model used instead. */
				esc_html__( 'Google does not let this key use %1$s now, so Kerf uses %2$s until it does.', 'kerf-pro' ),
				esc_html( kerf_pro_ai_model_label( $chosen ) ),
				esc_html( kerf_pro_ai_model_label( kerf_pro_ai_auto_model( 'pro' ) ) )
			);
			?>
		</p>
	<?php endif; ?>
	<?php
	kerf_ui_setting_close();
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES, AND THE SCREENS' SCRIPT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The AI routes every screen shares.
 */
function kerf_pro_ai_routes() {
	register_rest_route( 'kerf/v1', '/ai/check-key', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_check_key',
		'permission_callback' => static function () {
			// The key is the site's: only someone who may change settings checks it.
			return current_user_can( 'edit_theme_options' ) && kerf_pro_licensed();
		},
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_routes' );

/**
 * "Check the key": the models it can call, read from Google, and a one-word
 * answer from the one careful work would use.
 *
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_ai_rest_check_key() {
	if ( '' === kerf_pro_ai_key() ) {
		return new WP_Error( 'kerf_ai_no_key', __( 'There is no key to check.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	delete_transient( KERF_PRO_AI_MODELS_TRANSIENT );
	$response = wp_remote_get( 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=200', array(
		'headers' => array( 'x-goog-api-key' => kerf_pro_ai_key() ),
		'timeout' => 10,
	) );
	if ( is_wp_error( $response ) ) {
		return new WP_Error( 'kerf_ai_network', sprintf(
			/* translators: %s: the error the server gave. */
			__( 'Kerf could not reach Gemini: %s', 'kerf-pro' ),
			$response->get_error_message()
		), array( 'status' => 502 ) );
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		return kerf_pro_ai_gemini_error( $code, is_array( $data ) ? $data : array() );
	}
	$models = kerf_pro_ai_models( true );

	// A fresh check starts from what Google lists, and asks the model careful
	// work would use for one word: Google lists models a key's plan cannot
	// call, and the check should name one that answers.
	delete_transient( KERF_PRO_AI_REFUSED_TRANSIENT );
	for ( $tries = 0; $tries < 3; $tries++ ) {
		$model = kerf_pro_ai_model( 'pro' );
		$ping  = kerf_pro_ai_gemini_call( $model, array(
			'task'   => 'check',
			'system' => 'Answer with one word.',
			'parts'  => array( array( 'text' => 'Reply with the word OK.' ) ),
			'args'   => array( 'tier' => 'pro', 'json' => false, 'schema' => array(), 'temperature' => 0.0, 'max_tokens' => 0, 'timeout' => 60 ),
		) );
		if ( ! is_wp_error( $ping ) || ! in_array( $ping->get_error_code(), array( 'kerf_ai_model', 'kerf_ai_no_quota' ), true ) ) {
			break;
		}
		kerf_pro_ai_refuse_model( $model );
	}
	if ( is_wp_error( $ping ) ) {
		return $ping;
	}

	$chosen = kerf_pro_ai_chosen_model();
	return rest_ensure_response( array(
		'ok'      => true,
		'message' => '' !== $chosen && $chosen === $ping['model']
			? sprintf(
				/* translators: %s: a model's name. */
				__( 'The key works. Kerf uses %s, as chosen below, for everything.', 'kerf-pro' ),
				kerf_pro_ai_model_label( $chosen )
			)
			: sprintf(
				/* translators: 1: a model for careful work, 2: a model for quick answers. */
				__( 'The key works. Kerf uses %1$s for careful work and %2$s for quick answers.', 'kerf-pro' ),
				kerf_pro_ai_model_label( $ping['model'] ),
				kerf_pro_ai_model_label( kerf_pro_ai_model( 'flash' ) )
			),
		'models'  => count( $models ),
	) );
}

/**
 * The mark on AI's buttons and panels: a spark, drawn like the admin's other
 * icons (kerf_ui_icon()).
 *
 * @return string
 */
function kerf_pro_ai_icon() {
	return '<svg class="kerf-icon kerf-icon--ai" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5c.6 4.6 3.4 7.4 8 8-4.6.6-7.4 3.4-8 8-.6-4.6-3.4-7.4-8-8 4.6-.6 7.4-3.4 8-8z"/><path d="M18.5 3v4M16.5 5h4"/></svg>';
}

/**
 * What every AI screen shares (assets/js/kerf-ai.js, assets/css/kerf-ai.css):
 * requests, their waiting line, their errors, and the panels' look.
 *
 * @param string $hook
 */
function kerf_pro_ai_admin_assets( $hook ) {
	if ( ! function_exists( 'kerf_ui_is_kerf_screen' ) || ! kerf_ui_is_kerf_screen( $hook ) ) {
		return;
	}
	$rel = 'assets/js/kerf-ai.js';
	wp_enqueue_script( 'kerf-ai', kerf_pro_url( $rel ), array( 'wp-api-fetch', 'wp-i18n', 'kerf-admin' ), filemtime( kerf_pro_path( $rel ) ), true );
	wp_set_script_translations( 'kerf-ai', 'kerf-pro', kerf_pro_path( 'languages' ) );
	$css = 'assets/css/kerf-ai.css';
	wp_enqueue_style( 'kerf-ai', kerf_pro_url( $css ), array( 'kerf-admin' ), filemtime( kerf_pro_path( $css ) ) );
}
add_action( 'admin_enqueue_scripts', 'kerf_pro_ai_admin_assets', 20 );
