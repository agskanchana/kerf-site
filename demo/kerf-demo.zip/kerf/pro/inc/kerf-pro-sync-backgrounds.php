<?php
/**
 * Update from a newer design: the owner's background pictures, checked against
 * the new version (CLAUDE.md §5.41).
 *
 * The stylesheet is never edited, so an update checks each picture the owner
 * changed — "everywhere" rules and "here" styles on blocks — in the browser,
 * against the new stylesheets (assets/js/kerf-sync-backgrounds.js), and
 * applies what the owner ticks. Kerf Pro's, with the update; the pictures
 * themselves are drawn by the free plugin (its inc/kerf-backgrounds.php).
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ═══════════════════════════════════════════════════════════════════════════════
// UPDATE FROM MOCKUP
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Every picture the owner changed in the site's design: the "everywhere"
 * rules, and each block that carries one of its own (`kerfBg`) in the pages,
 * parts and templates an update compares.
 *
 * @return array[] Each: id, scope, selector, media, layer, design, url, where.
 */
function kerf_bg_overrides() {
	$list = array();
	foreach ( kerf_bg_rules( 0 ) as $key => $rule ) {
		$list[] = array(
			'id'       => 'rule:' . $key,
			'scope'    => 'everywhere',
			'selector' => (string) $rule['selector'],
			'media'    => (string) $rule['media'],
			'layer'    => (int) $rule['layer'],
			'design'   => (string) $rule['design'],
			'url'      => (string) $rule['url'],
			// Each page's featured image: the rule keeps the design's value,
			// so it takes the new version's whole (kerf-sync-backgrounds.js).
			'featured' => ! empty( $rule['featured'] ),
			'where'    => __( 'Everywhere', 'kerf-pro' ),
		);
	}

	foreach ( kerf_sync_targets() as $target ) {
		$post = get_post( (int) $target['id'] );
		if ( ! $post || false === strpos( $post->post_content, '"kerfBg"' ) ) {
			continue;
		}
		kerf_bg_walk( parse_blocks( $post->post_content ), static function ( $block ) use ( &$list, $post, $target ) {
			$mine = isset( $block['attrs']['kerfBg'] ) ? $block['attrs']['kerfBg'] : null;
			if ( ! is_array( $mine ) || empty( $mine['decl'] ) || empty( $mine['selector'] ) ) {
				return;
			}
			$list[] = array(
				'id'       => 'block:' . $post->ID . ':' . md5( (string) $mine['decl'] ),
				'scope'    => 'here',
				'selector' => (string) $mine['selector'],
				'media'    => (string) ( $mine['media'] ?? '' ),
				'layer'    => (int) ( $mine['layer'] ?? 0 ),
				'design'   => (string) ( $mine['design'] ?? '' ),
				'url'      => (string) ( $mine['url'] ?? '' ),
				'where'    => (string) $target['label'],
			);
		} );
	}

	return $list;
}

/**
 * Visit every block, depth first.
 *
 * @param array[]  $blocks
 * @param callable $visit
 */
function kerf_bg_walk( $blocks, $visit ) {
	foreach ( (array) $blocks as $block ) {
		$visit( $block );
		if ( ! empty( $block['innerBlocks'] ) ) {
			kerf_bg_walk( $block['innerBlocks'], $visit );
		}
	}
}

/**
 * What the update screen's check needs (assets/js/kerf-sync-backgrounds.js):
 * the owner's changes, and the new version's stylesheets — files by URL,
 * inline blocks by text. Null when the owner changed no picture.
 *
 * @param array $staging The new version.
 * @return array|null
 */
function kerf_bg_update_data( $staging ) {
	$overrides = kerf_bg_overrides();
	if ( ! $overrides ) {
		return null;
	}
	$sheets = array();
	// As the update would keep them — a ZIP's, or a pasted page's (kerf_sync_new_assets()).
	foreach ( kerf_sync_new_assets( $staging ) as $asset ) {
		if ( 'css' !== ( $asset['type'] ?? '' ) || ! empty( $asset['only'] ) ) {
			continue;
		}
		if ( 'file' === $asset['kind'] && ! empty( $asset['src'] ) ) {
			$sheets[] = array( 'url' => (string) $asset['src'] );
		} elseif ( 'inline' === $asset['kind'] ) {
			$sheets[] = array( 'text' => (string) $asset['content'], 'base' => '' !== (string) $staging['base_url'] ? (string) $staging['base_url'] : kerf_sync_paste_base( $staging ) );
		}
	}
	return array( 'overrides' => $overrides, 'sheets' => $sheets );
}

/**
 * Apply what the owner chose on the update screen: take the design's new
 * picture where ticked; elsewhere keep theirs, with the rest of the design's
 * value (an overlay, a texture) brought up to the new version's.
 *
 * @param bool $assets_updated Whether the new stylesheets went live: only then
 *                             do refreshed values (which name the new
 *                             version's files) make sense.
 * @return string[] Report lines.
 */
function kerf_bg_update_apply( $assets_updated ) {
	// phpcs:disable WordPress.Security.NonceVerification -- verified in kerf_sync_handle_post().
	$take    = isset( $_POST['kerf_bg_take'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['kerf_bg_take'] ) ) : array();
	// Each value is checked where it is used: a picture by kerf_bg_value_ok(),
	// the design's path by sanitize_text_field().
	$refresh = isset( $_POST['kerf_bg_refresh'] ) && $assets_updated ? (array) wp_unslash( $_POST['kerf_bg_refresh'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- see above.
	$design  = isset( $_POST['kerf_bg_design'] ) && $assets_updated ? (array) wp_unslash( $_POST['kerf_bg_design'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- see above.
	// phpcs:enable WordPress.Security.NonceVerification
	$lines   = array();
	$taken   = 0;

	// "Everywhere" changes.
	$rules   = kerf_bg_rules( 0 );
	$changed = false;
	foreach ( $rules as $key => $rule ) {
		$id = 'rule:' . $key;
		if ( in_array( $id, $take, true ) ) {
			unset( $rules[ $key ] );
			$changed = true;
			$taken++;
			continue;
		}
		if ( isset( $refresh[ $id ] ) && kerf_bg_value_ok( (string) $refresh[ $id ] ) ) {
			$rules[ $key ]['value']  = (string) $refresh[ $id ];
			$rules[ $key ]['design'] = substr( sanitize_text_field( (string) ( $design[ $id ] ?? $rule['design'] ) ), 0, 300 );
			$changed                 = true;
		}
	}
	if ( $changed ) {
		kerf_bg_rules_save( 0, $rules );
	}

	// Pictures on one block.
	$posts = array();
	foreach ( array_merge( $take, array_keys( $refresh ) ) as $id ) {
		if ( preg_match( '/^block:(\d+):([a-f0-9]{32})$/', (string) $id, $m ) ) {
			$posts[ (int) $m[1] ] = true;
		}
	}
	foreach ( array_keys( $posts ) as $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			continue;
		}
		$blocks = kerf_bg_update_blocks( parse_blocks( $post->post_content ), $post_id, $take, $refresh, $design, $taken );
		$markup = serialize_blocks( $blocks );
		if ( $markup !== $post->post_content ) {
			// wp_update_post() unslashes what it is given (scar 1).
			wp_update_post( wp_slash( array( 'ID' => $post_id, 'post_content' => $markup ) ) );
		}
	}

	if ( $taken ) {
		$lines[] = sprintf(
			/* translators: %d: number of pictures. */
			_n( 'Took the new design\'s picture in %d place where you had chosen your own.', 'Took the new design\'s pictures in %d places where you had chosen your own.', $taken, 'kerf-pro' ),
			$taken
		);
	}
	return $lines;
}

/**
 * The blocks of one post, with the owner's pictures taken back or refreshed.
 *
 * @param array[] $blocks
 * @param int     $post_id
 * @param array   $take
 * @param array   $refresh
 * @param array   $design
 * @param int     $taken   Counted up.
 * @return array[]
 */
function kerf_bg_update_blocks( $blocks, $post_id, $take, $refresh, $design, &$taken ) {
	foreach ( $blocks as $i => $block ) {
		$mine = isset( $block['attrs']['kerfBg'] ) ? $block['attrs']['kerfBg'] : null;
		if ( is_array( $mine ) && ! empty( $mine['decl'] ) ) {
			$id    = 'block:' . $post_id . ':' . md5( (string) $mine['decl'] );
			$style = isset( $block['attrs']['inlineStyle'] ) ? (string) $block['attrs']['inlineStyle'] : '';
			if ( in_array( $id, $take, true ) ) {
				$block['attrs']['inlineStyle'] = kerf_bg_remove_decl( $style, (string) $mine['decl'] );
				if ( '' === $block['attrs']['inlineStyle'] ) {
					unset( $block['attrs']['inlineStyle'] );
				}
				unset( $block['attrs']['kerfBg'] );
				$taken++;
			} elseif ( isset( $refresh[ $id ] ) && kerf_bg_value_ok( (string) $refresh[ $id ] ) && false !== strpos( $style, (string) $mine['decl'] ) ) {
				$decl = 'background-image: ' . (string) $refresh[ $id ] . ( false !== stripos( (string) $mine['decl'], '!important' ) ? ' !important' : '' );
				$block['attrs']['inlineStyle']      = str_replace( (string) $mine['decl'], $decl, $style );
				$block['attrs']['kerfBg']['decl']   = $decl;
				$block['attrs']['kerfBg']['design'] = substr( sanitize_text_field( (string) ( $design[ $id ] ?? $mine['design'] ?? '' ) ), 0, 300 );
			}
		}
		if ( ! empty( $block['innerBlocks'] ) ) {
			$block['innerBlocks'] = kerf_bg_update_blocks( $block['innerBlocks'], $post_id, $take, $refresh, $design, $taken );
		}
		$blocks[ $i ] = $block;
	}
	return $blocks;
}

/**
 * A declaration Kerf added, taken back out of a style (the PHP twin of the
 * panel's removeDecl()).
 *
 * @param string $style
 * @param string $decl
 * @return string
 */
function kerf_bg_remove_decl( $style, $decl ) {
	$at = '' === $decl ? false : strrpos( $style, $decl );
	if ( false === $at ) {
		return $style;
	}
	$out = substr( $style, 0, $at ) . substr( $style, $at + strlen( $decl ) );
	return trim( (string) preg_replace( '/;\s*;/', ';', $out ), " \t\n\r;" );
}

/**
 * The update screen's check (assets/js/kerf-sync-backgrounds.js).
 *
 * @param string $hook
 */
function kerf_bg_admin_assets( $hook ) {
	if ( false === strpos( (string) $hook, 'kerf-update' ) ) {
		return;
	}
	$rel = 'assets/js/kerf-sync-backgrounds.js';
	if ( ! file_exists( kerf_pro_path( $rel ) ) ) {
		return;
	}
	kerf_bg_register_core();
	wp_enqueue_script( 'kerf-sync-backgrounds', kerf_pro_url( $rel ), array( 'kerf-background-core' ), filemtime( kerf_pro_path( $rel ) ), true );
	wp_localize_script( 'kerf-sync-backgrounds', 'kerfSyncBackgrounds', array(
		'same'      => __( 'the new version keeps the design\'s picture here; yours stays.', 'kerf-pro' ),
		'changed'   => __( 'the new version changes this picture too; yours stays unless you tick the box.', 'kerf-pro' ),
		'goneRule'  => __( 'the new version no longer has this style, so your change does nothing there.', 'kerf-pro' ),
		'goneBlock' => __( 'the new version no longer has this style; your picture stays on the element.', 'kerf-pro' ),
		'featured'  => __( 'each page keeps showing its featured image here; a page without one shows the new version\'s picture.', 'kerf-pro' ),
		'take'      => __( 'Use the design\'s new picture', 'kerf-pro' ),
		'remove'    => __( 'Remove my change', 'kerf-pro' ),
		'failed'    => __( 'Could not check them against the new version. Your pictures will stay as they are.', 'kerf-pro' ),
	) );
}
add_action( 'admin_enqueue_scripts', 'kerf_bg_admin_assets' );
