<?php
/**
 * Kerf → Site details, and the import finding them (§5.36).
 *
 * The free plugin keeps the business's details and shows them wherever the
 * design does (inc/kerf-site.php: the `kerf/site` binding source, `kerfSite`).
 * Finding them in a design and binding each place to one key is the
 * converter's `site_details` option, which an import asks for here; changing
 * them once, for every page, is this screen.
 *
 * Kerf Pro's (§8.14). With a lapsed licence the details keep showing, an
 * import binds no new ones, and the screen waits for a renewal.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * An import (an update, a page) finds and binds the business's details.
 *
 * @param array $options The converter's options (kerf_import_converter_options()).
 * @return array
 */
function kerf_site_converter_options( $options ) {
	if ( kerf_pro_licensed() ) {
		$options['site_details'] = true;
	}
	return $options;
}
add_filter( 'kerf_import_converter_options', 'kerf_site_converter_options' );

/**
 * The screen.
 */
function kerf_site_menu() {
	add_submenu_page( 'kerf', __( 'Site details', 'kerf-pro' ), __( 'Site details', 'kerf-pro' ), 'edit_theme_options', 'kerf-site', 'kerf_site_render_page' );
}
add_action( 'admin_menu', 'kerf_site_menu', 25 );

/**
 * Save the screen's form.
 *
 * @return bool Whether something was saved.
 */
function kerf_site_handle_post() {
	if ( empty( $_POST['kerf_site_nonce'] ) || ! current_user_can( 'edit_theme_options' )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_site_nonce'] ) ), 'kerf_site' ) ) {
		return false;
	}

	$details = array();
	$posted  = isset( $_POST['kerf_site'] ) && is_array( $_POST['kerf_site'] ) ? wp_unslash( $_POST['kerf_site'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- each field is cleaned in kerf_site_clean().
	foreach ( $posted as $key => $detail ) {
		$key = sanitize_key( (string) $key );
		if ( '' === $key || ! is_array( $detail ) ) {
			continue;
		}
		$detail = kerf_site_clean( $detail );
		$base   = preg_replace( '/-\d+$/', '', $key );
		// Typed only as shown: the link follows (`tel:` digits, `mailto:`).
		if ( '' === $detail['href'] && '' !== $detail['text'] ) {
			if ( 'phone' === $base ) {
				$detail['href'] = 'tel:' . preg_replace( '/[^\d+]/', '', $detail['text'] );
			} elseif ( 'email' === $base && is_email( $detail['text'] ) ) {
				$detail['href'] = 'mailto:' . $detail['text'];
			}
		}
		if ( '' !== $detail['text'] || '' !== $detail['href'] ) {
			$details[ $key ] = $detail;
		}
	}
	update_option( KERF_SITE_OPTION, $details, false );
	return true;
}

/**
 * Render the screen: every detail the design has, and the common ones.
 */
function kerf_site_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to change these details.', 'kerf-pro' ) );
	}
	// A lapsed licence: the details keep showing on the site; changing them
	// here waits for a renewal.
	if ( ! kerf_pro_licensed() ) {
		kerf_ui_open( __( 'Site details', 'kerf-pro' ) );
		kerf_pro_renew_notice();
		kerf_ui_close();
		return;
	}
	$saved   = kerf_site_handle_post();
	$details = kerf_site_details();
	$keys    = array_unique( array_merge( array_keys( $details ), array( 'phone', 'email', 'address', 'hours' ) ) );
	$social  = array_diff( array_keys( kerf_site_labels() ), array( 'phone', 'email', 'address', 'hours' ) );

	kerf_ui_open( __( 'Site details', 'kerf-pro' ), array(
		'lede' => __( 'Your phone number, email, address and social links, wherever the design shows them — the top bar, the footer, the contact page. Change one here and every place changes.', 'kerf-pro' ),
	) );
	if ( $saved ) {
		echo kerf_ui_note( __( 'Saved. Every page shows the new details.', 'kerf-pro' ), 'ok' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}
	?>
	<form method="post" class="kerf-stack">
		<?php wp_nonce_field( 'kerf_site', 'kerf_site_nonce' ); ?>

		<section class="kerf-panel">
			<div class="kerf-panel__head"><h2><?php esc_html_e( 'How to reach you', 'kerf-pro' ); ?></h2></div>
			<?php foreach ( $keys as $key ) : ?>
				<?php
				$detail = isset( $details[ $key ] ) ? $details[ $key ] : array( 'text' => '', 'href' => '' );
				$base   = preg_replace( '/-\d+$/', '', $key );
				if ( in_array( $base, $social, true ) ) {
					continue;
				}
				$help = array(
					'phone'   => __( 'As shown, and the number a tap dials. Leave the second empty to dial what is shown.', 'kerf-pro' ),
					'email'   => __( 'As shown, and the address the link opens.', 'kerf-pro' ),
					'address' => __( 'One line per line, as the design shows it.', 'kerf-pro' ),
					'hours'   => __( 'One line per line, as the design shows them.', 'kerf-pro' ),
				);
				kerf_ui_setting_open( kerf_site_label( $key ), isset( $details[ $key ] ) ? '' : __( 'Not in your design yet.', 'kerf-pro' ) );
				?>
				<div class="kerf-field">
					<label class="screen-reader-text" for="kerf-site-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( kerf_site_label( $key ) ); ?></label>
					<?php if ( 'address' === $base || 'hours' === $base ) : ?>
						<textarea name="kerf_site[<?php echo esc_attr( $key ); ?>][text]" id="kerf-site-<?php echo esc_attr( $key ); ?>" rows="3"><?php echo esc_textarea( $detail['text'] ); ?></textarea>
						<input type="hidden" name="kerf_site[<?php echo esc_attr( $key ); ?>][href]" value="<?php echo esc_attr( $detail['href'] ); ?>">
					<?php else : ?>
						<div class="kerf-row">
							<input type="text" name="kerf_site[<?php echo esc_attr( $key ); ?>][text]" id="kerf-site-<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $detail['text'] ); ?>" placeholder="<?php esc_attr_e( 'As shown', 'kerf-pro' ); ?>">
							<input type="text" name="kerf_site[<?php echo esc_attr( $key ); ?>][href]" value="<?php echo esc_attr( $detail['href'] ); ?>" placeholder="<?php echo esc_attr( 'phone' === $base ? 'tel:+15551234567' : 'mailto:you@example.com' ); ?>" aria-label="<?php esc_attr_e( 'Where its link goes', 'kerf-pro' ); ?>">
						</div>
					<?php endif; ?>
					<?php if ( isset( $help[ $base ] ) ) : ?>
						<p class="kerf-help"><?php echo esc_html( $help[ $base ] ); ?></p>
					<?php endif; ?>
				</div>
				<?php kerf_ui_setting_close(); ?>
			<?php endforeach; ?>
		</section>

		<section class="kerf-panel">
			<div class="kerf-panel__head"><h2><?php esc_html_e( 'Social profiles', 'kerf-pro' ); ?></h2></div>
			<?php foreach ( $social as $key ) : ?>
				<?php kerf_ui_setting_open( kerf_site_label( $key ), isset( $details[ $key ] ) ? '' : __( 'Not in your design — filled in for when it is.', 'kerf-pro' ) ); ?>
				<label class="screen-reader-text" for="kerf-site-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( kerf_site_label( $key ) ); ?></label>
				<input type="url" name="kerf_site[<?php echo esc_attr( $key ); ?>][href]" id="kerf-site-<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( isset( $details[ $key ] ) ? $details[ $key ]['href'] : '' ); ?>" placeholder="https://">
				<input type="hidden" name="kerf_site[<?php echo esc_attr( $key ); ?>][text]" value="<?php echo esc_attr( isset( $details[ $key ] ) ? $details[ $key ]['text'] : '' ); ?>">
				<?php kerf_ui_setting_close(); ?>
			<?php endforeach; ?>
			<div class="kerf-panel__foot">
				<button type="submit" class="kerf-btn kerf-btn--primary"><?php esc_html_e( 'Save details', 'kerf-pro' ); ?></button>
				<p class="kerf-help"><?php esc_html_e( 'A detail shows where the design marked it (data-kerf-site) or where Kerf found it: phone and email links, links to social profiles. A number only mentioned in a sentence stays as written.', 'kerf-pro' ); ?></p>
			</div>
		</section>
	</form>
	<?php
	kerf_ui_close();
}
