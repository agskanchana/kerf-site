<?php
/**
 * Form entries: every message a design's forms send, kept (§5.35).
 *
 * The free plugin sends the designer's forms and emails each message
 * (inc/kerf-forms.php), then announces it (`kerf_form_received`). Here it is
 * kept as a private `kerf_entry` under Kerf → Form entries — spam too, marked
 * and not emailed — so nothing is lost if an email goes astray.
 *
 * Kerf Pro's (§8.14). A lapsed licence keeps the entries readable and stops
 * keeping new ones; the emails go on, as without Pro.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keep a message that arrived, while the licence lets Pro.
 *
 * @param string   $form
 * @param int      $page
 * @param array    $fields
 * @param bool     $spam
 * @param string[] $files The names of the files that came with it (emailed, not kept).
 */
function kerf_forms_keep( $form, $page, $fields, $spam, $files = array() ) {
	kerf_forms_last_entry( kerf_pro_licensed() ? kerf_forms_store( (string) $form, (int) $page, (array) $fields, (bool) $spam, (array) $files ) : 0 );
}
add_action( 'kerf_form_received', 'kerf_forms_keep', 10, 5 );

/**
 * The entry this request's message was kept as, or 0.
 *
 * @param int|null $id Set it.
 * @return int
 */
function kerf_forms_last_entry( $id = null ) {
	static $last = 0;
	if ( null !== $id ) {
		$last = (int) $id;
	}
	return $last;
}

/**
 * A message kept here is not lost when its email is: the free plugin then
 * thanks the visitor all the same (kerf_forms_receive()).
 *
 * @param bool $kept
 * @return bool
 */
function kerf_forms_kept( $kept ) {
	return $kept || kerf_forms_last_entry() > 0;
}
add_filter( 'kerf_form_kept', 'kerf_forms_kept' );

/**
 * Settings may say every message waits under Form entries only while the
 * licence lets Pro keep them (kerf_forms_keep()).
 *
 * @param bool $keeps
 * @return bool
 */
function kerf_forms_keeps( $keeps ) {
	return $keeps || kerf_pro_licensed();
}
add_filter( 'kerf_forms_keeps', 'kerf_forms_keeps' );

/**
 * Its email did not go out: the entry says so, and why.
 *
 * @param bool   $sent
 * @param string $error
 */
function kerf_forms_mailed( $sent, $error ) {
	$id = kerf_forms_last_entry();
	if ( $id && ! $sent ) {
		update_post_meta( $id, '_kerf_mail_failed', wp_slash( (string) $error ) );
	}
}
add_action( 'kerf_form_mailed', 'kerf_forms_mailed', 10, 2 );

/**
 * Keep the message as a Form entry.
 *
 * @param string   $form
 * @param int      $page
 * @param array    $fields
 * @param bool     $spam
 * @param string[] $files
 * @return int Entry ID.
 */
function kerf_forms_store( $form, $page, $fields, $spam, $files = array() ) {
	$who = '';
	foreach ( array( 'name', 'full-name', 'your-name', 'email' ) as $key ) {
		if ( ! empty( $fields[ $key ] ) ) {
			$who = $fields[ $key ];
			break;
		}
	}

	$id = wp_insert_post( array(
		'post_type'    => 'kerf_entry',
		'post_status'  => 'private',
		/* translators: 1: form name, 2: who sent it. */
		'post_title'   => wp_slash( trim( sprintf( __( '%1$s — %2$s', 'kerf-pro' ), ucfirst( $form ), $who ), ' —' ) ),
		'post_content' => wp_slash( kerf_forms_text( $fields ) ),
	), true );

	if ( is_wp_error( $id ) ) {
		return 0;
	}
	update_post_meta( $id, '_kerf_form', $form );
	update_post_meta( $id, '_kerf_page', (int) $page );
	update_post_meta( $id, '_kerf_fields', wp_slash( $fields ) );
	if ( $spam ) {
		update_post_meta( $id, '_kerf_spam', 1 );
	}
	if ( $files ) {
		update_post_meta( $id, '_kerf_files', wp_slash( array_values( array_map( 'strval', $files ) ) ) );
	}
	return (int) $id;
}

/**
 * The entries: private, and only for whoever runs the site.
 */
function kerf_forms_register() {
	register_post_type( 'kerf_entry', array(
		'labels'       => array(
			'name'          => __( 'Form entries', 'kerf-pro' ),
			'singular_name' => __( 'Form entry', 'kerf-pro' ),
			'menu_name'     => __( 'Form entries', 'kerf-pro' ),
			'edit_item'     => __( 'Form entry', 'kerf-pro' ),
			'not_found'     => __( 'No messages yet.', 'kerf-pro' ),
			'search_items'  => __( 'Search entries', 'kerf-pro' ),
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'kerf',
		'show_in_rest' => false,
		'supports'     => array( 'title' ),
		'map_meta_cap' => false,
		'capabilities' => array(
			'edit_post'          => 'edit_theme_options',
			'read_post'          => 'edit_theme_options',
			'delete_post'        => 'edit_theme_options',
			'edit_posts'         => 'edit_theme_options',
			'edit_others_posts'  => 'edit_theme_options',
			'delete_posts'       => 'edit_theme_options',
			'publish_posts'      => 'edit_theme_options',
			'read_private_posts' => 'edit_theme_options',
			'create_posts'       => 'do_not_allow',
		),
	) );
}
add_action( 'init', 'kerf_forms_register' );

/**
 * What was sent, on the entry's screen.
 */
function kerf_forms_meta_box() {
	add_meta_box( 'kerf-entry', __( 'Message', 'kerf-pro' ), static function ( $post ) {
		$fields = get_post_meta( $post->ID, '_kerf_fields', true );
		$page   = (int) get_post_meta( $post->ID, '_kerf_page', true );
		echo '<table class="widefat striped"><tbody>';
		foreach ( is_array( $fields ) ? $fields : array() as $name => $value ) {
			printf( '<tr><th style="width:180px">%s</th><td>%s</td></tr>', esc_html( ucfirst( str_replace( array( '-', '_' ), ' ', $name ) ) ), nl2br( esc_html( $value ) ) );
		}
		echo '</tbody></table>';
		printf(
			'<p class="description">%s %s%s</p>',
			/* translators: %s: date and time. */
			esc_html( sprintf( __( 'Sent %s', 'kerf-pro' ), get_the_date( '', $post ) . ' ' . get_the_time( '', $post ) ) ),
			/* translators: %s: page title. */
			$page ? esc_html( sprintf( __( 'from "%s".', 'kerf-pro' ), get_the_title( $page ) ) ) : '',
			get_post_meta( $post->ID, '_kerf_spam', true ) ? ' <strong>' . esc_html__( 'Marked as spam: not emailed.', 'kerf-pro' ) . '</strong>' : ''
		);
		$failed = (string) get_post_meta( $post->ID, '_kerf_mail_failed', true );
		if ( '' !== $failed ) {
			/* translators: %s: WordPress's reason. */
			printf( '<p class="description"><strong>%s</strong></p>', esc_html( sprintf( __( 'Its email could not be sent: %s. The message is all here.', 'kerf-pro' ), $failed ) ) );
		}
		if ( get_post_meta( $post->ID, '_kerf_files', true ) ) {
			printf( '<p class="description">%s</p>', esc_html( '' !== $failed
				? __( 'The files that came with it went only with the email, which did not go out: ask the sender for them again.', 'kerf-pro' )
				: __( 'The files that came with it were attached to the email; they are not kept on this site.', 'kerf-pro' ) ) );
		}
	}, 'kerf_entry', 'normal', 'high' );
}
add_action( 'add_meta_boxes_kerf_entry', 'kerf_forms_meta_box' );

/**
 * Columns: who, which form, the start of the message.
 *
 * @param array $columns
 * @return array
 */
function kerf_forms_columns( $columns ) {
	return array(
		'cb'           => $columns['cb'],
		'title'        => __( 'From', 'kerf-pro' ),
		'kerf_form'    => __( 'Form', 'kerf-pro' ),
		'kerf_message' => __( 'Message', 'kerf-pro' ),
		'date'         => $columns['date'],
	);
}
add_filter( 'manage_kerf_entry_posts_columns', 'kerf_forms_columns' );

/**
 * @param string $column
 * @param int    $post_id
 */
function kerf_forms_column( $column, $post_id ) {
	if ( 'kerf_form' === $column ) {
		echo esc_html( ucfirst( (string) get_post_meta( $post_id, '_kerf_form', true ) ) );
		if ( get_post_meta( $post_id, '_kerf_spam', true ) ) {
			echo ' <span class="kerf-chip kerf-chip--fail">' . esc_html__( 'spam', 'kerf-pro' ) . '</span>';
		}
		if ( '' !== (string) get_post_meta( $post_id, '_kerf_mail_failed', true ) ) {
			echo ' <span class="kerf-chip kerf-chip--fail">' . esc_html__( 'not emailed', 'kerf-pro' ) . '</span>';
		}
	} elseif ( 'kerf_message' === $column ) {
		echo esc_html( wp_trim_words( (string) get_post_field( 'post_content', $post_id ), 18 ) );
	}
}
add_action( 'manage_kerf_entry_posts_custom_column', 'kerf_forms_column', 10, 2 );

/**
 * On the entries' screen, with a lapsed licence: new messages are emailed but
 * no longer kept; the ones there stay.
 */
function kerf_forms_entries_notice() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $screen || 'edit-kerf_entry' !== $screen->id || kerf_pro_licensed() ) {
		return;
	}
	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html__( 'Your Kerf Pro licence has expired: new messages are still emailed to you, but no longer kept here. The ones below stay. Renew to keep every message again.', 'kerf-pro' )
	);
}
add_action( 'admin_notices', 'kerf_forms_entries_notice' );
