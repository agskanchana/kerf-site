<?php
/**
 * AI work longer than a web request: a job, done a step at a time while the
 * owner's browser asks after it.
 *
 * A Pro model writing a home page takes minutes, and a host's gateway gives
 * up on a request long before PHP does — Nginx at 60 s, Cloudflare at 100 s
 * (§9.28). So a job is a list of steps, each one model request at most, kept
 * in the database. The browser asks after it every few seconds
 * (GET kerf/v1/ai/jobs/<id>); the request that finds the next step free
 * answers at once — "working on it" — and does that step after the browser
 * has its answer (kerf_pro_ai_job_detach()). No cron and no request to itself,
 * both often blocked on hosts: the job moves while its page is open, and
 * waits where it was when it is closed.
 *
 * A step whose PHP process dies (a host's own limit) is taken up again once
 * its lock is stale. A step that fails for a reason that passes — Google
 * busy, a minute's quota — is tried again, twice; any other failure stops the
 * job and says why, in plain words.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Every job, by id: kept two days. */
const KERF_PRO_AI_JOBS_OPTION = 'kerf_pro_ai_jobs';

/** A step's lock older than this belonged to a process that died. */
const KERF_PRO_AI_JOB_STALE = 900;

/** Tries a step gets when it fails for a reason that passes. */
const KERF_PRO_AI_JOB_TRIES = 3;

/**
 * Start a job.
 *
 * @param string   $kind  What it is: its steps are done by the handler
 *                        `kerf_pro_ai_job_handlers()` names for it.
 * @param array[]  $steps Each { key, label }.
 * @param array    $data  What its steps work on.
 * @return array The job.
 */
function kerf_pro_ai_job_create( $kind, $steps, $data = array() ) {
	$job = array(
		'id'      => strtolower( wp_generate_password( 12, false, false ) ),
		'kind'    => (string) $kind,
		'user'    => get_current_user_id(),
		'created' => time(),
		'updated' => time(),
		'status'  => 'working',
		'steps'   => array_values( array_map( static function ( $step ) {
			return array( 'key' => (string) $step['key'], 'label' => (string) $step['label'] );
		}, $steps ) ),
		'at'      => 0,
		'tries'   => 0,
		'note'    => '',
		'error'   => '',
		'data'    => $data,
		'result'  => array(),
	);
	kerf_pro_ai_job_save( $job );
	return $job;
}

/**
 * Every job, as the database has them now. Not this process's copy: a step
 * runs for minutes while other requests stop its job or move another one,
 * and get_option() would answer with what it read when the step began — a
 * Stop never seen, another job's progress written back over.
 *
 * @return array[]
 */
function kerf_pro_ai_jobs() {
	$jobs = kerf_pro_ai_fresh_option( KERF_PRO_AI_JOBS_OPTION );
	return is_array( $jobs ) ? $jobs : array();
}

/**
 * A job, by id.
 *
 * @param string $id
 * @return array|null
 */
function kerf_pro_ai_job_get( $id ) {
	$jobs = kerf_pro_ai_jobs();
	return isset( $jobs[ $id ] ) && is_array( $jobs[ $id ] ) ? $jobs[ $id ] : null;
}

/**
 * Keep a job; drop those older than two days. A job stopped meanwhile stays
 * stopped: the step that was working when it was asked to stop saves its
 * work, and starts nothing after it.
 *
 * @param array $job
 * @return array The job as kept.
 */
function kerf_pro_ai_job_save( $job ) {
	$jobs = kerf_pro_ai_jobs();
	foreach ( $jobs as $id => $kept ) {
		if ( empty( $kept['updated'] ) || (int) $kept['updated'] < time() - 2 * DAY_IN_SECONDS ) {
			unset( $jobs[ $id ] );
		}
	}
	// A step that failed after the stop failed for nobody: stopped, not failed.
	if ( in_array( $job['status'], array( 'working', 'failed' ), true ) && isset( $jobs[ $job['id'] ]['status'] ) && 'cancelled' === $jobs[ $job['id'] ]['status'] ) {
		$job['status'] = 'cancelled';
		$job['note']   = '';
		$job['error']  = '';
	}
	$job['updated']      = time();
	$jobs[ $job['id'] ] = $job;
	update_option( KERF_PRO_AI_JOBS_OPTION, $jobs, false );
	return $job;
}

/**
 * What does each kind of job with its steps.
 *
 * @return array<string,callable> kind => function ( array &$job, array $step ): true|WP_Error.
 */
function kerf_pro_ai_job_handlers() {
	/**
	 * The handlers of AI jobs: kind => callable( &$job, $step ), which does one
	 * step, may add steps after it, and answers true or a WP_Error.
	 *
	 * @param array $handlers
	 */
	return (array) apply_filters( 'kerf_pro_ai_job_handlers', array() );
}

/**
 * Take the job's next step for this request — atomically: one row inserted,
 * or none when another request holds it. A lock left by a process that died
 * is taken over once it is stale.
 *
 * @param string $id
 * @return bool
 */
function kerf_pro_ai_job_claim( $id ) {
	global $wpdb;
	$name = 'kerf_pro_ai_job_lock_' . $id;
	for ( $round = 0; $round < 2; $round++ ) {
		// INSERT IGNORE, not add_option(): add_option() writes over a row
		// another request inserted a moment earlier (ON DUPLICATE KEY UPDATE).
		$taken = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'off')", $name, (string) time() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a lock: the one atomic way to take it.
		if ( 1 === (int) $taken ) {
			wp_cache_delete( $name, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
			return true;
		}
		$since = (int) $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- the lock's own row, never cached.
		if ( $since > time() - KERF_PRO_AI_JOB_STALE ) {
			return false;
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value = %s", $name, (string) $since ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- as above.
	}
	return false;
}

/**
 * Give the job's next step back.
 *
 * @param string $id
 */
function kerf_pro_ai_job_release( $id ) {
	global $wpdb;
	$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s", 'kerf_pro_ai_job_lock_' . $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- the lock's own row.
	wp_cache_delete( 'kerf_pro_ai_job_lock_' . $id, 'options' );
}

/**
 * Do the job's next step, if it has one and this request holds it.
 *
 * @param string $id
 * @param bool   $claimed This request took the step already.
 * @return array|null The job after it.
 */
function kerf_pro_ai_job_step( $id, $claimed = false ) {
	if ( ! $claimed && ! kerf_pro_ai_job_claim( $id ) ) {
		return kerf_pro_ai_job_get( $id );
	}
	$job = kerf_pro_ai_job_get( $id );
	if ( ! $job || 'working' !== $job['status'] || ! isset( $job['steps'][ $job['at'] ] ) ) {
		kerf_pro_ai_job_release( $id );
		return $job;
	}

	$handlers = kerf_pro_ai_job_handlers();
	$step     = $job['steps'][ $job['at'] ];
	if ( ! isset( $handlers[ $job['kind'] ] ) || ! is_callable( $handlers[ $job['kind'] ] ) ) {
		$done = new WP_Error( 'kerf_ai_job_kind', __( 'Kerf Pro cannot do this kind of AI work any more. Start it again.', 'kerf-pro' ) );
	} else {
		@set_time_limit( 900 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- disabled on some hosts; the step still runs.
		$done = call_user_func_array( $handlers[ $job['kind'] ], array( &$job, $step ) );
	}

	// Stopped while this step worked: what it did is kept, and nothing after
	// it starts — kerf_pro_ai_job_save() keeps the stop.
	if ( is_wp_error( $done ) ) {
		$job['tries']++;
		$passing = in_array( $done->get_error_code(), array( 'kerf_ai_quota', 'kerf_ai_down', 'kerf_ai_timeout', 'kerf_ai_network', 'kerf_ai_empty', 'kerf_ai_cut', 'kerf_ai_unreadable', 'kerf_ai_retry' ), true );
		if ( $passing && $job['tries'] < KERF_PRO_AI_JOB_TRIES ) {
			/* translators: %s: what went wrong, in plain words. */
			$job['note'] = sprintf( __( '%s Trying again…', 'kerf-pro' ), $done->get_error_message() );
		} else {
			$job['status'] = 'failed';
			$job['error']  = $done->get_error_message();
		}
	} else {
		$job['at']++;
		$job['tries'] = 0;
		$job['note']  = '';
		if ( $job['at'] >= count( $job['steps'] ) ) {
			$job['status'] = 'done';
		}
	}
	$job = kerf_pro_ai_job_save( $job );
	kerf_pro_ai_job_release( $id );
	return $job;
}

/**
 * Do every step now, one after the other — for WP-CLI and the lab, where no
 * browser waits.
 *
 * @param string        $id
 * @param callable|null $each Called after each step with the job.
 * @return array|null
 */
function kerf_pro_ai_job_run( $id, $each = null ) {
	$job = kerf_pro_ai_job_get( $id );
	for ( $n = 0; $job && 'working' === $job['status'] && $n < 100; $n++ ) {
		$job = kerf_pro_ai_job_step( $id );
		if ( $each ) {
			call_user_func( $each, $job );
		}
	}
	return $job;
}

/**
 * A job as the browser sees it.
 *
 * @param array $job
 * @return array
 */
function kerf_pro_ai_job_view( $job ) {
	$steps = array();
	foreach ( $job['steps'] as $i => $step ) {
		$steps[] = array(
			'label' => $step['label'],
			'state' => $i < $job['at'] ? 'done' : ( $i === $job['at'] && 'working' === $job['status'] ? 'now' : ( $i === $job['at'] && 'failed' === $job['status'] ? 'failed' : 'todo' ) ),
		);
	}
	return array(
		'id'     => $job['id'],
		'kind'   => $job['kind'],
		'status' => $job['status'],
		'steps'  => $steps,
		'done'   => min( (int) $job['at'], count( $job['steps'] ) ),
		'total'  => count( $job['steps'] ),
		'note'   => (string) $job['note'],
		'error'  => (string) $job['error'],
		'result' => (array) $job['result'],
	);
}

/**
 * Answer the browser now and keep running: the response ends here for the
 * client, and the process goes on with the step.
 *
 * PHP-FPM and LiteSpeed close the request themselves; anywhere else the
 * response says how long it is and that the connection closes, and is
 * flushed. A server that compresses or buffers the answer anyway keeps the
 * browser waiting for the step — the job still moves, and the browser asks
 * again (assets/js/kerf-ai.js treats a failed answer as "still working").
 *
 * @param array $data
 * @return bool False when the answer cannot be sent now (output started; the
 *              command line; the `kerf_pro_ai_job_detach` filter).
 */
function kerf_pro_ai_job_detach( $data ) {
	/**
	 * Answer a job's browser before working on its step.
	 *
	 * @param bool $detach
	 */
	if ( headers_sent() || 'cli' === PHP_SAPI || ! apply_filters( 'kerf_pro_ai_job_detach', true ) ) {
		return false;
	}
	ignore_user_abort( true );
	@set_time_limit( 900 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- disabled on some hosts.
	@ini_set( 'zlib.output_compression', '0' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.IniSet.Risky -- a compressed answer waits for the step; not every host lets this change.
	while ( ob_get_level() > 0 ) {
		ob_end_clean();
	}
	$body = (string) wp_json_encode( $data );
	status_header( 200 );
	nocache_headers();
	header( 'Content-Type: application/json; charset=' . get_option( 'blog_charset' ) );
	header( 'Content-Length: ' . strlen( $body ) );
	header( 'Connection: close' );
	echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON, encoded above.
	flush();
	if ( function_exists( 'fastcgi_finish_request' ) ) {
		fastcgi_finish_request();
	} elseif ( function_exists( 'litespeed_finish_request' ) ) {
		litespeed_finish_request();
	}
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * GET kerf/v1/ai/jobs/<id> — how it goes, and the next step started;
 * POST …/cancel.
 */
function kerf_pro_ai_job_routes() {
	register_rest_route( 'kerf/v1', '/ai/jobs/(?P<id>[a-z0-9]{12})', array(
		'methods'             => 'GET',
		'callback'            => 'kerf_pro_ai_rest_job',
		'permission_callback' => 'kerf_pro_ai_job_permission',
	) );
	register_rest_route( 'kerf/v1', '/ai/jobs/(?P<id>[a-z0-9]{12})/cancel', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_job_cancel',
		'permission_callback' => 'kerf_pro_ai_job_permission',
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_job_routes' );

/**
 * A job is its starter's: asking after it — and so moving it — is too, while
 * AI is on for them (the licence, the key, who may).
 *
 * @param WP_REST_Request $request
 * @return true|WP_Error
 */
function kerf_pro_ai_job_permission( $request ) {
	$job = kerf_pro_ai_job_get( (string) $request['id'] );
	if ( ! $job || (int) $job['user'] !== get_current_user_id() ) {
		return new WP_Error( 'kerf_ai_no_job', __( 'That AI work is not there any more. Start it again.', 'kerf-pro' ), array( 'status' => 404 ) );
	}
	return 'working' === $job['status'] ? kerf_pro_ai_rest_permission( $request ) : true;
}

/**
 * How the job goes — and, when its next step is free, that step: the answer
 * goes first, then the work (kerf_pro_ai_job_detach()).
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function kerf_pro_ai_rest_job( $request ) {
	$job = kerf_pro_ai_job_get( (string) $request['id'] );
	if ( 'working' === $job['status'] && kerf_pro_ai_job_claim( $job['id'] ) ) {
		if ( kerf_pro_ai_job_detach( kerf_pro_ai_job_view( $job ) ) ) {
			kerf_pro_ai_job_step( $job['id'], true );
			exit;
		}
		$job = kerf_pro_ai_job_step( $job['id'], true );
	}
	return rest_ensure_response( kerf_pro_ai_job_view( $job ) );
}

/**
 * Stop a job: the step working now finishes, and nothing after it starts.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function kerf_pro_ai_rest_job_cancel( $request ) {
	$job = kerf_pro_ai_job_get( (string) $request['id'] );
	if ( 'working' === $job['status'] ) {
		$job['status'] = 'cancelled';
		kerf_pro_ai_job_save( $job );
	}
	return rest_ensure_response( kerf_pro_ai_job_view( $job ) );
}
