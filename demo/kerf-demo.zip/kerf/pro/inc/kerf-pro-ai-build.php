<?php
/**
 * AI, phase 4: Kerf → Build with AI — the screen on the design generator
 * (kerf-pro-ai-design.php).
 *
 * The owner says what the business is and what the site should be, chooses
 * their pictures from the media library and confirms the business's details
 * (they go on the site as written — the site's own kept ones can be a
 * template's samples). Gemini then writes the design a step at a time, the
 * screen following the job (kerfAI.job(), assets/js/kerf-ai-build.js): the
 * plan as soon as it is made, each page as it is written. When it is done the
 * pages are shown one by one, in a frame that runs nothing (`sandbox`), and
 * the owner continues to the import's check step — the same step, report and
 * undo as for a ZIP. Nothing on the site changes before that.
 *
 * Reloaded in the middle, the screen follows the same job: it lives on the
 * server, not in the page.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The screen, under Kerf, after Import design (kerf_ui_menu_order()).
 */
function kerf_pro_ai_build_menu() {
	add_submenu_page(
		'kerf',
		__( 'Build with AI', 'kerf-pro' ),
		__( 'Build with AI', 'kerf-pro' ),
		'edit_theme_options',
		'kerf-build',
		'kerf_pro_ai_build_render'
	);
}
add_action( 'admin_menu', 'kerf_pro_ai_build_menu', 22 );

/**
 * Its Dashboard tile, after Import a design.
 *
 * @param array[] $tools
 * @return array[]
 */
function kerf_pro_ai_build_tool( $tools ) {
	array_splice( $tools, 1, 0, array( array(
		'kerf-build',
		'spark',
		__( 'Build with AI', 'kerf-pro' ),
		__( 'Say what your site is for and choose your pictures: Gemini designs every page, ready to import.', 'kerf-pro' ),
	) ) );
	return $tools;
}
add_filter( 'kerf_dashboard_tools', 'kerf_pro_ai_build_tool' );

/**
 * Its script, and the media library's chooser.
 *
 * @param string $hook
 */
function kerf_pro_ai_build_assets( $hook ) {
	if ( 'kerf_page_kerf-build' !== $hook ) {
		return;
	}
	wp_enqueue_media();
	$rel = 'assets/js/kerf-ai-build.js';
	wp_enqueue_script( 'kerf-ai-build', kerf_pro_url( $rel ), array( 'kerf-ai', 'wp-api-fetch', 'wp-i18n' ), filemtime( kerf_pro_path( $rel ) ), true );
	wp_set_script_translations( 'kerf-ai-build', 'kerf-pro', kerf_pro_path( 'languages' ) );
}
add_action( 'admin_enqueue_scripts', 'kerf_pro_ai_build_assets', 21 );

/**
 * The person's design being made, or made and not yet imported — the one the
 * screen shows again when it is opened.
 *
 * @return array|null The job.
 */
function kerf_pro_ai_build_current() {
	$best = null;
	foreach ( kerf_pro_ai_jobs() as $job ) {
		if ( ! is_array( $job ) || 'design' !== $job['kind'] || (int) $job['user'] !== get_current_user_id() || ! in_array( $job['status'], array( 'working', 'done' ), true ) ) {
			continue;
		}
		// Made, and imported or expired since: nothing to show again.
		if ( 'done' === $job['status'] && ( empty( $job['result']['token'] ) || ! kerf_import_pending_peek( (string) $job['result']['token'] ) ) ) {
			continue;
		}
		// Started in the same second, the later one: jobs are kept in the
		// order they were started.
		if ( ! $best || (int) $job['created'] >= (int) $best['created'] ) {
			$best = $job;
		}
	}
	return $best;
}

/**
 * Draw the screen.
 */
function kerf_pro_ai_build_render() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to see this page.', 'kerf-pro' ) );
	}

	kerf_ui_open( __( 'Build with AI', 'kerf-pro' ), array( 'class' => 'kerf-build-screen' ) );
	if ( function_exists( 'kerf_theme_active' ) && ! kerf_theme_active() ) {
		kerf_theme_required_notice();
	}

	$refusal = kerf_pro_ai_refusal();
	if ( $refusal ) {
		echo kerf_ui_note( $refusal->get_error_message(), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		if ( 'kerf_ai_no_key' === $refusal->get_error_code() ) {
			printf( '<p><a class="kerf-btn" href="%s">%s</a></p>', esc_url( admin_url( 'admin.php?page=kerf-settings' ) ), esc_html__( 'Add your Gemini key', 'kerf-pro' ) );
		}
		kerf_ui_close();
		return;
	}

	$current = kerf_pro_ai_build_current();
	$project = $current && ! empty( $current['data']['project'] ) ? kerf_pro_ai_design_get( (string) $current['data']['project'] ) : null;
	$brief   = $project ? $project['brief'] : (string) get_option( KERF_PRO_AI_ABOUT_OPTION, '' );
	$details = $project ? (array) $project['details'] : kerf_pro_ai_design_details( null );
	$details = kerf_pro_ai_build_details_order( $details );
	?>
	<div class="kerf-build" data-kerf-build data-job="<?php echo esc_attr( $current ? $current['id'] : '' ); ?>" data-max-pictures="<?php echo (int) KERF_PRO_AI_DESIGN_PICTURES; ?>">

		<?php // First: whichever panel follows, what went wrong is read before it. ?>
		<div class="kerf-note kerf-note--bad" role="alert" data-kerf-ai-error hidden><?php echo kerf_ui_icon( 'stop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><p></p></div>

		<form class="kerf-panel kerf-ai kerf-build__ask" data-kerf-build-form<?php echo $current ? ' hidden' : ''; ?>>
			<div class="kerf-panel__head">
				<h2><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Tell Gemini about your site', 'kerf-pro' ); ?></h2>
				<p><?php esc_html_e( 'Gemini plans the site, designs the home page and writes every other page — the blog, a post and a page-not-found page too — from what you say and the pictures you choose. You see every page before anything changes on your site.', 'kerf-pro' ); ?></p>
			</div>
			<div class="kerf-panel__body">
				<div class="kerf-field">
					<label class="kerf-label" for="kerf-build-brief"><?php esc_html_e( 'The business, and the site you want', 'kerf-pro' ); ?></label>
					<textarea id="kerf-build-brief" name="brief" rows="7" required minlength="20" maxlength="4000" data-kerf-build-brief placeholder="<?php esc_attr_e( 'A family dental practice in Austin since 1987: check-ups, implants and same-day crowns. Warm and plain-spoken, lots of white space. Pages about our dentists, our treatments and how to book.', 'kerf-pro' ); ?>"><?php echo esc_textarea( $brief ); ?></textarea>
					<p class="kerf-help"><?php esc_html_e( 'What you do, for whom and where; the pages you need; how it should feel. Gemini invents no facts: prices, awards and reviews are yours to add.', 'kerf-pro' ); ?></p>
				</div>

				<div class="kerf-field">
					<span class="kerf-label" id="kerf-build-pictures-label"><?php esc_html_e( 'Your pictures', 'kerf-pro' ); ?></span>
					<ul class="kerf-build__pictures" data-kerf-build-pictures aria-labelledby="kerf-build-pictures-label">
						<?php foreach ( $project ? $project['pictures'] : array() as $picture ) : ?>
							<?php kerf_pro_ai_build_picture( (int) $picture['id'] ); ?>
						<?php endforeach; ?>
					</ul>
					<p class="kerf-row">
						<button type="button" class="kerf-btn" data-kerf-build-choose><?php echo kerf_ui_icon( 'image' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Choose pictures', 'kerf-pro' ); ?></button>
					</p>
					<p class="kerf-help">
						<?php
						printf(
							/* translators: %d: how many pictures at most. */
							esc_html__( 'Up to %d, from your media library. Gemini sees them and puts each where it fits; the site shows no other pictures. With none, it uses colour, type and shapes.', 'kerf-pro' ),
							(int) KERF_PRO_AI_DESIGN_PICTURES
						);
						?>
					</p>
				</div>

				<fieldset class="kerf-field kerf-build__details">
					<legend class="kerf-label"><?php esc_html_e( 'Your business\'s details', 'kerf-pro' ); ?></legend>
					<p class="kerf-help"><?php esc_html_e( 'They go on the site exactly as written here, and become your Site details when you import the design. Leave out what you do not want shown.', 'kerf-pro' ); ?></p>
					<div class="kerf-build__detail-grid">
						<?php foreach ( $details as $key => $text ) : ?>
							<div class="kerf-build__detail">
								<label for="kerf-build-detail-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( kerf_site_label( $key ) ); ?></label>
								<input type="text" id="kerf-build-detail-<?php echo esc_attr( $key ); ?>" data-kerf-build-detail="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $text ); ?>">
							</div>
						<?php endforeach; ?>
					</div>
				</fieldset>
			</div>
			<div class="kerf-panel__foot">
				<button type="submit" class="kerf-btn kerf-btn--primary kerf-btn--lg" data-kerf-build-go><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Build my site', 'kerf-pro' ); ?></button>
				<p class="kerf-help"><?php esc_html_e( 'About ten minutes: you can leave this page and come back. Each step uses your Gemini key.', 'kerf-pro' ); ?></p>
			</div>
		</form>

		<section class="kerf-panel kerf-ai kerf-build__progress" data-kerf-build-progress hidden aria-live="polite">
			<div class="kerf-panel__head">
				<h2><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Building your site', 'kerf-pro' ); ?></h2>
				<p data-kerf-build-plan hidden></p>
			</div>
			<div class="kerf-panel__body">
				<ul class="kerf-build__swatches" data-kerf-build-colors hidden aria-hidden="true"></ul>
				<ol class="kerf-build__steps" data-kerf-build-steps></ol>
				<p class="kerf-help" data-kerf-build-note role="status"></p>
			</div>
			<div class="kerf-panel__foot">
				<button type="button" class="kerf-btn kerf-btn--quiet" data-kerf-build-cancel><?php esc_html_e( 'Stop', 'kerf-pro' ); ?></button>
				<p class="kerf-help"><?php esc_html_e( 'Stopping lets the step working now finish, and starts nothing after it.', 'kerf-pro' ); ?></p>
			</div>
		</section>

		<section class="kerf-panel kerf-ai kerf-build__result" data-kerf-build-result hidden>
			<div class="kerf-panel__head">
				<h2><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Your design', 'kerf-pro' ); ?></h2>
				<p><?php esc_html_e( 'Look through each page. Nothing on your site has changed yet: the next step checks the design and asks where it goes.', 'kerf-pro' ); ?></p>
			</div>
			<div class="kerf-panel__body">
				<div class="kerf-build__tabs" role="tablist" aria-label="<?php esc_attr_e( 'The design\'s pages', 'kerf-pro' ); ?>" data-kerf-build-tabs></div>
				<div class="kerf-crop">
					<div class="kerf-build__preview" data-kerf-build-preview data-width="1440">
						<iframe sandbox="" title="<?php esc_attr_e( 'A page of the design', 'kerf-pro' ); ?>" data-kerf-build-frame></iframe>
					</div>
				</div>
				<ul class="kerf-check" data-kerf-build-notes hidden></ul>
			</div>
			<div class="kerf-panel__foot kerf-row">
				<a class="kerf-btn kerf-btn--primary kerf-btn--lg" href="#" data-kerf-build-continue><?php esc_html_e( 'Continue to the check step', 'kerf-pro' ); ?></a>
				<button type="button" class="kerf-btn" data-kerf-build-again><?php echo kerf_ui_icon( 'refresh' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Make it again', 'kerf-pro' ); ?></button>
				<button type="button" class="kerf-btn kerf-btn--quiet" data-kerf-build-new><?php esc_html_e( 'Change what I asked', 'kerf-pro' ); ?></button>
			</div>
		</section>

		<template data-kerf-build-picture>
			<?php kerf_pro_ai_build_picture( 0 ); ?>
		</template>
		<template data-kerf-build-note-item>
			<li class="kerf-check--info"><span class="kerf-check__mark"><?php echo kerf_ui_icon( 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span><div class="kerf-check__text"><p></p></div></li>
		</template>
	</div>
	<?php
	kerf_ui_working();
	kerf_ui_close();
}

/**
 * The details as the owner reads them: phone, email, address and hours —
 * always offered — each followed by its second one (`address-2`), then the
 * rest (profiles…) as they were kept.
 *
 * @param array<string,string> $details key => value.
 * @return array<string,string>
 */
function kerf_pro_ai_build_details_order( $details ) {
	$first = array( 'phone', 'email', 'address', 'hours' );
	foreach ( $first as $key ) {
		if ( ! isset( $details[ $key ] ) ) {
			$details[ $key ] = '';
		}
	}
	$keys = array_keys( $details );
	$rank = static function ( $key ) use ( $first, $keys ) {
		$base = (string) preg_replace( '/-\d+$/', '', $key );
		$at   = array_search( $base, $first, true );
		$n    = preg_match( '/-(\d+)$/', $key, $m ) ? (int) $m[1] : 1;
		return array( false === $at ? count( $first ) : $at, false === $at ? array_search( $key, $keys, true ) : $n );
	};
	uksort( $details, static function ( $a, $b ) use ( $rank ) {
		return $rank( $a ) <=> $rank( $b );
	} );
	return $details;
}

/**
 * One chosen picture: its thumbnail and a way to take it out. With 0, the
 * empty one the script fills in for a picture chosen on the page.
 *
 * @param int $id Attachment id, or 0.
 */
function kerf_pro_ai_build_picture( $id ) {
	$thumb = $id ? wp_get_attachment_image_src( $id, 'thumbnail' ) : null;
	$alt   = $id ? trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) : '';
	?>
	<li class="kerf-build__picture" data-kerf-build-picture-id="<?php echo (int) $id; ?>">
		<img src="<?php echo esc_url( $thumb ? $thumb[0] : '' ); ?>" alt="<?php echo esc_attr( '' !== $alt ? $alt : ( $id ? get_the_title( $id ) : '' ) ); ?>" width="96" height="96" loading="lazy">
		<button type="button" class="kerf-build__remove" data-kerf-build-remove aria-label="<?php esc_attr_e( 'Take this picture out', 'kerf-pro' ); ?>">&times;</button>
	</li>
	<?php
}
