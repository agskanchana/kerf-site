<?php
/**
 * "Show my latest posts here" (§5.42).
 *
 * A design's home page often shows "Latest news": three of the designer's
 * sample cards, made up. Marked before import (`data-kerf-loop`, §5.25) they
 * become live posts; unmarked — an AI working without Kerf's brief — they
 * stayed three fixed samples, unconnected to the blog. Here the owner selects
 * the section in the editor and Kerf does what the markers would have done:
 *
 *   - finds the cards: consecutive siblings of one kind (the same block, tag
 *     and first class — the converter's rule for one list's cards), holding a
 *     heading;
 *   - reads each part of the first card — title, picture, link, date, summary,
 *     category, author, comment count — and shows them to the owner to confirm;
 *   - keeps the first card, bound to the post it stands for (the converter's
 *     own bindings: a date keeps the designer's format, a summary its length,
 *     a picture the sample's size), inside a `kerf/loop` of the latest posts —
 *     as many as there were samples — and drops the other samples.
 *
 * Proposed, never automatic: a row of team members has the same shape as a row
 * of posts. The section keeps its stamp, marked as replaced, so an update from
 * the mockup leaves it alone unless asked (§5.28).
 *
 * Kerf Pro's (§8.14): the tool. What it makes — a `kerf/loop` and its
 * bindings — the free plugin renders, so it keeps showing without Pro.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * REST: look at a section, or apply what the owner confirmed.
 */
function kerf_latest_routes() {
	register_rest_route( 'kerf/v1', '/latest-posts', array(
		'methods'             => 'POST',
		'permission_callback' => static function () {
			if ( ! current_user_can( 'edit_theme_options' ) ) {
				return false;
			}
			// What the tool made keeps showing (kerf/loop is the free plugin's);
			// making more waits for a licence.
			return kerf_pro_licensed() ? true : new WP_Error( 'kerf_pro_expired', __( 'Your Kerf Pro licence has expired: renew to use Latest posts again.', 'kerf-pro' ), array( 'status' => 403 ) );
		},
		'args'                => array(
			'markup' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static function ( $value ) {
					return (string) $value;
				},
			),
			'roles'  => array(
				'required' => false,
				'type'     => 'array',
				'default'  => array(),
			),
			'apply'  => array(
				'required' => false,
				'type'     => 'boolean',
				'default'  => false,
			),
		),
		'callback'            => static function ( $request ) {
			$blocks = parse_blocks( (string) $request->get_param( 'markup' ) );
			$blocks = array_values( array_filter( $blocks, static function ( $block ) {
				return ! empty( $block['blockName'] );
			} ) );
			if ( 1 !== count( $blocks ) ) {
				return new WP_Error( 'kerf_latest_shape', __( 'Select one section.', 'kerf-pro' ), array( 'status' => 400 ) );
			}
			$found = kerf_latest_find( $blocks[0] );
			if ( ! $found ) {
				return rest_ensure_response( array( 'found' => false ) );
			}
			if ( ! $request->get_param( 'apply' ) ) {
				return rest_ensure_response( array(
					'found' => true,
					'count' => $found['count'],
					'card'  => $found['label'],
					'roles' => array_map( static function ( $role ) {
						return array( 'role' => $role['role'], 'sample' => $role['sample'] );
					}, array_values( $found['roles'] ) ),
				) );
			}
			$chosen = array_map( 'sanitize_key', (array) $request->get_param( 'roles' ) );
			return rest_ensure_response( array(
				'found'  => true,
				'markup' => serialize_blocks( array( kerf_latest_apply( $blocks[0], $found, $chosen ) ) ),
			) );
		},
	) );
}
add_action( 'rest_api_init', 'kerf_latest_routes' );

/**
 * The Latest posts panel (assets/js/kerf-latest-posts.js), for whoever may
 * change the design — and whether the licence lets it act.
 */
function kerf_latest_editor_assets() {
	$rel = 'assets/js/kerf-latest-posts.js';
	if ( ! current_user_can( 'edit_theme_options' ) || ! file_exists( kerf_pro_path( $rel ) ) ) {
		return;
	}
	wp_enqueue_script( 'kerf-latest-posts', kerf_pro_url( $rel ), array( 'wp-hooks', 'wp-compose', 'wp-element', 'wp-data', 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-api-fetch', 'kerf-attributes-control' ), filemtime( kerf_pro_path( $rel ) ), true );
	wp_set_script_translations( 'kerf-latest-posts', 'kerf-pro', kerf_pro_path( 'languages' ) );
	wp_add_inline_script( 'kerf-latest-posts', 'window.kerfLatestPosts = ' . wp_json_encode( array( 'licensed' => kerf_pro_licensed() ) ) . ';', 'before' );
}
add_action( 'enqueue_block_editor_assets', 'kerf_latest_editor_assets' );

/**
 * A block's kind, as one list's cards share it: block, tag, first class.
 *
 * @param array $block
 * @return string
 */
function kerf_latest_kind( $block ) {
	$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
	$class = isset( $attrs['className'] ) ? strtok( trim( (string) $attrs['className'] ) . ' ', " \t\n" ) : '';
	return $block['blockName'] . '|' . strtolower( (string) ( $attrs['tagName'] ?? '' ) ) . '|' . $class;
}

/**
 * The text a block shows, without markup.
 *
 * @param array $block
 * @return string
 */
function kerf_latest_text( $block ) {
	$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
	if ( isset( $attrs['text'] ) ) {
		$text = (string) $attrs['text'];
	} elseif ( in_array( $block['blockName'], array( 'core/heading', 'core/paragraph' ), true ) ) {
		$text = (string) $block['innerHTML'];
	} else {
		$text = '';
		foreach ( (array) $block['innerBlocks'] as $inner ) {
			$text .= ' ' . kerf_latest_text( $inner );
		}
	}
	return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $text ), ENT_QUOTES, 'UTF-8' ) ) );
}

/**
 * Is this a heading: a core heading, or a Kerf element or text that is one?
 *
 * @param array $block
 * @return bool
 */
function kerf_latest_is_heading( $block ) {
	return 'core/heading' === $block['blockName']
		|| ( in_array( $block['blockName'], array( 'kerf/text', 'kerf/div' ), true ) && preg_match( '/^h[1-6]$/i', (string) ( $block['attrs']['tagName'] ?? '' ) ) );
}

/**
 * The cards in a section: the longest run of two or more consecutive siblings
 * of one kind whose first holds a heading. Depth first, from the section.
 *
 * @param array $root
 * @return array|null { path: indices to the cards' parent, start, count, label, roles }.
 */
function kerf_latest_find( $root ) {
	$best = null;
	$walk = static function ( $block, $path ) use ( &$walk, &$best ) {
		$children = isset( $block['innerBlocks'] ) ? (array) $block['innerBlocks'] : array();
		$count    = count( $children );
		for ( $i = 0; $i < $count; ) {
			$kind = kerf_latest_kind( $children[ $i ] );
			$j    = $i + 1;
			while ( $j < $count && kerf_latest_kind( $children[ $j ] ) === $kind ) {
				$j++;
			}
			$run = $j - $i;
			if ( $run >= 2 && 'kerf/loop' !== $children[ $i ]['blockName'] && ( ! $best || $run > $best['count'] ) ) {
				$roles = kerf_latest_roles( $children[ $i ] );
				if ( isset( $roles['title'] ) ) {
					$attrs = $children[ $i ]['attrs'];
					$best  = array(
						'path'  => $path,
						'start' => $i,
						'count' => $run,
						'label' => trim( '<' . ( $attrs['tagName'] ?? 'div' ) . '> ' . ( isset( $attrs['className'] ) ? '.' . strtok( (string) $attrs['className'], ' ' ) : '' ) ),
						'roles' => $roles,
					);
				}
			}
			$i = $j;
		}
		foreach ( $children as $index => $child ) {
			if ( 'kerf/loop' !== $child['blockName'] ) {
				$walk( $child, array_merge( $path, array( $index ) ) );
			}
		}
	};
	$walk( $root, array() );
	return $best;
}

/**
 * What each part of a card is, by what it holds and where it stands.
 *
 * @param array $card
 * @return array<string,array> Role => { role, path (within the card), sample }.
 */
function kerf_latest_roles( $card ) {
	$parts = array();
	$walk  = static function ( $block, $path ) use ( &$walk, &$parts ) {
		$parts[] = array( 'block' => $block, 'path' => $path );
		foreach ( (array) $block['innerBlocks'] as $i => $inner ) {
			$walk( $inner, array_merge( $path, array( $i ) ) );
		}
	};
	$walk( $card, array() );

	$roles = array();
	$take  = static function ( $role, $part, $sample = null ) use ( &$roles ) {
		if ( ! isset( $roles[ $role ] ) ) {
			$roles[ $role ] = array(
				'role'   => $role,
				'path'   => $part['path'],
				'name'   => $part['block']['blockName'],
				'sample' => null === $sample ? kerf_latest_text( $part['block'] ) : $sample,
			);
			// A piece of a paragraph: which one (kerf_latest_inline_parts()).
			if ( isset( $part['inline'] ) ) {
				$roles[ $role ]['inline'] = (int) $part['inline'];
			}
		}
	};

	// The title: the first heading — its link, where it holds one.
	$title_at = null;
	foreach ( $parts as $index => $part ) {
		if ( ! kerf_latest_is_heading( $part['block'] ) || '' === kerf_latest_text( $part['block'] ) ) {
			continue;
		}
		$title_at = $index;
		foreach ( array_slice( $parts, $index + 1 ) as $inner ) {
			if ( 'kerf/link' === $inner['block']['blockName'] && array_slice( $inner['path'], 0, count( $part['path'] ) ) === $part['path'] ) {
				$take( 'title', $inner );
				break;
			}
		}
		$take( 'title', $part );
		break;
	}

	foreach ( $parts as $index => $part ) {
		$block = $part['block'];
		$name  = $block['blockName'];
		$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
		$text  = kerf_latest_text( $block );
		$words = '' === $text ? 0 : count( preg_split( '/\s+/u', $text ) );
		$leaf  = in_array( $name, array( 'kerf/text', 'kerf/link', 'core/paragraph' ), true );
		$class = (string) ( $attrs['className'] ?? '' );

		if ( isset( $roles['title'] ) && $roles['title']['path'] === $part['path'] ) {
			continue;
		}

		// The picture: an image, or an element painted with one.
		if ( 'kerf/image' === $name ) {
			$take( 'image', $part, (string) ( $attrs['alt'] ?? '' ) );
		} elseif ( 'kerf/div' === $name && ( ! empty( $attrs['backgroundImage'] ) || ! empty( $attrs['customAttributes']['data-setbg'] ) ) ) {
			$take( 'image', $part, '' );
		}

		// A picture painted on a link: clark's `<a class="block-20"
		// style="background-image:…">` — the picture, and the way to the post.
		if ( 'kerf/link' === $name && '' === $text && preg_match( '/url\(/i', (string) ( $attrs['inlineStyle'] ?? '' ) ) ) {
			$take( 'image', $part, '' );
			$take( 'permalink', $part, '' );
			continue;
		}

		// The card's link: an <a> wrapping the picture or the card.
		if ( 'kerf/div' === $name && 'a' === strtolower( (string) ( $attrs['tagName'] ?? '' ) ) && null !== $title_at ) {
			$take( 'permalink', $part, '' );
		}

		// A line of meta written as one paragraph — `<p><span>June 21, 2019</span>
		// <a>Admin</a></p>`: its pieces, each a date, an author or a count.
		if ( 'core/paragraph' === $name && preg_match( '/<(?:span|a|time|small|em|strong|b|i)\b/i', (string) $block['innerHTML'] ) ) {
			$inline = kerf_latest_inline_parts( (string) $block['innerHTML'] );
			$meta   = false;
			foreach ( $inline as $n => $piece ) {
				$role = kerf_latest_meta_role( $piece['text'] );
				if ( $role ) {
					$take( $role, array( 'block' => $block, 'path' => $part['path'], 'inline' => $n ), $piece['text'] );
					$meta = true;
				}
			}
			// Beside a date, a short linked name is the author: Colorlib's
			// "June 21, 2019 · Admin · 3".
			if ( isset( $roles['date']['inline'] ) && ! isset( $roles['author'] ) ) {
				foreach ( $inline as $n => $piece ) {
					if ( 'a' === $piece['tag'] && preg_match( '/^\p{L}[\p{L}.\'-]*(?:\s\p{L}[\p{L}.\'-]*)?$/u', $piece['text'] ) ) {
						$take( 'author', array( 'block' => $block, 'path' => $part['path'], 'inline' => $n ), $piece['text'] );
						break;
					}
				}
			}
			if ( $meta ) {
				continue;
			}
		}

		if ( ! $leaf || '' === $text ) {
			continue;
		}

		$meta = kerf_latest_meta_role( $text );
		if ( ! $meta && preg_match( '/(?:^|[\s_-])author(?:$|[\s_-])/i', $class ) ) {
			$meta = 'author';
		}
		if ( $meta ) {
			$take( $meta, $part );
		} elseif ( $words <= 3 && (
			preg_match( '/(?:^|[\s_-])(?:cat|category|categories|tag|badge|label)(?:$|[\s_-])/i', $class )
			|| preg_match( '#/(?:category|categories|tag)/#i', (string) ( $attrs['url'] ?? '' ) )
			// Short, set in capitals, before the title: "NEWS". A name
			// before the title ("Admin") is not a category.
			|| ( null !== $title_at && $index < $title_at && preg_match( '/\p{Lu}/u', $text ) && $text === mb_strtoupper( $text ) )
		) ) {
			$take( 'category', $part );
		} elseif ( $words >= 6 && null !== $title_at && $index > $title_at && 'kerf/link' !== $name ) {
			$take( 'excerpt', $part );
		} elseif ( 'kerf/link' === $name && $words <= 4 && null !== $title_at && $index > $title_at ) {
			// "Read more": goes to the post.
			$take( 'permalink', $part, $text );
		}
	}

	return $roles;
}

/**
 * Is a piece of text a post's date, its author or its comment count — as the
 * converter's prepass reads sample meta (§5.30)?
 *
 * @param string $text
 * @return string The role, or ''.
 */
function kerf_latest_meta_role( $text ) {
	$text = trim( (string) $text );
	if ( '' === $text ) {
		return '';
	}
	if ( '' !== kerf_mc_date_format( $text ) ) {
		return 'date';
	}
	if ( preg_match( '/^(?:posted\s+by|written\s+by|by)\s+\S/i', $text ) ) {
		return 'author';
	}
	if ( preg_match( '/^\d+\s+(?:comments?|responses?|replies)$/i', $text ) ) {
		return 'comments-count';
	}
	return '';
}

/**
 * The pieces of a paragraph that hold only text — `<span>June 21, 2019</span>`,
 * `<a>Admin</a>` — in document order: what can be marked in it.
 *
 * @param string $html
 * @return array[] Each: text, tag — by position.
 */
function kerf_latest_inline_parts( $html ) {
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();

	$pieces = array();
	foreach ( ( new DOMXPath( $doc ) )->query( '//*[not(*)]' ) as $node ) {
		if ( in_array( strtolower( $node->nodeName ), array( 'div', 'p', 'br', 'img', 'hr' ), true ) ) {
			continue;
		}
		$pieces[] = array(
			'text' => trim( preg_replace( '/\s+/u', ' ', $node->textContent ) ),
			'tag'  => strtolower( $node->nodeName ),
		);
	}
	return $pieces;
}

/**
 * A paragraph with its pieces marked (`data-kerf-field`), converted again by
 * the converter: a marked paragraph becomes elements (§5.27), each piece
 * bound as an import of a marked design would bind it — a date in the
 * designer's format.
 *
 * @param array               $block A core/paragraph.
 * @param array<int,string>   $marks Piece position => role.
 * @return array|null The element block, or null if it did not come out as one.
 */
function kerf_latest_convert_marked( $block, $marks ) {
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . render_block( $block ) . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();

	$n = 0;
	foreach ( ( new DOMXPath( $doc ) )->query( '//*[not(*)]' ) as $node ) {
		if ( in_array( strtolower( $node->nodeName ), array( 'div', 'p', 'br', 'img', 'hr' ), true ) ) {
			continue;
		}
		if ( isset( $marks[ $n ] ) ) {
			$node->setAttribute( 'data-kerf-field', $marks[ $n ] );
		}
		$n++;
	}

	$html = '';
	foreach ( $doc->documentElement->childNodes as $child ) {
		$html .= $doc->saveHTML( $child );
	}
	// The marks are the markup contract's, filled in (`dynamic`).
	$result = kerf_mc_convert_html( $html, null, array( 'directives' => kerf_user_can_add_scripts(), 'dynamic' => true ) );
	$blocks = array_values( array_filter( parse_blocks( $result['markup'] ), static function ( $made ) {
		return ! empty( $made['blockName'] );
	} ) );
	return 1 === count( $blocks ) ? $blocks[0] : null;
}

/**
 * A picture painted on a link, as the same `<a>` element block: a link block
 * cannot hold a background to bind (kerf_apply_bound_background() works on
 * an element), and the element renders the same tag and attributes.
 *
 * @param array $block A kerf/link with a url() in its style.
 * @return array|null
 */
function kerf_latest_link_to_element( $block ) {
	$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
	$style = (string) ( $attrs['inlineStyle'] ?? '' );
	if ( ! preg_match( '/url\(\s*([\'"]?)(.*?)\1\s*\)/i', $style, $m ) ) {
		return null;
	}
	$div = array( 'tagName' => 'a', 'inlineStyle' => $style, 'backgroundImage' => $m[2] );
	foreach ( array( 'className', 'anchor', 'linkType', 'linkId' ) as $key ) {
		if ( isset( $attrs[ $key ] ) ) {
			$div[ $key ] = $attrs[ $key ];
		}
	}
	$custom = isset( $attrs['customAttributes'] ) ? (array) $attrs['customAttributes'] : array();
	if ( ! empty( $attrs['url'] ) ) {
		$custom['href'] = (string) $attrs['url'];
	}
	if ( ! empty( $attrs['newTab'] ) ) {
		$custom['target'] = '_blank';
	}
	if ( ! empty( $attrs['rel'] ) ) {
		$custom['rel'] = (string) $attrs['rel'];
	}
	if ( $custom ) {
		$div['customAttributes'] = $custom;
	}
	return array( 'blockName' => 'kerf/div', 'attrs' => $div, 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() );
}

/**
 * The block at a path of child indices.
 *
 * @param array $block
 * @param int[] $path
 * @return array
 */
function &kerf_latest_at( array &$block, $path ) {
	$here = &$block;
	foreach ( $path as $i ) {
		$here = &$here['innerBlocks'][ $i ];
	}
	return $here;
}

/**
 * Bind one part of the first card to the post it stands for, the way the
 * converter binds a marked one (kerf_mc_apply_fields()).
 *
 * @param array  $block
 * @param string $role
 * @param string $sample
 * @return array
 */
function kerf_latest_bind( $block, $role, $sample ) {
	$contract = kerf_mc_contract_fields();
	$post     = static function ( $key ) {
		return array( 'source' => 'kerf/post', 'args' => array( 'key' => $key ) );
	};
	$attrs    = isset( $block['attrs'] ) ? $block['attrs'] : array();
	$bindings = isset( $attrs['metadata']['bindings'] ) ? (array) $attrs['metadata']['bindings'] : array();
	$name     = $block['blockName'];
	$text     = isset( $contract['text'][ $role ] ) ? kerf_mc_text_binding( $role, $sample ) : null;
	$url      = isset( $contract['url'][ $role ] ) ? $contract['url'][ $role ] : null;

	if ( 'permalink' === $role ) {
		$text = null;
		$url  = $post( 'permalink' );
	}

	// A picture painted on a link becomes the same <a> as an element, which
	// can hold the background (kerf_latest_link_to_element()).
	if ( 'kerf/link' === $name && 'image' === $role ) {
		$element = kerf_latest_link_to_element( $block );
		return $element ? kerf_latest_bind( $element, 'image', $sample ) : $block;
	}

	// A title linked inside a core heading (`<h3><a href>Title</a></h3>`):
	// bound whole, the link would be lost — it becomes the same heading
	// element holding a link block, both bound.
	if ( 'title' === $role && 'core/heading' === $name && false !== stripos( (string) $block['innerHTML'], '<a ' ) ) {
		$linked = kerf_latest_heading_link( $block, $sample );
		if ( $linked ) {
			return $linked;
		}
	}

	switch ( $name ) {
		case 'kerf/text':
			if ( $text ) {
				$bindings['text'] = $text;
			}
			break;
		case 'core/heading':
		case 'core/paragraph':
			if ( $text ) {
				$bindings['content'] = $text;
			}
			break;
		case 'kerf/link':
			if ( $text ) {
				$bindings['text'] = $text;
			}
			if ( $url ) {
				$bindings['url'] = $url;
			}
			break;
		case 'kerf/image':
			if ( 'image' === $role ) {
				$bindings['src']     = $post( 'image' );
				$bindings['alt']     = $post( 'image-alt' );
				$bindings['mediaId'] = $post( 'image-id' );
				// The sample's size is the slot's (scar 52).
				$meta = ! empty( $attrs['mediaId'] ) ? wp_get_attachment_metadata( (int) $attrs['mediaId'] ) : array();
				$w    = ! empty( $attrs['width'] ) ? (int) $attrs['width'] : (int) ( $meta['width'] ?? 0 );
				$h    = ! empty( $attrs['height'] ) ? (int) $attrs['height'] : (int) ( $meta['height'] ?? 0 );
				if ( $w && $h ) {
					$bindings['src']['args']['fit'] = array( $w, $h );
				}
			}
			break;
		case 'kerf/div':
			if ( 'image' === $role && ! empty( $attrs['backgroundImage'] ) ) {
				$bindings['backgroundImage']   = $post( 'image' );
				$bindings['backgroundImageId'] = $post( 'image-id' );
			} elseif ( in_array( $role, array( 'image', 'permalink' ), true ) ) {
				// Swapped at render from the marker (kerf_apply_element_fields()):
				// a script's picture attribute, a card link's href.
				$have                     = isset( $attrs['kerfFields'] ) ? (string) $attrs['kerfFields'] . ' ' : '';
				$block['attrs']['kerfFields'] = trim( $have . $role );
			}
			break;
	}

	if ( $bindings ) {
		$block['attrs']['metadata']             = isset( $attrs['metadata'] ) ? (array) $attrs['metadata'] : array();
		$block['attrs']['metadata']['bindings'] = $bindings;
	}
	return $block;
}

/**
 * A core heading holding a link, as a Kerf heading element holding a link
 * block bound to the post: the heading's tag, classes (less WordPress's own),
 * id and attributes; the link's address and classes.
 *
 * @param array  $block  A core/heading.
 * @param string $sample Its text.
 * @return array|null
 */
function kerf_latest_heading_link( $block, $sample ) {
	$tags = new WP_HTML_Tag_Processor( (string) $block['innerHTML'] );
	if ( ! $tags->next_tag() ) {
		return null;
	}
	$tag   = strtolower( (string) $tags->get_tag() );
	$class = trim( (string) preg_replace( '/(?:^|\s)wp-block-heading(?=\s|$)/', ' ', (string) $tags->get_attribute( 'class' ) ) );
	$id    = (string) $tags->get_attribute( 'id' );
	if ( ! preg_match( '/^h[1-6]$/', $tag ) || ! $tags->next_tag( 'a' ) ) {
		return null;
	}

	$attrs = isset( $block['attrs'] ) ? $block['attrs'] : array();
	$div   = array( 'tagName' => $tag );
	if ( '' !== $class ) {
		$div['className'] = preg_replace( '/\s+/', ' ', $class );
	}
	if ( ! empty( $attrs['anchor'] ) || '' !== $id ) {
		$div['anchor'] = ! empty( $attrs['anchor'] ) ? $attrs['anchor'] : $id;
	}
	foreach ( array( 'customAttributes', 'inlineStyle' ) as $key ) {
		if ( ! empty( $attrs[ $key ] ) ) {
			$div[ $key ] = $attrs[ $key ];
		}
	}

	$link = array( 'text' => $sample, 'url' => (string) $tags->get_attribute( 'href' ) );
	if ( '' !== (string) $tags->get_attribute( 'class' ) ) {
		$link['className'] = (string) $tags->get_attribute( 'class' );
	}
	$link = kerf_latest_bind(
		array( 'blockName' => 'kerf/link', 'attrs' => $link, 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ),
		'title',
		$sample
	);

	return array(
		'blockName'    => 'kerf/div',
		'attrs'        => $div,
		'innerBlocks'  => array( $link ),
		'innerHTML'    => '',
		'innerContent' => array( null ),
	);
}

/**
 * The section with its first card repeating for the latest posts.
 *
 * @param array    $root
 * @param array    $found  kerf_latest_find().
 * @param string[] $chosen The roles the owner confirmed.
 * @return array
 */
function kerf_latest_apply( $root, $found, $chosen ) {
	$parent = &kerf_latest_at( $root, $found['path'] );
	$start  = $found['start'];
	$count  = $found['count'];
	$card   = $parent['innerBlocks'][ $start ];

	// Pieces of one paragraph are marked together and the paragraph converted
	// once (kerf_latest_convert_marked()); every other part is bound in place.
	$inline = array();
	foreach ( $found['roles'] as $role ) {
		if ( ! in_array( $role['role'], $chosen, true ) ) {
			continue;
		}
		if ( isset( $role['inline'] ) ) {
			$inline[ implode( '.', $role['path'] ) ][ $role['inline'] ] = $role['role'];
			continue;
		}
		$part = &kerf_latest_at( $card, $role['path'] );
		$part = kerf_latest_bind( $part, $role['role'], $role['sample'] );
		unset( $part );
	}
	foreach ( $inline as $key => $marks ) {
		$part      = &kerf_latest_at( $card, '' === $key ? array() : array_map( 'intval', explode( '.', (string) $key ) ) );
		$converted = kerf_latest_convert_marked( $part, $marks );
		if ( $converted ) {
			$part = $converted;
		}
		unset( $part );
	}

	// Whitespace between the samples was whitespace between every card
	// (§5.20): the loop's own, and the parent's record of it shrinks.
	$gaps = isset( $parent['attrs']['gaps'] ) ? (string) $parent['attrs']['gaps'] : '';
	$all  = count( $parent['innerBlocks'] );
	$loop = array(
		'blockName'    => 'kerf/loop',
		'attrs'        => array( 'query' => 'latest', 'perPage' => $count ),
		'innerBlocks'  => array( $card ),
		'innerHTML'    => "\n\n",
		'innerContent' => array( "\n", null, "\n" ),
	);
	if ( strlen( $gaps ) === $all + 1 && '0' === $gaps[ $start + 1 ] ) {
		$loop['attrs']['gap'] = false;
	}
	array_splice( $parent['innerBlocks'], $start, $count, array( $loop ) );
	if ( strlen( $gaps ) === $all + 1 ) {
		$parent['attrs']['gaps'] = substr( $gaps, 0, $start + 1 ) . substr( $gaps, $start + $count );
	}

	// One null per child, whitespace between: kerf_apply_gaps() rebuilds it
	// from `gaps` at render; this is what is saved.
	$inner = array( "\n" );
	foreach ( $parent['innerBlocks'] as $unused ) {
		$inner[] = null;
		$inner[] = "\n";
	}
	$parent['innerContent'] = $inner;
	unset( $parent );

	// Changed here on purpose: an update from the mockup leaves it alone
	// unless asked (§5.28).
	if ( isset( $root['attrs']['kerfSource'] ) && is_array( $root['attrs']['kerfSource'] ) ) {
		$root['attrs']['kerfSource']['out'] = 'replaced';
	}

	return $root;
}
