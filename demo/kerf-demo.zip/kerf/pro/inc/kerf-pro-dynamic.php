<?php
/**
 * Live content where the design marks it (§5.25, §5.30).
 *
 * The markup contract — `data-kerf-loop` on a post's card, `data-kerf-field`
 * on its title, date, picture…, the comments area and its form — and the
 * sample post meta Kerf recognises in a card are filled in with the site's
 * posts and comments when the converter is asked (`dynamic`). An import, an
 * update or a pasted section asks here. Without it the design's samples stay
 * as written, and its blog pages are not used.
 *
 * Kerf Pro's (§8.14). What it made — loops, bindings, the post's content and
 * comments — is the free plugin's to render, so it keeps showing; with a
 * lapsed licence a new import keeps the samples.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * An import (an update, a page, a pasted section) fills in what the design
 * marks.
 *
 * @param array $options The converter's options (kerf_import_converter_options()).
 * @return array
 */
function kerf_dynamic_converter_options( $options ) {
	if ( kerf_pro_licensed() ) {
		$options['dynamic'] = true;
	}
	return $options;
}
add_filter( 'kerf_import_converter_options', 'kerf_dynamic_converter_options' );
