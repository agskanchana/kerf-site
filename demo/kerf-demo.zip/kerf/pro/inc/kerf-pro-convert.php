<?php
/**
 * Convert HTML: the REST API for the editor sidebar's paste tools.
 *
 * The whole-document import (the free plugin's inc/kerf-import.php) is the
 * headline flow, but it is not the only one anybody needs. Converting one
 * section — a new pricing table a designer sent over, a hero the client wants
 * swapped — should not require re-importing the site. This endpoint is that:
 * paste markup in the editor, get blocks back, keep working
 * (assets/js/kerf-convert-panel.js: insert, or replace the selected block).
 *
 * Same engine, same report, same audit. The two entry points differ only in how
 * much HTML they are handed.
 *
 * Kerf Pro's (§8.14). What it inserted is ordinary Kerf blocks, the free
 * plugin's to render; a lapsed licence stops it converting more.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Largest markup payload accepted, in bytes.
 *
 * The converter walks the whole DOM and holds the result in memory; an
 * unbounded paste is the cheapest way to exhaust `memory_limit` on a shared
 * host. A very large real page is well under this.
 */
const KERF_API_MAX_HTML = 4194304; // 4 MB.

/**
 * Register the converter routes.
 */
function kerf_register_converter_routes() {
	register_rest_route( 'kerf/v1', '/convert', array(
		'methods'             => WP_REST_Server::CREATABLE,
		'callback'            => 'kerf_rest_convert',
		// Converting is authoring: the output goes straight into a post the
		// caller is about to save, so the bar is the same as editing that post.
		'permission_callback' => static function () {
			if ( ! current_user_can( 'edit_posts' ) ) {
				return false;
			}
			return kerf_pro_licensed() ? true : new WP_Error( 'kerf_pro_expired', __( 'Your Kerf Pro licence has expired: renew to convert HTML here again.', 'kerf-pro' ), array( 'status' => 403 ) );
		},
		'args'                => array(
			'html'     => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static function ( $value ) {
					return wp_unslash( $value );
				},
			),
			'base_url' => array(
				'required'          => false,
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			),
			// A section pasted INTO the header part should not arrive wrapped in
			// a second <header>; the part already renders the landmark.
			'demote_landmark' => array(
				'required' => false,
				'type'     => 'boolean',
				'default'  => false,
			),
			// The page being edited: one with a design of its own resolves a
			// section's `img/…` against that design's files.
			'post_id'         => array(
				'required' => false,
				'type'     => 'integer',
				'default'  => 0,
			),
			// The section's own styles and scripts, given to what is edited
			// (inc/kerf-pro-page-assets.php): this page; in the Site Editor a
			// template (`template`, its slug), or every page for a header or
			// footer (`everywhere`).
			'add_assets'      => array(
				'required' => false,
				'type'     => 'boolean',
				'default'  => false,
			),
			'template'        => array(
				'required'          => false,
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'sanitize_title',
			),
			'everywhere'      => array(
				'required' => false,
				'type'     => 'boolean',
				'default'  => false,
			),
		),
	) );
}

/**
 * Where a converted section's own files go: the page edited (any post), a
 * template, or every page — each only for whoever may change it.
 *
 * @param WP_REST_Request $request
 * @return int|string|WP_Error A page id, `tpl:<slug>`, '' for every page.
 */
function kerf_convert_assets_where( $request ) {
	$post_id  = (int) $request->get_param( 'post_id' );
	$template = (string) $request->get_param( 'template' );
	if ( '' !== $template || $request->get_param( 'everywhere' ) ) {
		if ( ! current_user_can( 'edit_theme_options' ) ) {
			return new WP_Error( 'kerf_forbidden', __( 'Only someone who may change the site\'s design can add styles to a template or every page.', 'kerf-pro' ), array( 'status' => 403 ) );
		}
		return '' !== $template ? 'tpl:' . $template : '';
	}
	if ( ! $post_id || ! current_user_can( 'edit_post', $post_id ) ) {
		return new WP_Error( 'kerf_forbidden', __( 'Save the page once, then convert again to add the section\'s styles to it.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	return $post_id;
}
add_action( 'rest_api_init', 'kerf_register_converter_routes' );

/**
 * Convert markup and return blocks plus the loss report.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_rest_convert( $request ) {
	$html = (string) $request->get_param( 'html' );

	if ( '' === trim( $html ) ) {
		return new WP_Error( 'kerf_empty', __( 'Nothing to convert.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	if ( strlen( $html ) > KERF_API_MAX_HTML ) {
		return new WP_Error(
			'kerf_too_large',
			sprintf(
				/* translators: %s: size limit. */
				__( 'That markup is larger than %s. Import it as a whole mockup instead, or convert it in sections.', 'kerf-pro' ),
				size_format( KERF_API_MAX_HTML )
			),
			array( 'status' => 413 )
		);
	}

	$body = kerf_mc_extract_body( $html );

	if ( $request->get_param( 'demote_landmark' ) ) {
		$demoted = kerf_mc_demote_root_landmark( $body );
		if ( '' !== $demoted['demoted'] ) {
			$body = $demoted['html'];
		}
	}

	// Relative paths in a pasted section — `img/team-1.jpg`, `url(../img/x.jpg)`
	// — mean the mockup's folder, as they did in the import: resolved against
	// the files the last import (or update) staged.
	// The edited page's design, when it has one of its own (kerf_assets_design()).
	$staged  = kerf_assets_design( (int) $request->get_param( 'post_id' ) )['staging'];
	$options = array(
		'base_url'   => (string) $request->get_param( 'base_url' ),
		// Attributes that run code (Alpine, htmx…) are scripts (§5.32).
		'directives' => kerf_user_can_add_scripts(),
	);
	if ( '' === $options['base_url'] && ! empty( $staged['url'] ) ) {
		$options['staging_url'] = (string) $staged['url'];
		$options['base_rel']    = isset( $staged['rel'] ) ? (string) $staged['rel'] : '';
	}

	// As an import converts (the business's details bound, §5.36).
	$result = kerf_mc_convert_html( $body, null, kerf_import_converter_options( $options ) );

	$audit = kerf_mc_audit( $body, $result['markup'] );

	// And its links find the site's pages, as an import's do (§5.14).
	if ( function_exists( 'kerf_links_bind' ) ) {
		$bound            = kerf_links_bind( $result['markup'] );
		$result['markup'] = $bound['markup'];
	}

	// A section's own styles and scripts never rewrite the site's — the import
	// screen is where that is decided. Asked for, they are given to what is
	// edited alone: this page, this template, or (a header's) every page; else
	// they are named, and left out.
	$assets = kerf_assets_extract( $html );
	$given  = array( 'added' => array(), 'styles' => array(), 'skipped' => array() );
	if ( $assets && ! current_user_can( 'unfiltered_html' ) ) {
		// Authoring the blocks is still allowed. Their styles and scripts need
		// the same permission as Additional CSS and the Custom HTML block.
		$given = kerf_pro_page_assets_add( 0, $assets, 'convert' );
	} elseif ( $assets && $request->get_param( 'add_assets' ) ) {
		$where = kerf_convert_assets_where( $request );
		if ( is_wp_error( $where ) ) {
			return $where;
		}
		$staging = kerf_pro_page_assets_staging( is_int( $where ) ? $where : 0 );
		$local   = $staging ? kerf_import_localize_assets( $assets, $staging ) : $assets;
		foreach ( $assets as $i => $asset ) {
			// A file the design's folder does not have: never enqueued at a
			// broken address (scar 82).
			if ( ! isset( $local[ $i ] ) || ( 'file' === $asset['kind'] && ! preg_match( '#^(?:https?:)?//#i', (string) $local[ $i ]['src'] ) ) ) {
				$given['skipped'][] = kerf_pro_page_assets_label( $asset );
				unset( $local[ $i ] );
			}
		}
		$added = kerf_pro_page_assets_add( $where, array_values( $local ), 'convert' );
		$given = array(
			'added'   => $added['added'],
			'styles'  => $added['styles'],
			'skipped' => array_merge( $given['skipped'], $added['skipped'] ),
		);
	}

	return rest_ensure_response( array(
		'markup'    => $result['markup'],
		'report'    => $result['report'],
		'audit'     => $audit,
		'elements'  => $result['elements'],
		'truncated' => $result['truncated'],
		'assets'    => array_map(
			static function ( $asset ) {
				return array(
					'type'  => $asset['type'],
					'kind'  => $asset['kind'],
					'src'   => $asset['src'],
					'label' => kerf_pro_page_assets_label( $asset ),
				);
			},
			$assets
		),
		'added'     => $given['added'],
		'skipped'   => $given['skipped'],
		'styles'    => $given['styles'],
	) );
}

/**
 * The sidebar's Convert HTML panel (assets/js/kerf-convert-panel.js), filling
 * the free plugin's Kerf sidebar — and whether the licence lets it act.
 */
function kerf_convert_panel_assets() {
	$rel = 'assets/js/kerf-convert-panel.js';
	if ( ! current_user_can( 'edit_posts' ) || ! file_exists( kerf_pro_path( $rel ) ) ) {
		return;
	}
	wp_enqueue_script( 'kerf-convert-panel', kerf_pro_url( $rel ), array( 'kerf-editor-ux', 'wp-plugins', 'wp-element', 'wp-components', 'wp-i18n', 'wp-data', 'wp-blocks', 'wp-block-editor', 'wp-api-fetch' ), filemtime( kerf_pro_path( $rel ) ), true );
	wp_set_script_translations( 'kerf-convert-panel', 'kerf-pro', kerf_pro_path( 'languages' ) );
	wp_add_inline_script( 'kerf-convert-panel', 'window.kerfProConvert = ' . wp_json_encode( array( 'licensed' => kerf_pro_licensed() ) ) . ';', 'before' );

	// The editor's own document, where the sidebar is drawn (scar 75).
	$css = 'assets/css/kerf-pro-editor-ui.css';
	if ( file_exists( kerf_pro_path( $css ) ) ) {
		wp_enqueue_style( 'kerf-pro-editor-ui', kerf_pro_url( $css ), array(), filemtime( kerf_pro_path( $css ) ) );
	}
}
add_action( 'enqueue_block_editor_assets', 'kerf_convert_panel_assets' );
