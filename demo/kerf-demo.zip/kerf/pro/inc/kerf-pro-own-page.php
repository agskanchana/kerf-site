<?php
/**
 * A page with a design of its own (§5.39).
 *
 * A landing page from another tool: imported for "One page of its own", the
 * whole body is the page (no split), it gets the Blank template, and its
 * stylesheets, scripts, <html>/<body> attributes, staged folder and capture are
 * a set kept on the page (kerf_asset_sets). The site's parts, assets, frame and
 * front page are untouched; the ZIP's other pages are not imported.
 *
 * The free import asks for it as a scope (`kerf_import_scopes`) and writes
 * nothing site-wide for one; the set is read and dressed by the free plugin
 * (kerf_assets_design()) wherever the page renders, so it outlives the add-on.
 * Kerf Pro's (§8.14): with a lapsed licence the scope is not offered.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Offer "One page of its own" on the import form.
 *
 * @param array<string,string> $scopes
 * @return array<string,string>
 */
function kerf_own_page_scope( $scopes ) {
	if ( kerf_pro_licensed() ) {
		$scopes['page'] = __( 'One page of its own — a landing page with its own header, footer, styles and scripts. The rest of the site is not touched.', 'kerf-pro' );
	}
	return $scopes;
}
add_filter( 'kerf_import_scopes', 'kerf_own_page_scope' );

/**
 * Its regions: the body whole — and what the report says about that.
 *
 * @param array      $split { parts, actions }.
 * @param string     $body
 * @param string     $scope
 * @param array|null $staging
 * @return array
 */
function kerf_own_page_parts( $split, $body, $scope, $staging ) {
	if ( 'page' !== $scope ) {
		return $split;
	}
	$split['parts']     = kerf_import_whole_page( $body );
	$split['actions'][] = __( 'Imported as a page of its own: its header and footer are part of the page, and its stylesheets, scripts and <body> attributes load on this page only. The site\'s header, footer and styles were not touched.', 'kerf-pro' );
	if ( ! empty( $staging['pages'] ) ) {
		$split['actions'][] = sprintf(
			/* translators: %s: list of file names. */
			__( 'Not imported, because a page of its own is one page: %s.', 'kerf-pro' ),
			implode( ', ', array_keys( $staging['pages'] ) )
		);
	}
	return $split;
}
add_filter( 'kerf_import_parts', 'kerf_own_page_parts', 10, 4 );

/**
 * The scripts a re-import replaces are the page's own (§5.32): someone who
 * may not add scripts keeps THAT page's, not the site's.
 *
 * @param array  $replaced
 * @param string $scope
 * @param int    $target
 * @return array
 */
function kerf_own_page_replaced_assets( $replaced, $scope, $target ) {
	if ( 'page' !== $scope || ! $target ) {
		return $replaced;
	}
	$before = kerf_assets_design( (int) $target );
	return $before['page'] ? $before['assets'] : array();
}
add_filter( 'kerf_import_replaced_assets', 'kerf_own_page_replaced_assets', 10, 3 );

/**
 * The design kept on the page; with its assets not imported this time, the
 * page keeps the ones it had.
 *
 * @param string[] $actions
 * @param string   $scope
 * @param int      $page_id
 * @param array    $design
 * @return string[]
 */
function kerf_own_page_written( $actions, $scope, $page_id, $design ) {
	if ( 'page' !== $scope ) {
		return $actions;
	}
	if ( null === $design['assets'] ) {
		$before           = kerf_assets_design( (int) $page_id );
		$design['assets'] = $before['page'] ? $before['assets'] : array();
	}
	return array_merge( $actions, kerf_import_own_design( (int) $page_id, $design ) );
}
add_filter( 'kerf_import_scope_written', 'kerf_own_page_written', 10, 4 );

/**
 * After the import: what the page's scripts make (Tailwind's CSS, drawn icons)
 * is read from it for its editor (the free plugin's inc/kerf-capture.php). The
 * site's look did not change, so the home page is not read again.
 *
 * @param array $result
 */
function kerf_own_page_report_items( $result ) {
	if ( ! empty( $result['dry_run'] ) || 'page' !== ( $result['scope'] ?? '' ) || empty( $result['page_id'] ) ) {
		return;
	}
	printf(
		'<li class="kerf-capture-after-import" data-url="%s" data-page="%d" data-done="%s" data-failed="%s">%s</li>',
		esc_url( get_permalink( $result['page_id'] ) ),
		(int) $result['page_id'],
		esc_attr__( 'Read the page for its editor: what its scripts draw shows there too.', 'kerf-pro' ),
		esc_attr__( 'Could not read the page for its editor; designs styled by a script may look unstyled there until it is imported again.', 'kerf-pro' ),
		esc_html__( 'Reading the page for its editor…', 'kerf-pro' )
	);
}
add_action( 'kerf_import_report_items', 'kerf_own_page_report_items' );

/**
 * The regions of a page of its own: the whole body is the page — its header,
 * footer and any frame included — and nothing goes to the site's parts.
 * kerf_import_split()'s shape.
 *
 * @param string $body
 * @return array
 */
function kerf_import_whole_page( $body ) {
	return array(
		'header'      => '',
		'main'        => $body,
		'footer'      => '',
		'before'      => '',
		'after'       => '',
		'frame'       => array(),
		'folded'      => array(),
		'front_only'  => array(),
		'chrome'      => '',
		'footer_node' => '',
	);
}

/**
 * Give a page its own design (§5.39): the set kerf_assets_design() reads on
 * its requests and in its editor, and the Blank template, so the site's
 * header and footer do not render around the design's own.
 *
 * @param int   $page_id
 * @param array $set { assets, body, html, staging, source }.
 * @return string[] Report lines.
 */
function kerf_import_own_design( $page_id, $set ) {
	$before = kerf_asset_sets();
	$set   += array(
		'version' => (string) time(),
		'at'      => time(),
	);
	// What a reading of the page captured for the editor is for that design:
	// a re-import keeps it until the page is read again.
	if ( isset( $before[ $page_id ]['captured'] ) ) {
		$set['captured'] = $before[ $page_id ]['captured'];
	}
	kerf_asset_set_save( $page_id, $set );
	update_post_meta( $page_id, '_wp_page_template', 'blank' );

	$counts = array_count_values( wp_list_pluck( $set['assets'], 'type' ) );
	return array(
		sprintf(
			/* translators: 1: stylesheet count, 2: script count. */
			__( 'This page has a design of its own: %1$d stylesheets and %2$d scripts load on it and nowhere else, and it uses the Blank template, so the site\'s header and footer are not shown around its own.', 'kerf-pro' ),
			isset( $counts['css'] ) ? $counts['css'] : 0,
			isset( $counts['js'] ) ? $counts['js'] : 0
		),
	);
}
