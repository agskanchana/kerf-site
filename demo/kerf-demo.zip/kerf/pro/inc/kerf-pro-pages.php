<?php
/**
 * The other pages in a mockup ZIP.
 *
 * A designer hands over a folder, not a page: index.html, and beside it
 * about.html, contact.html — and often blog.html, blog-details.html, 404.html.
 * Every one of them now goes somewhere:
 *
 *   A page WordPress has a template for — the blog, a post, an archive, search
 *   results, a page, the 404 — becomes that template, IF it is marked up with
 *   the contract (`data-kerf-template`, `data-kerf-loop`, `data-kerf-field`;
 *   see kerf_shell_prompt()). Unmarked, it cannot be filled with real posts, so
 *   it is recorded, reported, and offered for marking under Kerf → Inner pages.
 *
 *   Any other page becomes a WordPress page with the same name — about.html is
 *   "About" at /about/ — so the links between the mockup's pages resolve on the
 *   first import instead of landing on Kerf → Links.
 *
 *   Alternative home pages (home-02.html, index-3.html) are left out and said so.
 *
 * Every page shares the entry's header, footer and frame: those are written
 * once, from index.html. A page whose header text differs is reported, because
 * the site will show index.html's.
 *
 * Kerf Pro's (§8.14): the free plugin's import asks it at four points, in
 * the order it does these things (`kerf_import_check_sections` — the check
 * step, where the owner says what each file becomes — then
 * `kerf_import_other_pages`, `kerf_import_other_pages_assets` and
 * `kerf_import_other_pages_written` — below). The pages and templates it
 * writes are ordinary content the free plugin renders. The pause between
 * the check and the import is the free plugin's (kerf_import_pending_save()).
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What a file in the ZIP is for.
 *
 * `data-kerf-template` on its `<body>` decides; otherwise its name does, the
 * way a designer names these files.
 *
 * @param string $file File name.
 * @param string $html Its HTML.
 * @return string A page type from kerf_shell_page_types(), 'page:ordinary' or 'skip'.
 */
function kerf_import_classify_page( $file, $html ) {
	$types = array( 'home', 'single', 'page', 'archive', 'search', '404' );
	$body  = kerf_mc_extract_body_attributes( $html );

	if ( ! empty( $body['attributes']['data-kerf-template'] ) ) {
		$type = strtolower( trim( (string) $body['attributes']['data-kerf-template'] ) );
		if ( in_array( $type, $types, true ) ) {
			return $type;
		}
	}

	$name = strtolower( preg_replace( '/\.x?html?$/i', '', $file ) );

	if ( preg_match( '/^(?:index|home)[-_]?(?:\d+|v\d+|alt.*|old|copy)$/', $name ) ) {
		return 'skip';
	}
	if ( preg_match( '/^(?:blog|news|articles?|journal|posts?)(?:[-_](?:grid|list|standard|classic|masonry|sidebar|right-sidebar|left-sidebar|full|\d))?$/', $name ) ) {
		return 'home';
	}
	if ( preg_match( '/^(?:(?:blog|news|post|article)[-_]?(?:details?|single|post|read|view|page)|single(?:[-_]post)?|post|article)$/', $name ) ) {
		return 'single';
	}
	if ( preg_match( '/^(?:404|error|not-?found)$/', $name ) ) {
		return '404';
	}
	if ( preg_match( '/^search(?:[-_]results?)?$/', $name ) ) {
		return 'search';
	}
	if ( preg_match( '/^(?:archive|category|categories|tag|tags)$/', $name ) ) {
		return 'archive';
	}
	if ( preg_match( '/^(?:page|generic|default)$/', $name ) ) {
		return 'page';
	}
	// A style guide, not a page of the site.
	if ( preg_match( '/^(?:elements?|components?|styleguide|style-guide|typography|shortcodes?)$/', $name ) ) {
		return 'skip';
	}

	return 'page:ordinary';
}

/**
 * Does the page carry the markup contract at all?
 *
 * @param string $html
 * @return bool
 */
function kerf_import_page_is_marked( $html ) {
	return (bool) preg_match( '/\sdata-kerf-(?:template|loop|field)\b/i', $html );
}

/**
 * A fingerprint of a page with the contract's markers taken out: the same
 * page before and after marking gives the same fingerprint, and anything else
 * that changed — a class, a word — does not.
 *
 * @param string $html
 * @return string
 */
function kerf_import_page_fingerprint( $html ) {
	$body = kerf_mc_extract_body( $html );
	$doc  = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . $body . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();

	$walk = function ( $node ) use ( &$walk ) {
		if ( XML_TEXT_NODE === $node->nodeType ) {
			$text = trim( preg_replace( '/\s+/u', ' ', $node->textContent ) );
			return '' === $text ? '' : 't:' . $text . ';';
		}
		if ( XML_ELEMENT_NODE !== $node->nodeType ) {
			return '';
		}
		$attrs = array();
		foreach ( $node->attributes as $attribute ) {
			if ( 0 !== stripos( $attribute->name, 'data-kerf-' ) ) {
				$attrs[] = strtolower( $attribute->name ) . '=' . trim( $attribute->value );
			}
		}
		sort( $attrs );
		$out = '<' . strtolower( $node->nodeName ) . ' ' . implode( ' ', $attrs ) . '>';
		foreach ( $node->childNodes as $child ) {
			$out .= $walk( $child );
		}
		return $out . '</>';
	};

	return $doc->documentElement ? md5( $walk( $doc->documentElement ) ) : '';
}

/**
 * The plain text of a region, for comparing headers.
 *
 * @param string $html
 * @return string
 */
function kerf_import_region_text( $html ) {
	return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES, 'UTF-8' ) ) );
}

/**
 * Decide what each page becomes, before anything is written.
 *
 * @param array<string,string> $pages       file => HTML.
 * @param array                $entry_parts The entry's split (kerf_import_split()).
 * @return array[] One entry per file: file, html, type, marked, fingerprint, split, notes.
 */
function kerf_import_pages_plan( $pages, $entry_parts ) {
	$previous     = get_option( 'kerf_import_pages', array() );
	$previous     = is_array( $previous ) ? $previous : array();
	$entry_header = kerf_import_region_text( $entry_parts['header'] );
	$plan         = array();

	foreach ( $pages as $file => $html ) {
		$type   = kerf_import_classify_page( $file, $html );
		$marked = kerf_import_page_is_marked( $html );
		$split  = kerf_import_split( kerf_mc_extract_body( $html ) );
		$notes  = array();

		if ( 'skip' !== $type && '' !== $entry_header && '' !== trim( $split['header'] )
			&& kerf_import_region_text( $split['header'] ) !== $entry_header ) {
			$notes[] = 'header';
		}

		$fingerprint = kerf_import_page_fingerprint( $html );
		if ( $marked && ! empty( $previous[ $file ]['fingerprint'] ) && empty( $previous[ $file ]['marked'] )
			&& $previous[ $file ]['fingerprint'] !== $fingerprint ) {
			// The "prepare" brief asked for markers and nothing else.
			$notes[] = 'changed';
		}

		$plan[] = array(
			'file'        => $file,
			'html'        => $html,
			'type'        => $type,
			'marked'      => $marked,
			'fingerprint' => $fingerprint,
			'split'       => $split,
			'notes'       => $notes,
		);
	}

	return $plan;
}

/**
 * The slug a page file becomes: about-us.html → about-us.
 *
 * @param string $file
 * @return string
 */
function kerf_import_page_slug( $file ) {
	return sanitize_title( preg_replace( '/\.x?html?$/i', '', $file ) );
}

/**
 * The title a page file becomes: about-us.html → "About Us".
 *
 * @param string $file
 * @return string
 */
function kerf_import_page_title( $file ) {
	$name = preg_replace( '/\.x?html?$/i', '', $file );
	return ucwords( trim( preg_replace( '/[-_]+/', ' ', $name ) ) );
}

/**
 * Make sure every ordinary page exists before links are bound, so a link to
 * about.html from anywhere in the mockup finds the About page on this import.
 *
 * An existing page with the same slug is used if it came from a mockup; one
 * written in WordPress is left alone, and the file is not imported over it.
 *
 * @param array[] $plan By reference: each ordinary page gains 'page_id' or a note.
 */
function kerf_import_pages_reserve( &$plan ) {
	foreach ( $plan as &$item ) {
		if ( 'page:ordinary' !== $item['type'] ) {
			continue;
		}

		// The address and title chosen on the review screen, else the file's.
		$slug  = ! empty( $item['slug'] ) ? sanitize_title( $item['slug'] ) : kerf_import_page_slug( $item['file'] );
		$title = ! empty( $item['title'] ) ? $item['title'] : kerf_import_page_title( $item['file'] );

		// An ARRAY of types, always: given one type as a string,
		// get_page_by_path() adds 'attachment' to it, and gymlife's
		// about-us.jpg was taken for the About page — its description
		// overwritten with the page's blocks.
		$existing = get_page_by_path( $slug, OBJECT, array( 'page' ) );

		if ( $existing && ! kerf_shell_is_mockup_post( $existing ) && '' !== trim( $existing->post_content ) ) {
			$item['notes'][] = 'exists';
			continue;
		}

		if ( $existing ) {
			$item['page_id'] = (int) $existing->ID;
			if ( ! empty( $item['title'] ) && $existing->post_title !== $title ) {
				wp_update_post( array( 'ID' => $existing->ID, 'post_title' => $title ) );
			}
		} else {
			$id = wp_insert_post( array(
				'post_type'   => 'page',
				'post_status' => 'publish',
				'post_title'  => $title,
				'post_name'   => $slug,
			), true );

			if ( ! is_wp_error( $id ) ) {
				$item['page_id'] = (int) $id;
			}
		}

		if ( ! empty( $item['page_id'] ) && function_exists( 'kerf_links_known' ) ) {
			kerf_links_known( kerf_links_normalize( $item['file'] ), $item['page_id'] );
		}
	}
	unset( $item );
}

/**
 * Apply the review screen's choices to the plan: leave a file out, use it as
 * something else, give its page another title or address.
 *
 * Only what the screen offers is honoured. A page that is not marked up cannot
 * become a blog or post template — filled with nothing, it would show the
 * designer's sample posts — but it can become an ordinary page.
 *
 * @param array[] $plan
 * @param array   $choices file => array{type?:string,title?:string,slug?:string}
 * @return array[]
 */
function kerf_import_pages_apply_choices( $plan, $choices ) {
	$templates = array_keys( kerf_shell_page_types() );

	foreach ( $plan as &$item ) {
		if ( ! isset( $choices[ $item['file'] ] ) || ! is_array( $choices[ $item['file'] ] ) ) {
			continue;
		}
		$choice = $choices[ $item['file'] ];
		$type   = isset( $choice['type'] ) ? (string) $choice['type'] : '';

		if ( 'skip' === $type ) {
			$item['type']    = 'skip';
			$item['notes'][] = 'chosen';
			continue;
		}

		if ( 'page:ordinary' === $type || ( $item['marked'] && in_array( $type, $templates, true ) ) ) {
			$item['type'] = $type;
		}

		if ( 'page:ordinary' === $item['type'] ) {
			if ( isset( $choice['title'] ) && '' !== trim( (string) $choice['title'] ) ) {
				$item['title'] = sanitize_text_field( (string) $choice['title'] );
			}
			if ( isset( $choice['slug'] ) && '' !== trim( (string) $choice['slug'] ) ) {
				$item['slug'] = sanitize_title( (string) $choice['slug'] );
			}
		}
	}
	unset( $item );

	return $plan;
}

/**
 * Where an inner page renders: its WordPress page, or the templates it became.
 *
 * @param array   $item
 * @param array[] $plan
 * @return array|null `only` for kerf_assets_applies_here(), or null when the
 *                    page is not being imported.
 */
function kerf_import_page_where( $item, $plan ) {
	if ( 'page:ordinary' === $item['type'] ) {
		return empty( $item['page_id'] ) ? null : array( 'pages' => array( (int) $item['page_id'] ) );
	}
	if ( 'skip' === $item['type'] || ! $item['marked'] ) {
		return null;
	}

	$templates = array( $item['type'] );
	if ( 'home' === $item['type'] ) {
		foreach ( array( 'archive', 'search' ) as $fallback ) {
			if ( ! kerf_import_plan_has( $plan, $fallback ) ) {
				$templates[] = $fallback;
			}
		}
	}
	return array( 'templates' => $templates );
}

/**
 * Stylesheets and scripts an inner page loads that the home page does not.
 *
 * Appended after the home page's, and marked with where they apply, so they
 * load only on the pages and templates that brought them. Site-wide, a page's
 * own CSS is somebody else's bug: gymlife's main.html is a launch page whose
 * `<style>` sets `img { margin: 20% auto 0; display: block }`, and it pushed
 * every picture on every page down by a fifth (scar 45). The brief asks
 * designers to put the new pages' CSS in one css/pages.css; every new page
 * links it, so it loads wherever one of them renders.
 *
 * @param array[] $assets  The entry's assets.
 * @param array[] $plan    After kerf_import_pages_reserve(), so pages have ids.
 * @param string  $base_url
 * @param array   $staging
 * @return array{assets:array[],added:string[]}
 */
function kerf_import_pages_merge_assets( $assets, $plan, $base_url, $staging ) {
	$key = function ( $asset ) {
		if ( 'file' === $asset['kind'] ) {
			return $asset['type'] . '|file|' . ( isset( $asset['src'] ) ? $asset['src'] : '' );
		}
		return $asset['type'] . '|inline|' . md5( isset( $asset['content'] ) ? $asset['content'] : '' );
	};

	$site  = array();
	$index = array();
	$added = array();
	foreach ( $assets as $asset ) {
		$site[ $key( $asset ) ] = true;
	}

	foreach ( $plan as $item ) {
		$where = kerf_import_page_where( $item, $plan );
		if ( ! $where ) {
			continue;
		}
		$extra = kerf_assets_extract( $item['html'], $base_url );
		if ( $staging ) {
			$extra = kerf_import_localize_assets( $extra, $staging );
		}
		foreach ( $extra as $asset ) {
			$k = $key( $asset );
			if ( isset( $site[ $k ] ) ) {
				continue; // The home page loads it already, everywhere.
			}
			if ( isset( $index[ $k ] ) ) {
				// Another page brought it too: it loads on both.
				$only = &$assets[ $index[ $k ] ]['only'];
				foreach ( $where as $kind => $list ) {
					$only[ $kind ] = array_values( array_unique( array_merge( isset( $only[ $kind ] ) ? $only[ $kind ] : array(), $list ) ) );
				}
				unset( $only );
				continue;
			}

			$asset['only'] = $where;
			$assets[]      = $asset;
			$index[ $k ]   = count( $assets ) - 1;

			// A script that writes where it stands (§5.21) is part of that
			// page's content, found by reference; it is not "added".
			if ( isset( $asset['position'] ) && 'inplace' === $asset['position'] ) {
				continue;
			}
			$added[] = 'file' === $asset['kind']
				? kerf_shell_asset_label( (string) $asset['src'] ) . ' (' . $item['file'] . ')'
				: sprintf( 'an inline %s block (%s)', $asset['type'], $item['file'] );
		}
	}

	return array( 'assets' => $assets, 'added' => $added );
}

/**
 * Convert and write every page in the plan.
 *
 * @param array[] $plan
 * @param array   $ctx {manifest, options (converter options), create_missing}
 * @return array{actions:string[],report:array[],unresolved:array}
 */
function kerf_import_pages_write( $plan, $ctx ) {
	$actions    = array();
	$report     = array();
	$unresolved = array();
	$types      = kerf_shell_page_types();
	$templates  = array();
	$ordinary   = array();
	$skipped    = array();
	$left_out   = array();
	$unmarked   = array();
	$samples    = array();

	foreach ( $plan as $item ) {
		if ( in_array( 'header', $item['notes'], true ) && 'skip' !== $item['type'] ) {
			$actions[] = sprintf(
				/* translators: %s: file name. */
				__( '%s has a different header from the home page; every page uses the home page\'s header.', 'kerf-pro' ),
				$item['file']
			);
		}
		if ( in_array( 'changed', $item['notes'], true ) ) {
			$actions[] = sprintf(
				/* translators: %s: file name. */
				__( '%s changed beyond its markers since it was last imported — check that nothing else in it was altered.', 'kerf-pro' ),
				$item['file']
			);
		}

		if ( 'skip' === $item['type'] ) {
			if ( in_array( 'chosen', $item['notes'], true ) ) {
				$left_out[] = $item['file'];
			} else {
				$skipped[] = $item['file'];
			}
			continue;
		}

		if ( 'page:ordinary' !== $item['type'] && ! $item['marked'] ) {
			$unmarked[] = $item['file'];
			continue;
		}
		// A designer's blog page is made to show the site's posts. Converted
		// without them (`dynamic`, Kerf Pro's), it would show its samples as
		// if they were: those pages keep the blog's plain look instead.
		if ( 'page:ordinary' !== $item['type'] && empty( $ctx['options']['dynamic'] ) ) {
			$samples[] = $item['file'];
			continue;
		}

		if ( 'page:ordinary' === $item['type'] && empty( $item['page_id'] ) ) {
			if ( in_array( 'exists', $item['notes'], true ) ) {
				$actions[] = sprintf(
					/* translators: 1: file name, 2: slug. */
					__( '%1$s was not imported: a page at /%2$s/ already exists and was written in WordPress.', 'kerf-pro' ),
					$item['file'],
					! empty( $item['slug'] ) ? $item['slug'] : kerf_import_page_slug( $item['file'] )
				);
			}
			continue;
		}

		$result = kerf_mc_convert_html( $item['split']['main'], $ctx['manifest'], $ctx['options'] + array(
			'template'   => 'page:ordinary' === $item['type'] ? '' : $item['type'],
			'stamp'      => true,
			'site_known' => kerf_site_run_known(),
		) );
		$report = array_merge( $report, $result['report'], kerf_import_svg_loss( $result['markup'], $item['file'] ) );
		// Its pictures' descriptions, for the media library (kerf_import_fill_alts()).
		kerf_import_fill_alts( $result['markup'] );
		// A contact page's details (inc/kerf-site.php), for the pages after it too.
		kerf_site_run_known( $result['site'] );
		kerf_site_remember( $result['site'] );

		$links = kerf_links_bind( $result['markup'], array( 'create_missing' => ! empty( $ctx['create_missing'] ) ) );
		foreach ( $links['unresolved'] as $href => $count ) {
			$unresolved[ $href ] = ( isset( $unresolved[ $href ] ) ? $unresolved[ $href ] : 0 ) + $count;
		}
		// Sections a newer version of this file can update (inc/kerf-sync.php).
		$links['markup'] = kerf_sync_stamp_out( $links['markup'] );

		if ( 'page:ordinary' === $item['type'] ) {
			wp_update_post( array(
				'ID'           => $item['page_id'],
				// wp_slash() is mandatory (scar 1).
				'post_content' => wp_slash( $links['markup'] ),
			) );
			$ordinary[] = $item['file'] . ' → ' . get_the_title( $item['page_id'] );
			continue;
		}

		$content = kerf_import_template_content( $links['markup'] );
		$slugs   = array( $item['type'] );

		// The designer's blog is also the archive and the search results,
		// until pages of their own arrive: WordPress would fall back the same
		// way, if the default templates were not in between.
		if ( 'home' === $item['type'] ) {
			foreach ( array( 'archive', 'search' ) as $fallback ) {
				if ( ! kerf_import_plan_has( $plan, $fallback ) ) {
					$slugs[] = $fallback;
				}
			}
		}

		foreach ( $slugs as $slug ) {
			kerf_import_write_template(
				$types[ $slug ]['slug'],
				$types[ $slug ]['label'],
				$content,
				$slug === $item['type'] ? $item['file'] : $item['file'] . ' (as ' . $slug . ')'
			);
			$templates[] = $types[ $slug ]['label'] . ' ← ' . $item['file'];
		}
	}

	if ( $templates ) {
		$actions[] = sprintf(
			/* translators: %s: list of "Blog ← blog.html". */
			__( 'Made your designer\'s pages the templates for: %s. They fill with your real posts.', 'kerf-pro' ),
			implode( ', ', $templates )
		);
	}
	if ( $ordinary ) {
		$actions[] = sprintf(
			/* translators: %s: list of "about.html → About". */
			__( 'Imported the other pages: %s.', 'kerf-pro' ),
			implode( ', ', $ordinary )
		);
	}
	if ( $unmarked ) {
		$actions[] = sprintf(
			/* translators: %s: list of file names. */
			__( 'Not used yet: %s. They look like a blog, post, search or 404 page but are not marked up, so Kerf cannot fill them with your posts. Kerf → Inner pages → Design your own has a brief that marks them up without changing them.', 'kerf-pro' ),
			implode( ', ', $unmarked )
		);
	}
	if ( $samples ) {
		$actions[] = sprintf(
			/* translators: %s: list of file names. */
			_n(
				'Not used: %s. It is your designer\'s blog page, made to show your posts; Kerf Pro fills it with your real posts. Until then the blog has its plain look.',
				'Not used: %s. They are your designer\'s blog pages, made to show your posts; Kerf Pro fills them with your real posts. Until then the blog has its plain look.',
				count( $samples ),
				'kerf-pro'
			),
			implode( ', ', $samples )
		);
	}
	if ( $skipped ) {
		$actions[] = sprintf(
			/* translators: %s: list of file names. */
			__( 'Left out, as other versions of the home page or a style guide: %s.', 'kerf-pro' ),
			implode( ', ', $skipped )
		);
	}
	if ( $left_out ) {
		$actions[] = sprintf(
			/* translators: %s: list of file names. */
			__( 'Left out, as you chose: %s.', 'kerf-pro' ),
			implode( ', ', $left_out )
		);
	}

	return array( 'actions' => $actions, 'report' => $report, 'unresolved' => $unresolved );
}

/**
 * Is there a page of this type in the plan, marked and ready?
 *
 * @param array[] $plan
 * @param string  $type
 * @return bool
 */
function kerf_import_plan_has( $plan, $type ) {
	foreach ( $plan as $item ) {
		if ( $type === $item['type'] && $item['marked'] ) {
			return true;
		}
	}
	return false;
}

/**
 * A designer page's content as a whole template: the frame, the shared
 * header and footer parts, and the page between them.
 *
 * @param string $main Converted block markup.
 * @return string
 */
function kerf_import_template_content( $main ) {
	return '<!-- wp:kerf/frame {"lock":{"move":true,"remove":true}} -->' . "\n"
		. '<!-- wp:template-part {"slug":"header","area":"header"} /-->' . "\n\n"
		. $main . "\n"
		. '<!-- wp:template-part {"slug":"footer","area":"footer"} /-->' . "\n"
		. '<!-- /wp:kerf/frame -->' . "\n";
}

/**
 * Create or replace a template in the database.
 *
 * A database record, like the template parts (§5.9): editable in the Site
 * Editor, and it overrides the theme's default file of the same name. Marked
 * with the file it came from, which is what Kerf → Inner pages → Status lists
 * and what "Back to the default style" is allowed to delete.
 *
 * @param string $slug
 * @param string $title
 * @param string $content Block markup.
 * @param string $source  File name, for the record.
 * @return int Post ID, or 0.
 */
function kerf_import_write_template( $slug, $title, $content, $source ) {
	$theme = get_stylesheet();

	$existing = get_posts( array(
		'post_type'      => 'wp_template',
		'post_status'    => array( 'publish', 'draft', 'auto-draft' ),
		'name'           => $slug,
		'posts_per_page' => 1,
		'no_found_rows'  => true,
		'tax_query'      => array( array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a template is its theme's: how core finds one too.
			'taxonomy' => 'wp_theme',
			'field'    => 'name',
			'terms'    => $theme,
		) ),
	) );

	$postarr = array(
		'post_type'    => 'wp_template',
		'post_status'  => 'publish',
		'post_name'    => $slug,
		'post_title'   => $title,
		/* translators: %s: file name. */
		'post_excerpt' => sprintf( __( 'From your mockup\'s %s.', 'kerf-pro' ), $source ),
		// wp_slash() is mandatory (scar 1).
		'post_content' => wp_slash( $content ),
	);

	if ( ! empty( $existing ) ) {
		$postarr['ID'] = $existing[0]->ID;
		$post_id       = wp_update_post( $postarr, true );
	} else {
		$post_id = wp_insert_post( $postarr, true );
	}

	if ( is_wp_error( $post_id ) || ! $post_id ) {
		return 0;
	}

	wp_set_object_terms( $post_id, $theme, 'wp_theme' );
	update_post_meta( $post_id, '_kerf_source', $source );
	clean_post_cache( $post_id );

	return (int) $post_id;
}

/**
 * Remember what each page of the last import was, for Kerf → Inner pages.
 *
 * @param array[] $plan
 */
function kerf_import_pages_record( $plan ) {
	$record = array();
	foreach ( $plan as $item ) {
		$record[ $item['file'] ] = array(
			'type'        => $item['type'],
			'marked'      => $item['marked'] ? 1 : 0,
			'fingerprint' => $item['fingerprint'],
			'page_id'     => isset( $item['page_id'] ) ? (int) $item['page_id'] : 0,
		);
	}
	update_option( 'kerf_import_pages', $record, false );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE CHECK STEP: WHAT EACH OTHER PAGE BECOMES
// ═══════════════════════════════════════════════════════════════════════════════
//
// The free plugin's import pauses after staging, before anything is written,
// and shows what it found (kerf_import_check()); this adds the design's other
// pages to that step — what each file becomes, its title and address. The
// answers come back with the import (`kerf_page`, the context's `choices`).

/**
 * What the check step shows for each file.
 *
 * @param array[] $plan From kerf_import_pages_plan().
 * @return array[]
 */
function kerf_import_review_rows( $plan ) {
	$rows = array();
	foreach ( $plan as $item ) {
		$slug     = kerf_import_page_slug( $item['file'] );
		$existing = get_page_by_path( $slug, OBJECT, array( 'page' ) );
		$rows[]   = array(
			'file'    => $item['file'],
			'type'    => $item['type'],
			'marked'  => (bool) $item['marked'],
			'title'   => kerf_import_page_title( $item['file'] ),
			'slug'    => $slug,
			'taken'   => $existing && ! kerf_shell_is_mockup_post( $existing ) && '' !== trim( $existing->post_content ),
			'header'  => in_array( 'header', $item['notes'], true ),
			'changed' => in_array( 'changed', $item['notes'], true ),
		);
	}
	return $rows;
}

/**
 * What a file can become, as the check step offers it: the design of any of
 * WordPress's own pages when it is marked; when it looks like one but is not
 * marked, that it is not used yet; and always a page, or left out.
 *
 * @param string $type   From kerf_import_classify_page().
 * @param bool   $marked kerf_import_page_is_marked().
 * @return array<string,string> value => label.
 */
function kerf_pages_type_options( $type, $marked ) {
	$types   = kerf_shell_page_types();
	$options = array();
	if ( isset( $types[ $type ] ) && $marked ) {
		foreach ( $types as $key => $info ) {
			/* translators: %s: kind of page, e.g. "Blog" or "Single post". */
			$options[ $key ] = sprintf( __( 'The design of: %s', 'kerf-pro' ), $info['label'] );
		}
	} elseif ( isset( $types[ $type ] ) ) {
		$options[ $type ] = __( 'Not used — mark it up first (Kerf → Inner pages)', 'kerf-pro' );
	}
	$options['page:ordinary'] = __( 'A page', 'kerf-pro' );
	$options['skip']          = __( 'Leave out', 'kerf-pro' );
	return $options;
}

/**
 * The design's other pages, in the import's check step: one row per file —
 * what it becomes, and for a page its title and address.
 *
 * @param array $result From kerf_import_check(): `source` (html, staging).
 */
function kerf_pages_check_section( $result ) {
	$staging = isset( $result['source']['staging'] ) ? $result['source']['staging'] : null;
	if ( ! $staging || empty( $staging['pages'] ) ) {
		return;
	}

	if ( ! kerf_pro_licensed() ) {
		echo kerf_ui_note( __( 'Your Kerf Pro licence has expired: renew it to import the design\'s other pages too.', 'kerf-pro' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		return;
	}

	$plan = kerf_import_pages_plan( $staging['pages'], kerf_import_split( kerf_mc_extract_body( $result['source']['html'] ) ) );
	$rows = kerf_import_review_rows( $plan );
	?>
	<section class="kerf-panel kerf-site-only">
		<div class="kerf-panel__head">
			<h2><?php esc_html_e( 'Your design\'s other pages', 'kerf-pro' ); ?></h2>
			<p><?php esc_html_e( 'Each file becomes a page of the site, or the design of WordPress\'s own pages — the blog, a post, search results. Links between them keep working, whatever you call them here.', 'kerf-pro' ); ?></p>
		</div>
		<div class="kerf-panel__body">
			<label class="kerf-switch">
				<input type="checkbox" name="kerf_do_pages" value="1" checked>
				<span class="kerf-switch__text">
					<strong><?php esc_html_e( 'Import these pages too', 'kerf-pro' ); ?></strong>
					<span><?php esc_html_e( 'Off: only the home page is imported, and these are left out.', 'kerf-pro' ); ?></span>
				</span>
			</label>
			<table class="kerf-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'File', 'kerf-pro' ); ?></th>
						<th><?php esc_html_e( 'Becomes', 'kerf-pro' ); ?></th>
						<th><?php esc_html_e( 'Page title', 'kerf-pro' ); ?></th>
						<th><?php esc_html_e( 'Address', 'kerf-pro' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $rows as $row ) :
						$name    = 'kerf_page[' . $row['file'] . ']';
						$options = kerf_pages_type_options( $row['type'], $row['marked'] );
						$chosen  = 'skip' === $row['type'] ? 'skip' : $row['type'];
						?>
						<tr>
							<td>
								<code class="kerf-chip"><?php echo esc_html( $row['file'] ); ?></code>
								<?php if ( $row['header'] ) : ?>
									<p class="kerf-help"><?php esc_html_e( 'Its header differs from the home page\'s; the site uses the home page\'s.', 'kerf-pro' ); ?></p>
								<?php endif; ?>
								<?php if ( $row['changed'] ) : ?>
									<p class="kerf-help"><?php esc_html_e( 'Changed beyond its markers since the last import.', 'kerf-pro' ); ?></p>
								<?php endif; ?>
							</td>
							<td>
								<select name="<?php echo esc_attr( $name . '[type]' ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: file name. */ __( 'What %s becomes', 'kerf-pro' ), $row['file'] ) ); ?>">
									<?php foreach ( $options as $value => $label ) : ?>
										<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $chosen, $value ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
								<?php
								/**
								 * More for one file of the check step, under what it becomes —
								 * AI's "Mark it with AI" (inc/kerf-pro-ai-prepare.php).
								 *
								 * @param array $row From kerf_import_review_rows().
								 */
								do_action( 'kerf_pro_pages_check_row', $row );
								?>
							</td>
							<td>
								<input type="text" name="<?php echo esc_attr( $name . '[title]' ); ?>" value="<?php echo esc_attr( $row['title'] ); ?>" aria-label="<?php esc_attr_e( 'Page title', 'kerf-pro' ); ?>">
							</td>
							<td>
								<input type="text" name="<?php echo esc_attr( $name . '[slug]' ); ?>" value="<?php echo esc_attr( $row['slug'] ); ?>" aria-label="<?php esc_attr_e( 'Address', 'kerf-pro' ); ?>">
								<?php if ( $row['taken'] ) : ?>
									<p class="kerf-help"><?php esc_html_e( 'A page written in WordPress has this address and will be left alone — choose another to import this one.', 'kerf-pro' ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</section>
	<?php
}
add_action( 'kerf_import_check_sections', 'kerf_pages_check_section' );

// ═══════════════════════════════════════════════════════════════════════════════
// THE IMPORT'S HOOKS
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * What each other page becomes — the ordinary ones made now, so the home
 * page's links find them. A dry run lists them instead.
 *
 * @param array $planned { plan, actions }.
 * @param array $context { staging, parts, choices, dry_run, standalone }.
 * @return array
 */
function kerf_pages_plan_for_import( $planned, $context ) {
	$staging = $context['staging'];
	// A design for the whole site that brings no other pages — one page, or
	// its others left out — is the last import too: the record of an earlier
	// design's pages is not this one's. Kept, Make a page took an earlier
	// design's page as the model for this one's (kerf_pro_ai_page_vocabulary()),
	// and Update design listed its files. Undo puts it back.
	$forget = empty( $context['standalone'] ) && empty( $context['dry_run'] );
	if ( ! $staging || empty( $staging['pages'] ) || ! empty( $context['standalone'] ) ) {
		if ( $forget ) {
			delete_option( 'kerf_import_pages' );
		}
		return $planned;
	}
	if ( ! kerf_pro_licensed() ) {
		$planned['actions'][] = sprintf(
			/* translators: %s: list of file names. */
			__( 'Your Kerf Pro licence has expired, so the design\'s other pages were not imported: %s.', 'kerf-pro' ),
			implode( ', ', array_keys( $staging['pages'] ) )
		);
		if ( $forget ) {
			delete_option( 'kerf_import_pages' );
		}
		return $planned;
	}
	if ( empty( $_POST['kerf_do_pages'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification -- the import checked its nonce.
		if ( $forget ) {
			delete_option( 'kerf_import_pages' );
		}
		return $planned;
	}

	$plan = kerf_import_pages_plan( $staging['pages'], $context['parts'] );
	if ( $context['choices'] ) {
		$plan = kerf_import_pages_apply_choices( $plan, $context['choices'] );
	}
	if ( empty( $context['dry_run'] ) ) {
		kerf_import_pages_reserve( $plan );
	} else {
		$kinds = array();
		foreach ( $plan as $item ) {
			$kinds[] = $item['file'] . ' (' . ( 'page:ordinary' === $item['type'] ? __( 'page', 'kerf-pro' ) : $item['type'] . ( $item['marked'] ? '' : ', ' . __( 'not marked up', 'kerf-pro' ) ) ) . ')';
		}
		$planned['actions'][] = sprintf(
			/* translators: %s: list of files. */
			__( 'Other pages in the ZIP: %s.', 'kerf-pro' ),
			implode( ', ', $kinds )
		);
	}
	$planned['plan'] = $plan;
	return $planned;
}
add_filter( 'kerf_import_other_pages', 'kerf_pages_plan_for_import', 10, 2 );

/**
 * Their own stylesheets and scripts (kerf_import_pages_merge_assets()).
 *
 * @param array  $merged { assets, added }.
 * @param array  $plan
 * @param string $base_url
 * @param array  $staging
 * @return array
 */
function kerf_pages_assets_for_import( $merged, $plan, $base_url, $staging ) {
	return kerf_import_pages_merge_assets( $merged['assets'], $plan, $base_url, $staging );
}
add_filter( 'kerf_import_other_pages_assets', 'kerf_pages_assets_for_import', 10, 4 );

/**
 * Write them, and remember what each was, for Kerf → Inner pages.
 *
 * @param array $written { actions, report, unresolved }.
 * @param array $plan
 * @param array $context { manifest, options, create_missing }.
 * @return array
 */
function kerf_pages_write_for_import( $written, $plan, $context ) {
	$done = kerf_import_pages_write( $plan, $context );
	kerf_import_pages_record( $plan );
	return $done;
}
add_filter( 'kerf_import_other_pages_written', 'kerf_pages_write_for_import', 10, 3 );
