<?php
/**
 * Updating a site from a newer version of its mockup, section by section.
 *
 * A designer changes the pricing section, or the header, and sends the folder
 * again. Re-importing replaced everything that was ticked, wholesale: every
 * edit made in WordPress since — a menu item renamed, a phone number fixed,
 * a paragraph rewritten — went with it, silently.
 *
 * So each top-level section is stamped at import (`kerfSource` on its block:
 * a key that finds it again, a hash of its markup in the mockup, a hash of
 * what was written), and an update compares the new mockup against the
 * stamps: which sections changed, which are new, which are gone — and which
 * were edited in WordPress since, whose update would replace those edits.
 * Nothing is applied that was not ticked; what is ticked by default makes the
 * site the new version — changed, new and gone sections alike — except a
 * section edited in WordPress, which never is. Kerf → Update design is the
 * screen; the new version comes as a ZIP or, for one page, pasted.
 *
 * What is a section: a top-level element of a region — the header part's,
 * the footer part's, the page's (§5.23) — keyed by tag and id, else its first
 * class (kerf_mc_sections()), through the elements it sits in when a region
 * is one wrapper (`main#content > section.hero`). Content changes; what a
 * designer calls a section rarely does — and when its key does change, it is
 * found again by its own part of the key or its heading (kerf_sync_match()).
 * The wrapper is compared too, as a row of its own. A page imported before
 * stamps existed has none to compare: it can only be replaced whole, and the
 * screen says so.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHAT CAN BE UPDATED
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Everything on the site an import wrote, and where in the mockup it came
 * from.
 *
 * @return array[] Each: id, label, kind (part|page|template), file ('' = the
 *                 home page's file), region (header|footer|before|after|main),
 *                 template (the page type, for a template).
 */
function kerf_sync_targets() {
	$targets = array();
	$parts   = array(
		'header'     => array( 'header', __( 'Header', 'kerf-pro' ) ),
		'footer'     => array( 'footer', __( 'Footer', 'kerf-pro' ) ),
		'page-start' => array( 'before', __( 'Before the page frame', 'kerf-pro' ) ),
		'page-end'   => array( 'after', __( 'After the page frame', 'kerf-pro' ) ),
	);

	foreach ( $parts as $slug => $info ) {
		$post = kerf_sync_part( $slug );
		if ( $post && '' !== trim( $post->post_content ) ) {
			$targets[] = array( 'id' => $post->ID, 'label' => $info[1], 'kind' => 'part', 'file' => '', 'region' => $info[0], 'template' => '' );
		}
	}

	$home = (int) get_option( 'kerf_mockup_page' );
	if ( $home && get_post( $home ) ) {
		$targets[] = array(
			'id'       => $home,
			/* translators: %s: page title. */
			'label'    => sprintf( __( 'Page: %s', 'kerf-pro' ), get_the_title( $home ) ),
			'kind'     => 'page',
			'file'     => '',
			'region'   => 'main',
			'template' => '',
		);
	}

	$pages = get_option( 'kerf_import_pages', array() );
	foreach ( is_array( $pages ) ? $pages : array() as $file => $record ) {
		if ( ! empty( $record['page_id'] ) && 'page:ordinary' === $record['type'] && get_post( (int) $record['page_id'] ) ) {
			$targets[] = array(
				'id'       => (int) $record['page_id'],
				/* translators: %s: page title. */
				'label'    => sprintf( __( 'Page: %s', 'kerf-pro' ), get_the_title( (int) $record['page_id'] ) ),
				'kind'     => 'page',
				'file'     => (string) $file,
				'region'   => 'main',
				'template' => '',
			);
		}
	}

	$templates = get_posts( array(
		'post_type'      => 'wp_template',
		'post_status'    => array( 'publish', 'draft', 'auto-draft' ),
		'posts_per_page' => 50,
		'meta_key'       => '_kerf_source', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- the theme's templates made from a design: a few rows.
		'tax_query'      => array( array( 'taxonomy' => 'wp_theme', 'field' => 'name', 'terms' => get_stylesheet() ) ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a template is its theme's: how core finds one too.
	) );
	foreach ( $templates as $template ) {
		$source    = (string) get_post_meta( $template->ID, '_kerf_source', true );
		$targets[] = array(
			'id'       => $template->ID,
			/* translators: %s: kind of page, e.g. "Blog" or "Single post". */
			'label'    => sprintf( __( 'Template: %s', 'kerf-pro' ), $template->post_title ),
			'kind'     => 'template',
			'file'     => (string) strtok( $source, ' ' ),
			'region'   => 'main',
			'template' => $template->post_name,
		);
	}

	return $targets;
}

/**
 * The theme's template part with this slug, as a post.
 *
 * @param string $slug
 * @return WP_Post|null
 */
function kerf_sync_part( $slug ) {
	$posts = get_posts( array(
		'post_type'      => 'wp_template_part',
		'name'           => $slug,
		'post_status'    => array( 'publish', 'draft', 'auto-draft' ),
		'posts_per_page' => 1,
		'tax_query'      => array( array( 'taxonomy' => 'wp_theme', 'field' => 'name', 'terms' => get_stylesheet() ) ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a template is its theme's: how core finds one too.
	) );
	return $posts ? $posts[0] : null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHICH SECTION IS WHICH
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The row of the element(s) a region's sections sit in — not a section, but
 * compared, previewed and ticked like one.
 */
const KERF_SYNC_WRAPPER = '@wrapper';

/**
 * A key's own part: the section's tag, id or class and count, without the
 * wrappers it was keyed through (kerf_mc_section_keys()).
 *
 * @param string $key `main#content > section.hero`.
 * @return string `section.hero`.
 */
function kerf_sync_key_tail( $key ) {
	$key = (string) $key;
	$at  = strrpos( $key, ' > ' );
	return false === $at ? $key : substr( $key, $at + 3 );
}

/**
 * A key's tag: `section` for `main > section#pricing~2`.
 *
 * @param string $key
 * @return string
 */
function kerf_sync_key_tag( $key ) {
	return preg_match( '/^[^#.~]+/', kerf_sync_key_tail( $key ), $m ) ? strtolower( $m[0] ) : '';
}

/**
 * Which section on the site each section of the new version is (§9.16).
 *
 * By key first. But a key names a section through the wrappers it sits in
 * (`nav > b`), so when the designer gives a wrapper an id or a class, or adds
 * one, every key under it changes: the owner's design, whose new version gave
 * its `<nav>` an `id="nav"`, showed its brand and links twice after an update
 * — the old ones "gone from the new version", the same ones "new" — and its
 * menu's script stopped. So, second, by the section's own part of the key.
 * Third, a section whose own id or class was renamed (`section.pricing` →
 * `section#pricing`, §8.11): by its tag and the heading it opens with, when
 * exactly one section on each side has them — so an edit made to it in
 * WordPress is still seen, and it is never shown twice.
 *
 * @param string[]      $current  The site's section keys, in order.
 * @param array[]       $new      The new version's sections, in order: key, label.
 * @param callable|null $label_of A site section's label, by key — the third
 *                                rule's; it renders the section, so it is
 *                                asked only for those still unmatched.
 * @return array<string,string> New key ⇒ the site's key; each site key once.
 */
function kerf_sync_match( $current, $new, $label_of = null ) {
	$free  = array();
	$match = array();
	foreach ( (array) $current as $key ) {
		$free[ (string) $key ] = true;
	}

	$open = array();
	foreach ( (array) $new as $section ) {
		$key = (string) $section['key'];
		if ( isset( $free[ $key ] ) ) {
			$match[ $key ] = $key;
			unset( $free[ $key ] );
		} else {
			$open[] = $section;
		}
	}

	$rest = array();
	foreach ( $open as $section ) {
		$tail  = kerf_sync_key_tail( $section['key'] );
		$found = null;
		foreach ( array_keys( $free ) as $candidate ) {
			if ( kerf_sync_key_tail( (string) $candidate ) === $tail ) {
				$found = (string) $candidate;
				break;
			}
		}
		if ( null !== $found ) {
			$match[ (string) $section['key'] ] = $found;
			unset( $free[ $found ] );
		} else {
			$rest[] = $section;
		}
	}

	if ( ! $label_of || ! $rest || ! $free ) {
		return $match;
	}
	$sides = array( 'site' => array(), 'new' => array() );
	foreach ( array_keys( $free ) as $candidate ) {
		$label = trim( (string) call_user_func( $label_of, (string) $candidate ) );
		if ( '' !== $label ) {
			$sides['site'][ kerf_sync_key_tag( (string) $candidate ) . "\n" . $label ][] = (string) $candidate;
		}
	}
	foreach ( $rest as $section ) {
		$label = trim( isset( $section['label'] ) ? (string) $section['label'] : '' );
		if ( '' !== $label ) {
			$sides['new'][ kerf_sync_key_tag( $section['key'] ) . "\n" . $label ][] = (string) $section['key'];
		}
	}
	foreach ( $sides['new'] as $named => $keys ) {
		if ( 1 === count( $keys ) && isset( $sides['site'][ $named ] ) && 1 === count( $sides['site'][ $named ] ) ) {
			$match[ $keys[0] ] = $sides['site'][ $named ][0];
		}
	}
	return $match;
}

/**
 * A section on the site as a person would name it — its first heading, else
 * its opening words — read from it as it renders, the way the new version's
 * are read from its markup (kerf_mc_section_label()).
 *
 * @param array $block A parsed block.
 * @return string
 */
function kerf_sync_block_label( $block ) {
	unset( $block['attrs']['kerfSource'], $block['attrs']['kerfOnly'] );
	$html = trim( (string) render_block( $block ) );
	if ( '' === $html ) {
		return '';
	}
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div data-kerf-mc-root="1">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();
	if ( ! $doc->documentElement ) {
		return '';
	}
	foreach ( $doc->documentElement->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType && ! kerf_mc_is_asset_tag( $child ) ) {
			return kerf_mc_section_label( $child );
		}
	}
	return '';
}

/**
 * kerf_sync_match() between the sections of a list of blocks on the site and
 * the new version's, every rule on.
 *
 * @param array<string,array> $current The site's stamped blocks, by key (kerf_sync_stamped()).
 * @param array[]             $new     The new version's sections, in order: key, label.
 * @return array<string,string>
 */
function kerf_sync_match_blocks( $current, $new ) {
	return kerf_sync_match( array_keys( $current ), $new, static function ( $key ) use ( $current ) {
		return isset( $current[ $key ] ) ? kerf_sync_block_label( $current[ $key ] ) : '';
	} );
}

/**
 * Where a region's sections are, and the elements they sit in: the path to
 * the list that holds them (kerf_sync_find_list()) and the blocks on the way.
 * The kerf/frame Kerf puts round a template is not the design's, and is
 * passed over (`skip`: how many steps of the path are frames).
 *
 * @param array[] $blocks
 * @return array{path:int[]|null,chain:array[],skip:int}
 */
function kerf_sync_region_chain( $blocks ) {
	$path  = kerf_sync_find_list( $blocks );
	$chain = array();
	$skip  = 0;
	$list  = $blocks;
	foreach ( null === $path ? array() : $path as $step => $i ) {
		$block = $list[ $i ];
		if ( ! $chain && $step === $skip && 'kerf/frame' === $block['blockName'] ) {
			$skip++;
		} else {
			$chain[] = $block;
		}
		$list = $block['innerBlocks'];
	}
	return array( 'path' => $path, 'chain' => $chain, 'skip' => $skip );
}

/**
 * The elements round the sections as they render, without what is in them —
 * what the wrapper row compares and shows: `<nav id="nav">`, one to a line.
 *
 * @param array[] $chain From kerf_sync_region_chain().
 * @return string
 */
function kerf_sync_chain_preview( $chain ) {
	$lines = array();
	foreach ( $chain as $block ) {
		$block['innerBlocks']  = array();
		$block['innerContent'] = array();
		$block['innerHTML']    = '';
		$lines[]               = kerf_sync_preview_html( $block );
	}
	return implode( "\n", $lines );
}

/**
 * The elements round the sections, named as keys are: `main#content > div`.
 *
 * @param array[] $chain
 * @return string
 */
function kerf_sync_chain_name( $chain ) {
	$names = array();
	foreach ( $chain as $block ) {
		$attrs   = isset( $block['attrs'] ) ? $block['attrs'] : array();
		$tag     = isset( $attrs['tagName'] ) ? (string) $attrs['tagName'] : ( 'kerf/div' === $block['blockName'] ? 'div' : (string) $block['blockName'] );
		$class   = isset( $attrs['className'] ) ? (string) strtok( trim( (string) $attrs['className'] ) . ' ', ' ' ) : '';
		$names[] = $tag . ( ! empty( $attrs['anchor'] ) ? '#' . $attrs['anchor'] : ( '' !== $class ? '.' . $class : '' ) );
	}
	return implode( ' > ', $names );
}

/**
 * The wrapper's hash as Kerf last wrote it (`kerfSource.wrap` of the
 * sections in it, kerf_sync_wrapper_sign()); '' when it was never recorded —
 * a site imported before 0.7.0.
 *
 * @param array[] $blocks The sections' list.
 * @return string
 */
function kerf_sync_recorded_wrap( $blocks ) {
	foreach ( $blocks as $block ) {
		if ( '' !== kerf_sync_key( $block ) && isset( $block['attrs']['kerfSource']['wrap'] ) && is_string( $block['attrs']['kerfSource']['wrap'] ) ) {
			return $block['attrs']['kerfSource']['wrap'];
		}
	}
	return '';
}

/**
 * Compare one target with the same region of the new mockup.
 *
 * @param array        $target     From kerf_sync_targets().
 * @param array        $sections   kerf_mc_sections() of the new region.
 * @param array[]|null $new_blocks The new region converted (kerf_sync_convert_region()):
 *                                 for the row of the element round the sections.
 * @return array{rows:array[],stamped:bool,changes:int}
 */
function kerf_sync_compare( $target, $sections, $new_blocks = null ) {
	$post    = get_post( $target['id'] );
	$tree    = $post ? parse_blocks( (string) $post->post_content ) : array();
	$blocks  = kerf_sync_stamped( $tree );
	$current = array();
	foreach ( $blocks as $key => $block ) {
		$stamp           = $block['attrs']['kerfSource'];
		$current[ $key ] = array(
			'src'    => isset( $stamp['src'] ) ? (string) $stamp['src'] : '',
			'edited' => ! empty( $stamp['out'] ) && kerf_sync_block_hash( $block ) !== $stamp['out'],
		);
	}
	$match = kerf_sync_match_blocks( $blocks, $sections );

	$rows    = array();
	$changes = 0;
	foreach ( $sections as $section ) {
		$key  = $section['key'];
		$here = isset( $match[ $key ] ) ? $match[ $key ] : null;
		if ( null === $here ) {
			$status = 'new';
		} elseif ( $current[ $here ]['src'] === $section['src'] ) {
			$status = 'unchanged';
		} else {
			$status = 'changed';
		}
		$rows[] = array(
			'key'    => $key,
			'was'    => null !== $here && $here !== $key ? $here : '',
			'label'  => $section['label'],
			'status' => $status,
			'edited' => null !== $here && $current[ $here ]['edited'],
		);
	}
	$matched = array_flip( $match );
	foreach ( $current as $key => $info ) {
		if ( ! isset( $matched[ $key ] ) ) {
			// Named by its words, as the new version's sections are.
			$rows[] = array( 'key' => $key, 'was' => '', 'label' => kerf_sync_block_label( $blocks[ $key ] ), 'status' => 'removed', 'edited' => $info['edited'] );
		}
	}

	// The element(s) the sections sit in: a `<nav>` given an id, a wrapper
	// added. Compared as they render, as the preview shows them; changed in
	// WordPress when they are no longer what Kerf wrote (`kerfSource.wrap`).
	if ( $current && null !== $new_blocks ) {
		$here  = kerf_sync_region_chain( $tree );
		$there = kerf_sync_region_chain( $new_blocks );
		if ( null !== $here['path'] && null !== $there['path'] && kerf_sync_chain_preview( $here['chain'] ) !== kerf_sync_chain_preview( $there['chain'] ) ) {
			$recorded = kerf_sync_recorded_wrap( kerf_sync_list_at( $tree, $here['path'] ) );
			$rows[]   = array(
				'key'    => KERF_SYNC_WRAPPER,
				'was'    => kerf_sync_chain_name( $here['chain'] ),
				'label'  => kerf_sync_chain_name( $there['chain'] ),
				'status' => 'changed',
				'edited' => '' !== $recorded && kerf_sync_wrapper_sign( $here['chain'] ) !== $recorded,
			);
		}
	}

	foreach ( $rows as $n => $row ) {
		$changes += 'unchanged' !== $row['status'] ? 1 : 0;
		// What is ticked by default makes the site the new version, but for
		// what was changed in WordPress since: a section the new version no
		// longer has goes too — left, it stood beside the sections that
		// replaced it.
		$rows[ $n ]['ticked'] = 'unchanged' !== $row['status'] && ! $row['edited'];
	}

	return array( 'rows' => $rows, 'stamped' => ! empty( $current ), 'changes' => $changes );
}

// ═══════════════════════════════════════════════════════════════════════════════
// APPLYING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Splice chosen sections of the new version into a list of blocks.
 *
 * Changed: the block is replaced where it stands — the site's section the new
 * one was matched with (kerf_sync_match()), under whatever key it had. Removed:
 * it goes. New: it goes after the section it follows in the new mockup, or
 * before the first section when nothing precedes it. Everything else in the
 * list — sections not chosen, blocks added in WordPress — stays exactly as it
 * is, but for a section matched under another key: it takes the new version's
 * key, so the stamps name what the site now is.
 *
 * @param array[]                   $blocks Current blocks.
 * @param array[]                   $new    The new region's blocks, stamped.
 * @param string[]                  $chosen Keys to apply: the new version's, or
 *                                          the site's for a section it no longer has.
 * @param array<string,string>|null $match  New key ⇒ site key; null to match by
 *                                          key and by the key's own part.
 * @return array[]
 */
function kerf_sync_splice( $blocks, $new, $chosen, $match = null ) {
	$key_of = 'kerf_sync_key';

	$new_by_key = array();
	$new_order  = array();
	foreach ( $new as $block ) {
		$key = $key_of( $block );
		if ( '' !== $key ) {
			$new_by_key[ $key ] = $block;
			$new_order[]        = $key;
		}
	}

	if ( null === $match ) {
		$current = array();
		foreach ( $blocks as $block ) {
			if ( '' !== $key_of( $block ) ) {
				$current[] = $key_of( $block );
			}
		}
		$match = kerf_sync_match( $current, array_map( static function ( $key ) {
			return array( 'key' => $key, 'label' => '' );
		}, $new_order ) );
	}
	$matched = array_flip( $match );

	$find = function ( $list, $key ) use ( $key_of ) {
		foreach ( $list as $i => $block ) {
			if ( $key === $key_of( $block ) ) {
				return $i;
			}
		}
		return -1;
	};

	$chosen = array_map( 'strval', (array) $chosen );
	foreach ( $chosen as $key ) {
		if ( isset( $new_by_key[ $key ] ) ) {
			$at = isset( $match[ $key ] ) ? $find( $blocks, $match[ $key ] ) : -1;
			if ( $at >= 0 ) {
				$blocks[ $at ] = $new_by_key[ $key ];
			}
		} elseif ( ! isset( $matched[ $key ] ) ) {
			// The new version no longer has it (the wrapper row is not a section).
			$at = $find( $blocks, $key );
			if ( $at >= 0 ) {
				array_splice( $blocks, $at, 1 );
			}
		}
	}

	foreach ( $match as $new_key => $site_key ) {
		$at = (string) $new_key !== (string) $site_key ? $find( $blocks, (string) $site_key ) : -1;
		if ( $at >= 0 ) {
			$blocks[ $at ]['attrs']['kerfSource']['key'] = (string) $new_key;
		}
	}

	foreach ( $new_order as $n => $key ) {
		if ( ! in_array( $key, $chosen, true ) || isset( $match[ $key ] ) || $find( $blocks, $key ) >= 0 ) {
			continue;
		}
		$after = -1;
		for ( $p = $n - 1; $p >= 0 && $after < 0; $p-- ) {
			$after = $find( $blocks, $new_order[ $p ] );
		}
		if ( $after < 0 ) {
			foreach ( $blocks as $i => $block ) {
				if ( '' !== $key_of( $block ) ) {
					$after = $i - 1;
					break;
				}
			}
		}
		array_splice( $blocks, $after + 1, 0, array( $new_by_key[ $key ] ) );
	}

	return $blocks;
}

/**
 * What every section in a list records of the element(s) round it
 * (`kerfSource.wrap`, kerf_sync_wrapper_sign()) after an update: the new
 * version's when they were brought in, else what was recorded before — the
 * sections the update brought carry the new version's, and the next
 * comparison would have called the wrapper changed in WordPress.
 *
 * @param array[] $blocks The sections' list.
 * @param string  $wrap   '' when nothing was recorded.
 * @return array[]
 */
function kerf_sync_set_wrap( $blocks, $wrap ) {
	foreach ( $blocks as $i => $block ) {
		if ( '' === kerf_sync_key( $block ) ) {
			continue;
		}
		if ( '' === $wrap ) {
			unset( $blocks[ $i ]['attrs']['kerfSource']['wrap'] );
		} else {
			$blocks[ $i ]['attrs']['kerfSource']['wrap'] = $wrap;
		}
	}
	return $blocks;
}

/**
 * Bring in the new version's element(s) round the sections, with the
 * sections — spliced — in them.
 *
 * As deep as before (a `<nav>` given an id): each element takes the new
 * version's tag and attributes where it stands, keeping its List View name
 * and its lock. Deeper or shallower (a wrapper added, or gone): the outermost
 * one is replaced by the new version's elements, or by the sections
 * themselves; where the sections stood at the top, the run from the first of
 * them to the last goes inside the new element — what is before and after
 * it, a template's header and footer, stays outside.
 *
 * @param array[] $tree  The site's blocks.
 * @param array   $here  kerf_sync_region_chain( $tree ).
 * @param array[] $new   The new version's blocks.
 * @param array   $there kerf_sync_region_chain( $new ).
 * @param array[] $list  The sections, spliced.
 * @return array[] The site's blocks.
 */
function kerf_sync_rewrap( $tree, $here, $new, $there, $list ) {
	$root = array_slice( $here['path'], 0, $here['skip'] );
	$deep = array_slice( $here['path'], $here['skip'] );
	$tops = kerf_sync_list_at( $tree, $root );

	if ( $deep && count( $deep ) === count( $there['path'] ) ) {
		$tops = kerf_sync_rewrap_steps( $tops, $deep, $there['chain'] );
		return kerf_sync_with_list( kerf_sync_with_list( $tree, $root, $tops ), $here['path'], $list );
	}

	if ( $deep ) {
		array_splice( $tops, $deep[0], 1, $there['path'] ? array( kerf_sync_wrapped( $new, $there['path'], $list ) ) : $list );
	} else {
		$first = -1;
		$last  = -1;
		foreach ( $list as $n => $block ) {
			if ( '' !== kerf_sync_key( $block ) ) {
				$first = $first < 0 ? $n : $first;
				$last  = $n;
			}
		}
		$tops = $first < 0 || ! $there['path'] ? $list : array_merge(
			array_slice( $list, 0, $first ),
			array( kerf_sync_wrapped( $new, $there['path'], array_slice( $list, $first, $last - $first + 1 ) ) ),
			array_slice( $list, $last + 1 )
		);
	}
	return kerf_sync_with_list( $tree, $root, $tops );
}

/**
 * kerf_sync_rewrap() as deep as before: the elements on a path take the new
 * version's tag and attributes, one level after another.
 *
 * @param array[] $blocks
 * @param int[]   $path
 * @param array[] $chain The new version's elements, outermost first.
 * @return array[]
 */
function kerf_sync_rewrap_steps( $blocks, $path, $chain ) {
	if ( ! $path || ! $chain ) {
		return $blocks;
	}
	$i     = array_shift( $path );
	$from  = array_shift( $chain );
	$block = $blocks[ $i ];
	$attrs = isset( $from['attrs'] ) && is_array( $from['attrs'] ) ? $from['attrs'] : array();
	foreach ( array( 'metadata', 'lock' ) as $own ) {
		unset( $attrs[ $own ] );
		if ( isset( $block['attrs'][ $own ] ) ) {
			$attrs[ $own ] = $block['attrs'][ $own ];
		}
	}
	$block['blockName']   = $from['blockName'];
	$block['attrs']       = $attrs;
	$block['innerBlocks'] = kerf_sync_rewrap_steps( $block['innerBlocks'], $path, $chain );
	$blocks[ $i ]         = $block;
	return $blocks;
}

/**
 * The new version's outermost element round the sections, holding a list.
 *
 * @param array[] $new  The new version's blocks.
 * @param int[]   $path kerf_sync_region_chain( $new )['path'], not empty.
 * @param array[] $list
 * @return array
 */
function kerf_sync_wrapped( $new, $path, $list ) {
	$wrapped = kerf_sync_with_list( array( $new[ $path[0] ] ), array_merge( array( 0 ), array_slice( $path, 1 ) ), $list );
	return $wrapped[0];
}

/**
 * Apply chosen sections of the new version to one target and save it.
 *
 * @param array    $target  From kerf_sync_targets().
 * @param string   $region  The new region's HTML.
 * @param string[] $chosen  Section keys, and KERF_SYNC_WRAPPER for the element
 *                          round them; `*` replaces the whole region.
 * @param array    $context manifest, options (converter options).
 * @return array{applied:int,wrapper:bool,report:array[]}
 */
function kerf_sync_apply( $target, $region, $chosen, $context ) {
	$post = get_post( $target['id'] );
	if ( ! $post || ! $chosen ) {
		return array( 'applied' => 0, 'wrapper' => false, 'report' => array() );
	}

	$result = kerf_mc_convert_html( $region, $context['manifest'], $context['options'] + kerf_sync_convert_options( $target ) );
	// The new version's pictures get the design's descriptions where the
	// library has none (kerf_import_fill_alts()).
	kerf_import_fill_alts( $result['markup'] );
	// New details only (inc/kerf-site.php), and known to the targets after this.
	kerf_site_run_known( $result['site'] );
	kerf_site_remember( $result['site'] );
	// The header's logo goes to the home page, as an import binds it (scar 135).
	$links  = kerf_links_bind( $result['markup'], array( 'logo' => 'part' === $target['kind'] && 'header' === $target['region'] ) );
	$markup = kerf_sync_stamp_out( $links['markup'] );
	$new    = parse_blocks( $markup );
	$tree   = parse_blocks( (string) $post->post_content );
	$framed = false;
	foreach ( $tree as $block ) {
		$framed = $framed || 'kerf/frame' === $block['blockName'];
	}

	$wrapper = false;
	if ( in_array( '*', $chosen, true ) ) {
		// Imported before stamps: the region, whole — inside the frame, for a
		// template, as the import writes one.
		$content = $framed ? kerf_import_template_content( $markup ) : $markup;
		$count   = count( $result['sections'] );
	} else {
		// The sections, wherever they sit: at the top, inside the page's
		// wrapper, inside a template's frame.
		$here  = kerf_sync_region_chain( $tree );
		$there = kerf_sync_region_chain( $new );
		if ( null === $here['path'] || null === $there['path'] ) {
			return array( 'applied' => 0, 'wrapper' => false, 'report' => $result['report'] );
		}
		$site_list = kerf_sync_list_at( $tree, $here['path'] );
		// Matched as the comparison matched them, headings included: a renamed
		// section the owner ticked replaces itself, not a section beside it.
		$sections = array();
		foreach ( $result['sections'] as $section ) {
			$sections[] = array( 'key' => $section['key'], 'label' => $section['label'] );
		}
		$match   = kerf_sync_match_blocks( kerf_sync_stamped( $site_list ), $sections );
		$wrapper = in_array( KERF_SYNC_WRAPPER, $chosen, true );
		$list    = kerf_sync_splice( $site_list, kerf_sync_list_at( $new, $there['path'] ), $chosen, $match );
		$list    = kerf_sync_set_wrap( $list, $wrapper ? kerf_sync_wrapper_sign( $there['chain'] ) : kerf_sync_recorded_wrap( $site_list ) );
		$tree    = $wrapper ? kerf_sync_rewrap( $tree, $here, $new, $there, $list ) : kerf_sync_with_list( $tree, $here['path'], $list );
		$content = serialize_blocks( $tree );
		$count   = count( array_diff( $chosen, array( KERF_SYNC_WRAPPER ) ) );
	}

	// wp_slash() is mandatory (scar 1).
	wp_update_post( wp_slash( array( 'ID' => $post->ID, 'post_content' => $content ) ) );

	// The whole post is saved, so for someone without unfiltered_html every
	// inline SVG in it goes through KSES — not only the updated sections'.
	return array( 'applied' => $count, 'wrapper' => $wrapper, 'report' => array_merge( $result['report'], kerf_import_svg_loss( $content, $target['label'] ) ) );
}

/**
 * How a target's region is converted — by the update, and for its preview,
 * which must convert it the same way or show differences that are not there
 * (a header's logo is eager-loaded; the preview once said it would turn lazy).
 *
 * @param array $target From kerf_sync_targets().
 * @return array Converter options.
 */
function kerf_sync_convert_options( $target ) {
	return kerf_import_converter_options( array(
		'stamp'        => true,
		'eager_images' => 'header' === $target['region'],
		'template'     => 'template' === $target['kind'] ? $target['template'] : '',
		// Attributes that run code (Alpine, htmx…) are scripts (§5.32).
		'directives'   => kerf_user_can_add_scripts(),
		// The business's details as the design had them (§5.36).
		'site_known'   => kerf_site_run_known(),
	) );
}

/**
 * What each section will be after the update, against what it is now.
 *
 * Both are rendered by the same code — the site's block as it stands, the new
 * version's converted as the update would convert it — and a Kerf page renders
 * as the mockup's own HTML (§1). So a section nobody touched comes out line
 * for line the same, and the difference is what the designer changed, plus
 * whatever was edited in WordPress since: the update replaces that, so it is
 * worth seeing too (§8.11).
 *
 * @param array   $target     From kerf_sync_targets().
 * @param array[] $rows       kerf_sync_compare()'s: the changed ones are previewed.
 * @param array[] $new_blocks The new version's region, kerf_sync_convert_region().
 * @return array<string,array{old:string,new:string}> By row key, one tag to a
 *                                                   line; '' where a side has
 *                                                   no such section.
 */
function kerf_sync_previews( $target, $rows, $new_blocks ) {
	$post = get_post( $target['id'] );
	if ( ! $post ) {
		return array();
	}
	$tree    = parse_blocks( (string) $post->post_content );
	$new     = kerf_sync_stamped( $new_blocks );
	$current = kerf_sync_stamped( $tree );

	$out = array();
	foreach ( $rows as $row ) {
		if ( 'unchanged' === $row['status'] ) {
			continue;
		}
		$key = $row['key'];
		if ( KERF_SYNC_WRAPPER === $key ) {
			$out[ $key ] = array(
				'old' => kerf_sync_chain_preview( kerf_sync_region_chain( $tree )['chain'] ),
				'new' => kerf_sync_chain_preview( kerf_sync_region_chain( $new_blocks )['chain'] ),
			);
			continue;
		}
		// The site's side under the key it has there, for a section the new
		// version names otherwise.
		$here        = '' !== $row['was'] ? $row['was'] : $key;
		$out[ $key ] = array(
			'old' => 'new' !== $row['status'] && isset( $current[ $here ] ) ? kerf_sync_preview_html( $current[ $here ] ) : '',
			'new' => 'removed' !== $row['status'] && isset( $new[ $key ] ) ? kerf_sync_preview_html( $new[ $key ] ) : '',
		);
	}
	return $out;
}

/**
 * A target's region of the new version, converted as the update converts it
 * (kerf_sync_convert_options(), scar 71) and its links bound — for the
 * comparison's wrapper row and its previews. Its pictures are the new
 * version's staged files: the preview names pictures by file, and the
 * library copies are only made when the update is applied.
 *
 * @param array  $target  From kerf_sync_targets().
 * @param string $region  The new version's markup for it.
 * @param array  $staging The new version (kerf_sync_handle_post()).
 * @return array[] Parsed blocks.
 */
function kerf_sync_convert_region( $target, $region, $staging ) {
	$converted = kerf_mc_convert_html( $region, array(), array(
		'staging_url' => $staging['base_url'],
		'base_rel'    => $staging['base_rel'],
		'base_url'    => kerf_sync_paste_base( $staging ),
	) + kerf_sync_convert_options( $target ) );
	$links = kerf_links_bind( $converted['markup'], array( 'logo' => 'part' === $target['kind'] && 'header' === $target['region'] ) );
	return parse_blocks( $links['markup'] );
}

/**
 * A section rendered for comparison, one tag to a line.
 *
 * Pictures are named by file: the site's are media-library copies and the new
 * version's are still in its staged folder, so their URLs never match, and
 * the srcset and sizes WordPress generates for a library picture are left out.
 * A home-page-only section is shown wherever it is (kerfOnly, §5.23) — this is
 * about its markup.
 *
 * @param array $block A parsed block.
 * @return string
 */
function kerf_sync_preview_html( $block ) {
	unset( $block['attrs']['kerfSource'], $block['attrs']['kerfOnly'] );

	$html = (string) render_block( $block );
	$html = (string) preg_replace( '/\s(?:srcset|sizes)="[^"]*"/i', '', $html );
	// A form Kerf sends is signed with the second it was drawn
	// (kerf_forms_action_url()): drawn a second apart, it is the same form.
	$html = (string) preg_replace( '/\b(kerf_[ts]=)[0-9a-f]+/i', '$1', $html );

	$by_name = static function ( $url ) {
		$path = (string) strtok( html_entity_decode( $url ), '?#' );
		if ( ! preg_match( '#\.(?:jpe?g|png|gif|webp|avif|svg|mp4|webm|ogv)$#i', $path ) ) {
			return $url;
		}
		// hero.jpg, hero-1024x683.jpg and hero-scaled.jpg are one picture.
		$name = (string) preg_replace( '/-(?:\d+x\d+|scaled)(?=\.[a-z0-9]+$)/i', '', basename( $path ) );

		// A library copy is named by what it is. WordPress stores a second
		// hero.jpg — another design's — as hero-2.jpg, and the preview showed a
		// changed picture that was the same one. Matched by content to the new
		// version's own file (the import's hash, KERF_IMPORT_HASH_META).
		$names = kerf_sync_picture_names();
		if ( $names && ! kerf_assets_storage_for_url( $path ) ) {
			$base = (string) preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $path );
			foreach ( array_unique( array( $base, (string) preg_replace( '/-scaled(?=\.[a-z0-9]+$)/i', '', $base ), (string) preg_replace( '/(?<!-scaled)(\.[a-z0-9]+)$/i', '-scaled$1', $base ) ) ) as $candidate ) {
				$id = attachment_url_to_postid( $candidate );
				$hash = $id ? (string) get_post_meta( $id, KERF_IMPORT_HASH_META, true ) : '';
				if ( '' !== $hash && isset( $names[ $hash ] ) ) {
					return $names[ $hash ];
				}
			}
		}
		return $name;
	};
	$html = (string) preg_replace_callback( '/\b(src|href|poster|data-[\w-]+)="([^"]*)"/i', static function ( $m ) use ( $by_name ) {
		return $m[1] . '="' . $by_name( $m[2] ) . '"';
	}, $html );
	$html = (string) preg_replace_callback( '/url\(\s*([\'"]?)([^\'")]+)\1\s*\)/i', static function ( $m ) use ( $by_name ) {
		return 'url(' . $by_name( $m[2] ) . ')';
	}, $html );

	return trim( (string) preg_replace( '/>\s*</', ">\n<", trim( $html ) ) );
}

/**
 * The new version's pictures by content: their md5 (as the import hashes
 * them) to their file name in its staged folder.
 *
 * @param string|null $dir The staged folder to read, or null to ask.
 * @return array<string,string>
 */
function kerf_sync_picture_names( $dir = null ) {
	static $names = array();
	if ( null !== $dir ) {
		$names = array();
		if ( '' !== $dir && is_dir( $dir ) ) {
			foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) ) as $file ) {
				if ( preg_match( '#\.(?:jpe?g|png|gif|webp|avif|svg)$#i', $file->getFilename() ) ) {
					$names[ md5_file( $file->getPathname() ) ] = $file->getFilename();
				}
			}
		}
	}
	return $names;
}

/**
 * One section's before and after, side by side, in a collapsed <details>.
 *
 * @param array{old:string,new:string} $preview From kerf_sync_previews().
 * @return string Markup; wp_text_diff() escapes what it prints.
 */
function kerf_sync_render_diff( $preview ) {
	// Past this, a line-by-line diff of a section is not something to read.
	$limit = 800;
	if ( substr_count( $preview['old'], "\n" ) > $limit || substr_count( $preview['new'], "\n" ) > $limit ) {
		return '<p class="description">' . esc_html__( 'Too long to show here — compare the two files instead.', 'kerf-pro' ) . '</p>';
	}

	// A new section, or one the new version no longer has: shown whole. A
	// diff against nothing is the same lines with a stray empty one beside them.
	if ( '' === $preview['old'] || '' === $preview['new'] ) {
		return '<details class="kerf-diff"><summary>' . esc_html__( 'Show the section', 'kerf-pro' ) . '</summary>'
			. '<pre class="kerf-diff__whole kerf-diff__whole--' . ( '' === $preview['old'] ? 'new' : 'gone' ) . '">'
			. esc_html( '' === $preview['old'] ? $preview['new'] : $preview['old'] ) . '</pre></details>';
	}

	// The titles go into the table as they are.
	$diff = wp_text_diff( $preview['old'], $preview['new'], array(
		'title_left'      => esc_html__( 'On the site now', 'kerf-pro' ),
		'title_right'     => esc_html__( 'After the update', 'kerf-pro' ),
		'show_split_view' => true,
	) );
	if ( '' === $diff ) {
		$diff = '<p class="description">' . esc_html__( 'No difference in the markup: only whitespace, or something the page does not show, changed.', 'kerf-pro' ) . '</p>';
	}

	return '<details class="kerf-diff"><summary>' . esc_html__( 'Show what changes', 'kerf-pro' ) . '</summary>' . kerf_sync_fold_diff( $diff ) . '</details>';
}

/**
 * Fold the long unchanged stretches of a wp_text_diff() table into one row.
 *
 * A one-word change in a 150-line footer is otherwise a page of identical
 * lines around it. Core's renderer can drop context itself, but joins what
 * is left without a mark, so two changes far apart would read as neighbours.
 * An unchanged row is one line of the table holding only `diff-context`
 * cells; a changed one can run over several (a line's own newline stays in it).
 *
 * @param string $table
 * @param int    $keep  Unchanged rows kept on each side of a change.
 * @return string
 */
function kerf_sync_fold_diff( $table, $keep = 3 ) {
	$out     = array();
	$run     = array();
	$in_body = false;
	$changed = false; // A change has been printed above the current run.

	$flush = static function ( $before_change ) use ( &$run, &$out, &$changed, $keep ) {
		$head   = $changed ? $keep : 0;
		$tail   = $before_change ? $keep : 0;
		$hidden = count( $run ) - $head - $tail;
		if ( $hidden > 1 ) {
			$out   = array_merge( $out, array_slice( $run, 0, $head ) );
			$out[] = '<tr class="kerf-diff__fold"><td colspan="2">' . esc_html( sprintf(
				/* translators: %d: number of lines. */
				_n( '⋯ %d unchanged line', '⋯ %d unchanged lines', $hidden, 'kerf-pro' ),
				$hidden
			) ) . '</td></tr>';
			$out   = array_merge( $out, $tail ? array_slice( $run, -$tail ) : array() );
		} else {
			$out = array_merge( $out, $run );
		}
		$run = array();
	};

	foreach ( explode( "\n", $table ) as $line ) {
		if ( ! $in_body ) {
			$in_body = false !== strpos( $line, '<tbody>' );
			$out[]   = $line;
			continue;
		}
		if ( '' === trim( $line ) ) {
			continue; // Between rows, a newline is nothing.
		}
		if ( 0 === strpos( $line, '<tr><td class=\'diff-context\'>' ) && false === strpos( $line, 'diff-addedline' ) && false === strpos( $line, 'diff-deletedline' ) ) {
			$run[] = $line;
			continue;
		}
		$end = false !== strpos( $line, '</tbody>' );
		if ( $run ) {
			$flush( ! $end );
		}
		$changed = $changed || ! $end;
		$out[]   = $line;
	}
	if ( $run ) {
		$flush( false );
	}

	return implode( "\n", $out );
}

/**
 * The new version's region for a target: the home page's file for the parts
 * and the home page, the target's own file otherwise. Null when the file is
 * not in the new version.
 *
 * @param array $target
 * @param array $parts  kerf_import_split() of the new home page.
 * @param array $pages  file => HTML of the new version's other pages.
 * @return string|null
 */
function kerf_sync_region( $target, $parts, $pages ) {
	if ( '' === $target['file'] ) {
		return isset( $parts[ $target['region'] ] ) ? (string) $parts[ $target['region'] ] : '';
	}
	if ( ! isset( $pages[ $target['file'] ] ) ) {
		return null;
	}
	$split = kerf_import_split( kerf_mc_extract_body( $pages[ $target['file'] ] ) );
	return (string) $split['main'];
}

/**
 * Is a template's file in the new version without its markup contract? Then
 * it is not updated: filled with nothing, it would show the designer's sample
 * posts in place of the site's (§5.25).
 *
 * @param array $target
 * @param array $pages
 * @return bool
 */
function kerf_sync_unmarked( $target, $pages ) {
	return 'template' === $target['kind'] && isset( $pages[ $target['file'] ] )
		&& ! kerf_import_page_is_marked( $pages[ $target['file'] ] );
}

/**
 * Which of the home page's stylesheets and scripts differ in the new version:
 * by the path the designer knows them by, and by what is in them.
 *
 * @param array  $staging The new version, staged.
 * @param string $html    Its home page.
 * @return array{changed:string[],added:string[],removed:string[]}
 */
function kerf_sync_assets_diff( $staging, $html ) {
	$index = function ( $assets ) {
		$out = array();
		foreach ( $assets as $asset ) {
			if ( ! empty( $asset['only'] ) ) {
				continue; // Another page's; compared with that page.
			}
			if ( 'file' === $asset['kind'] ) {
				$name = kerf_shell_asset_label( (string) $asset['src'] );
				$path = kerf_sync_asset_path( (string) $asset['src'] );
				$out[ $asset['type'] . ' ' . $name ] = array( $name, $path ? md5_file( $path ) : (string) $asset['src'] );
			} else {
				$hash                                          = md5( (string) $asset['content'] );
				$out[ $asset['type'] . ' inline ' . $hash ] = array(
					/* translators: %s: "css" or "js". */
					sprintf( __( 'an inline %s block', 'kerf-pro' ), $asset['type'] ),
					$hash,
				);
			}
		}
		return $out;
	};

	$now  = $index( kerf_assets_get() );
	$next = $index( kerf_sync_new_assets( array( 'html' => $html ) + $staging ) );
	$diff = array( 'changed' => array(), 'added' => array(), 'removed' => array() );

	foreach ( $next as $id => $asset ) {
		if ( ! isset( $now[ $id ] ) ) {
			$diff['added'][] = $asset[0];
		} elseif ( $now[ $id ][1] !== $asset[1] ) {
			$diff['changed'][] = $asset[0];
		}
	}
	foreach ( $now as $id => $asset ) {
		if ( ! isset( $next[ $id ] ) ) {
			$diff['removed'][] = $asset[0];
		}
	}

	return $diff;
}

/**
 * A new version pasted, in the shape of a staged one.
 *
 * A pasted page has no folder. What it names by a relative path — a design's
 * `css/style.css`, `img/hero.jpg` — is looked for in the folder of the design
 * the site has now (kerf_assets_design()), as a section pasted in the editor
 * finds its pictures there (kerf_rest_convert()): whoever pastes the page they
 * changed has usually changed nothing else. What is not there is named before
 * anything is applied (kerf_sync_paste_missing()). Given the address where the
 * page is online, its files load from there instead, as on import.
 *
 * `slug` stays empty whatever the folder, so that cancelling the comparison
 * (kerf_import_discard()) never removes the site's own files with it.
 *
 * @param string $html
 * @param string $base_url Where the page is online; '' for none.
 * @return array
 */
function kerf_sync_paste_staging( $html, $base_url ) {
	$staging = array(
		'dir'        => '',
		'url'        => '',
		'slug'       => '',
		'files'      => 0,
		'html'       => (string) $html,
		'entry_name' => '',
		'base_url'   => '',
		'base_rel'   => '',
		'pages'      => array(),
		'pasted'     => true,
		'paste_base' => (string) $base_url,
	);
	$last    = '' === $staging['paste_base'] ? kerf_assets_design( 0 )['staging'] : array();
	$storage = kerf_assets_storage_for_url( isset( $last['url'] ) ? $last['url'] : '' );
	$uploads = wp_upload_dir();
	if ( empty( $last['url'] ) || ! $storage || ! empty( $uploads['error'] ) ) {
		return $staging;
	}

	$base = trailingslashit( (string) $last['url'] );
	$rel  = isset( $last['rel'] ) ? trim( (string) $last['rel'], '/' ) : '';
	$root = '' !== $rel && substr( $base, -strlen( $rel ) - 1 ) === $rel . '/' ? substr( $base, 0, -strlen( $rel ) - 1 ) : $base;
	$from = trailingslashit( $uploads['baseurl'] );
	$dir  = 0 === strpos( $root, $from ) ? wp_normalize_path( trailingslashit( $uploads['basedir'] ) . rawurldecode( substr( $root, strlen( $from ) ) ) ) : '';
	// A staged design's folder, and only that.
	if ( '' === $dir || false !== strpos( $dir, '..' ) || 0 !== strpos( $dir, wp_normalize_path( $storage['dir'] ) ) || ! is_dir( $dir ) ) {
		return $staging;
	}
	return array_merge( $staging, array( 'dir' => trailingslashit( $dir ), 'url' => $root, 'base_url' => $base, 'base_rel' => $rel ) );
}

/**
 * Where a pasted new version is online; '' for a ZIP, or a paste without.
 *
 * @param array $staging
 * @return string
 */
function kerf_sync_paste_base( $staging ) {
	return ! empty( $staging['paste_base'] ) ? (string) $staging['paste_base'] : '';
}

/**
 * The new version's stylesheets and scripts, as the update would keep them: a
 * ZIP's at their staged copies, a pasted page's in the site's design folder
 * or where the page is online. A file named by a relative path that is in
 * neither is left out, as an import leaves out a file its ZIP lacks (scar 82):
 * linked, it was a 404 at a mangled address — and here it would have taken
 * the place of the site's working stylesheet.
 *
 * @param array $staging The new version.
 * @return array[]
 */
function kerf_sync_new_assets( $staging ) {
	$assets = kerf_assets_extract( (string) $staging['html'], kerf_sync_paste_base( $staging ) );
	if ( '' !== (string) $staging['dir'] ) {
		return kerf_import_localize_assets( $assets, $staging );
	}
	foreach ( $assets as $i => $asset ) {
		if ( 'file' === $asset['kind'] && ! preg_match( '#^(?:[a-z][a-z0-9+.-]*:|//)#i', (string) $asset['src'] ) ) {
			unset( $assets[ $i ] );
		}
	}
	return array_values( $assets );
}

/**
 * What a pasted new version names by a relative path that the site does not
 * have: missing after the update, and only its ZIP can bring them.
 *
 * @param array $staging
 * @return string[]
 */
function kerf_sync_paste_missing( $staging ) {
	if ( empty( $staging['pasted'] ) || '' !== kerf_sync_paste_base( $staging ) ) {
		return array();
	}
	$dir   = (string) $staging['dir'];
	$files = array();
	if ( '' !== $dir ) {
		foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ) ) as $file ) {
			$files[] = ltrim( substr( wp_normalize_path( $file->getPathname() ), strlen( wp_normalize_path( $dir ) ) ), '/' );
		}
	}
	$refs = kerf_preflight_references( array( 'index.html' => (string) $staging['html'] ), $files, (string) $staging['base_rel'], $dir );
	return array_values( array_unique( array_merge( $refs['missing'], $refs['case'] ) ) );
}

/**
 * A staged file's path on disk, from its URL; '' for anything else.
 *
 * @param string $src
 * @return string
 */
function kerf_sync_asset_path( $src ) {
	$uploads = wp_upload_dir();
	$base    = trailingslashit( $uploads['baseurl'] );
	if ( 0 !== strpos( $src, $base ) ) {
		return '';
	}
	$path = trailingslashit( $uploads['basedir'] ) . (string) strtok( substr( $src, strlen( $base ) ), '?' );
	return is_file( $path ) ? $path : '';
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE SCREEN
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Add Kerf → Update design.
 */
function kerf_sync_menu() {
	add_submenu_page(
		'kerf',
		__( 'Update the design', 'kerf-pro' ),
		__( 'Update design', 'kerf-pro' ),
		'edit_theme_options',
		'kerf-update',
		'kerf_sync_render_page'
	);
}
add_action( 'admin_menu', 'kerf_sync_menu', 12 );

/**
 * Handle the screen's three steps: compare, apply, cancel.
 *
 * @return array|null
 */
function kerf_sync_handle_post() {
	if ( empty( $_POST['kerf_sync_action'] ) ) {
		return null;
	}
	if ( ! kerf_user_can_import() ) {
		return array( 'error' => __( 'You do not have permission to update the site from a mockup.', 'kerf-pro' ) );
	}
	if ( ! isset( $_POST['kerf_sync_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_sync_nonce'] ) ), 'kerf_sync' ) ) {
		return array( 'error' => __( 'Security check failed. Reload the page and try again.', 'kerf-pro' ) );
	}

	$action = sanitize_key( wp_unslash( $_POST['kerf_sync_action'] ) );
	$token  = isset( $_POST['kerf_pending'] ) ? sanitize_key( wp_unslash( $_POST['kerf_pending'] ) ) : '';

	if ( 'cancel' === $action ) {
		$pending = '' !== $token ? kerf_import_pending_take( $token, 'sync' ) : null;
		if ( $pending ) {
			kerf_import_discard( $pending['staging'] ?? null );
		}
		return array( 'cancelled' => true );
	}

	if ( 'compare' === $action ) {
		// A ZIP, or one page pasted — as the import reads either.
		$source = kerf_import_read_source();
		if ( ! empty( $source['error'] ) ) {
			return array( 'error' => $source['error'] );
		}
		if ( empty( $source['staging'] ) ) {
			$base_url          = isset( $_POST['kerf_base_url'] ) ? esc_url_raw( wp_unslash( $_POST['kerf_base_url'] ) ) : '';
			$source['staging'] = kerf_sync_paste_staging( $source['html'], $base_url );
			$source['actions'] = array( __( 'Read the pasted HTML.', 'kerf-pro' ) );
		}
		return kerf_sync_compare_all( $source );
	}

	if ( 'apply' === $action ) {
		$pending = '' !== $token ? kerf_import_pending_take( $token, 'sync' ) : null;
		if ( ! $pending ) {
			return array( 'error' => __( 'That comparison has expired or was already applied. Upload the new version again.', 'kerf-pro' ) );
		}
		// Recorded, so it can be undone (inc/kerf-undo.php).
		kerf_undo_begin();
		$applied = kerf_sync_apply_all( $pending );
		kerf_undo_finish( __( 'Update from mockup', 'kerf-pro' ) );
		return $applied;
	}

	return null;
}

/**
 * Compare every target with the new version, and park the version for the
 * apply step.
 *
 * @param array $source From kerf_import_read_source().
 * @return array
 */
function kerf_sync_compare_all( $source ) {
	if ( ! kerf_user_can_import() ) {
		return array( 'error' => __( 'You do not have permission to update the site from a mockup.', 'kerf-pro' ) );
	}
	$staging = $source['staging'];
	$parts   = kerf_import_split( kerf_mc_extract_body( $staging['html'] ) );
	$pages   = isset( $staging['pages'] ) ? (array) $staging['pages'] : array();
	$compare = array();
	// The new version's home page file means the home page, as an import's
	// does (kerf_links_home_file(), scar 134); a pasted page keeps the site's.
	if ( ! empty( $staging['entry_name'] ) ) {
		kerf_links_home_file( (string) $staging['entry_name'] );
	}

	// The new version's pictures by content, so a library copy WordPress
	// renamed is shown by the designer's name (kerf_sync_preview_html()).
	kerf_sync_picture_names( (string) $staging['dir'] );

	foreach ( kerf_sync_targets() as $target ) {
		$region = kerf_sync_region( $target, $parts, $pages );
		$entry  = array( 'target' => $target, 'missing' => null === $region, 'unmarked' => kerf_sync_unmarked( $target, $pages ) );
		if ( null !== $region && ! $entry['unmarked'] ) {
			$new    = kerf_sync_convert_region( $target, $region, $staging );
			$entry += kerf_sync_compare( $target, kerf_mc_sections( $region ), $new );
			// What each change looks like, for the owner to read before ticking.
			$entry['previews'] = $entry['stamped'] ? kerf_sync_previews( $target, $entry['rows'], $new ) : array();
		}
		$compare[] = $entry;
	}

	return array(
		'compare'     => $compare,
		'assets'      => kerf_sync_assets_diff( $staging, $staging['html'] ),
		// The background pictures the owner changed, for the screen's check
		// against the new stylesheets (inc/kerf-backgrounds.php).
		'backgrounds' => function_exists( 'kerf_bg_update_data' ) ? kerf_bg_update_data( $staging ) : null,
		// A pasted version's files the site does not have.
		'missing'     => kerf_sync_paste_missing( $staging ),
		'pasted'      => ! empty( $staging['pasted'] ),
		'token'       => kerf_import_pending_save( $staging, $source['actions'], 'sync' ),
	);
}

/**
 * Apply what was ticked.
 *
 * @param array $pending The parked version.
 * @return array
 */
function kerf_sync_apply_all( $pending ) {
	if ( ! kerf_user_can_import() ) {
		return array( 'error' => __( 'You do not have permission to update the site from a mockup.', 'kerf-pro' ) );
	}
	$staging = $pending['staging'];
	$parts   = kerf_import_split( kerf_mc_extract_body( $staging['html'] ) );
	$pages   = isset( $staging['pages'] ) ? (array) $staging['pages'] : array();
	if ( ! empty( $staging['entry_name'] ) ) {
		kerf_links_home_file( (string) $staging['entry_name'] );
		update_option( KERF_LINKS_HOME_FILE_OPTION, kerf_links_home_file(), true );
	}
	// Verified in kerf_sync_handle_post(); each key is cleaned where it is used
	// (below), and only ever compared with the update's own.
	$chosen  = isset( $_POST['kerf_sync'] ) && is_array( $_POST['kerf_sync'] ) ? wp_unslash( $_POST['kerf_sync'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- see above.
	$whole   = isset( $_POST['kerf_sync_whole'] ) && is_array( $_POST['kerf_sync_whole'] ) ? wp_unslash( $_POST['kerf_sync_whole'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- see above.
	$actions = array();
	$report  = array();

	// New pictures into the library; unchanged ones are found by their hash
	// and reused (§5.22). A pasted page has none of its own: its pictures are
	// the site's design folder's, if it has one.
	$media   = '' !== (string) $staging['dir'] ? kerf_import_media( $staging['dir'] ) : array( 'items' => array() );
	$context = array(
		'manifest' => array( 'media' => $media['items'] ),
		'options'  => kerf_import_converter_options( array(
			'base_url'    => kerf_sync_paste_base( $staging ),
			'staging_url' => $staging['base_url'],
			'base_rel'    => $staging['base_rel'],
			'directives'  => kerf_user_can_add_scripts(),
		) ),
	);

	// The pictures owners chose on single blocks, before sections are
	// replaced: a ticked section takes the new version's picture with it.
	$own_before = function_exists( 'kerf_bg_overrides' ) ? wp_list_pluck( kerf_bg_overrides(), 'where', 'id' ) : array();

	foreach ( kerf_sync_targets() as $target ) {
		$keys = array();
		if ( ! empty( $whole[ $target['id'] ] ) ) {
			$keys = array( '*' );
		} elseif ( ! empty( $chosen[ $target['id'] ] ) && is_array( $chosen[ $target['id'] ] ) ) {
			$keys = array_map( 'sanitize_text_field', $chosen[ $target['id'] ] );
		}
		$region = $keys && ! kerf_sync_unmarked( $target, $pages ) ? kerf_sync_region( $target, $parts, $pages ) : null;
		if ( null === $region ) {
			continue;
		}

		$done   = kerf_sync_apply( $target, $region, $keys, $context );
		$report = array_merge( $report, $done['report'] );
		if ( $done['applied'] && $done['wrapper'] ) {
			$actions[] = sprintf(
				/* translators: 1: what was updated, 2: number of sections. */
				_n( '%1$s: updated %2$d section, and the element around the sections.', '%1$s: updated %2$d sections, and the element around them.', $done['applied'], 'kerf-pro' ),
				$target['label'],
				$done['applied']
			);
		} elseif ( $done['applied'] ) {
			$actions[] = sprintf(
				/* translators: 1: what was updated, 2: number of sections. */
				_n( '%1$s: updated %2$d section.', '%1$s: updated %2$d sections.', $done['applied'], 'kerf-pro' ),
				$target['label'],
				$done['applied']
			);
		} elseif ( $done['wrapper'] ) {
			$actions[] = sprintf(
				/* translators: %s: what was updated, e.g. "Header". */
				__( '%s: updated the element around its sections.', 'kerf-pro' ),
				$target['label']
			);
		}

		// The page frame travels with the header, as it does on import.
		if ( 'header' === $target['region'] ) {
			$frame = array();
			foreach ( $parts['frame'] as $shell ) {
				$converted = kerf_mc_convert_html( $shell, $context['manifest'], $context['options'] );
				$blocks    = parse_blocks( $converted['markup'] );
				if ( isset( $blocks[0]['blockName'] ) && 'kerf/div' === $blocks[0]['blockName'] ) {
					$frame[] = $blocks[0]['attrs'];
				}
			}
			update_option( KERF_FRAME_OPTION, $frame, false );
		}
	}

	if ( ! empty( $_POST['kerf_sync_assets'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$assets = kerf_sync_new_assets( $staging );

		// Other pages' own assets, where those pages are.
		$plan = array();
		foreach ( (array) get_option( 'kerf_import_pages', array() ) as $file => $record ) {
			if ( isset( $pages[ $file ] ) ) {
				$plan[] = array( 'file' => $file, 'html' => $pages[ $file ], 'type' => $record['type'], 'marked' => ! empty( $record['marked'] ), 'page_id' => isset( $record['page_id'] ) ? (int) $record['page_id'] : 0, 'notes' => array() );
			}
		}
		if ( $plan ) {
			$merged = kerf_import_pages_merge_assets( $assets, $plan, '', $staging );
			$assets = $merged['assets'];
		}

		// Scripts only from someone who may add them (§5.32).
		$gate = kerf_assets_for_user( $assets );
		// What a page was given or had added in WordPress stays its own.
		kerf_assets_save( kerf_pro_page_assets_carry( $gate['assets'] ) );
		update_option( 'kerf_assets_version', (string) time(), false );
		$doc_dropped              = array();
		$body_attrs               = kerf_mc_extract_body_attributes( $staging['html'] );
		$body_attrs['attributes'] = kerf_directives_document_attributes( $body_attrs['attributes'], $doc_dropped );
		update_option( KERF_BODY_OPTION, $body_attrs, false );
		update_option( KERF_HTML_OPTION, kerf_directives_document_attributes( kerf_mc_extract_html_attributes( $staging['html'] ), $doc_dropped ), false );
		if ( $doc_dropped ) {
			$report[] = array(
				'category' => 'dropped',
				'message'  => sprintf(
					/* translators: %s: attribute names. */
					__( 'Left out of the page\'s <html> and <body>, because they run code and only someone who may add scripts can import them: %s.', 'kerf-pro' ),
					implode( ', ', $doc_dropped )
				),
			);
		}
		$actions[] = kerf_user_can_add_scripts()
			? __( 'Updated the stylesheets and scripts, and the page\'s own attributes, to the new version.', 'kerf-pro' )
			: __( 'Updated the stylesheets, and the page\'s own attributes, to the new version. The scripts were kept as they were.', 'kerf-pro' );
		if ( $gate['withheld'] ) {
			$report[] = array( 'category' => 'dropped', 'message' => kerf_assets_withheld_message( $gate ) );
		}
	}

	// The owner's background pictures (inc/kerf-backgrounds.php): taken back
	// where they chose the new design's, refreshed elsewhere; and said where a
	// replaced section took one with it.
	if ( function_exists( 'kerf_bg_update_apply' ) ) {
		// phpcs:disable WordPress.Security.NonceVerification -- verified in kerf_sync_handle_post().
		$assets_live = ! empty( $_POST['kerf_sync_assets'] );
		$handled     = array_merge(
			isset( $_POST['kerf_bg_take'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['kerf_bg_take'] ) ) : array(),
			isset( $_POST['kerf_bg_refresh'] ) && $assets_live ? array_keys( (array) wp_unslash( $_POST['kerf_bg_refresh'] ) ) : array() // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- its keys only, compared with the update's own.
		);
		// phpcs:enable WordPress.Security.NonceVerification
		$actions   = array_merge( $actions, kerf_bg_update_apply( $assets_live ) );
		$own_after = wp_list_pluck( kerf_bg_overrides(), 'where', 'id' );
		foreach ( array_diff_key( $own_before, $own_after ) as $id => $where ) {
			if ( 0 === strpos( (string) $id, 'block:' ) && ! in_array( $id, $handled, true ) ) {
				$actions[] = sprintf(
					/* translators: %s: a page or part, e.g. "Page: About". */
					__( '%s: a section you updated had a background picture you chose; it now shows the new version\'s. Choose yours again in the editor if you want it back.', 'kerf-pro' ),
					$where
				);
			}
		}
	}

	if ( ! $actions ) {
		kerf_import_discard( $staging );
		$actions[] = __( 'Nothing was ticked, so nothing changed.', 'kerf-pro' );
	} elseif ( empty( $staging['pasted'] ) ) {
		// A pasted version brought no folder: the design's stays where it was.
		update_option( 'kerf_last_staging', array( 'url' => $staging['base_url'], 'rel' => $staging['base_rel'] ), false );
	}

	return array( 'applied' => true, 'actions' => $actions, 'report' => $report );
}

/**
 * Render Kerf → Update design: upload, compare and choose, done.
 */
function kerf_sync_render_page() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to update the site from a mockup.', 'kerf-pro' ) );
	}

	$title = __( 'Update the design', 'kerf-pro' );

	if ( ! kerf_user_can_import() ) {
		kerf_ui_open( $title );
		echo kerf_ui_note( __( 'Updating a design adds its stylesheets and scripts to your site. WordPress lets only users who may add code do this. On a network, that is the network\'s super admin. If your host has turned off adding code, nobody can update a design.', 'kerf-pro' ), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		kerf_ui_close();
		return;
	}

	// A lapsed licence keeps everything an update made, not the tool.
	if ( ! kerf_pro_licensed() ) {
		kerf_ui_open( $title );
		kerf_pro_renew_notice();
		kerf_ui_close();
		return;
	}

	// The update writes the Kerf theme's parts and templates.
	if ( ! kerf_theme_active() ) {
		kerf_ui_open( $title );
		kerf_theme_required_notice();
		kerf_ui_close();
		return;
	}

	$result    = kerf_sync_handle_post();
	$comparing = ! empty( $result['compare'] ) || ( isset( $result['compare'] ) && isset( $result['token'] ) );
	$step      = $comparing ? 2 : ( ! empty( $result['applied'] ) ? 3 : 1 );

	kerf_ui_open( $title, array(
		'lede' => 1 === $step ? __( 'Your design changed — a section, the header, the stylesheet? Bring in the new version. Kerf shows what changed, section by section, and updates only what you tick. Anything edited in WordPress since is pointed out, and never replaced unless you say so.', 'kerf-pro' ) : '',
	) );
	kerf_ui_steps( array( __( 'Upload', 'kerf-pro' ), __( 'Compare and choose', 'kerf-pro' ), __( 'Done', 'kerf-pro' ) ), $step, __( 'Updating the design', 'kerf-pro' ) );

	if ( ! empty( $result['error'] ) ) {
		echo kerf_ui_note( $result['error'], 'bad' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}
	if ( ! empty( $result['cancelled'] ) ) {
		echo kerf_ui_note( __( 'Update cancelled. Nothing changed, and the uploaded files were removed.', 'kerf-pro' ), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}

	if ( ! empty( $result['applied'] ) ) {
		?>
		<section class="kerf-panel kerf-gap-bottom">
			<div class="kerf-panel__head">
				<h2><?php esc_html_e( 'Your design is updated', 'kerf-pro' ); ?></h2>
			</div>
			<div class="kerf-panel__body">
				<ul class="kerf-actions">
					<?php foreach ( $result['actions'] as $action ) : ?>
						<li><?php echo esc_html( $action ); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<div class="kerf-panel__foot">
				<a class="kerf-btn kerf-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener"><?php echo kerf_ui_icon( 'external' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'View the site', 'kerf-pro' ); ?></a>
				<a class="kerf-btn kerf-btn--quiet" href="<?php echo esc_url( admin_url( 'admin.php?page=kerf' ) ); ?>"><?php esc_html_e( 'Dashboard', 'kerf-pro' ); ?></a>
			</div>
		</section>
		<?php
	}

	if ( $comparing ) {
		kerf_sync_render_compare( $result );
		kerf_ui_working();
		kerf_ui_close();
		return;
	}

	if ( 1 === $step ) {
		?>
		<form method="post" enctype="multipart/form-data" class="kerf-panel" data-working="<?php esc_attr_e( 'Comparing the new version with your site…', 'kerf-pro' ); ?>">
			<?php wp_nonce_field( 'kerf_sync', 'kerf_sync_nonce' ); ?>
			<input type="hidden" name="kerf_sync_action" value="compare">
			<input type="hidden" name="kerf_source" value="zip">
			<div class="kerf-panel__head">
				<h2><?php esc_html_e( 'The new version', 'kerf-pro' ); ?></h2>
				<p><?php esc_html_e( 'The same design with its changes: its folder as a ZIP, or the page\'s HTML pasted. Comparing changes nothing on the site.', 'kerf-pro' ); ?></p>
			</div>
			<div class="kerf-panel__body">
				<?php // The import's switch, drawn the same and run by the same script (kerf-admin.js). ?>
				<div class="kerf-source-switch" role="group" aria-label="<?php esc_attr_e( 'Where the new version comes from', 'kerf-pro' ); ?>">
					<button type="button" data-source="zip" aria-pressed="true" aria-controls="kerf-source-zip"><?php echo kerf_ui_icon( 'file' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'A ZIP file', 'kerf-pro' ); ?></button>
					<button type="button" data-source="paste" aria-pressed="false" aria-controls="kerf-source-paste"><?php echo kerf_ui_icon( 'paste' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Pasted HTML', 'kerf-pro' ); ?></button>
				</div>

				<div id="kerf-source-zip">
					<?php kerf_ui_drop( 'kerf_zip', __( 'Drop the new version\'s ZIP here', 'kerf-pro' ) ); ?>
				</div>

				<div id="kerf-source-paste" class="kerf-paste" hidden>
					<div class="kerf-field">
						<label class="kerf-label" for="kerf_html"><?php esc_html_e( 'The page\'s new HTML', 'kerf-pro' ); ?></label>
						<textarea name="kerf_html" id="kerf_html" rows="12" placeholder="&lt;!DOCTYPE html&gt;&#10;&lt;html&gt;…"></textarea>
						<p class="kerf-help"><?php esc_html_e( 'For a design of one page — what an AI tool gives you as one HTML file. Files it names by a relative path (css/style.css, img/hero.jpg) are taken from the design the site has now; a file that is new needs the ZIP.', 'kerf-pro' ); ?></p>
					</div>
					<div class="kerf-field">
						<label class="kerf-label" for="kerf_base_url"><?php esc_html_e( 'Where the page is online', 'kerf-pro' ); ?> <span class="kerf-optional"><?php esc_html_e( '(optional)', 'kerf-pro' ); ?></span></label>
						<input type="url" name="kerf_base_url" id="kerf_base_url" placeholder="https://preview.example.com/home.html">
						<p class="kerf-help"><?php esc_html_e( 'Its relative links and files are then loaded from there.', 'kerf-pro' ); ?></p>
					</div>
				</div>
			</div>
			<div class="kerf-panel__foot">
				<button type="submit" class="kerf-btn kerf-btn--primary kerf-btn--lg" data-needs-source><?php esc_html_e( 'Compare with this site', 'kerf-pro' ); ?></button>
				<p class="kerf-help"><?php esc_html_e( 'One section only? Select it in the editor, open the Kerf sidebar, paste its new HTML under "Convert HTML" and choose "Replace the selected block".', 'kerf-pro' ); ?></p>
			</div>
		</form>
		<?php
	}

	// The last import or update, undoable (inc/kerf-undo.php).
	echo '<div class="kerf-gap-top">';
	kerf_undo_render();
	echo '</div>';

	kerf_ui_working();
	kerf_ui_close();
}

/**
 * The comparison: one panel per part, page and template, what changed in
 * each, ticked unless it was edited in WordPress.
 *
 * @param array $result From kerf_sync_compare_all().
 */
function kerf_sync_render_compare( $result ) {
	$badges = array(
		'changed'   => array( __( 'Changed', 'kerf-pro' ), 'warn' ),
		'new'       => array( __( 'New', 'kerf-pro' ), 'ok' ),
		'removed'   => array( __( 'Gone from the new version', 'kerf-pro' ), 'bad' ),
		'unchanged' => array( __( 'Unchanged', 'kerf-pro' ), 'quiet' ),
	);

	echo '<form method="post" class="kerf-stack kerf-sync" data-working="' . esc_attr__( 'Updating your site…', 'kerf-pro' ) . '">';
	wp_nonce_field( 'kerf_sync', 'kerf_sync_nonce' );
	printf( '<input type="hidden" name="kerf_pending" value="%s">', esc_attr( $result['token'] ) );

	// A pasted version's files the site does not have (kerf_sync_paste_missing()).
	if ( ! empty( $result['missing'] ) ) {
		echo '<section class="kerf-panel"><div class="kerf-panel__body">';
		echo kerf_ui_note( __( 'The pasted HTML names these files by a relative path, and the site does not have them: after the update they are missing. Upload the design as a ZIP to bring them.', 'kerf-pro' ), 'warn' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
		echo '<div class="kerf-check__items">';
		foreach ( array_slice( (array) $result['missing'], 0, 20 ) as $file ) {
			echo '<code class="kerf-chip">' . esc_html( $file ) . '</code>';
		}
		echo '</div></div></section>';
	}

	$anything  = false;
	$unchanged = array();
	foreach ( $result['compare'] as $entry ) {
		$target = $entry['target'];

		// Listed once, at the end: the ones that need a decision come first.
		if ( ! $entry['missing'] && ! $entry['unmarked'] && ! empty( $entry['stamped'] ) && empty( $entry['changes'] ) ) {
			$unchanged[] = $target['label'];
			continue;
		}

		echo '<section class="kerf-panel"><div class="kerf-panel__head"><h2>' . esc_html( $target['label'] ) . '</h2></div><div class="kerf-panel__body">';

		if ( $entry['missing'] ) {
			echo '<p class="kerf-help">' . esc_html( sprintf(
				/* translators: %s: a file of the mockup, e.g. "blog.html". */
				__( '%s is not in the new version; this is left as it is.', 'kerf-pro' ),
				$target['file']
			) ) . '</p></div></section>';
			continue;
		}

		if ( $entry['unmarked'] ) {
			echo '<p class="kerf-help">' . esc_html( sprintf(
				/* translators: %s: a file of the mockup, e.g. "blog.html". */
				__( '%s in the new version is not marked up, so it cannot fill with your posts; this template is left as it is. Mark it up (Kerf → Inner pages → Design your own) and upload again.', 'kerf-pro' ),
				$target['file']
			) ) . '</p></div></section>';
			continue;
		}

		if ( ! $entry['stamped'] ) {
			// Imported before sections were recorded.
			$anything = true;
			echo '<label class="kerf-switch"><input type="checkbox" name="kerf_sync_whole[' . (int) $target['id'] . ']" value="1"><span class="kerf-switch__text"><strong>'
				. esc_html__( 'Replace it all with the new version', 'kerf-pro' ) . '</strong><span>'
				. esc_html__( 'It was imported before Kerf recorded sections, so it cannot be updated one section at a time — anything edited in WordPress since is replaced.', 'kerf-pro' )
				. '</span></span></label></div></section>';
			continue;
		}

		$anything = true;
		echo '<table class="kerf-table"><tbody>';
		foreach ( $entry['rows'] as $row ) {
			if ( 'unchanged' === $row['status'] ) {
				continue;
			}
			// Ticked as kerf_sync_compare() says: what makes the site the new
			// version, but for what was changed in WordPress since.
			$ticked = ! empty( $row['ticked'] );
			if ( KERF_SYNC_WRAPPER === $row['key'] ) {
				$label = __( 'The element around these sections', 'kerf-pro' );
				$where = ( '' !== $row['was'] ? $row['was'] : __( '(none)', 'kerf-pro' ) ) . ' → ' . ( '' !== $row['label'] ? $row['label'] : __( '(none)', 'kerf-pro' ) );
			} else {
				$label = '' !== $row['label'] ? $row['label'] : $row['key'];
				// Found again under another name (kerf_sync_match()).
				$where = '' !== $row['was'] ? $row['was'] . ' → ' . $row['key'] : $row['key'];
			}
			echo '<tr><td class="kerf-table__narrow"><input type="checkbox" name="kerf_sync[' . (int) $target['id'] . '][]" value="' . esc_attr( $row['key'] ) . '"' . checked( $ticked, true, false ) . ' aria-label="' . esc_attr( sprintf( /* translators: %s: a section's name. */ __( 'Update %s', 'kerf-pro' ), $label ) ) . '"></td>';
			echo '<td><span class="kerf-link-text">' . esc_html( $label ) . '</span><span class="kerf-link-href">' . esc_html( $where ) . '</span></td>';
			echo '<td class="kerf-table__narrow">' . kerf_ui_pill( $badges[ $row['status'] ][0], $badges[ $row['status'] ][1] ) . '</td>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			echo '<td>' . ( $row['edited']
				? '<span class="kerf-help kerf-undo__changed">' . esc_html__( 'Edited in WordPress since the import — updating replaces those edits.', 'kerf-pro' ) . '</span>'
				: '' ) . '</td></tr>';

			$preview = isset( $entry['previews'][ $row['key'] ] ) ? $entry['previews'][ $row['key'] ] : null;
			if ( $preview ) {
				echo '<tr class="kerf-sync__diff"><td></td><td colspan="3">' . kerf_sync_render_diff( $preview ) . '</td></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_text_diff() escapes both sides.
			}
		}
		echo '</tbody></table></div></section>';
	}

	if ( $unchanged ) {
		echo kerf_ui_note( sprintf( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			/* translators: %s: list of parts, pages and templates, e.g. "Header, Footer". */
			__( 'Unchanged: %s.', 'kerf-pro' ),
			implode( ', ', $unchanged )
		), 'ok' );
	}

	$assets = $result['assets'];
	echo '<section class="kerf-panel"><div class="kerf-panel__head"><h2>' . esc_html__( 'Stylesheets and scripts', 'kerf-pro' ) . '</h2></div><div class="kerf-panel__body">';
	if ( $assets['changed'] || $assets['added'] || $assets['removed'] ) {
		$anything = true;
		$lines    = array();
		foreach ( array( 'changed' => __( 'changed', 'kerf-pro' ), 'added' => __( 'new', 'kerf-pro' ), 'removed' => __( 'no longer linked', 'kerf-pro' ) ) as $key => $word ) {
			if ( $assets[ $key ] ) {
				$lines[] = $word . ': ' . implode( ', ', $assets[ $key ] );
			}
		}
		echo '<label class="kerf-switch"><input type="checkbox" name="kerf_sync_assets" value="1" checked><span class="kerf-switch__text"><strong>'
			. esc_html__( 'Update them', 'kerf-pro' ) . '</strong><span>'
			. esc_html( sprintf(
				/* translators: %s: what changed, e.g. "changed: style.css; new: an inline css block". */
				__( '%s. They style every page, so a changed section usually needs its stylesheet too.', 'kerf-pro' ),
				ucfirst( implode( '; ', $lines ) )
			) )
			. '</span></span></label>';
		if ( ! kerf_user_can_add_scripts() ) {
			echo '<p class="kerf-help">' . esc_html__( 'Stylesheets only: on this site only a user who may add unfiltered HTML (on a network, a super admin) can add or change scripts. The scripts the site has now are kept as they are.', 'kerf-pro' ) . '</p>';
		}
	} else {
		echo '<p class="kerf-help">' . esc_html__( 'Unchanged.', 'kerf-pro' ) . '</p>';
	}
	echo '</div></section>';

	// The background pictures the owner changed, checked against the new
	// stylesheets in the browser, which reads CSS the way the canvas did
	// (assets/js/kerf-sync-backgrounds.js). Without it nothing is ticked, and
	// every picture of the owner's stays.
	if ( ! empty( $result['backgrounds'] ) ) {
		echo '<section class="kerf-panel"><div class="kerf-panel__head"><h2>' . esc_html__( 'Background pictures you changed', 'kerf-pro' ) . '</h2></div><div class="kerf-panel__body">';
		printf(
			'<div class="kerf-bg-check" data-kerf-bg-check="%s"><p class="kerf-help">%s</p></div>',
			esc_attr( wp_json_encode( $result['backgrounds'] ) ),
			esc_html__( 'Checking them against the new version…', 'kerf-pro' )
		);
		echo '</div></section>';
	}

	if ( ! $anything ) {
		echo kerf_ui_note( __( 'The site already matches this version of the design.', 'kerf-pro' ), 'ok' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}

	echo '<div class="kerf-actionbar">';
	if ( $anything ) {
		echo '<button type="submit" name="kerf_sync_action" value="apply" class="kerf-btn kerf-btn--primary kerf-btn--lg">' . esc_html__( 'Update what is ticked', 'kerf-pro' ) . '</button>';
	}
	echo '<button type="submit" name="kerf_sync_action" value="cancel" class="kerf-btn kerf-btn--quiet kerf-btn--lg" data-no-working>' . esc_html__( 'Cancel', 'kerf-pro' ) . '</button>';
	if ( $anything ) {
		echo '<p class="kerf-help kerf-actionbar__end">' . esc_html__( 'You can undo the update afterwards.', 'kerf-pro' ) . '</p>';
	}
	echo '</div></form>';
}
