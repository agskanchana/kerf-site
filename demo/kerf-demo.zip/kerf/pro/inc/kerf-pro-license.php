<?php
/**
 * Whether Kerf Pro's tools are on.
 *
 * Asked by every Pro entry point — a screen, a panel's request, an import
 * option — and never by anything that renders a page: whatever Pro made keeps
 * showing without a licence (CLAUDE.md §8.14). Freemius answers where it runs
 * (kerf_fs(), functions.php); a copy that runs without it — the repository's
 * working copies, the live demo — has the tools on.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Are Pro's tools on — the site's licence active (Freemius)?
 *
 * @return bool
 */
function kerf_pro_licensed() {
	$licensed = function_exists( 'kerf_fs' ) ? kerf_fs()->can_use_premium_code() : true;

	/**
	 * Filter whether Kerf Pro's tools are on.
	 *
	 * @param bool $licensed
	 */
	return (bool) apply_filters( 'kerf_pro_licensed', $licensed );
}

/**
 * The notice a Pro screen shows instead of its tools without an active
 * licence: what made it keeps working; the tool waits for the licence.
 */
function kerf_pro_renew_notice() {
	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html__( 'Your Kerf licence is not active on this site. Everything Kerf made keeps working; activate your licence under Kerf → Account to use this tool again.', 'kerf-pro' )
	);
}

/**
 * The Pro badge in every Kerf screen's header (kerf_ui_open()), while the
 * licence is active.
 *
 * @param bool $pro
 * @return bool
 */
function kerf_pro_ui_badge( $pro ) {
	return $pro || kerf_pro_licensed();
}
add_filter( 'kerf_ui_pro_active', 'kerf_pro_ui_badge' );
