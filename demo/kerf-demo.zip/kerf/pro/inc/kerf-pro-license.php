<?php
/**
 * Whether Kerf Pro's tools are on.
 *
 * Asked by every Pro entry point — a screen, a panel's request, an import
 * option — and never by anything that renders a page: whatever Pro made keeps
 * showing when a licence lapses (CLAUDE.md §8.14). Freemius answers from
 * step 4 of the plan; until then the tools are on.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Are Pro's tools on — an active licence (Freemius, §8.14 step 4)?
 *
 * @return bool
 */
function kerf_pro_licensed() {
	/**
	 * Filter whether Kerf Pro's tools are on.
	 *
	 * @param bool $licensed
	 */
	return (bool) apply_filters( 'kerf_pro_licensed', true );
}

/**
 * The notice a Pro screen shows instead of its tools when the licence has
 * lapsed: what made it keeps working; the tool waits for a renewal.
 */
function kerf_pro_renew_notice() {
	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html__( 'Your Kerf Pro licence has expired. Everything Pro made keeps working on your site; renew to use this tool again.', 'kerf-pro' )
	);
}

/**
 * The Pro badge in every Kerf screen's header (kerf_ui_open()), while the
 * licence is active.
 *
 * @param bool $pro
 * @return bool
 */
function kerf_pro_ui_badge( $pro ) {
	return $pro || kerf_pro_licensed();
}
add_filter( 'kerf_ui_pro_active', 'kerf_pro_ui_badge' );
