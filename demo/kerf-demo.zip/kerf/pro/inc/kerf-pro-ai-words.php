<?php
/**
 * The owner's words for a page, from whatever they have them in.
 *
 * A page's words arrive as a Word document, text copied from Word or Google
 * Docs, a web page's markup, a Markdown file or plain notes. Sent to the model
 * as a textarea's plain text they lost their shape: a list copied from Word is
 * paragraphs of "·" and tabs, a table is words in a row, and the model could
 * only guess which line was a heading. Whatever they came as, they become
 * Markdown here — headings, paragraphs, lists (numbered or not, nested), tables,
 * links, bold and italic, quotes — which the owner sees and can change before
 * anything is sent, and which the model reads as the structure it is.
 *
 * No AI here: this reads files and markup, on the site. Kerf Pro's, for the
 * editor's AI panel (assets/js/kerf-ai-editor.js).
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** A file of words, in bytes. */
const KERF_PRO_WORDS_FILE = 10 * MB_IN_BYTES;

/** A part of a Word document, unpacked, in bytes: past it, it is no document of words. */
const KERF_PRO_WORDS_PART = 20 * MB_IN_BYTES;

/** Markup pasted, in bytes. */
const KERF_PRO_WORDS_HTML = 4 * MB_IN_BYTES;

// ═══════════════════════════════════════════════════════════════════════════════
// FROM MARKUP
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Markup as Markdown: what Word, Google Docs or a browser put on the
 * clipboard, a web page, a design's section.
 *
 * Word does not write a list as a list: each item is a paragraph,
 * `<p class=MsoListParagraph style='mso-list:l0 level1 lfo1'>`, its bullet or
 * number a span marked `mso-list:Ignore` inside conditional comments. Google
 * Docs wraps the whole paste in a `<b style="font-weight:normal">` and writes
 * bold as a span's `font-weight:700`, a nested list as a `<ul>` directly in its
 * `<ul>`. Each is read for what it shows.
 *
 * @param string $html
 * @return string
 */
function kerf_pro_words_from_html( $html ) {
	$html = (string) $html;
	if ( '' === trim( $html ) ) {
		return '';
	}
	// Word's downlevel conditionals, which libxml reads as text, and its
	// namespaced empty paragraphs.
	$html = (string) preg_replace( '/<!\[(?:if\s[^\]]*|endif)\]>/i', '', $html );
	$html = (string) preg_replace( '#</?o:p\b[^>]*>#i', '', $html );

	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML(
		'<?xml encoding="utf-8"?><div>' . kerf_mc_extract_body( $html ) . '</div>',
		LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET
	);
	libxml_clear_errors();
	if ( ! $doc->documentElement ) {
		return '';
	}

	$lines = kerf_pro_words_blocks( $doc->documentElement, 0 );
	return kerf_pro_words_tidy( implode( "\n", $lines ) );
}

/** Elements whose content is not words. */
const KERF_PRO_WORDS_SKIP = array( 'script', 'style', 'template', 'noscript', 'svg', 'iframe', 'object', 'embed', 'canvas', 'head', 'title', 'meta', 'link', 'button', 'select', 'input', 'textarea', 'video', 'audio', 'map' );

/** Elements that make blocks of their own. */
const KERF_PRO_WORDS_BLOCK = array( 'address', 'article', 'aside', 'blockquote', 'center', 'dd', 'details', 'dialog', 'div', 'dl', 'dt', 'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hgroup', 'hr', 'li', 'main', 'nav', 'ol', 'p', 'pre', 'section', 'summary', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr', 'ul' );

/**
 * A container's blocks, as Markdown lines (blocks separated by an empty line).
 *
 * @param DOMNode $node
 * @param int     $depth Lists it stands in.
 * @return string[]
 */
function kerf_pro_words_blocks( $node, $depth ) {
	$lines  = array();
	$inline = '';
	$run    = array(); // Word's list paragraphs, level => number.
	$list   = '';      // …and which of its lists they are.

	$flush = static function () use ( &$lines, &$inline ) {
		$text = kerf_pro_words_line( $inline );
		if ( '' !== $text ) {
			$lines[] = $text;
			$lines[] = '';
		}
		$inline = '';
	};

	foreach ( iterator_to_array( $node->childNodes ) as $child ) {
		if ( XML_TEXT_NODE === $child->nodeType || XML_CDATA_SECTION_NODE === $child->nodeType ) {
			$inline .= kerf_pro_words_text( $child->nodeValue );
			continue;
		}
		if ( XML_ELEMENT_NODE !== $child->nodeType ) {
			continue;
		}
		$tag = strtolower( $child->nodeName );
		if ( in_array( $tag, KERF_PRO_WORDS_SKIP, true ) || kerf_pro_words_hidden( $child ) ) {
			continue;
		}

		// A paragraph of one of Word's lists.
		$item = kerf_pro_words_word_item( $child );
		if ( $item ) {
			if ( '' !== trim( $inline ) ) {
				$flush();
			}
			// Another list right after: its own numbers, and a line between.
			if ( $run && $item['list'] !== $list ) {
				$run     = array();
				$lines[] = '';
			}
			$list  = $item['list'];
			$level = $item['level'];
			foreach ( array_keys( $run ) as $deeper ) {
				if ( $deeper > $level ) {
					unset( $run[ $deeper ] );
				}
			}
			$run[ $level ] = isset( $run[ $level ] ) ? $run[ $level ] + 1 : 1;
			$lines[]       = str_repeat( '   ', $depth + $level - 1 ) . ( $item['ordered'] ? $run[ $level ] . '.' : '-' ) . ' ' . $item['text'];
			continue;
		}
		if ( $run ) {
			$run     = array();
			$lines[] = '';
		}

		if ( ! in_array( $tag, KERF_PRO_WORDS_BLOCK, true ) && ! kerf_pro_words_holds_blocks( $child ) ) {
			$inline .= kerf_pro_words_inline( $child );
			continue;
		}
		$flush();

		if ( preg_match( '/^h([1-6])$/', $tag, $m ) ) {
			$text = kerf_pro_words_line( kerf_pro_words_inline( $child, true ) );
			if ( '' !== $text ) {
				$lines[] = str_repeat( '#', (int) $m[1] ) . ' ' . $text;
				$lines[] = '';
			}
		} elseif ( 'ul' === $tag || 'ol' === $tag ) {
			$lines   = array_merge( $lines, kerf_pro_words_list( $child, $depth ) );
			$lines[] = '';
		} elseif ( 'table' === $tag ) {
			$lines   = array_merge( $lines, kerf_pro_words_table( $child ) );
			$lines[] = '';
		} elseif ( 'blockquote' === $tag ) {
			foreach ( kerf_pro_words_blocks( $child, 0 ) as $line ) {
				$lines[] = '' === $line ? '>' : '> ' . $line;
			}
			$lines[] = '';
		} elseif ( 'pre' === $tag ) {
			$lines[] = '```';
			$lines[] = rtrim( (string) $child->textContent );
			$lines[] = '```';
			$lines[] = '';
		} elseif ( 'hr' === $tag ) {
			$lines[] = '---';
			$lines[] = '';
		} elseif ( 'dt' === $tag || 'summary' === $tag ) {
			$text = kerf_pro_words_line( kerf_pro_words_inline( $child, true ) );
			if ( '' !== $text ) {
				$lines[] = '**' . $text . '**';
				$lines[] = '';
			}
		} elseif ( 'p' === $tag && kerf_pro_words_word_title( $child ) ) {
			$text = kerf_pro_words_line( kerf_pro_words_inline( $child, true ) );
			if ( '' !== $text ) {
				$lines[] = '# ' . $text;
				$lines[] = '';
			}
		} elseif ( 'p' === $tag && ! kerf_pro_words_holds_blocks( $child ) ) {
			$text = kerf_pro_words_line( kerf_pro_words_inline( $child ) );
			if ( '' !== $text ) {
				$lines[] = $text;
				$lines[] = '';
			}
		} else {
			// A box of blocks — a section, a cell's worth, Google Docs's wrapper.
			$lines = array_merge( $lines, kerf_pro_words_blocks( $child, $depth ) );
		}
	}
	$flush();
	return $lines;
}

/**
 * A list, and the lists inside it, indented by depth.
 *
 * @param DOMElement $list
 * @param int        $depth
 * @return string[]
 */
function kerf_pro_words_list( $list, $depth ) {
	$lines   = array();
	$ordered = 'ol' === strtolower( $list->nodeName );
	$number  = $ordered && $list->hasAttribute( 'start' ) ? max( 1, (int) $list->getAttribute( 'start' ) ) : 1;

	foreach ( iterator_to_array( $list->childNodes ) as $child ) {
		if ( XML_ELEMENT_NODE !== $child->nodeType || kerf_pro_words_hidden( $child ) ) {
			continue;
		}
		$tag = strtolower( $child->nodeName );
		// Google Docs puts a nested list straight in its list.
		if ( 'ul' === $tag || 'ol' === $tag ) {
			$lines = array_merge( $lines, kerf_pro_words_list( $child, $depth + 1 ) );
			continue;
		}
		if ( 'li' !== $tag ) {
			continue;
		}
		// Google Docs says how deep an item is, rather than nesting it.
		$level = $child->hasAttribute( 'aria-level' ) ? max( $depth, (int) $child->getAttribute( 'aria-level' ) - 1 ) : $depth;

		$first = '';
		$more  = array();
		foreach ( iterator_to_array( $child->childNodes ) as $part ) {
			$name = XML_ELEMENT_NODE === $part->nodeType ? strtolower( $part->nodeName ) : '';
			if ( 'ul' === $name || 'ol' === $name ) {
				$more = array_merge( $more, kerf_pro_words_list( $part, $level + 1 ) );
			} elseif ( '' !== $name && ( in_array( $name, KERF_PRO_WORDS_BLOCK, true ) || kerf_pro_words_holds_blocks( $part ) ) ) {
				foreach ( kerf_pro_words_blocks( $part, $level + 1 ) as $line ) {
					if ( '' === $line ) {
						continue;
					}
					if ( '' === trim( $first ) && ! $more ) {
						$first .= ( '' !== $first ? ' ' : '' ) . $line;
					} else {
						$more[] = str_repeat( '   ', $level + 1 ) . ltrim( $line );
					}
				}
			} elseif ( XML_TEXT_NODE === $part->nodeType ) {
				$first .= kerf_pro_words_text( $part->nodeValue );
			} elseif ( '' !== $name && ! in_array( $name, KERF_PRO_WORDS_SKIP, true ) ) {
				$first .= kerf_pro_words_inline( $part );
			}
		}
		$lines[] = str_repeat( '   ', $level ) . ( $ordered ? $number . '.' : '-' ) . ' ' . kerf_pro_words_line( $first );
		$lines   = array_merge( $lines, $more );
		$number++;
	}
	return $lines;
}

/**
 * A table, as a Markdown table: its first row the header.
 *
 * @param DOMElement $table
 * @return string[]
 */
function kerf_pro_words_table( $table ) {
	$rows = array();
	foreach ( $table->getElementsByTagName( 'tr' ) as $tr ) {
		// Not a nested table's rows.
		$owner = $tr->parentNode;
		while ( $owner && 'table' !== strtolower( $owner->nodeName ) ) {
			$owner = $owner->parentNode;
		}
		if ( $owner !== $table ) {
			continue;
		}
		$cells = array();
		foreach ( iterator_to_array( $tr->childNodes ) as $cell ) {
			$name = XML_ELEMENT_NODE === $cell->nodeType ? strtolower( $cell->nodeName ) : '';
			if ( 'td' !== $name && 'th' !== $name ) {
				continue;
			}
			$words   = array_filter( kerf_pro_words_blocks( $cell, 0 ), static function ( $line ) {
				return '' !== $line;
			} );
			$text    = str_replace( '|', '\\|', implode( ' <br> ', $words ) );
			$cells[] = $text;
			for ( $span = (int) $cell->getAttribute( 'colspan' ); $span > 1; $span-- ) {
				$cells[] = '';
			}
		}
		if ( $cells && '' !== trim( implode( '', $cells ) ) ) {
			$rows[] = $cells;
		}
	}
	if ( ! $rows ) {
		return array();
	}
	$width = max( array_map( 'count', $rows ) );
	$lines = array();
	foreach ( $rows as $i => $cells ) {
		$cells   = array_pad( $cells, $width, '' );
		$lines[] = '| ' . implode( ' | ', $cells ) . ' |';
		if ( 0 === $i ) {
			$lines[] = '|' . str_repeat( ' --- |', $width );
		}
	}
	return $lines;
}

/**
 * An element's words, inline: bold, italic, links, line breaks.
 *
 * @param DOMNode $node
 * @param bool    $plain No bold or italic (a heading is bold already).
 * @return string
 */
function kerf_pro_words_inline( $node, $plain = false ) {
	if ( XML_TEXT_NODE === $node->nodeType || XML_CDATA_SECTION_NODE === $node->nodeType ) {
		return kerf_pro_words_text( $node->nodeValue );
	}
	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return '';
	}
	$tag = strtolower( $node->nodeName );
	if ( in_array( $tag, KERF_PRO_WORDS_SKIP, true ) || kerf_pro_words_hidden( $node ) ) {
		return '';
	}
	if ( 'br' === $tag ) {
		return "\n";
	}
	if ( 'img' === $tag ) {
		$alt = trim( (string) $node->getAttribute( 'alt' ) );
		return '' !== $alt ? '[Picture: ' . $alt . ']' : '[Picture]';
	}
	// Word's own bullet or number, written again by the list.
	$style = strtolower( (string) $node->getAttribute( 'style' ) );
	if ( false !== strpos( preg_replace( '/\s+/', '', $style ), 'mso-list:ignore' ) ) {
		return '';
	}

	$inner = '';
	foreach ( iterator_to_array( $node->childNodes ) as $child ) {
		$inner .= kerf_pro_words_inline( $child, $plain );
	}

	if ( 'a' === $tag ) {
		$href = trim( (string) $node->getAttribute( 'href' ) );
		$text = trim( $inner );
		if ( '' === $text || '' === $href || '#' === $href[0] || preg_match( '/^\s*(?:javascript|vbscript|data):/i', $href ) ) {
			return $inner;
		}
		return kerf_pro_words_wrap( $inner, '[', '](' . str_replace( array( ' ', ')' ), array( '%20', '%29' ), $href ) . ')' );
	}
	if ( 'code' === $tag || 'kbd' === $tag ) {
		return kerf_pro_words_wrap( $inner, '`', '`' );
	}
	if ( $plain ) {
		return $inner;
	}

	$bold   = in_array( $tag, array( 'strong', 'b' ), true );
	$italic = in_array( $tag, array( 'em', 'i', 'cite', 'dfn' ), true );
	if ( preg_match( '/font-weight\s*:\s*(\w+)/', $style, $m ) ) {
		$bold = in_array( $m[1], array( 'bold', 'bolder', '600', '700', '800', '900' ), true );
	}
	if ( preg_match( '/font-style\s*:\s*(\w+)/', $style, $m ) ) {
		$italic = $italic || 'italic' === $m[1] || 'oblique' === $m[1];
	}
	if ( $bold && $italic ) {
		return kerf_pro_words_wrap( $inner, '***', '***' );
	}
	if ( $bold ) {
		return kerf_pro_words_wrap( $inner, '**', '**' );
	}
	if ( $italic ) {
		return kerf_pro_words_wrap( $inner, '*', '*' );
	}
	return $inner;
}

/**
 * Words wrapped in Markdown's marks, the spaces round them kept outside —
 * `** bold**` is no bold to Markdown.
 *
 * @param string $inner
 * @param string $open
 * @param string $close
 * @return string
 */
function kerf_pro_words_wrap( $inner, $open, $close ) {
	if ( '' === trim( $inner ) ) {
		return $inner;
	}
	preg_match( '/^(\s*)(.*?)(\s*)$/s', $inner, $m );
	// A mark already round the words (Word's bold run inside a bold span).
	if ( '**' === $open && 0 === strpos( $m[2], '**' ) && '**' === substr( $m[2], -2 ) ) {
		return $inner;
	}
	return $m[1] . $open . $m[2] . $close . $m[3];
}

/**
 * Text as it reads: runs of white space one space, a no-break space a space.
 *
 * @param string $text
 * @return string
 */
function kerf_pro_words_text( $text ) {
	return (string) preg_replace( '/[ \t\r\n\x{00A0}\x{200B}]+/u', ' ', (string) $text );
}

/**
 * A line of words: trimmed, each of its own line breaks a Markdown break.
 *
 * @param string $text
 * @return string
 */
function kerf_pro_words_line( $text ) {
	$parts = array_map( 'trim', explode( "\n", (string) $text ) );
	$parts = array_values( array_filter( $parts, static function ( $part ) {
		return '' !== $part;
	} ) );
	return implode( "  \n", $parts );
}

/**
 * Is this element a box of blocks, though its tag is inline (Google Docs's
 * `<b>` round the whole paste, a link round a card)?
 *
 * @param DOMNode $node
 * @return bool
 */
function kerf_pro_words_holds_blocks( $node ) {
	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return false;
	}
	foreach ( $node->getElementsByTagName( '*' ) as $inner ) {
		if ( in_array( strtolower( $inner->nodeName ), KERF_PRO_WORDS_BLOCK, true ) ) {
			return true;
		}
	}
	return false;
}

/**
 * Is it hidden — nothing a reader sees?
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_pro_words_hidden( $node ) {
	if ( ! $node instanceof DOMElement ) {
		return false;
	}
	if ( $node->hasAttribute( 'hidden' ) || 'true' === strtolower( (string) $node->getAttribute( 'aria-hidden' ) ) ) {
		return true;
	}
	return (bool) preg_match( '/(?:^|;)\s*(?:display\s*:\s*none|visibility\s*:\s*hidden|mso-hide\s*:\s*all)/i', (string) $node->getAttribute( 'style' ) );
}

/**
 * A paragraph of one of Word's lists: its level, whether it is numbered, its
 * words.
 *
 * @param DOMElement $node
 * @return array{list:string,level:int,ordered:bool,text:string}|null
 */
function kerf_pro_words_word_item( $node ) {
	if ( ! $node instanceof DOMElement || 'p' !== strtolower( $node->nodeName ) ) {
		return null;
	}
	$style = strtolower( (string) $node->getAttribute( 'style' ) );
	if ( ! preg_match( '/mso-list\s*:\s*l(\d+)\s+level(\d+)/', $style, $m ) ) {
		return null;
	}
	$label = '';
	foreach ( $node->getElementsByTagName( '*' ) as $inner ) {
		if ( false !== strpos( preg_replace( '/\s+/', '', strtolower( (string) $inner->getAttribute( 'style' ) ) ), 'mso-list:ignore' ) ) {
			$label = trim( kerf_pro_words_text( $inner->textContent ) );
			break;
		}
	}
	return array(
		'list'    => $m[1],
		'level'   => max( 1, min( 9, (int) $m[2] ) ),
		// "1." "a)" "iv." "(2)" — numbers and letters; "·" "o" "§" "-" — bullets.
		'ordered' => (bool) preg_match( '/^\(?[0-9a-z]{1,5}[.)]/i', $label ),
		'text'    => kerf_pro_words_line( kerf_pro_words_inline( $node ) ),
	);
}

/**
 * Word's Title paragraph, which is the document's heading.
 *
 * @param DOMElement $node
 * @return bool
 */
function kerf_pro_words_word_title( $node ) {
	return $node instanceof DOMElement && (bool) preg_match( '/(?:^|\s)MsoTitle(?:\s|$)/', (string) $node->getAttribute( 'class' ) );
}

/**
 * Markdown, tidied: no runs of empty lines, no trailing spaces but a break's.
 *
 * @param string $markdown
 * @return string
 */
function kerf_pro_words_tidy( $markdown ) {
	$markdown = str_replace( array( "\r\n", "\r" ), "\n", (string) $markdown );
	$markdown = (string) preg_replace( '/[ \t]+$/m', '', preg_replace( '/(?<! ) +\n/', "\n", $markdown ) );
	$markdown = (string) preg_replace( "/\n{3,}/", "\n\n", $markdown );
	return trim( $markdown );
}

// ═══════════════════════════════════════════════════════════════════════════════
// FROM A WORD DOCUMENT
// ═══════════════════════════════════════════════════════════════════════════════

/** WordprocessingML's namespace, and its relationships'. */
const KERF_PRO_WORDS_W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const KERF_PRO_WORDS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';

/**
 * A Word document (.docx) as Markdown.
 *
 * Read as Word means it: a paragraph's style says it is a heading (by the
 * style's name, which is "heading 1" whatever the language Word speaks), its
 * numbering says it is a list item, at which level, numbered or bulleted
 * (numbering.xml); runs say bold and italic; a hyperlink says where it goes
 * (the document's relationships). Written as Word's own clipboard markup, so
 * one reader (kerf_pro_words_from_html()) makes the Markdown.
 *
 * @param string $path The file.
 * @return string|WP_Error
 */
function kerf_pro_words_from_docx( $path ) {
	$parts = kerf_pro_words_zip( $path, array( 'word/document.xml', 'word/styles.xml', 'word/numbering.xml', 'word/_rels/document.xml.rels' ) );
	if ( is_wp_error( $parts ) ) {
		return $parts;
	}
	if ( empty( $parts['word/document.xml'] ) ) {
		return new WP_Error( 'kerf_words_docx', __( 'That file is not a Word document Kerf can read. Save it as .docx, or copy its text and paste it here.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	$read = static function ( $xml ) {
		if ( '' === (string) $xml ) {
			return null;
		}
		// "Strict Open XML", which Word saves on request, names the same
		// elements in other namespaces.
		$xml = str_replace(
			array( 'http://purl.oclc.org/ooxml/wordprocessingml/main', 'http://purl.oclc.org/ooxml/officeDocument/relationships' ),
			array( KERF_PRO_WORDS_W, KERF_PRO_WORDS_R ),
			(string) $xml
		);
		$doc = new DOMDocument();
		libxml_use_internal_errors( true );
		// Never LIBXML_NOENT: it substitutes entities, external ones too (scar 62).
		$ok = $doc->loadXML( (string) $xml, LIBXML_NONET | LIBXML_COMPACT );
		libxml_clear_errors();
		if ( ! $ok ) {
			return null;
		}
		$xpath = new DOMXPath( $doc );
		$xpath->registerNamespace( 'w', KERF_PRO_WORDS_W );
		$xpath->registerNamespace( 'r', KERF_PRO_WORDS_R );
		return $xpath;
	};

	$document = $read( $parts['word/document.xml'] );
	if ( ! $document ) {
		return new WP_Error( 'kerf_words_docx', __( 'That file is not a Word document Kerf can read. Save it as .docx, or copy its text and paste it here.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	// Styles: id => heading level.
	$headings = array();
	$styles   = $read( isset( $parts['word/styles.xml'] ) ? $parts['word/styles.xml'] : '' );
	if ( $styles ) {
		foreach ( $styles->query( '//w:style' ) as $style ) {
			$id    = $style->getAttributeNS( KERF_PRO_WORDS_W, 'styleId' );
			$names = $styles->query( 'w:name', $style );
			$name  = $names->length ? strtolower( $names->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) ) : '';
			if ( preg_match( '/^heading\s*([1-6])$/', $name, $m ) ) {
				$headings[ $id ] = (int) $m[1];
			} elseif ( 'title' === $name ) {
				$headings[ $id ] = 1;
			}
		}
	}

	// Numbering: numId => level => numbered?
	$numbered  = array();
	$numbering = $read( isset( $parts['word/numbering.xml'] ) ? $parts['word/numbering.xml'] : '' );
	if ( $numbering ) {
		$abstract = array();
		foreach ( $numbering->query( '//w:abstractNum' ) as $node ) {
			$aid = $node->getAttributeNS( KERF_PRO_WORDS_W, 'abstractNumId' );
			foreach ( $numbering->query( 'w:lvl', $node ) as $lvl ) {
				$formats = $numbering->query( 'w:numFmt', $lvl );
				$format  = $formats->length ? $formats->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) : 'decimal';
				$abstract[ $aid ][ (int) $lvl->getAttributeNS( KERF_PRO_WORDS_W, 'ilvl' ) ] = ! in_array( $format, array( 'bullet', 'none' ), true );
			}
		}
		foreach ( $numbering->query( '//w:num' ) as $node ) {
			$ids = $numbering->query( 'w:abstractNumId', $node );
			$aid = $ids->length ? $ids->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) : '';
			if ( isset( $abstract[ $aid ] ) ) {
				$numbered[ $node->getAttributeNS( KERF_PRO_WORDS_W, 'numId' ) ] = $abstract[ $aid ];
			}
		}
	}

	// Links: relationship id => address.
	$links = array();
	if ( ! empty( $parts['word/_rels/document.xml.rels'] ) ) {
		$rels = new DOMDocument();
		libxml_use_internal_errors( true );
		if ( $rels->loadXML( $parts['word/_rels/document.xml.rels'], LIBXML_NONET ) ) {
			foreach ( $rels->getElementsByTagName( 'Relationship' ) as $rel ) {
				if ( false !== strpos( (string) $rel->getAttribute( 'Type' ), '/hyperlink' ) ) {
					$links[ $rel->getAttribute( 'Id' ) ] = (string) $rel->getAttribute( 'Target' );
				}
			}
		}
		libxml_clear_errors();
	}

	$ctx  = array( 'x' => $document, 'headings' => $headings, 'numbered' => $numbered, 'links' => $links );
	$body = $document->query( '/w:document/w:body' );
	$html = $body->length ? kerf_pro_words_docx_blocks( $body->item( 0 ), $ctx ) : '';
	return kerf_pro_words_from_html( $html );
}

/**
 * A part of the document's body, as Word's clipboard markup.
 *
 * @param DOMElement $node
 * @param array      $ctx
 * @return string
 */
function kerf_pro_words_docx_blocks( $node, $ctx ) {
	$html = '';
	foreach ( iterator_to_array( $node->childNodes ) as $child ) {
		if ( XML_ELEMENT_NODE !== $child->nodeType || KERF_PRO_WORDS_W !== $child->namespaceURI ) {
			continue;
		}
		switch ( $child->localName ) {
			case 'p':
				$html .= kerf_pro_words_docx_paragraph( $child, $ctx );
				break;
			case 'tbl':
				$html .= '<table>';
				foreach ( $ctx['x']->query( 'w:tr', $child ) as $tr ) {
					$html .= '<tr>';
					foreach ( $ctx['x']->query( 'w:tc', $tr ) as $tc ) {
						$html .= '<td>' . kerf_pro_words_docx_blocks( $tc, $ctx ) . '</td>';
					}
					$html .= '</tr>';
				}
				$html .= '</table>';
				break;
			case 'sdt':
				foreach ( $ctx['x']->query( 'w:sdtContent', $child ) as $content ) {
					$html .= kerf_pro_words_docx_blocks( $content, $ctx );
				}
				break;
		}
	}
	return $html;
}

/**
 * One paragraph: a heading, a list item or words.
 *
 * @param DOMElement $p
 * @param array      $ctx
 * @return string
 */
function kerf_pro_words_docx_paragraph( $p, $ctx ) {
	$x     = $ctx['x'];
	$words = kerf_pro_words_docx_runs( $p, $ctx );

	// A text box anchored here: its paragraphs after this one (once — Word
	// writes a box twice, for itself and for older readers).
	$boxes = '';
	$seen  = array();
	foreach ( $x->query( './/w:txbxContent', $p ) as $box ) {
		$html = kerf_pro_words_docx_blocks( $box, $ctx );
		if ( '' !== $html && ! isset( $seen[ $html ] ) ) {
			$seen[ $html ] = true;
			$boxes        .= $html;
		}
	}

	if ( '' === trim( wp_strip_all_tags( str_replace( '<img', 'x<img', $words ) ) ) ) {
		return $boxes;
	}

	$style = $x->query( 'w:pPr/w:pStyle', $p );
	$id    = $style->length ? $style->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) : '';
	$level = isset( $ctx['headings'][ $id ] ) ? $ctx['headings'][ $id ] : 0;
	$lvl   = $x->query( 'w:pPr/w:outlineLvl', $p );
	if ( ! $level && $lvl->length ) {
		$outline = (int) $lvl->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' );
		$level   = $outline < 6 ? $outline + 1 : 0;
	}
	if ( $level ) {
		return '<h' . $level . '>' . $words . '</h' . $level . '>' . $boxes;
	}

	$num = $x->query( 'w:pPr/w:numPr', $p );
	if ( $num->length ) {
		$ids    = $x->query( 'w:numId', $num->item( 0 ) );
		$ilvls  = $x->query( 'w:ilvl', $num->item( 0 ) );
		$num_id = $ids->length ? $ids->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) : '';
		$ilvl   = $ilvls->length ? (int) $ilvls->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) : 0;
		// numId 0 is "no numbering".
		if ( '' !== $num_id && '0' !== $num_id ) {
			$ordered = ! empty( $ctx['numbered'][ $num_id ][ $ilvl ] );
			return '<p style="mso-list:l' . (int) $num_id . ' level' . ( $ilvl + 1 ) . ' lfo1"><span style="mso-list:Ignore">' . ( $ordered ? '1.' : '&middot;' ) . '</span>' . $words . '</p>' . $boxes;
		}
	}
	return '<p>' . $words . '</p>' . $boxes;
}

/**
 * A paragraph's runs: its words, bold, italic, links, breaks, pictures.
 *
 * @param DOMElement $node
 * @param array      $ctx
 * @return string
 */
function kerf_pro_words_docx_runs( $node, $ctx ) {
	$x    = $ctx['x'];
	$html = '';
	foreach ( iterator_to_array( $node->childNodes ) as $child ) {
		if ( XML_ELEMENT_NODE !== $child->nodeType || KERF_PRO_WORDS_W !== $child->namespaceURI ) {
			continue;
		}
		switch ( $child->localName ) {
			case 'r':
				$on = static function ( $name ) use ( $x, $child ) {
					$flags = $x->query( 'w:rPr/w:' . $name, $child );
					if ( ! $flags->length ) {
						return false;
					}
					$val = strtolower( (string) $flags->item( 0 )->getAttributeNS( KERF_PRO_WORDS_W, 'val' ) );
					return ! in_array( $val, array( '0', 'false', 'off', 'none' ), true );
				};
				$text = '';
				foreach ( iterator_to_array( $child->childNodes ) as $bit ) {
					if ( XML_ELEMENT_NODE !== $bit->nodeType ) {
						continue;
					}
					if ( 't' === $bit->localName ) {
						$text .= esc_html( $bit->textContent );
					} elseif ( 'tab' === $bit->localName ) {
						$text .= ' ';
					} elseif ( ( 'br' === $bit->localName && 'page' !== $bit->getAttributeNS( KERF_PRO_WORDS_W, 'type' ) ) || 'cr' === $bit->localName ) {
						$text .= '<br>';
					} elseif ( 'noBreakHyphen' === $bit->localName ) {
						$text .= '-';
					} elseif ( ( 'drawing' === $bit->localName || 'pict' === $bit->localName ) && ! $bit->getElementsByTagNameNS( KERF_PRO_WORDS_W, 'txbxContent' )->length ) {
						// A text box is no picture: its words follow the paragraph.
						$alt = '';
						foreach ( $bit->getElementsByTagName( 'docPr' ) as $about ) {
							$alt = trim( (string) ( $about->getAttribute( 'descr' ) ? $about->getAttribute( 'descr' ) : $about->getAttribute( 'title' ) ) );
						}
						$text .= '<img alt="' . esc_attr( $alt ) . '">';
					}
				}
				if ( $on( 'vanish' ) ) {
					break;
				}
				if ( $on( 'i' ) ) {
					$text = '<em>' . $text . '</em>';
				}
				if ( $on( 'b' ) ) {
					$text = '<strong>' . $text . '</strong>';
				}
				$html .= $text;
				break;
			case 'hyperlink':
				$rid    = $child->getAttributeNS( KERF_PRO_WORDS_R, 'id' );
				$href   = '' !== $rid && isset( $ctx['links'][ $rid ] ) ? $ctx['links'][ $rid ] : '';
				$inner  = kerf_pro_words_docx_runs( $child, $ctx );
				$html  .= '' !== $href ? '<a href="' . esc_attr( $href ) . '">' . $inner . '</a>' : $inner;
				break;
			case 'ins':
			case 'smartTag':
			case 'fldSimple':
			case 'customXml':
				$html .= kerf_pro_words_docx_runs( $child, $ctx );
				break;
			case 'sdt':
				foreach ( $x->query( 'w:sdtContent', $child ) as $content ) {
					$html .= kerf_pro_words_docx_runs( $content, $ctx );
				}
				break;
		}
	}
	// Word splits words into runs wherever a change was made: rejoin the marks.
	return (string) preg_replace( array( '#</strong><strong>#', '#</em><em>#' ), '', $html );
}

/**
 * Parts of a ZIP file, read by its own directory — no extension needed, and
 * no part unpacked past KERF_PRO_WORDS_PART, whatever its header claims: a
 * file of a few megabytes can unpack to gigabytes.
 *
 * @param string   $path
 * @param string[] $names The parts wanted.
 * @return array<string,string>|WP_Error Name => contents, for those found.
 */
function kerf_pro_words_zip( $path, $names ) {
	$bad  = new WP_Error( 'kerf_words_docx', __( 'That file is not a Word document Kerf can read. Save it as .docx, or copy its text and paste it here.', 'kerf-pro' ), array( 'status' => 400 ) );
	$size = is_readable( $path ) ? (int) filesize( $path ) : 0;
	if ( $size < 22 || $size > KERF_PRO_WORDS_FILE ) {
		return $bad;
	}
	$data = (string) file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local upload, read whole (10 MB at most).

	// The end of the central directory: in the last 64 KB and 22 bytes.
	$end = strrpos( substr( $data, -65557 ), "PK\x05\x06" );
	if ( false === $end ) {
		return $bad;
	}
	$end   += max( 0, $size - 65557 );
	$header = unpack( 'vdisk/vstart/ventries/vtotal/Vsize/Voffset', substr( $data, $end + 4, 16 ) );
	if ( ! $header || $header['offset'] + $header['size'] > $size ) {
		return $bad;
	}

	$out = array();
	$at  = (int) $header['offset'];
	for ( $i = 0; $i < (int) $header['total'] && $at + 46 <= $size; $i++ ) {
		if ( "PK\x01\x02" !== substr( $data, $at, 4 ) ) {
			return $bad;
		}
		$entry = unpack( 'vmade/vneed/vflags/vmethod/vtime/vdate/Vcrc/Vpacked/Vsize/vname/vextra/vcomment/vdisk/vinternal/Vexternal/Voffset', substr( $data, $at + 4, 42 ) );
		$name  = substr( $data, $at + 46, $entry['name'] );
		$at   += 46 + $entry['name'] + $entry['extra'] + $entry['comment'];
		if ( ! in_array( $name, $names, true ) ) {
			continue;
		}
		$local = (int) $entry['offset'];
		if ( "PK\x03\x04" !== substr( $data, $local, 4 ) ) {
			return $bad;
		}
		$lengths = unpack( 'vname/vextra', substr( $data, $local + 26, 4 ) );
		$packed  = substr( $data, $local + 30 + $lengths['name'] + $lengths['extra'], (int) $entry['packed'] );
		if ( 0 === (int) $entry['method'] ) {
			$part = $packed;
		} elseif ( 8 === (int) $entry['method'] ) {
			// The limit is gzinflate()'s own: it stops there, whatever was claimed.
			$part = @gzinflate( $packed, KERF_PRO_WORDS_PART ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- false is the answer for a broken or too large part.
		} else {
			$part = false;
		}
		if ( false === $part || strlen( $part ) > KERF_PRO_WORDS_PART ) {
			return $bad;
		}
		$out[ $name ] = $part;
	}
	return $out;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHAT CAME IN
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Text as UTF-8: a file saved by Windows in its own encoding is read as that.
 *
 * @param string $text
 * @return string
 */
function kerf_pro_words_utf8( $text ) {
	$text = (string) $text;
	if ( 0 === strncmp( $text, "\xEF\xBB\xBF", 3 ) ) {
		$text = substr( $text, 3 );
	} elseif ( 0 === strncmp( $text, "\xFF\xFE", 2 ) || 0 === strncmp( $text, "\xFE\xFF", 2 ) ) {
		$text = (string) mb_convert_encoding( substr( $text, 2 ), 'UTF-8', "\xFF" === $text[0] ? 'UTF-16LE' : 'UTF-16BE' );
	}
	if ( ! mb_check_encoding( $text, 'UTF-8' ) ) {
		$text = (string) mb_convert_encoding( $text, 'UTF-8', 'Windows-1252' );
	}
	return $text;
}

/**
 * Does text that came as text hold a web page's markup — a design's section
 * copied from a code editor, an HTML file's source?
 *
 * @param string $text
 * @return bool
 */
function kerf_pro_words_is_markup( $text ) {
	$text = ltrim( (string) $text );
	return (bool) preg_match( '/^(?:<!doctype\s+html|<(?:html|head|body|main|section|article|header|footer|div|h[1-6]|p|ul|ol|table|nav|aside|span|a|figure|blockquote)\b[^>]*>)/i', $text )
		&& (bool) preg_match( '#</(?:html|body|main|section|article|div|h[1-6]|p|ul|ol|table|li|span|a)>#i', $text );
}

/**
 * The owner's words as Markdown, from what they gave.
 *
 * @param array $input { file: { name, tmp_name, size }?, html?: string, text?: string }.
 * @return array{words:string,from:string}|WP_Error
 */
function kerf_pro_words_read( $input ) {
	if ( ! empty( $input['file']['tmp_name'] ) ) {
		$file = $input['file'];
		$name = strtolower( (string) ( isset( $file['name'] ) ? $file['name'] : '' ) );
		$ext  = pathinfo( $name, PATHINFO_EXTENSION );
		$path = (string) $file['tmp_name'];
		$size = is_readable( $path ) ? (int) filesize( $path ) : 0;
		if ( ! $size ) {
			return new WP_Error( 'kerf_words_empty', __( 'That file is empty.', 'kerf-pro' ), array( 'status' => 400 ) );
		}
		if ( $size > KERF_PRO_WORDS_FILE ) {
			/* translators: %s: a size, such as 10 MB. */
			return new WP_Error( 'kerf_words_large', sprintf( __( 'That file is larger than %s.', 'kerf-pro' ), size_format( KERF_PRO_WORDS_FILE ) ), array( 'status' => 413 ) );
		}
		if ( 'docx' === $ext ) {
			$words = kerf_pro_words_from_docx( $path );
			return is_wp_error( $words ) ? $words : array( 'words' => $words, 'from' => 'docx' );
		}
		if ( in_array( $ext, array( 'md', 'markdown', 'txt', 'text', 'html', 'htm' ), true ) ) {
			$text = kerf_pro_words_utf8( (string) file_get_contents( $path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local upload.
			if ( in_array( $ext, array( 'html', 'htm' ), true ) || ( 'txt' === $ext && kerf_pro_words_is_markup( $text ) ) ) {
				return array( 'words' => kerf_pro_words_from_html( $text ), 'from' => 'html' );
			}
			return array( 'words' => kerf_pro_words_tidy( $text ), 'from' => 'txt' === $ext || 'text' === $ext ? 'text' : 'markdown' );
		}
		return new WP_Error(
			'kerf_words_type',
			__( 'Kerf reads Word documents (.docx), Markdown (.md), web pages (.html) and text files (.txt). For a PDF or an older Word file (.doc), open it, copy its text and paste it here.', 'kerf-pro' ),
			array( 'status' => 415 )
		);
	}

	if ( isset( $input['html'] ) && '' !== trim( (string) $input['html'] ) ) {
		if ( strlen( (string) $input['html'] ) > KERF_PRO_WORDS_HTML ) {
			return new WP_Error( 'kerf_words_large', __( 'That is too much to paste at once. Paste it in parts.', 'kerf-pro' ), array( 'status' => 413 ) );
		}
		return array( 'words' => kerf_pro_words_from_html( (string) $input['html'] ), 'from' => 'html' );
	}

	$text = isset( $input['text'] ) ? (string) $input['text'] : '';
	if ( kerf_pro_words_is_markup( $text ) ) {
		return array( 'words' => kerf_pro_words_from_html( $text ), 'from' => 'html' );
	}
	return array( 'words' => kerf_pro_words_tidy( $text ), 'from' => 'text' );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE ROUTE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * POST kerf/v1/ai/words — a file (`file`), pasted markup (`html`) or text
 * (`text`), answered as Markdown. Nothing is kept: a file is read from where
 * PHP put the upload, and PHP deletes it.
 */
function kerf_pro_words_routes() {
	register_rest_route( 'kerf/v1', '/ai/words', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_words_rest',
		'permission_callback' => static function () {
			if ( ! current_user_can( 'edit_posts' ) ) {
				return new WP_Error( 'kerf_ai_forbidden', __( 'Only someone who may write posts can do this.', 'kerf-pro' ), array( 'status' => 403 ) );
			}
			return kerf_pro_licensed() ? true : new WP_Error( 'kerf_ai_licence', __( 'Your Kerf Pro licence has expired. Renew it to use AI again; everything it made keeps working.', 'kerf-pro' ), array( 'status' => 403 ) );
		},
		'args'                => array(
			'html' => array( 'type' => 'string', 'default' => '' ),
			'text' => array( 'type' => 'string', 'default' => '' ),
		),
	) );
}
add_action( 'rest_api_init', 'kerf_pro_words_routes' );

/**
 * Read what was sent.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_words_rest( $request ) {
	$files = $request->get_file_params();
	$read  = kerf_pro_words_read( array(
		'file' => isset( $files['file'] ) && is_array( $files['file'] ) && empty( $files['file']['error'] ) ? $files['file'] : null,
		'html' => (string) $request['html'],
		'text' => (string) $request['text'],
	) );
	if ( is_wp_error( $read ) ) {
		return $read;
	}
	if ( '' === trim( $read['words'] ) ) {
		return new WP_Error( 'kerf_words_empty', __( 'Kerf found no words in that.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	return rest_ensure_response( $read );
}
