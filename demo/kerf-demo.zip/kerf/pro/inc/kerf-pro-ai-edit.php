<?php
/**
 * AI in the editor: a page, or one of its sections, changed as the owner asks
 * — "add a question about parking", "make this three cards", "these are the
 * new opening hours" — in the design the site has.
 *
 * The editor sends the blocks to change as they are now (saved or not); Kerf
 * renders them as the page does and shows the model that HTML with what the
 * owner asked, the design's stylesheet and the home page. What comes back is
 * held to the rules a made page is held to and converted as an import
 * converts. Nothing is saved: the editor puts the blocks in, and the owner
 * looks, undoes (Ctrl+Z) or saves (assets/js/kerf-ai-editor.js).
 *
 * What the model does not change keeps everything it had. Each section is
 * numbered (`data-kerf-n`) in what the model is shown, and a section that comes
 * back as it went is the page's own block again — its bound links, its Site
 * details, its stamp for Update design, its name in the List View. What
 * WordPress fills in or runs — the latest posts, a comment list, a design's
 * in-place script, a block from another plugin — is shown as a placeholder
 * (`<kerf-keep>`) the model keeps where it stands, and is put back as it was.
 * A section changed is converted again: what it was bound to is named in it
 * for the converter (`data-kerf-site`, `data-kerf-field`), so it binds again,
 * and its stamp says it was replaced.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Changes asked for, and made: the newest five, by id. */
const KERF_PRO_AI_EDITS_OPTION = 'kerf_pro_ai_edits';

/** What is changed at once, as the model is shown it, in bytes. */
const KERF_PRO_AI_EDIT_HTML = 150000;

/** What the owner asks, in characters. */
const KERF_PRO_AI_EDIT_ASK = 4000;

/**
 * Is this block one the model may change, or one it is shown only as a
 * placeholder to keep where it stands? The design's own elements and
 * WordPress's headings and paragraphs are the model's to change; a loop, the
 * post's content, comments, pagination, an in-place script, and any other
 * plugin's or core's block are not.
 *
 * @param string $name
 * @return bool
 */
function kerf_pro_ai_edit_keeps( $name ) {
	$name = (string) $name;
	if ( in_array( $name, array( 'kerf/loop', 'kerf/post-content', 'kerf/comments', 'kerf/pagination', 'kerf/script' ), true ) ) {
		return true;
	}
	return 0 !== strpos( $name, 'kerf/' ) && ! in_array( $name, array( 'core/heading', 'core/paragraph' ), true );
}

/**
 * Is this block kept as it is — one the model may not change, or one that
 * plays or frames something (a page's own video, a map), which the rules
 * hold a new page to none of and would take out?
 *
 * @param array $block
 * @return bool
 */
function kerf_pro_ai_edit_kept( $block ) {
	$name = isset( $block['blockName'] ) ? (string) $block['blockName'] : '';
	$tag  = isset( $block['attrs']['tagName'] ) ? strtolower( (string) $block['attrs']['tagName'] ) : '';
	return '' !== $name && ( kerf_pro_ai_edit_keeps( $name ) || 'kerf/video' === $name || in_array( $tag, array( 'iframe', 'video', 'audio', 'object', 'embed' ), true ) );
}

// ═══════════════════════════════════════════════════════════════════════════════
// STARTING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Start a change: checked now, written by a job.
 *
 * @param array $input {
 *     @type int    $post_id  The page.
 *     @type string $scope    `page` (all its blocks) or `block` (one section).
 *     @type string $markup   The blocks to change, as the editor has them (serialized).
 *     @type string $ask      What the owner wants changed.
 *     @type string $words    New words for it, in Markdown (optional).
 *     @type int[]  $pictures The owner's new pictures (optional).
 *     @type int[]  $path     Where a section stands: its index, and its parents'.
 * }
 * @return array|WP_Error The job.
 */
function kerf_pro_ai_edit_start( $input ) {
	$ready = kerf_pro_ai_page_ready();
	if ( true !== $ready ) {
		return $ready;
	}
	$post_id = isset( $input['post_id'] ) ? (int) $input['post_id'] : 0;
	if ( ! $post_id || ! get_post( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return new WP_Error( 'kerf_ai_page_target', __( 'You may not change this page.', 'kerf-pro' ), array( 'status' => 403 ) );
	}
	$scope  = isset( $input['scope'] ) && 'block' === $input['scope'] ? 'block' : 'page';
	$markup = isset( $input['markup'] ) ? (string) $input['markup'] : '';
	$ask    = kerf_pro_ai_page_clean_words( isset( $input['ask'] ) ? (string) $input['ask'] : '', KERF_PRO_AI_EDIT_ASK );
	$words  = kerf_pro_ai_page_clean_words( isset( $input['words'] ) ? (string) $input['words'] : '' );
	if ( mb_strlen( $ask ) < 4 ) {
		return new WP_Error( 'kerf_ai_edit_ask', __( 'Say what should change.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	if ( mb_strlen( $words ) > KERF_PRO_AI_PAGE_WORDS ) {
		/* translators: %s: a number of characters. */
		return new WP_Error( 'kerf_ai_page_words', sprintf( __( 'The words are longer than %s characters: change the page in parts.', 'kerf-pro' ), number_format_i18n( KERF_PRO_AI_PAGE_WORDS ) ), array( 'status' => 400 ) );
	}
	if ( false === strpos( $markup, '<!-- wp:kerf/' ) && ! preg_match( '/<!-- wp:(?:heading|paragraph)\b/', $markup ) ) {
		return new WP_Error( 'kerf_ai_edit_nothing', __( 'AI changes the parts of a page made in your design. Select one of them, or make the page with AI first.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	$ids      = isset( $input['pictures'] ) ? array_slice( array_map( 'absint', (array) $input['pictures'] ), 0, KERF_PRO_AI_PAGE_PICTURES ) : array();
	$pictures = kerf_pro_ai_design_pictures( $ids );
	if ( is_wp_error( $pictures ) ) {
		return $pictures;
	}

	$prepared = kerf_pro_ai_edit_prepare( $markup, $post_id, $pictures );
	if ( strlen( $prepared['html'] ) > KERF_PRO_AI_EDIT_HTML ) {
		return new WP_Error( 'kerf_ai_edit_long', __( 'This page is too long to change at once. Select one of its sections and change that.', 'kerf-pro' ), array( 'status' => 413 ) );
	}
	if ( '' === trim( wp_strip_all_tags( $prepared['html'] ) ) && false === strpos( $prepared['html'], '<img' ) ) {
		return new WP_Error( 'kerf_ai_edit_nothing', __( 'There is nothing here for AI to change.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	$project = array(
		'id'       => strtolower( wp_generate_password( 12, false, false ) ),
		'user'     => get_current_user_id(),
		'created'  => time(),
		'target'   => $post_id,
		'scope'    => $scope,
		// Where the section stands in the page (its index, and its parents'):
		// the editor puts the answer there when the page was reloaded meanwhile.
		'path'     => 'block' === $scope && isset( $input['path'] ) ? array_slice( array_map( 'intval', (array) $input['path'] ), 0, 20 ) : array(),
		'markup'   => $markup,
		'ask'      => $ask,
		'words'    => $words,
		'chosen'   => $pictures,
		'scripts'  => kerf_user_can_add_scripts(),
		'answer'   => null,
		'result'   => null,
	);
	kerf_pro_ai_edit_save( $project );

	return kerf_pro_ai_job_create(
		'edit',
		array(
			array( 'key' => 'write', 'label' => 'block' === $scope ? __( 'Changing the section', 'kerf-pro' ) : __( 'Changing the page', 'kerf-pro' ) ),
			array( 'key' => 'make', 'label' => __( 'Putting it in your design', 'kerf-pro' ) ),
		),
		array( 'project' => $project['id'], 'post' => $post_id )
	);
}

/**
 * A change's project, by id.
 *
 * @param string $id
 * @return array|null
 */
function kerf_pro_ai_edit_get( $id ) {
	$all = kerf_pro_ai_fresh_option( KERF_PRO_AI_EDITS_OPTION );
	return is_array( $all ) && isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : null;
}

/**
 * Keep a change's project — the newest five (scar 100).
 *
 * @param array $project
 */
function kerf_pro_ai_edit_save( $project ) {
	$all = kerf_pro_ai_fresh_option( KERF_PRO_AI_EDITS_OPTION );
	$all = is_array( $all ) ? $all : array();
	$all[ $project['id'] ] = $project;
	uasort( $all, static function ( $a, $b ) {
		return ( isset( $b['created'] ) ? (int) $b['created'] : 0 ) <=> ( isset( $a['created'] ) ? (int) $a['created'] : 0 );
	} );
	update_option( KERF_PRO_AI_EDITS_OPTION, array_slice( $all, 0, 5, true ), false );
}

/**
 * The job handler for changes.
 *
 * @param array $handlers
 * @return array
 */
function kerf_pro_ai_edit_handler( $handlers ) {
	$handlers['edit'] = 'kerf_pro_ai_edit_step';
	return $handlers;
}
add_filter( 'kerf_pro_ai_job_handlers', 'kerf_pro_ai_edit_handler' );

/**
 * One step of a change.
 *
 * @param array $job  By reference.
 * @param array $step { key, label }.
 * @return true|WP_Error
 */
function kerf_pro_ai_edit_step( &$job, $step ) {
	$project = kerf_pro_ai_edit_get( isset( $job['data']['project'] ) ? (string) $job['data']['project'] : '' );
	if ( ! $project ) {
		return new WP_Error( 'kerf_ai_page_gone', __( 'This change\'s request is gone. Ask again.', 'kerf-pro' ) );
	}
	$done = 'write' === $step['key'] ? kerf_pro_ai_edit_write( $project ) : kerf_pro_ai_edit_make( $project );
	kerf_pro_ai_edit_save( $project );
	if ( is_wp_error( $done ) ) {
		return $done;
	}
	if ( 'make' === $step['key'] ) {
		$job['result'] = $project['result'] + array( 'project' => $project['id'] );
	}
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WHAT THE MODEL IS SHOWN
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The blocks to change as the model is shown them: rendered as the page
 * renders them, sections numbered, what it must keep a placeholder, what they
 * are bound to named, pictures by short paths, the site's pages by path.
 *
 * Deterministic for the same blocks: made again for the `make` step, which
 * compares what came back with it.
 *
 * @param string  $markup
 * @param int     $post_id
 * @param array[] $chosen  The owner's new pictures (kerf_pro_ai_design_pictures()).
 * @return array{html:string,blocks:array[],sections:array<string,array{path:int[],hash:string}>,wrappers:array<string,int[]>,keep:array[],pictures:array[]}
 */
function kerf_pro_ai_edit_prepare( $markup, $post_id, $chosen = array() ) {
	$blocks = array_values( array_filter( parse_blocks( (string) $markup ), static function ( $block ) {
		return ! empty( $block['blockName'] ) || '' !== trim( (string) $block['innerHTML'] );
	} ) );

	// Sections: the top blocks, or — inside up to three lone wrappers, as a
	// design's <main> holds its page — the wrapper's children.
	$sections = array();
	$wrappers = array();
	$path     = array();
	$level    = $blocks;
	for ( $depth = 0; $depth < 3; $depth++ ) {
		$real = array_keys( array_filter( $level, static function ( $block ) {
			return ! empty( $block['blockName'] );
		} ) );
		if ( 1 !== count( $real ) || 'kerf/div' !== $level[ $real[0] ]['blockName'] || empty( $level[ $real[0] ]['innerBlocks'] ) ) {
			break;
		}
		$path[]                     = $real[0];
		$wrappers[ (string) $depth ] = $path;
		$level                      = $level[ $real[0] ]['innerBlocks'];
	}
	foreach ( $level as $i => $block ) {
		if ( ! empty( $block['blockName'] ) && ! kerf_pro_ai_edit_kept( $block ) ) {
			$sections[ (string) count( $sections ) ] = array( 'path' => array_merge( $path, array( $i ) ), 'hash' => '' );
		}
	}

	// A copy marked for the model; the blocks themselves stay as they were.
	$marked = $blocks;
	foreach ( $wrappers as $w => $at ) {
		kerf_pro_ai_edit_attr( $marked, $at, 'data-kerf-w', $w );
	}
	foreach ( $sections as $n => $section ) {
		kerf_pro_ai_edit_attr( $marked, $section['path'], 'data-kerf-n', $n );
	}
	$keep = array();
	foreach ( $marked as $i => $block ) {
		$marked[ $i ] = kerf_pro_ai_edit_mark( $block, $keep );
	}

	$html     = kerf_pro_ai_edit_render( $marked, $post_id );
	$pictures = array();
	$html     = kerf_pro_ai_edit_lean( $html, $blocks, $chosen, $pictures );

	// What each section was, as the model sees it: compared with what comes back.
	foreach ( kerf_pro_ai_edit_by_marker( $html, 'data-kerf-n' ) as $n => $canon ) {
		if ( isset( $sections[ $n ] ) ) {
			$sections[ $n ]['hash'] = md5( $canon );
		}
	}

	return array(
		'html'     => $html,
		'blocks'   => $blocks,
		'sections' => $sections,
		'wrappers' => $wrappers,
		'keep'     => $keep,
		'pictures' => $pictures,
	);
}

/**
 * Give the block at a path an attribute, as its element renders it.
 *
 * @param array[] $blocks By reference.
 * @param int[]   $path
 * @param string  $name
 * @param string  $value
 */
function kerf_pro_ai_edit_attr( &$blocks, $path, $name, $value ) {
	$block = &$blocks[ $path[0] ];
	foreach ( array_slice( $path, 1 ) as $i ) {
		$block = &$block['innerBlocks'][ $i ];
	}
	$custom                              = isset( $block['attrs']['customAttributes'] ) && is_array( $block['attrs']['customAttributes'] ) ? $block['attrs']['customAttributes'] : array();
	$custom[ $name ]                     = (string) $value;
	$block['attrs']['customAttributes'] = $custom;
	unset( $block );
}

/**
 * A block as the model is shown it: one it must keep as a placeholder; one
 * bound to a Site detail or the page's own values named so (the markers a
 * design writes, which the converter binds again).
 *
 * @param array   $block
 * @param array[] $keep  By reference: the blocks kept, by number.
 * @return array
 */
function kerf_pro_ai_edit_mark( $block, &$keep ) {
	if ( empty( $block['blockName'] ) ) {
		return $block;
	}
	if ( kerf_pro_ai_edit_kept( $block ) ) {
		$k          = count( $keep );
		$keep[ $k ] = $block;
		$tag        = '<kerf-keep data-k="' . $k . '"></kerf-keep>';
		return array( 'blockName' => null, 'attrs' => array(), 'innerBlocks' => array(), 'innerHTML' => $tag, 'innerContent' => array( $tag ) );
	}
	$attrs  = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	$custom = isset( $attrs['customAttributes'] ) && is_array( $attrs['customAttributes'] ) ? $attrs['customAttributes'] : array();
	if ( ! empty( $attrs['kerfSite'] ) && ! isset( $custom['data-kerf-site'] ) ) {
		$custom['data-kerf-site'] = (string) $attrs['kerfSite'];
	}
	foreach ( isset( $attrs['metadata']['bindings'] ) && is_array( $attrs['metadata']['bindings'] ) ? $attrs['metadata']['bindings'] : array() as $binding ) {
		$source = isset( $binding['source'] ) ? (string) $binding['source'] : '';
		$key    = isset( $binding['args']['key'] ) ? (string) $binding['args']['key'] : '';
		if ( 'kerf/site' === $source && '' !== $key && ! isset( $custom['data-kerf-site'] ) ) {
			$custom['data-kerf-site'] = $key;
		} elseif ( 'kerf/post' === $source && in_array( $key, array( 'image', 'title', 'excerpt', 'date', 'author' ), true ) && ! isset( $custom['data-kerf-field'] ) ) {
			$custom['data-kerf-field'] = $key;
		}
	}
	if ( $custom ) {
		$block['attrs']['customAttributes'] = $custom;
	}
	foreach ( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array() as $i => $inner ) {
		$block['innerBlocks'][ $i ] = kerf_pro_ai_edit_mark( $inner, $keep );
	}
	return $block;
}

/**
 * Blocks rendered as the page renders them: the page is the post the
 * bindings read.
 *
 * @param array[] $blocks
 * @param int     $post_id
 * @return string
 */
function kerf_pro_ai_edit_render( $blocks, $post_id ) {
	global $post;
	$was  = $post;
	$page = get_post( (int) $post_id );
	if ( $page ) {
		$post = $page; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the blocks' bindings read the page; put back below.
		setup_postdata( $page );
	}
	$html = '';
	foreach ( $blocks as $block ) {
		$html .= render_block( $block );
	}
	$post = $was; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- put back.
	if ( $was ) {
		setup_postdata( $was );
	} else {
		wp_reset_postdata();
	}
	return $html;
}

/**
 * Rendered HTML, lean for the model: no scripts, styles or comments,
 * WordPress's own classes out, the site's pages by path (as the binder reads
 * them, under plain permalinks too), every picture by a short path the model
 * keeps — each remembered with its library picture, or its address.
 *
 * @param string  $html
 * @param array[] $blocks   The blocks: their pictures' library ids.
 * @param array[] $chosen   The owner's new pictures: their paths are taken.
 * @param array[] $pictures By reference: path => { id, path, url, width, height, alt }.
 * @return string
 */
function kerf_pro_ai_edit_lean( $html, $blocks, $chosen, &$pictures ) {
	$html = (string) preg_replace(
		array( '#<(script|style|noscript)\b[^>]*>.*?</\1\s*>#is', '#<!--.*?-->#s', '/\s(?:srcset|sizes|decoding|loading|fetchpriority)="[^"]*"/i', '/\s+/' ),
		array( '', '', '', ' ' ),
		(string) $html
	);
	$html = kerf_pro_ai_page_strip_wp_classes( $html );
	// A form's address is Kerf's, made at render (§5.35): the model is not to
	// keep it, and the rules take it from anything it writes.
	$html = (string) preg_replace( '/(<form\b[^>]*?)\saction="[^"]*"/i', '$1', $html );
	$html = (string) preg_replace( '/<([a-z][a-z0-9-]*) >/i', '<$1>', $html );

	// The library's pictures the blocks name, by address.
	$ids = array();
	$walk = static function ( $list ) use ( &$walk, &$ids ) {
		foreach ( $list as $block ) {
			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			if ( ! empty( $attrs['mediaId'] ) && ! empty( $attrs['src'] ) ) {
				$ids[ (string) $attrs['src'] ] = (int) $attrs['mediaId'];
			}
			if ( ! empty( $attrs['backgroundImageId'] ) && ! empty( $attrs['backgroundImage'] ) ) {
				$ids[ (string) $attrs['backgroundImage'] ] = (int) $attrs['backgroundImageId'];
			}
			$walk( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array() );
		}
	};
	$walk( $blocks );

	$taken = array();
	foreach ( $chosen as $picture ) {
		$taken[ $picture['path'] ] = true;
	}
	$by_url = array();
	$token  = static function ( $url ) use ( &$by_url, &$taken, &$pictures, $ids ) {
		$url = html_entity_decode( trim( (string) $url ), ENT_QUOTES );
		if ( isset( $by_url[ $url ] ) ) {
			return $by_url[ $url ];
		}
		$id = isset( $ids[ $url ] ) ? $ids[ $url ] : (int) attachment_url_to_postid( $url );
		if ( ! $id ) {
			$full = (string) preg_replace( '/-\d+x\d+(\.[a-z0-9]+)$/i', '$1', $url );
			$id   = $full !== $url ? (int) attachment_url_to_postid( $full ) : 0;
		}
		$name = sanitize_title( preg_replace( '/-\d+x\d+$/', '', pathinfo( (string) wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_FILENAME ) ) );
		$ext  = strtolower( pathinfo( (string) wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
		$name = '' !== $name ? substr( $name, 0, 40 ) : 'picture';
		$path = 'img/' . $name . '.' . $ext;
		for ( $n = 2; isset( $taken[ $path ] ); $n++ ) {
			$path = 'img/' . $name . '-' . $n . '.' . $ext;
		}
		$taken[ $path ]   = true;
		$meta             = $id ? wp_get_attachment_metadata( $id ) : array();
		$pictures[ $path ] = array(
			'id'     => $id,
			'path'   => $path,
			'url'    => $id ? (string) wp_get_attachment_url( $id ) : $url,
			'width'  => isset( $meta['width'] ) ? (int) $meta['width'] : 0,
			'height' => isset( $meta['height'] ) ? (int) $meta['height'] : 0,
			'alt'    => $id ? trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) : '',
		);
		$by_url[ $url ]   = $path;
		return $path;
	};
	$picture = '[^"\'()&\s]+\.(?:jpe?g|png|gif|webp|avif|svg)(?:\?[^"\'()&\s]*)?';
	$html    = (string) preg_replace_callback(
		'/(\s(?:src|data-src|data-setbg|data-bg|data-background|data-image|poster)=")(' . $picture . ')(")/i',
		static function ( $m ) use ( $token ) {
			return $m[1] . $token( $m[2] ) . $m[3];
		},
		$html
	);
	$html = (string) preg_replace_callback(
		'/url\(\s*(&quot;|&#0?39;|&apos;|["\']?)(' . $picture . ')\1\s*\)/i',
		static function ( $m ) use ( $token ) {
			return 'url(' . $m[1] . $token( $m[2] ) . $m[1] . ')';
		},
		$html
	);

	// The site's pages, by path: as Make a page gives them, and the binder reads them.
	$paths = array( trailingslashit( home_url( '/' ) ) => wp_make_link_relative( home_url( '/' ) ) );
	foreach ( get_pages( array( 'number' => 200 ) ) as $page ) {
		$paths[ (string) get_permalink( $page ) ] = wp_make_link_relative( home_url( '/' . get_page_uri( $page ) . '/' ) );
	}
	return (string) preg_replace_callback(
		'/(\shref=")([^"]+)(")/i',
		static function ( $m ) use ( $paths ) {
			$href = html_entity_decode( $m[2], ENT_QUOTES );
			return isset( $paths[ $href ] ) ? $m[1] . esc_attr( $paths[ $href ] ) . $m[3] : $m[0];
		},
		$html
	);
}

/**
 * Each element marked with an attribute, written canonically — its tag,
 * attributes in order, classes in order, text with its spaces collapsed — so
 * the same element written over again by the model reads the same.
 *
 * @param string $html
 * @param string $marker
 * @return array<string,string> marker value => the element, canonical.
 */
function kerf_pro_ai_edit_by_marker( $html, $marker ) {
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . kerf_mc_extract_body( (string) $html ) . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();
	$out = array();
	if ( ! $doc->documentElement ) {
		return $out;
	}
	foreach ( $doc->documentElement->getElementsByTagName( '*' ) as $element ) {
		if ( $element->hasAttribute( $marker ) ) {
			$value = (string) $element->getAttribute( $marker );
			if ( ! isset( $out[ $value ] ) ) {
				$out[ $value ] = kerf_pro_ai_edit_canon( $element );
			}
		}
	}
	return $out;
}

/**
 * An element, canonical.
 *
 * @param DOMNode $node
 * @return string
 */
function kerf_pro_ai_edit_canon( $node ) {
	if ( XML_TEXT_NODE === $node->nodeType ) {
		return trim( (string) preg_replace( '/\s+/u', ' ', (string) $node->nodeValue ) );
	}
	if ( XML_ELEMENT_NODE !== $node->nodeType ) {
		return '';
	}
	$attrs = array();
	foreach ( $node->attributes as $attr ) {
		$value = trim( (string) preg_replace( '/\s+/', ' ', (string) $attr->value ) );
		if ( 'class' === $attr->name ) {
			$names = preg_split( '/\s+/', $value, -1, PREG_SPLIT_NO_EMPTY );
			sort( $names );
			$value = implode( ' ', $names );
		} elseif ( 'style' === $attr->name ) {
			$value = rtrim( (string) preg_replace( '/\s*([:;])\s*/', '$1', $value ), ';' );
		}
		$attrs[ $attr->name ] = $value;
	}
	ksort( $attrs );
	$out = '<' . strtolower( $node->nodeName );
	foreach ( $attrs as $name => $value ) {
		$out .= ' ' . $name . '="' . $value . '"';
	}
	$out .= '>';
	foreach ( $node->childNodes as $child ) {
		$part = kerf_pro_ai_edit_canon( $child );
		if ( '' !== $part ) {
			$out .= $part . "\n";
		}
	}
	return $out . '</' . strtolower( $node->nodeName ) . '>';
}

// ═══════════════════════════════════════════════════════════════════════════════
// WRITING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Step one: ask the model.
 *
 * @param array $project By reference: its answer.
 * @return true|WP_Error
 */
function kerf_pro_ai_edit_write( &$project ) {
	$prepared   = kerf_pro_ai_edit_prepare( $project['markup'], (int) $project['target'], $project['chosen'] );
	$vocabulary = kerf_pro_ai_page_vocabulary();
	$answer     = kerf_pro_ai_request(
		'edit',
		kerf_pro_ai_edit_rules( $project, $vocabulary ),
		array_merge(
			array( array( 'text' => kerf_pro_ai_edit_request( $project, $prepared, $vocabulary ) ) ),
			kerf_pro_ai_design_picture_parts( array( 'pictures' => $project['chosen'] ) )
		),
		array(
			'tier'        => 'pro',
			'json'        => true,
			'temperature' => 0.3,
			'schema'      => array(
				'type'       => 'OBJECT',
				'properties' => array(
					'html'  => array( 'type' => 'STRING' ),
					'css'   => array( 'type' => 'STRING' ),
					'notes' => array( 'type' => 'ARRAY', 'items' => array( 'type' => 'STRING' ) ),
				),
				'required'   => array( 'html' ),
			),
		)
	);
	if ( is_wp_error( $answer ) ) {
		return $answer;
	}
	$read = kerf_pro_ai_page_answer( $answer );
	if ( is_wp_error( $read ) ) {
		return $read;
	}
	$project['answer'] = $read;
	return true;
}

/**
 * The rules for changing part of a page.
 *
 * @param array $project
 * @param array $vocabulary From kerf_pro_ai_page_vocabulary().
 * @return string
 */
function kerf_pro_ai_edit_rules( $project, $vocabulary ) {
	$part = 'block' === $project['scope'] ? 'one section of a page' : 'a page';
	return implode( "\n", array(
		'You change ' . $part . ' of an existing website, in the website\'s own design, as its owner asks. Kerf turns your HTML back into the page, keeping every tag, class and attribute exactly as you write them.',
		'',
		'You are given the HTML to change, what the owner wants, and the site\'s design — its stylesheet and its home page — so that what you add looks like the rest of the site: the same colours, fonts, spacing, shapes and classes' . ( $vocabulary['tailwind'] ? ' (or Tailwind CSS utility classes: Tailwind builds this design\'s styles in the browser).' : '.' ),
		'',
		'Rules:',
		'- Change only what the owner asks. Everything else stays exactly as it is — the same tags, classes, attributes, words and order. Do not tidy, reformat, rename or improve what you were not asked to change.',
		'- Answer with the whole HTML you were given, changed: the same outer elements, every part of it you did not change as it was.',
		'- Keep each data-kerf-n and data-kerf-w attribute on the element it is on, in parts you change too; a new section has none. Keep each <kerf-keep> element where it is, as it is — WordPress fills it in — unless the owner asks to remove that part.',
		'- Keep data-kerf-site, data-kerf-field and data-kerf-form attributes: they connect the page to the business\'s details, the page\'s own picture and title, and the site\'s forms.',
		'- Words: write the owner\'s words when they give them (as Markdown: keep its structure — a list stays a list, a table a table). Never add facts: no prices, numbers, years, awards, reviews, quotes, names or details the owner did not give. Write in the language of the page.',
		'- Pictures: only those already in the HTML, and the owner\'s new ones, by the paths you are given. No other picture, no stock or placeholder services.',
		'- Links: to the site\'s pages by the paths you are given, to the business\'s details (tel:, mailto:, its social profiles), or "#". No other address on this site.',
		'- The business\'s details exactly as given: data-kerf-site="phone" on a new tel: link, "email" on a new mailto: link, "address" on the element holding the address.',
		'- A new form: <form data-kerf-form="contact"> with no action, every field with a name and a <label>, a thank-you <div data-kerf-form-success hidden>…</div> and an error <div data-kerf-form-error hidden>…</div> inside it.',
		'- Nothing that runs, and nothing from other sites: no scripts, no on… attributes, no <style> or <link> elements (CSS goes in css), no iframes, embeds, maps or videos.',
		'- Accessible: headings in order, alt text on pictures, a label on every field.',
		'- CSS: where the design has nothing for something you add, write it in css, with the design\'s own colours, fonts and spacing, for classes you add (start their names with "pg-"); never restyle the design\'s own classes or elements. css is the page\'s whole own CSS: what it had (given to you) with what this change needs; empty when it needs none.',
		'',
		'Answer with JSON: html (the HTML you were given, changed), css, notes (at most five short sentences to the owner, in their language: what they should check or add — none when there is nothing to say).',
	) );
}

/**
 * What the model is given.
 *
 * @param array $project
 * @param array $prepared   From kerf_pro_ai_edit_prepare().
 * @param array $vocabulary
 * @return string
 */
function kerf_pro_ai_edit_request( $project, $prepared, $vocabulary ) {
	$name  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$lines = array( 'The site: ' . $name . '.', 'The page: “' . get_the_title( (int) $project['target'] ) . '”.' );

	$lines[] = '';
	$lines[] = 'What the owner wants changed:';
	$lines[] = $project['ask'];
	if ( '' !== $project['words'] ) {
		$lines[] = '';
		$lines[] = 'The owner\'s words for it, in Markdown — keep them, and their structure:';
		$lines[] = '<<<';
		$lines[] = $project['words'];
		$lines[] = '>>>';
	}

	$details = kerf_pro_ai_design_details( null );
	if ( $details ) {
		$lines[] = '';
		$lines[] = 'The business\'s details — exactly as given, only where needed:';
		foreach ( $details as $key => $text ) {
			$lines[] = '- ' . $key . ': ' . $text;
		}
	}

	$lines[] = '';
	if ( $project['chosen'] ) {
		$lines[] = 'The owner\'s new pictures for it, by these paths (each is shown below):';
		foreach ( $project['chosen'] as $picture ) {
			$lines[] = '- ' . $picture['path'] . ( $picture['width'] ? ' (' . $picture['width'] . '×' . $picture['height'] . ')' : '' ) . ( '' !== $picture['alt'] ? ' — ' . $picture['alt'] : '' );
		}
	} else {
		$lines[] = 'The owner gave no new pictures: use only those already in the HTML.';
	}

	$lines[] = '';
	$lines[] = 'The site\'s pages, for links:';
	foreach ( $vocabulary['pages'] as $page ) {
		$lines[] = '- ' . $page['title'] . ' — ' . $page['path'];
	}

	$lines[] = '';
	$lines[] = 'The HTML to change:';
	$lines[] = $prepared['html'];

	$css = kerf_pro_ai_page_css( (int) $project['target'] );
	if ( '' !== trim( $css ) ) {
		$lines[] = '';
		$lines[] = 'The page\'s own CSS so far:';
		$lines[] = kerf_pro_ai_page_lean_css( $css );
	}

	// The home page shows how the site's sections are written — unless it is
	// the page being changed.
	if ( (int) get_option( 'kerf_mockup_page' ) !== (int) $project['target'] && '' !== $vocabulary['home'] ) {
		$lines[] = '';
		$lines[] = 'How the site\'s pages are written — its home page, between its header and footer:';
		$lines[] = $vocabulary['home'];
	}
	if ( '' !== trim( $vocabulary['css'] ) ) {
		$lines[] = '';
		$lines[] = 'The design\'s stylesheet:';
		$lines[] = $vocabulary['css'];
	}
	if ( $vocabulary['elsewhere'] ) {
		$lines[] = '';
		$lines[] = 'Also loaded, from other sites — their classes work too: ' . implode( ', ', $vocabulary['elsewhere'] ) . '.';
	}
	return implode( "\n", $lines );
}

// ═══════════════════════════════════════════════════════════════════════════════
// PUTTING IT BACK
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Step two: check what the model wrote, convert what changed, keep what did
 * not, and answer the editor with the blocks.
 *
 * @param array $project By reference: its result.
 * @return true|WP_Error
 */
function kerf_pro_ai_edit_make( &$project ) {
	if ( empty( $project['answer']['html'] ) ) {
		return new WP_Error( 'kerf_ai_page_order', __( 'Gemini\'s answer is missing. Ask again.', 'kerf-pro' ) );
	}
	$target   = (int) $project['target'];
	$prepared = kerf_pro_ai_edit_prepare( $project['markup'], $target, $project['chosen'] );
	// Pictures: those it had, and the owner's new ones.
	$pictures = array_values( array_merge( array_values( $prepared['pictures'] ), $project['chosen'] ) );
	$rules    = array( 'pictures' => $pictures, 'id' => $project['id'], 'scripts' => ! empty( $project['scripts'] ) );
	$notes    = array();
	// The page's own header and footer stay (a page with a design of its own
	// holds them) when it had them.
	$html = kerf_pro_ai_edit_clean( (string) $project['answer']['html'], $rules, $prepared['html'], $notes );
	if ( '' === trim( wp_strip_all_tags( $html ) ) && ! preg_match( '#<(?:img|kerf-keep)\b#i', $html ) ) {
		return new WP_Error( 'kerf_ai_page_empty', __( 'Nothing was left of Gemini\'s answer once it was held to the rules. Ask again.', 'kerf-pro' ) );
	}

	$vocabulary = kerf_pro_ai_page_vocabulary();
	if ( ! $vocabulary['tailwind'] ) {
		// Styled by the design, by the page's own CSS so far, or by the CSS
		// written with this answer.
		$unknown = kerf_pro_ai_page_unknown_classes( $html, $vocabulary['classes'], kerf_pro_ai_page_css( $target ) . "\n" . (string) $project['answer']['css'] );
		if ( $unknown ) {
			$notes['classes'] = sprintf(
				/* translators: 1: how many, 2: a list of class names. */
				_n( 'Gemini used %1$d class your design does not style (%2$s): that part looks plain until it is styled.', 'Gemini used %1$d classes your design does not style (%2$s): those parts look plain until they are styled.', count( $unknown ), 'kerf-pro' ),
				count( $unknown ),
				implode( ', ', array_slice( $unknown, 0, 8 ) )
			);
		}
	}

	// What came back of each section, to tell the unchanged from the changed.
	$back = array();
	foreach ( kerf_pro_ai_edit_by_marker( $html, 'data-kerf-n' ) as $n => $canon ) {
		$back[ $n ] = md5( $canon );
	}

	$result = kerf_mc_convert_html(
		$html,
		kerf_pro_ai_page_manifest_any( $pictures ),
		kerf_import_converter_options( array( 'directives' => ! empty( $project['scripts'] ) ) ) + array( 'site_known' => kerf_site_details() )
	);
	kerf_import_fill_alts( $result['markup'] );
	if ( ! empty( $result['site'] ) ) {
		kerf_site_remember( $result['site'] );
	}

	$kept    = 0;
	$changed = 0;
	$used    = array();
	$blocks  = parse_blocks( $result['markup'] );
	foreach ( $blocks as $i => $block ) {
		$blocks[ $i ] = kerf_pro_ai_edit_restore( $block, $prepared, $back, $used, $kept, $changed );
	}
	$blocks = array_values( array_filter( $blocks, static function ( $block ) {
		return ! empty( $block['blockName'] ) || '' !== trim( (string) $block['innerHTML'] );
	} ) );
	$markup = serialize_blocks( $blocks );

	// Links in what changed find the site's pages; what was kept is as it was.
	$links = kerf_links_bind( $markup );
	if ( ! empty( $links['unresolved'] ) ) {
		$notes['links'] = sprintf(
			/* translators: %s: a list of addresses. */
			__( 'Some links go to pages your site does not have yet (%s): make those pages, or change the links in the editor.', 'kerf-pro' ),
			implode( ', ', array_slice( array_keys( $links['unresolved'] ), 0, 5 ) )
		);
	}
	// Nothing changed at all — every section as it went, none new, none gone:
	// the editor is left as it is, and the owner told.
	$same = kerf_pro_ai_edit_shape( $prepared['blocks'] ) === kerf_pro_ai_edit_shape( $blocks );
	if ( $same ) {
		$notes['same'] = __( 'Gemini changed nothing here. Say more precisely what should change, and ask again.', 'kerf-pro' );
	}

	$files             = kerf_pro_ai_page_own_files( $target, 0, (string) $project['answer']['css'], array( 'pictures' => $pictures, 'id' => $project['id'] ), $notes, true );
	$project['result'] = array(
		'post'    => $target,
		'scope'   => $project['scope'],
		'path'    => isset( $project['path'] ) ? (array) $project['path'] : array(),
		'markup'  => $links['markup'],
		'kept'    => $kept,
		'changed' => $changed,
		'same'    => $same,
		'styles'  => $files['styles'],
		'removed' => $files['removed'],
		'notes'   => array_values( array_merge( array_values( $notes ), $project['answer']['notes'] ) ),
	);
	return true;
}

/**
 * What the model wrote, held to a page's rules (kerf_pro_ai_page_clean()) —
 * but a header or footer it was given stays its own.
 *
 * @param string $html
 * @param array  $rules { pictures }.
 * @param string $sent  What the model was shown.
 * @param array  $notes By reference.
 * @return string
 */
function kerf_pro_ai_edit_clean( $html, $rules, $sent, &$notes ) {
	$chrome = (bool) preg_match( '#<(?:header|footer)\b#i', $sent );

	// What the page had that the rules would take from a new page — an inline
	// handler a design's button runs (§5.32, scar 108), a link that is a
	// no-op script — stays where the model kept it as it was, for someone who
	// may add scripts; anything new of the kind goes.
	$had = array();
	if ( ! empty( $rules['scripts'] ) && preg_match_all( '/\s(on[a-z]+|href)="([^"]*)"/i', (string) $sent, $found, PREG_SET_ORDER ) ) {
		foreach ( $found as $pair ) {
			if ( 'href' !== strtolower( $pair[1] ) || preg_match( '/^\s*javascript:/i', $pair[2] ) ) {
				$had[ strtolower( $pair[1] ) . '|' . $pair[2] ] = true;
			}
		}
	}
	if ( $had ) {
		$html = (string) preg_replace_callback(
			'/\s(on[a-z]+|href)="([^"]*)"/i',
			static function ( $m ) use ( $had ) {
				return isset( $had[ strtolower( $m[1] ) . '|' . $m[2] ] ) ? ' data-kerf-had-' . strtolower( $m[1] ) . '="' . $m[2] . '"' : $m[0];
			},
			$html
		);
	}
	$html = kerf_pro_ai_page_clean( $html, $rules, $notes, $chrome );
	return $had ? (string) preg_replace( '/\sdata-kerf-had-(on[a-z]+|href)="/i', ' $1="', $html ) : $html;
}

/**
 * A converted block put back: a section that came back as it went is the
 * page's own block again; one changed keeps its stamp, marked replaced; a
 * wrapper keeps what it was; a placeholder is the block it stood for.
 *
 * @param array $block
 * @param array $prepared From kerf_pro_ai_edit_prepare().
 * @param array $back     Marker => hash of what came back.
 * @param array $used     By reference: sections seen.
 * @param int   $kept     By reference.
 * @param int   $changed  By reference.
 * @return array
 */
function kerf_pro_ai_edit_restore( $block, $prepared, $back, &$used, &$kept, &$changed ) {
	if ( empty( $block['blockName'] ) ) {
		return $block;
	}
	$attrs  = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	$custom = isset( $attrs['customAttributes'] ) && is_array( $attrs['customAttributes'] ) ? $attrs['customAttributes'] : array();

	// A placeholder: the block it stood for.
	if ( 'kerf/div' === $block['blockName'] && 'kerf-keep' === ( $attrs['tagName'] ?? '' ) ) {
		$k = isset( $custom['data-k'] ) ? (int) $custom['data-k'] : -1;
		return isset( $prepared['keep'][ $k ] ) ? $prepared['keep'][ $k ] : array( 'blockName' => null, 'attrs' => array(), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() );
	}

	$n = isset( $custom['data-kerf-n'] ) ? (string) $custom['data-kerf-n'] : null;
	$w = isset( $custom['data-kerf-w'] ) ? (string) $custom['data-kerf-w'] : null;
	unset( $custom['data-kerf-n'], $custom['data-kerf-w'] );
	if ( $custom ) {
		$block['attrs']['customAttributes'] = $custom;
	} else {
		unset( $block['attrs']['customAttributes'] );
	}

	if ( null !== $n && isset( $prepared['sections'][ $n ] ) && ! isset( $used[ $n ] ) ) {
		$used[ $n ] = true;
		$original   = kerf_pro_ai_edit_at( $prepared['blocks'], $prepared['sections'][ $n ]['path'] );
		if ( $original && isset( $back[ $n ] ) && $back[ $n ] === $prepared['sections'][ $n ]['hash'] ) {
			$kept++;
			return $original;
		}
		$changed++;
		if ( $original && ! empty( $original['attrs']['kerfSource'] ) ) {
			$block['attrs']['kerfSource'] = array_merge( (array) $original['attrs']['kerfSource'], array( 'out' => 'replaced' ) );
		}
		if ( $original && ! empty( $original['attrs']['metadata']['name'] ) ) {
			$block['attrs']['metadata']['name'] = $original['attrs']['metadata']['name'];
		}
	} elseif ( null !== $w && isset( $prepared['wrappers'][ $w ] ) ) {
		// A wrapper: what it was — its name, its lock, its stamp — round
		// what it holds now.
		$original = kerf_pro_ai_edit_at( $prepared['blocks'], $prepared['wrappers'][ $w ] );
		if ( $original && ( $original['attrs']['tagName'] ?? 'div' ) === ( $block['attrs']['tagName'] ?? 'div' ) ) {
			// Its gaps (§5.20) are its own while it holds as many as it did;
			// else they are read from what it holds now.
			$gaps           = isset( $block['attrs']['gaps'] ) ? $block['attrs']['gaps'] : null;
			$same           = count( (array) ( $original['innerBlocks'] ?? array() ) ) === count( (array) ( $block['innerBlocks'] ?? array() ) );
			$block['attrs'] = $original['attrs'];
			if ( ! $same ) {
				if ( null === $gaps ) {
					unset( $block['attrs']['gaps'] );
				} else {
					$block['attrs']['gaps'] = $gaps;
				}
			}
		}
	}

	foreach ( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array() as $i => $inner ) {
		$block['innerBlocks'][ $i ] = kerf_pro_ai_edit_restore( $inner, $prepared, $back, $used, $kept, $changed );
	}
	return $block;
}

/**
 * Blocks as what they are — names, attributes, the HTML of each, in order —
 * so that a change that changed nothing reads the same as what was sent,
 * whatever the white space between the blocks' comments.
 *
 * @param array[] $blocks
 * @return string
 */
function kerf_pro_ai_edit_shape( $blocks ) {
	$shape = static function ( $list ) use ( &$shape ) {
		$out = array();
		foreach ( (array) $list as $block ) {
			if ( empty( $block['blockName'] ) ) {
				if ( '' !== trim( (string) $block['innerHTML'] ) ) {
					$out[] = array( 'html' => trim( (string) $block['innerHTML'] ) );
				}
				continue;
			}
			$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
			ksort( $attrs );
			$out[] = array(
				'name'  => $block['blockName'],
				'attrs' => $attrs,
				'html'  => empty( $block['innerBlocks'] ) ? trim( (string) $block['innerHTML'] ) : '',
				'inner' => $shape( isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array() ),
			);
		}
		return $out;
	};
	return md5( (string) wp_json_encode( $shape( $blocks ) ) );
}

/**
 * The block at a path.
 *
 * @param array[] $blocks
 * @param int[]   $path
 * @return array|null
 */
function kerf_pro_ai_edit_at( $blocks, $path ) {
	$block = null;
	$level = $blocks;
	foreach ( $path as $i ) {
		if ( ! isset( $level[ $i ] ) ) {
			return null;
		}
		$block = $level[ $i ];
		$level = isset( $block['innerBlocks'] ) ? $block['innerBlocks'] : array();
	}
	return $block;
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE ROUTE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * POST kerf/v1/ai/edit — start a change.
 */
function kerf_pro_ai_edit_routes() {
	register_rest_route( 'kerf/v1', '/ai/edit', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_edit',
		'permission_callback' => 'kerf_pro_ai_page_permission',
		'args'                => array(
			'post_id'  => array( 'type' => 'integer', 'required' => true ),
			'scope'    => array( 'type' => 'string', 'enum' => array( 'page', 'block' ), 'default' => 'page' ),
			'markup'   => array( 'type' => 'string', 'required' => true ),
			'ask'      => array( 'type' => 'string', 'required' => true ),
			'words'    => array( 'type' => 'string', 'default' => '' ),
			'pictures' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ), 'default' => array() ),
			'path'     => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ), 'default' => array() ),
		),
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_edit_routes' );

/**
 * Start a change.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_ai_rest_edit( $request ) {
	$job = kerf_pro_ai_edit_start( array(
		'post_id'  => (int) $request['post_id'],
		'scope'    => (string) $request['scope'],
		'markup'   => (string) $request['markup'],
		'ask'      => (string) $request['ask'],
		'words'    => (string) $request['words'],
		'pictures' => (array) $request['pictures'],
		'path'     => (array) $request['path'],
	) );
	return is_wp_error( $job ) ? $job : rest_ensure_response( kerf_pro_ai_job_view( $job ) );
}
