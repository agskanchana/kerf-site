<?php
/**
 * AI, phase 2: "Prepare my pages" — a designer's blog, post, search or 404
 * page marked for WordPress in the import's check step.
 *
 * Kerf fills a designer's blog page with the site's posts only where the page
 * says what is what: the markup contract, `data-kerf-loop` on the card that
 * repeats and `data-kerf-field` on its title, its date (§5.25). A page that
 * does not say is never used — filled with nothing, it would show the
 * designer's sample posts as if they were the site's. Until now the owner
 * pasted a brief into their AI tool and imported the files it gave back. Here
 * Gemini reads the page and answers with PLACEMENTS — element n12 is the card,
 * n15 its title — and Kerf adds those attributes itself (.github/AI-PLAN.md,
 * §5.46).
 *
 * The model never writes the page. Kerf numbers a copy's elements
 * (`data-k="n12"`), sends that copy with the contract, and applies only the
 * contract's names and values, each on an element that can hold it, to the
 * file as written: by WordPress's tag processor, counting tags the same way,
 * so nothing else in the file moves. Then it proves it —
 * kerf_import_page_fingerprint() unchanged (the same page, only marked), the
 * page marked, still the kind it was. The marked file replaces the original
 * in the import's pause (kerf_import_pending_put()); nothing is written until
 * the owner imports, so undo is untouched.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** The placements Gemini gave, by page: the same page marked again costs no request. */
const KERF_PRO_AI_PREPARED_OPTION = 'kerf_pro_ai_prepared';

/** The longest page copy sent to mark, in bytes: past it, a page is not one page. */
const KERF_PRO_AI_PREPARE_MAX = 200000;

// ═══════════════════════════════════════════════════════════════════════════════
// THE CHECK STEP: "MARK IT WITH AI"
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Beside a blog, post or 404 file that is not marked, in the check step's
 * table of the design's other pages (kerf_pages_check_section()). The answer
 * is filled in by the script as text (assets/js/kerf-ai.js).
 *
 * @param array $row From kerf_import_review_rows().
 */
function kerf_pro_ai_prepare_row( $row ) {
	if ( $row['marked'] || ! isset( kerf_shell_page_types()[ $row['type'] ] ) ) {
		return;
	}
	if ( ! kerf_pro_ai_available() ) {
		if ( '' === kerf_pro_ai_key() && current_user_can( 'edit_theme_options' ) ) {
			printf(
				'<p class="kerf-help">%s</p>',
				sprintf(
					/* translators: %s: link to Kerf → Settings. */
					esc_html__( 'With a Gemini key under %s, Kerf can mark it for you.', 'kerf-pro' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=kerf-settings' ) ) . '">' . esc_html__( 'Kerf → Settings', 'kerf-pro' ) . '</a>'
				)
			);
		}
		return;
	}
	?>
	<div class="kerf-ai kerf-ai-mark" data-kerf-ai-mark="<?php echo esc_attr( $row['file'] ); ?>">
		<button type="button" class="kerf-btn kerf-btn--sm" data-kerf-ai-mark-go><?php echo kerf_pro_ai_icon(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?><?php esc_html_e( 'Mark it with AI', 'kerf-pro' ); ?></button>
		<p class="kerf-help" data-kerf-ai-mark-about><?php esc_html_e( 'Gemini finds its post cards, titles and dates; Kerf adds the markers WordPress needs and changes nothing else.', 'kerf-pro' ); ?></p>
		<ul class="kerf-ai-mark__done" data-kerf-ai-mark-done hidden></ul>
		<p class="kerf-ai-mark__error" role="alert" data-kerf-ai-error hidden></p>
	</div>
	<?php
}
add_action( 'kerf_pro_pages_check_row', 'kerf_pro_ai_prepare_row' );

/**
 * The import's report says which pages Gemini marked.
 *
 * @param array $planned { plan, actions }.
 * @param array $context { staging, … }.
 * @return array
 */
function kerf_pro_ai_prepare_report( $planned, $context ) {
	$marked = ! empty( $context['staging']['ai_marked'] ) && is_array( $context['staging']['ai_marked'] ) ? array_keys( $context['staging']['ai_marked'] ) : array();
	if ( $marked && ! empty( $planned['plan'] ) ) {
		$planned['actions'][] = sprintf(
			/* translators: %s: list of file names. */
			_n( 'Gemini marked %s for WordPress; nothing else in it changed.', 'Gemini marked %s for WordPress; nothing else in them changed.', count( $marked ), 'kerf-pro' ),
			implode( ', ', $marked )
		);
	}
	return $planned;
}
add_filter( 'kerf_import_other_pages', 'kerf_pro_ai_prepare_report', 20, 2 );

// ═══════════════════════════════════════════════════════════════════════════════
// THE ROUTE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * POST kerf/v1/ai/prepare { token, file }.
 */
function kerf_pro_ai_prepare_routes() {
	register_rest_route( 'kerf/v1', '/ai/prepare', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_prepare',
		'permission_callback' => 'kerf_pro_ai_prepare_permission',
		'args'                => array(
			'token' => array( 'type' => 'string', 'required' => true ),
			'file'  => array( 'type' => 'string', 'required' => true ),
		),
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_prepare_routes' );

/**
 * Who may mark a page: whoever may import a design, and use AI.
 *
 * @param WP_REST_Request $request
 * @return true|WP_Error
 */
function kerf_pro_ai_prepare_permission( $request ) {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		return new WP_Error( 'kerf_ai_forbidden', __( 'Only someone who may import a design can mark its pages.', 'kerf-pro' ), array( 'status' => 403 ) );
	}
	return kerf_pro_ai_rest_permission( $request );
}

/**
 * Mark the page the check step asked for — as a job (kerf-pro-ai-jobs.php),
 * so a slow model outlasts no host's gateway (§9.28). What can be said at
 * once is: no such page, nothing to mark, or the answer it had.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error The job.
 */
function kerf_pro_ai_rest_prepare( $request ) {
	$token = sanitize_key( (string) $request['token'] );
	$file  = (string) $request['file'];
	$ready = kerf_pro_ai_prepare_ready( $token, $file );
	if ( is_wp_error( $ready ) ) {
		return $ready;
	}
	$job = kerf_pro_ai_job_create(
		'prepare',
		/* translators: %s: file name. */
		array( array( 'key' => 'mark', 'label' => sprintf( __( 'Marking %s', 'kerf-pro' ), $file ) ) ),
		array( 'token' => $token, 'file' => $file )
	);
	if ( is_array( $ready ) ) {
		$job['status'] = 'done';
		$job['at']     = 1;
		$job['result'] = $ready;
		kerf_pro_ai_job_save( $job );
	}
	return rest_ensure_response( kerf_pro_ai_job_view( $job ) );
}

/**
 * The job's one step.
 *
 * @param array $job By reference: its result is the row's answer.
 * @param array $step
 * @return true|WP_Error
 */
function kerf_pro_ai_prepare_job( &$job, $step ) {
	$done = kerf_pro_ai_prepare_pending( (string) $job['data']['token'], (string) $job['data']['file'] );
	if ( is_wp_error( $done ) ) {
		return $done;
	}
	$job['result'] = $done;
	return true;
}

/**
 * The job handler for marking a page.
 *
 * @param array $handlers
 * @return array
 */
function kerf_pro_ai_prepare_handler( $handlers ) {
	$handlers['prepare'] = 'kerf_pro_ai_prepare_job';
	return $handlers;
}
add_filter( 'kerf_pro_ai_job_handlers', 'kerf_pro_ai_prepare_handler' );

/**
 * Can this page of a paused import be marked?
 *
 * @param string $token
 * @param string $file
 * @return true|array|WP_Error True; the answer it had when Gemini marked it
 *                             here before — a host's gateway can give up on
 *                             a slow model while PHP finishes, and asking
 *                             again shows what was marked; or why not.
 */
function kerf_pro_ai_prepare_ready( $token, $file ) {
	$pending = kerf_import_pending_peek( $token );
	if ( ! $pending ) {
		return new WP_Error( 'kerf_ai_expired', __( 'That import has expired or was already finished. Upload the ZIP again.', 'kerf-pro' ), array( 'status' => 404 ) );
	}
	$pages = isset( $pending['staging']['pages'] ) && is_array( $pending['staging']['pages'] ) ? $pending['staging']['pages'] : array();
	if ( ! isset( $pages[ $file ] ) ) {
		return new WP_Error( 'kerf_ai_no_page', __( 'That page is not in this design.', 'kerf-pro' ), array( 'status' => 404 ) );
	}
	$html = (string) $pages[ $file ];
	$kind = kerf_import_classify_page( $file, $html );
	if ( ! isset( kerf_shell_page_types()[ $kind ] ) ) {
		/* translators: %s: file name. */
		return new WP_Error( 'kerf_ai_not_template', sprintf( __( '%s becomes an ordinary page, as it is: there is nothing to mark.', 'kerf-pro' ), $file ), array( 'status' => 400 ) );
	}
	if ( kerf_import_page_is_marked( $html ) ) {
		if ( isset( $pending['staging']['ai_marked'][ $file ] ) ) {
			return kerf_pro_ai_prepare_answer( $file, $kind, (array) $pending['staging']['ai_marked'][ $file ] );
		}
		/* translators: %s: file name. */
		return new WP_Error( 'kerf_ai_marked', sprintf( __( '%s is marked already.', 'kerf-pro' ), $file ), array( 'status' => 400 ) );
	}
	return true;
}

/**
 * Mark one page of a paused import, and put it back in the pause.
 *
 * @param string $token The import's pause (kerf_import_pending_save()).
 * @param string $file  The page's file name, as the check step lists it.
 * @return array{file:string,kind:string,summary:string[],options:array[],selected:string}|WP_Error
 */
function kerf_pro_ai_prepare_pending( $token, $file ) {
	$ready = kerf_pro_ai_prepare_ready( $token, $file );
	if ( true !== $ready ) {
		return $ready;
	}
	$expired = new WP_Error( 'kerf_ai_expired', __( 'That import has expired or was already finished. Upload the ZIP again.', 'kerf-pro' ), array( 'status' => 404 ) );
	$pending = kerf_import_pending_peek( $token );
	$html    = (string) $pending['staging']['pages'][ $file ];
	$kind    = kerf_import_classify_page( $file, $html );

	$prepared = kerf_pro_ai_prepare( $file, $html, $kind );
	if ( is_wp_error( $prepared ) ) {
		return $prepared;
	}

	// Read again before writing: the model took a while, and another page may
	// have been marked meanwhile — put() replaces the whole pause.
	$pending = kerf_import_pending_peek( $token );
	if ( ! $pending || ! isset( $pending['staging']['pages'][ $file ] ) ) {
		return $expired;
	}
	if ( $pending['staging']['pages'][ $file ] !== $html ) {
		return new WP_Error( 'kerf_ai_changed', __( 'That page changed while Gemini read it. Try again.', 'kerf-pro' ), array( 'status' => 409 ) );
	}
	$pending['staging']['pages'][ $file ]     = $prepared['html'];
	$pending['staging']['ai_marked'][ $file ] = $prepared['summary'];
	if ( ! kerf_import_pending_put( $token, $pending ) ) {
		return $expired;
	}

	return kerf_pro_ai_prepare_answer( $file, $kind, $prepared['summary'] );
}

/**
 * What the check step's row is told: what was marked, and what the file can
 * become now that WordPress can use it.
 *
 * @param string   $file
 * @param string   $kind
 * @param string[] $summary
 * @return array{file:string,kind:string,summary:string[],options:array[],selected:string}
 */
function kerf_pro_ai_prepare_answer( $file, $kind, $summary ) {
	$options = array();
	foreach ( kerf_pages_type_options( $kind, true ) as $value => $label ) {
		// A list, not an object: a browser puts a key like "404" first.
		$options[] = array( 'value' => (string) $value, 'label' => $label );
	}
	return array(
		'file'     => $file,
		'kind'     => $kind,
		'summary'  => array_values( array_map( 'strval', $summary ) ),
		'options'  => $options,
		'selected' => $kind,
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// MARKING A PAGE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Mark a page for WordPress: number it, ask, check, apply, prove.
 *
 * @param string $file
 * @param string $html The file as the design wrote it.
 * @param string $kind A page type (kerf_shell_page_types()).
 * @return array{html:string,summary:string[]}|WP_Error
 */
function kerf_pro_ai_prepare( $file, $html, $kind ) {
	$tree = kerf_pro_ai_prepare_tree( kerf_pro_ai_prepare_number( $html ) );
	$hash = md5( $kind . "\n" . $html );
	$kept = get_option( KERF_PRO_AI_PREPARED_OPTION, array() );
	$kept = is_array( $kept ) ? $kept : array();

	if ( isset( $kept[ $hash ]['placements'] ) && is_array( $kept[ $hash ]['placements'] ) ) {
		$placements = $kept[ $hash ]['placements'];
	} else {
		$copy = kerf_pro_ai_prepare_compact( $tree['root'] );
		if ( strlen( $copy ) > KERF_PRO_AI_PREPARE_MAX ) {
			/* translators: %s: file name. */
			return new WP_Error( 'kerf_ai_too_large', sprintf( __( '%s is too large for the AI to read at once.', 'kerf-pro' ), $file ), array( 'status' => 413 ) );
		}
		$answer = kerf_pro_ai_request(
			'prepare',
			kerf_pro_ai_prepare_instructions( $kind ),
			array( array( 'text' => 'The file ' . $file . ":\n\n" . $copy ) ),
			array(
				'tier'        => 'pro',
				'json'        => true,
				'temperature' => 0.1,
				'schema'      => kerf_pro_ai_prepare_schema(),
			)
		);
		if ( is_wp_error( $answer ) ) {
			return $answer;
		}
		$placements = isset( $answer['json']['placements'] ) && is_array( $answer['json']['placements'] ) ? $answer['json']['placements'] : array();
	}
	$placements = array_slice( array_values( $placements ), 0, 300 );

	$checked = kerf_pro_ai_prepare_check( $placements, $tree, $kind, $file );
	if ( is_wp_error( $checked ) ) {
		return $checked;
	}
	$marked = kerf_pro_ai_prepare_apply( $html, $checked['marks'], $kind );
	$proved = kerf_pro_ai_prepare_prove( $html, $marked, $file, $kind );
	if ( is_wp_error( $proved ) ) {
		return $proved;
	}

	// The answer is kept as the model gave it, and checked again — by the
	// rules of the day — whenever it is used. Read again first: other pages'
	// answers were kept while the model worked on this one.
	$kept          = kerf_pro_ai_fresh_option( KERF_PRO_AI_PREPARED_OPTION );
	$kept          = is_array( $kept ) ? $kept : array();
	$kept[ $hash ] = array( 'placements' => $placements, 'time' => time() );
	uasort( $kept, static function ( $a, $b ) {
		return ( isset( $b['time'] ) ? (int) $b['time'] : 0 ) <=> ( isset( $a['time'] ) ? (int) $a['time'] : 0 );
	} );
	update_option( KERF_PRO_AI_PREPARED_OPTION, array_slice( $kept, 0, 20, true ), false );

	return array( 'html' => $marked, 'summary' => kerf_pro_ai_prepare_summary( $checked ) );
}

/**
 * Number every tag of a page, in the order it is written: the copy the model
 * reads carries `data-k="n<i>"` on each element.
 *
 * WordPress's tag processor reads tags as a browser does — a `<div>` in a
 * script's text is no tag — and changes only the tag it is on. The answer is
 * applied counting the same way over the same file
 * (kerf_pro_ai_prepare_apply()), so n12 is the twelfth tag both times.
 *
 * @param string $html
 * @return string The numbered copy.
 */
function kerf_pro_ai_prepare_number( $html ) {
	$tags = new WP_HTML_Tag_Processor( (string) $html );
	$n    = 0;
	while ( $tags->next_tag() ) {
		$tags->set_attribute( 'data-k', 'n' . ( ++$n ) );
	}
	return $tags->get_updated_html();
}

/**
 * The numbered copy's body as the converter reads a page — libxml's tree, as
 * kerf_import_page_fingerprint() and the converter parse it — with each
 * numbered element by its number. What the model marks is checked against
 * this tree: the lists, cards and fields as the converter will see them.
 *
 * @param string $numbered
 * @return array{doc:DOMDocument,root:DOMElement,nodes:array<string,DOMElement>}
 */
function kerf_pro_ai_prepare_tree( $numbered ) {
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	// Never LIBXML_NOENT: it substitutes entities, external ones too (scar 62).
	$doc->loadHTML( '<?xml encoding="utf-8"?><div>' . kerf_mc_extract_body( $numbered ) . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();

	$nodes = array();
	foreach ( $doc->getElementsByTagName( '*' ) as $el ) {
		$k = $el->getAttribute( 'data-k' );
		if ( '' !== $k && ! isset( $nodes[ $k ] ) ) {
			$nodes[ $k ] = $el;
		}
	}
	return array( 'doc' => $doc, 'root' => $doc->documentElement, 'nodes' => $nodes );
}

/**
 * The page as the model reads it: its elements with their numbers, classes
 * and words — without what costs tokens and says nothing about where a post's
 * title or date is: scripts, styles, templates, an SVG's drawing, most
 * attributes, long text.
 *
 * @param DOMElement $root
 * @return string
 */
function kerf_pro_ai_prepare_compact( $root ) {
	$block = array( 'address', 'article', 'aside', 'blockquote', 'dd', 'div', 'dl', 'dt', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'header', 'hr', 'li', 'main', 'nav', 'ol', 'p', 'section', 'table', 'tbody', 'td', 'tfoot', 'th', 'thead', 'tr', 'ul' );
	$void  = array( 'area', 'br', 'col', 'embed', 'hr', 'img', 'input', 'source', 'track', 'wbr' );
	$out   = '';
	$walk  = static function ( $node ) use ( &$walk, &$out, $block, $void ) {
		foreach ( $node->childNodes as $child ) {
			if ( XML_TEXT_NODE === $child->nodeType || XML_CDATA_SECTION_NODE === $child->nodeType ) {
				$text = trim( (string) preg_replace( '/\s+/u', ' ', $child->textContent ) );
				if ( '' !== $text ) {
					$out .= esc_html( mb_strlen( $text ) > 140 ? mb_substr( $text, 0, 139 ) . '…' : $text );
				}
				continue;
			}
			if ( XML_ELEMENT_NODE !== $child->nodeType ) {
				continue;
			}
			$tag = strtolower( $child->nodeName );
			if ( in_array( $tag, array( 'script', 'style', 'noscript', 'template', 'link', 'meta' ), true ) ) {
				continue;
			}
			$out .= ( in_array( $tag, $block, true ) ? "\n" : '' ) . '<' . $tag . kerf_pro_ai_prepare_compact_attributes( $child ) . '>';
			if ( in_array( $tag, $void, true ) ) {
				continue;
			}
			if ( 'svg' !== $tag ) {
				$walk( $child );
			}
			$out .= '</' . $tag . '>';
		}
	};
	$walk( $root );
	return trim( $out );
}

/**
 * The attributes the model reads on an element: its number, what names it
 * (id, a few classes, role, label), where it leads and what it shows.
 *
 * @param DOMElement $el
 * @return string
 */
function kerf_pro_ai_prepare_compact_attributes( $el ) {
	$out = '';
	foreach ( array( 'data-k', 'id', 'class', 'href', 'src', 'alt', 'type', 'name', 'placeholder', 'role', 'aria-label', 'datetime', 'action', 'style' ) as $name ) {
		if ( ! $el->hasAttribute( $name ) ) {
			continue;
		}
		$value = trim( $el->getAttribute( $name ) );
		if ( 'style' === $name ) {
			// Only a picture: a card's photo is often a background.
			if ( ! preg_match( '/url\(\s*[\'"]?([^\'")]+)/i', $value, $found ) ) {
				continue;
			}
			$value = 'background-image:url(' . wp_basename( $found[1] ) . ')';
		} elseif ( 'src' === $name ) {
			$value = 0 === stripos( $value, 'data:' ) ? 'data:…' : wp_basename( (string) strtok( $value, '?#' ) );
		} elseif ( 'class' === $name ) {
			$value = implode( ' ', array_slice( preg_split( '/\s+/', $value ), 0, 6 ) );
		}
		$out .= ' ' . $name . '="' . esc_attr( mb_substr( $value, 0, 100 ) ) . '"';
	}
	foreach ( kerf_mc_image_data_attributes( $el ) as $name => $value ) {
		$out .= ' ' . $name . '="' . esc_attr( wp_basename( $value ) ) . '"';
	}
	return $out;
}

/**
 * What the model is told: the contract, what this kind of page needs, and
 * that it answers with placements only.
 *
 * @param string $kind
 * @return string
 */
function kerf_pro_ai_prepare_instructions( $kind ) {
	$types = kerf_shell_page_types();
	// The template is Kerf's to set: it knows the kind.
	$contract = array_values( array_filter( kerf_shell_contract_lines(), static function ( $line ) {
		return false === strpos( $line, 'data-kerf-template' );
	} ) );
	// Every list of posts, or a sidebar's samples stay the designer's — gymlife's
	// has a large latest post and small ones beside it: two lists. A listing
	// page's category and tag lists are the site's, not a post's own
	// (`data-kerf-loop="tags"` is the post's), so they stay as drawn.
	$lists = ' Mark every other list of posts on the page too — recent or popular posts in a sidebar take data-kerf-loop="latest" on the first card of each list; a large featured post beside smaller ones is two lists. Lists of categories or tags on this page stay as they are: do not mark them.';
	$needs = array(
		'home'    => 'This page is the blog: a list of posts. It needs data-kerf-loop on the first post card of that list, and inside that card at least the title.' . $lists,
		'archive' => 'This page lists the posts of a category or a tag. It needs data-kerf-loop on the first post card, and inside that card at least the title; the category\'s name takes archive-title.' . $lists,
		'search'  => 'This page shows search results, a list of posts. It needs data-kerf-loop on the first result card, and inside that card at least the title; the words searched for take search-query.' . $lists,
		'single'  => 'This page is one blog post. It needs data-kerf-field="content" on the element that holds the article\'s text, and the post\'s title.',
		'page'    => 'This page is a page written in WordPress, such as About. It needs data-kerf-field="content" on the element that holds the page\'s text, and its title.',
		'404'     => 'This page says that a page was not found. A search form on it works without a marker; a list of recent posts takes data-kerf-loop="latest" on its first card. If WordPress fills in nothing on it, answer with no placements.',
	);

	return implode( "\n", array_merge(
		array(
			'You prepare one page of a website design for WordPress. Kerf will use it as WordPress\'s template for: ' . $types[ $kind ]['label'] . '. You do not change the page: you say where Kerf adds the attributes below, and Kerf adds them.',
			'Every element of the page carries data-k="n…", its number. Scripts, styles, the drawing inside SVGs and most attributes were left out of your copy, and long text was shortened.',
			'',
		),
		$contract,
		array(
			'',
			$needs[ $kind ],
			'',
			'Answer with placements. Each names an element by its number (node), the attribute (data-kerf-loop or data-kerf-field) and its value.',
			'- data-kerf-loop goes on the FIRST card of a list only: the element that repeats once per post. Kerf marks the other cards of that list itself. Put that card\'s fields on elements inside it.',
			'- data-kerf-field goes on the innermost element that holds the text, the link or the picture. Two fields on one element share one placement: "title permalink".',
			'- Only elements that are on the page; only the names and values listed above. Leave out what the page does not have. Do not mark the site\'s header, menu or footer.',
		)
	) );
}

/**
 * The answer's shape (an OpenAPI subset, as Gemini reads it).
 *
 * @return array
 */
function kerf_pro_ai_prepare_schema() {
	return array(
		'type'       => 'OBJECT',
		'properties' => array(
			'placements' => array(
				'type'  => 'ARRAY',
				'items' => array(
					'type'       => 'OBJECT',
					'properties' => array(
						'node'      => array( 'type' => 'STRING' ),
						'attribute' => array( 'type' => 'STRING', 'enum' => array( 'data-kerf-loop', 'data-kerf-field' ) ),
						'value'     => array( 'type' => 'STRING' ),
					),
					'required'   => array( 'node', 'attribute', 'value' ),
				),
			),
		),
		'required'   => array( 'placements' ),
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// CHECKING THE ANSWER
// ═══════════════════════════════════════════════════════════════════════════════
//
// What the model says is untrusted, like a mockup (§6). A placement is kept
// only when it names an element of the page, an attribute and value of the
// contract (kerf_mc_contract_fields()), and an element that can hold it where
// it stands: a card's fields inside its card, a search box on an <input>. A
// few slips are corrected the way the converter would want them — the title
// on the <h3> moves to the link inside it; the marker on a grid's card moves
// to the column that repeats — and the rest are left out and counted. What
// the kind of page cannot do without (a blog's list, a post's text) refuses
// the whole answer: a half-marked blog would still show its samples.

/**
 * Check the model's placements against the page.
 *
 * @param array  $placements [ { node, attribute, value } ].
 * @param array  $tree       From kerf_pro_ai_prepare_tree().
 * @param string $kind
 * @param string $file       For the messages.
 * @return array{marks:array<string,array<string,string>>,cards:array[],fields:string[],refused:array[]}|WP_Error
 */
function kerf_pro_ai_prepare_check( $placements, $tree, $kind, $file ) {
	$contract = kerf_mc_contract_fields();
	$known    = array_unique( array_merge( array_keys( $contract['text'] ), array_keys( $contract['url'] ), $contract['other'] ) );
	$listing  = in_array( $kind, array( 'home', 'archive', 'search' ), true );
	$loops    = $listing ? array( '', 'main', 'latest' )
		: ( '404' === $kind ? array( '', 'latest' ) : array( '', 'latest', 'comments', 'tags', 'categories' ) );

	$refused = array();
	$wanted  = array( 'loops' => array(), 'fields' => array() );
	foreach ( $placements as $placement ) {
		$node  = is_array( $placement ) && isset( $placement['node'] ) && is_scalar( $placement['node'] ) ? trim( (string) $placement['node'] ) : '';
		$name  = is_array( $placement ) && isset( $placement['attribute'] ) && is_scalar( $placement['attribute'] ) ? strtolower( trim( (string) $placement['attribute'] ) ) : '';
		$value = is_array( $placement ) && isset( $placement['value'] ) && is_scalar( $placement['value'] ) ? strtolower( trim( (string) preg_replace( '/\s+/', ' ', (string) $placement['value'] ) ) ) : '';

		if ( ! preg_match( '/^n\d+$/', $node ) || ! isset( $tree['nodes'][ $node ] ) ) {
			$refused[] = array( $node, 'no such element' );
		} elseif ( 'data-kerf-loop' === $name ) {
			if ( in_array( $value, $loops, true ) ) {
				$wanted['loops'][] = array( $tree['nodes'][ $node ], $value );
			} else {
				$refused[] = array( $node, 'not a list of this page' );
			}
		} elseif ( 'data-kerf-field' === $name ) {
			$names = array_values( array_unique( array_filter( explode( ' ', $value ) ) ) );
			if ( $names && ! array_diff( $names, $known ) ) {
				foreach ( $names as $field ) {
					$wanted['fields'][] = array( $tree['nodes'][ $node ], $field, $node );
				}
			} else {
				$refused[] = array( $node, 'not a field of the contract' );
			}
		} else {
			$refused[] = array( $node, 'not an attribute of the contract' );
		}
	}

	// The cards. Each list's first card carries the marker, and Kerf marks the
	// others: the converter repeats the first and drops the marked rest
	// (kerf_mc_wrap_loop()); an unmarked sample after them would stay a post.
	// A model that marks every card, as the brief asks a designer to, has
	// said nothing wrong: the later ones are passed over without a word.
	$cards   = array();
	$samples = array();
	$later   = array();
	foreach ( $wanted['loops'] as $loop ) {
		list( $el, $value ) = $loop;
		$title = null;
		foreach ( $wanted['fields'] as $field ) {
			if ( in_array( $field[1], array( 'title', 'permalink' ), true ) && kerf_pro_ai_prepare_within( $field[0], $el ) ) {
				$title = $field[0];
				break;
			}
		}
		$card = kerf_pro_ai_prepare_card( $el, $tree['root'], $title );
		if ( ! $card || '' === $card->getAttribute( 'data-k' ) ) {
			$later[] = $el;
			continue;
		}
		foreach ( $cards as $known_card ) {
			if ( $known_card['el'] === $card || kerf_pro_ai_prepare_within( $card, $known_card['el'] ) ) {
				// One list, said twice; or a list inside a card of another.
				continue 2;
			}
		}
		$others = array();
		foreach ( kerf_pro_ai_prepare_alike( $card, 'next' ) as $other ) {
			if ( '' !== $other->getAttribute( 'data-k' ) ) {
				$others[]  = $other;
				$samples[] = $other;
			}
		}
		$cards[] = array( 'el' => $card, 'value' => $value, 'others' => $others );
	}
	foreach ( $later as $el ) {
		if ( 'sample' !== kerf_pro_ai_prepare_where( $el, $cards, $samples ) ) {
			$refused[] = array( $el->getAttribute( 'data-k' ), 'a sample card after the first, of a list with no first' );
		}
	}

	// The fields, each on the element that can hold it, where it stands.
	$fields = array();
	$marks  = array();
	foreach ( $wanted['fields'] as $wanted_field ) {
		list( $el, $field, $node ) = $wanted_field;
		$targets = kerf_pro_ai_prepare_targets( $el, $field );
		if ( ! $targets ) {
			$refused[] = array( $node, $field . ' cannot go on this element' );
			continue;
		}
		$where = kerf_pro_ai_prepare_where( $targets[0], $cards, $samples );
		if ( 'sample' === $where ) {
			// The converter drops that card: marked or not, it is not shown.
			continue;
		}
		// A tag's link is the tag's, not a post's: what a model means by
		// "permalink" on it (it says so on every tag cloud).
		if ( 'permalink' === $field && in_array( $where, array( 'tags', 'categories' ), true ) ) {
			$field = 'term-link';
		}
		if ( ! in_array( $field, kerf_pro_ai_prepare_fields_for( $where, $kind ), true ) ) {
			$refused[] = array( $node, $field . ' does not belong there' );
			continue;
		}
		foreach ( $targets as $target ) {
			$k    = $target->getAttribute( 'data-k' );
			$have = isset( $marks[ $k ]['data-kerf-field'] ) ? explode( ' ', $marks[ $k ]['data-kerf-field'] ) : array();
			if ( ! in_array( $field, $have, true ) ) {
				$have[] = $field;
			}
			$marks[ $k ]['data-kerf-field'] = implode( ' ', $have );
		}
		$fields[] = $field;
	}

	// What this kind of page cannot do without.
	if ( $listing ) {
		$main = false;
		foreach ( $cards as $card ) {
			if ( in_array( $card['value'], array( '', 'main' ), true ) ) {
				foreach ( $marks as $k => $mark ) {
					$el = $tree['nodes'][ $k ];
					if ( array_intersect( array( 'title', 'permalink' ), explode( ' ', isset( $mark['data-kerf-field'] ) ? $mark['data-kerf-field'] : '' ) )
						&& kerf_pro_ai_prepare_within( $el, $card['el'] ) ) {
						$main = true;
						break 2;
					}
				}
			}
		}
		if ( ! $main ) {
			/* translators: %s: file name. */
			return new WP_Error( 'kerf_ai_prepare_incomplete', sprintf( __( 'Gemini did not find the list of posts on %s and its titles, so Kerf left the page as it was. Try again, or mark it with the brief under Kerf → Inner pages.', 'kerf-pro' ), $file ), array( 'status' => 422 ) );
		}
	} elseif ( in_array( $kind, array( 'single', 'page' ), true ) && ! in_array( 'content', $fields, true ) ) {
		/* translators: %s: file name. */
		return new WP_Error( 'kerf_ai_prepare_incomplete', sprintf( __( 'Gemini did not find where the text goes on %s, so Kerf left the page as it was. Try again, or mark it with the brief under Kerf → Inner pages.', 'kerf-pro' ), $file ), array( 'status' => 422 ) );
	}

	foreach ( $cards as $card ) {
		foreach ( array_merge( array( $card['el'] ), $card['others'] ) as $el ) {
			$marks[ $el->getAttribute( 'data-k' ) ]['data-kerf-loop'] = $card['value'];
		}
	}

	return array( 'marks' => $marks, 'cards' => $cards, 'fields' => array_values( array_unique( $fields ) ), 'refused' => $refused );
}

/**
 * The card a list's marker belongs on, from the element the model chose: that
 * element when it repeats; the wrapper it sits in when that repeats instead —
 * a grid's columns, each holding one card; the repeated card inside it that
 * holds the title, when the model chose the whole list. Null when the choice
 * is a sample after the first: its fields would be in a card the converter
 * drops.
 *
 * @param DOMElement      $el
 * @param DOMElement      $root
 * @param DOMElement|null $title An element marked title or permalink inside it.
 * @return DOMElement|null
 */
function kerf_pro_ai_prepare_card( $el, $root, $title = null ) {
	if ( kerf_pro_ai_prepare_alike( $el ) ) {
		return kerf_pro_ai_prepare_alike( $el, 'previous' ) ? null : $el;
	}

	$shape = kerf_pro_ai_prepare_shape( $el );
	$up    = $el->parentNode;
	for ( $level = 0; $level < 3 && $up instanceof DOMElement && $up !== $root; $level++, $up = $up->parentNode ) {
		$alike = kerf_pro_ai_prepare_alike( $up );
		if ( ! $alike ) {
			continue;
		}
		foreach ( $alike as $other ) {
			if ( kerf_pro_ai_prepare_holds( $other, $shape ) ) {
				return kerf_pro_ai_prepare_alike( $up, 'previous' ) ? null : $up;
			}
		}
		// Repeated, but not cards like this one: a page's sections.
		break;
	}

	if ( $title && $title !== $el && kerf_pro_ai_prepare_within( $title, $el ) ) {
		$child = $title;
		while ( $child->parentNode !== $el ) {
			$child = $child->parentNode;
		}
		if ( kerf_pro_ai_prepare_alike( $child ) ) {
			return kerf_pro_ai_prepare_alike( $child, 'previous' ) ? null : $child;
		}
	}
	return $el;
}

/**
 * The elements a field goes on, from the one the model chose — none when no
 * element there can hold it.
 *
 * @param DOMElement $el
 * @param string     $field
 * @return DOMElement[]
 */
function kerf_pro_ai_prepare_targets( $el, $field ) {
	$tag  = strtolower( $el->nodeName );
	$void = array( 'img', 'input', 'br', 'hr', 'source', 'track', 'wbr', 'area', 'col', 'embed', 'select', 'textarea' );

	if ( in_array( $field, array( 'image', 'author-avatar', 'comment-avatar' ), true ) ) {
		// A post's picture may be a background — the element's own style, or
		// an attribute a script reads (kerf_mc_image_data_attributes()).
		if ( 'img' === $tag || ( 'image' === $field && ( preg_match( '/url\(/i', $el->getAttribute( 'style' ) ) || kerf_mc_image_data_attributes( $el ) ) ) ) {
			return array( $el );
		}
		$only = kerf_pro_ai_prepare_only( $el, 'img' );
		return $only ? array( $only ) : array();
	}
	if ( in_array( $field, array( 'search-form', 'comment-form', 'search-input' ), true ) ) {
		$want = 'search-input' === $field ? 'input' : 'form';
		$only = $want === $tag ? $el : kerf_pro_ai_prepare_only( $el, $want );
		return $only ? array( $only ) : array();
	}
	if ( in_array( $field, array( 'content', 'comments', 'pagination', 'none' ), true ) ) {
		return in_array( $tag, $void, true ) ? array() : array( $el );
	}

	// Text, or a link: on the innermost element — `<h3><a>A title</a></h3>`
	// is the link's, which keeps the link to the post.
	$el  = kerf_pro_ai_prepare_innermost( $el );
	$tag = strtolower( $el->nodeName );
	if ( in_array( $field, array( 'permalink', 'term-link' ), true ) ) {
		return 'a' === $tag ? array( $el ) : array();
	}
	if ( 'a' === $tag && kerf_pro_ai_prepare_has_elements( $el ) ) {
		// A link holding elements takes its address from the field, and its
		// words only where an element inside it is marked too
		// (kerf_mc_bind_fields()): the field goes on both, the way the brief
		// writes a card link.
		$targets = isset( kerf_mc_contract_fields()['url'][ $field ] ) ? array( $el ) : array();
		$inner   = kerf_pro_ai_prepare_innermost( $el, false );
		if ( $inner !== $el && kerf_pro_ai_prepare_holds_text( $inner ) ) {
			$targets[] = $inner;
		}
		return $targets;
	}
	return kerf_pro_ai_prepare_holds_text( $el ) ? array( $el ) : array();
}

/**
 * Can an element's text be replaced? A heading, a paragraph or a link takes
 * its text whatever is inside it; any other element holding elements cannot
 * (kerf_mc_bind_fields()' warning).
 *
 * @param DOMElement $el
 * @return bool
 */
function kerf_pro_ai_prepare_holds_text( $el ) {
	return in_array( strtolower( $el->nodeName ), array( 'a', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) || ! kerf_pro_ai_prepare_has_elements( $el );
}

/**
 * Does an element hold elements?
 *
 * @param DOMElement $el
 * @return bool
 */
function kerf_pro_ai_prepare_has_elements( $el ) {
	foreach ( $el->childNodes as $child ) {
		if ( XML_ELEMENT_NODE === $child->nodeType ) {
			return true;
		}
	}
	return false;
}

/**
 * The innermost element holding the same words: down through elements that
 * only wrap one numbered element — stopping at a link, unless starting from
 * one.
 *
 * @param DOMElement $el
 * @param bool       $stop_at_link
 * @return DOMElement
 */
function kerf_pro_ai_prepare_innermost( $el, $stop_at_link = true ) {
	while ( ! ( $stop_at_link && 'a' === strtolower( $el->nodeName ) ) ) {
		$only = null;
		foreach ( $el->childNodes as $child ) {
			if ( XML_TEXT_NODE === $child->nodeType && '' !== trim( $child->textContent ) ) {
				return $el;
			}
			if ( XML_ELEMENT_NODE === $child->nodeType ) {
				if ( $only ) {
					return $el;
				}
				$only = $child;
			}
		}
		if ( ! $only || '' === $only->getAttribute( 'data-k' ) ) {
			return $el;
		}
		$el           = $only;
		$stop_at_link = true;
	}
	return $el;
}

/**
 * The one numbered element of a kind inside an element, or null when there
 * is none or more than one.
 *
 * @param DOMElement $el
 * @param string     $tag
 * @return DOMElement|null
 */
function kerf_pro_ai_prepare_only( $el, $tag ) {
	$found = $el->getElementsByTagName( $tag );
	return 1 === $found->length && '' !== $found->item( 0 )->getAttribute( 'data-k' ) ? $found->item( 0 ) : null;
}

/**
 * Where an element stands: in a list's first card (its value), in a sample
 * card after it, or outside every list.
 *
 * @param DOMElement   $el
 * @param array[]      $cards
 * @param DOMElement[] $samples
 * @return string 'post', 'comments', 'tags', 'categories', 'sample' or ''.
 */
function kerf_pro_ai_prepare_where( $el, $cards, $samples ) {
	for ( $node = $el; $node instanceof DOMElement; $node = $node->parentNode ) {
		foreach ( $cards as $card ) {
			if ( $card['el'] === $node ) {
				return in_array( $card['value'], array( 'comments', 'tags', 'categories' ), true ) ? $card['value'] : 'post';
			}
		}
		if ( in_array( $node, $samples, true ) ) {
			return 'sample';
		}
	}
	return '';
}

/**
 * The fields an element may hold where it stands, on this kind of page.
 *
 * @param string $where From kerf_pro_ai_prepare_where().
 * @param string $kind
 * @return string[]
 */
function kerf_pro_ai_prepare_fields_for( $where, $kind ) {
	$by_card = array(
		'post'       => array( 'title', 'permalink', 'date', 'author', 'category', 'excerpt', 'image', 'tags', 'comments-count', 'none' ),
		'comments'   => array( 'comment-author', 'comment-date', 'comment-text', 'comment-avatar', 'none' ),
		'tags'       => array( 'term-name', 'term-link', 'none' ),
		'categories' => array( 'term-name', 'term-link', 'none' ),
	);
	if ( isset( $by_card[ $where ] ) ) {
		return $by_card[ $where ];
	}
	if ( in_array( $kind, array( 'home', 'archive', 'search' ), true ) ) {
		return array( 'archive-title', 'archive-description', 'search-query', 'result-count', 'search-form', 'search-input', 'pagination', 'none' );
	}
	if ( '404' === $kind ) {
		return array( 'search-form', 'search-input', 'none' );
	}
	return array( 'title', 'permalink', 'date', 'author', 'category', 'excerpt', 'image', 'tags', 'comments-count', 'content', 'comments', 'comment-form', 'prev', 'next', 'author-bio', 'author-avatar', 'search-form', 'search-input', 'none' );
}

/**
 * The tag and first class a list's cards share (kerf_mc_marked_sibling()'s
 * rule: one list's cards are the same tag with the same first class).
 *
 * @param DOMElement $el
 * @return string
 */
function kerf_pro_ai_prepare_shape( $el ) {
	$classes = preg_split( '/\s+/', trim( $el->getAttribute( 'class' ) ) );
	return strtolower( $el->nodeName ) . '.' . $classes[0];
}

/**
 * The element siblings shaped like this one: the other cards of its list.
 *
 * @param DOMElement $el
 * @param string     $direction 'previous', 'next' or 'both'.
 * @return DOMElement[]
 */
function kerf_pro_ai_prepare_alike( $el, $direction = 'both' ) {
	$found = array();
	$shape = kerf_pro_ai_prepare_shape( $el );
	foreach ( array( 'previous' => 'previousSibling', 'next' => 'nextSibling' ) as $way => $property ) {
		if ( 'both' !== $direction && $way !== $direction ) {
			continue;
		}
		for ( $sibling = $el->$property; $sibling; $sibling = $sibling->$property ) {
			if ( XML_ELEMENT_NODE === $sibling->nodeType && kerf_pro_ai_prepare_shape( $sibling ) === $shape ) {
				$found[] = $sibling;
			}
		}
	}
	return $found;
}

/**
 * Does an element hold one of this shape?
 *
 * @param DOMElement $el
 * @param string     $shape
 * @return bool
 */
function kerf_pro_ai_prepare_holds( $el, $shape ) {
	foreach ( $el->getElementsByTagName( '*' ) as $inside ) {
		if ( kerf_pro_ai_prepare_shape( $inside ) === $shape ) {
			return true;
		}
	}
	return false;
}

/**
 * Is an element this one, or inside it?
 *
 * @param DOMNode $el
 * @param DOMNode $ancestor
 * @return bool
 */
function kerf_pro_ai_prepare_within( $el, $ancestor ) {
	for ( $node = $el; $node; $node = $node->parentNode ) {
		if ( $node === $ancestor ) {
			return true;
		}
	}
	return false;
}

// ═══════════════════════════════════════════════════════════════════════════════
// APPLYING, AND PROVING IT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Add the checked markers to the file as written, counting tags as
 * kerf_pro_ai_prepare_number() did, and the page's kind to its `<body>`.
 *
 * @param string $html
 * @param array  $marks n<i> => [ attribute => value ].
 * @param string $kind
 * @return string
 */
function kerf_pro_ai_prepare_apply( $html, $marks, $kind ) {
	$tags = new WP_HTML_Tag_Processor( (string) $html );
	$n    = 0;
	$body = false;
	while ( $tags->next_tag() ) {
		$k = 'n' . ( ++$n );
		if ( ! $body && 'BODY' === $tags->get_tag() ) {
			$tags->set_attribute( 'data-kerf-template', $kind );
			$body = true;
		}
		if ( isset( $marks[ $k ] ) ) {
			foreach ( $marks[ $k ] as $name => $value ) {
				// Only the contract's names reach here (kerf_pro_ai_prepare_check()).
				if ( in_array( $name, array( 'data-kerf-loop', 'data-kerf-field' ), true ) ) {
					$tags->set_attribute( $name, (string) $value );
				}
			}
		}
	}
	return $tags->get_updated_html();
}

/**
 * Prove the marked file is the same page, only marked: the fingerprint that
 * leaves markers out is the original's, it carries the contract, and it is
 * still the kind of page it was.
 *
 * @param string $original
 * @param string $marked
 * @param string $file
 * @param string $kind
 * @return true|WP_Error
 */
function kerf_pro_ai_prepare_prove( $original, $marked, $file, $kind ) {
	if ( kerf_import_page_fingerprint( $marked ) !== kerf_import_page_fingerprint( $original )
		|| ! kerf_import_page_is_marked( $marked )
		|| kerf_import_classify_page( $file, $marked ) !== $kind ) {
		/* translators: %s: file name. */
		return new WP_Error( 'kerf_ai_prepare_changed', sprintf( __( 'Marking %s would have changed more than its markers, so Kerf left it as it was.', 'kerf-pro' ), $file ), array( 'status' => 422 ) );
	}
	return true;
}

/**
 * What was marked, in plain words, for the check step.
 *
 * @param array $checked From kerf_pro_ai_prepare_check().
 * @return string[]
 */
function kerf_pro_ai_prepare_summary( $checked ) {
	$lines = array();
	foreach ( $checked['cards'] as $card ) {
		$count = 1 + count( $card['others'] );
		switch ( $card['value'] ) {
			case 'comments':
				/* translators: %s: an element, as "<li> .comment". */
				$line = __( 'Repeats for each comment: %s.', 'kerf-pro' );
				break;
			case 'tags':
			case 'categories':
				/* translators: %s: an element, as "<a> .tag". */
				$line = __( 'Repeats for each tag or category: %s.', 'kerf-pro' );
				break;
			case 'latest':
				/* translators: %s: an element, as "<div> .recent-post". */
				$line = __( 'Shows your latest posts: %s.', 'kerf-pro' );
				break;
			default:
				/* translators: %s: an element, as "<article> .post-card". */
				$line = __( 'Repeats for each post: %s.', 'kerf-pro' );
		}
		$line = sprintf( $line, kerf_mc_describe( $card['el'] ) );
		if ( $count > 1 ) {
			$line .= ' ' . sprintf(
				'latest' === $card['value']
					/* translators: %d: how many sample cards the design drew. */
					? _n( 'As many as the design\'s %d sample.', 'As many as the design\'s %d samples.', $count, 'kerf-pro' )
					/* translators: %d: how many sample cards the design drew. */
					: _n( 'The first of the design\'s %d sample is used.', 'The first of the design\'s %d samples is used.', $count, 'kerf-pro' ),
				$count
			);
		}
		$lines[] = $line;
	}

	$labels = kerf_pro_ai_prepare_field_labels();
	$filled = array();
	foreach ( $labels as $field => $label ) {
		if ( in_array( $field, $checked['fields'], true ) ) {
			$filled[] = $label;
		}
	}
	if ( $filled ) {
		/* translators: %s: list of things, as "title, date, picture". */
		$lines[] = sprintf( __( 'WordPress fills in: %s.', 'kerf-pro' ), implode( ', ', $filled ) );
	} elseif ( ! $checked['cards'] ) {
		// A page-not-found page usually has nothing of WordPress's on it.
		$lines[] = __( 'Nothing on it is WordPress\'s to fill in: it is used as drawn.', 'kerf-pro' );
	}
	if ( $checked['refused'] ) {
		$lines[] = sprintf(
			/* translators: %d: how many markers. */
			_n( 'Kerf left out %d marker of Gemini\'s that did not fit.', 'Kerf left out %d markers of Gemini\'s that did not fit.', count( $checked['refused'] ), 'kerf-pro' ),
			count( $checked['refused'] )
		);
	}
	$lines[] = __( 'Nothing else in the file changed.', 'kerf-pro' );
	return $lines;
}

/**
 * The contract's fields as an owner reads them, in the order they are said.
 *
 * @return array<string,string>
 */
function kerf_pro_ai_prepare_field_labels() {
	return array(
		'title'               => __( 'title', 'kerf-pro' ),
		'permalink'           => __( 'link to the post', 'kerf-pro' ),
		'image'               => __( 'picture', 'kerf-pro' ),
		'date'                => __( 'date', 'kerf-pro' ),
		'author'              => __( 'author', 'kerf-pro' ),
		'category'            => __( 'category', 'kerf-pro' ),
		'excerpt'             => __( 'summary', 'kerf-pro' ),
		'tags'                => __( 'tags', 'kerf-pro' ),
		'comments-count'      => __( 'number of comments', 'kerf-pro' ),
		'content'             => __( 'the text', 'kerf-pro' ),
		'author-bio'          => __( 'about the author', 'kerf-pro' ),
		'author-avatar'       => __( 'the author\'s picture', 'kerf-pro' ),
		'prev'                => __( 'previous post', 'kerf-pro' ),
		'next'                => __( 'next post', 'kerf-pro' ),
		'comments'            => __( 'comments', 'kerf-pro' ),
		'comment-author'      => __( 'commenter', 'kerf-pro' ),
		'comment-date'        => __( 'comment date', 'kerf-pro' ),
		'comment-text'        => __( 'comment', 'kerf-pro' ),
		'comment-avatar'      => __( 'commenter\'s picture', 'kerf-pro' ),
		'comment-form'        => __( 'comment form', 'kerf-pro' ),
		'term-name'           => __( 'tag or category name', 'kerf-pro' ),
		'term-link'           => __( 'tag or category link', 'kerf-pro' ),
		'archive-title'       => __( 'category or tag name', 'kerf-pro' ),
		'archive-description' => __( 'its description', 'kerf-pro' ),
		'search-query'        => __( 'the words searched for', 'kerf-pro' ),
		'result-count'        => __( 'number of results', 'kerf-pro' ),
		'search-form'         => __( 'search form', 'kerf-pro' ),
		'search-input'        => __( 'search box', 'kerf-pro' ),
		'pagination'          => __( 'page links', 'kerf-pro' ),
	);
}
