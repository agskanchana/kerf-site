<?php
/**
 * Kerf → Inner pages.
 *
 * Three tabs, for the three ways an owner takes charge of the pages the mockup
 * did not draw:
 *
 *   Style             adjust the default style — fonts, colours, width, the
 *                     blog layout — with the page itself as the preview. Values
 *                     start as the home page's, measured in the browser.
 *   Design your own   two copy-paste prompts for the designer or their AI: one
 *                     to design the missing pages in the mockup's style, one to
 *                     mark up pages the template already has. Kerf itself calls
 *                     no AI (§5.4); the owner does, if they want to.
 *   Status            which pages use the default style and which a designer's
 *                     template, with a way back to the default.
 *
 * And the measurement those start from: the endpoint the browser's reading
 * saves to (assets/js/kerf-design-measure.js), after an import or when asked.
 *
 * Kerf Pro's (§8.14). The free plugin applies a measurement and the owner's
 * choices wherever the shell renders, so a look made here keeps showing; with
 * a lapsed licence nothing is measured and this screen waits for a renewal.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The page types a site needs beyond its home page, in the order an owner
 * thinks of them, with the template slug each is written to.
 *
 * @return array<string,array{slug:string,label:string,file:string}>
 */
function kerf_shell_page_types() {
	return array(
		'home'    => array( 'slug' => 'home', 'label' => __( 'Blog (list of posts)', 'kerf-pro' ), 'file' => 'blog.html' ),
		'single'  => array( 'slug' => 'single', 'label' => __( 'A blog post', 'kerf-pro' ), 'file' => 'single.html' ),
		'page'    => array( 'slug' => 'page', 'label' => __( 'A page written in WordPress', 'kerf-pro' ), 'file' => 'page.html' ),
		'archive' => array( 'slug' => 'archive', 'label' => __( 'Category and tag archives', 'kerf-pro' ), 'file' => 'archive.html' ),
		'search'  => array( 'slug' => 'search', 'label' => __( 'Search results', 'kerf-pro' ), 'file' => 'search.html' ),
		'404'     => array( 'slug' => '404', 'label' => __( 'Page not found (404)', 'kerf-pro' ), 'file' => '404.html' ),
	);
}

/**
 * The designer templates Kerf imported, by page type.
 *
 * @return array<string,WP_Post>
 */
function kerf_shell_designed_templates() {
	$found = array();
	foreach ( kerf_shell_page_types() as $type => $info ) {
		$posts = get_posts( array(
			'post_type'      => 'wp_template',
			'post_status'    => array( 'publish' ),
			'name'           => $info['slug'],
			'posts_per_page' => 1,
			'no_found_rows'  => true,
			'tax_query'      => array( array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- a template is its theme's: how core finds one too.
				'taxonomy' => 'wp_theme',
				'field'    => 'name',
				'terms'    => get_stylesheet(),
			) ),
		) );
		if ( $posts ) {
			$found[ $type ] = $posts[0];
		}
	}
	return $found;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MEASURING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * REST: save what the home page measured like.
 */
function kerf_shell_rest_routes() {
	register_rest_route( 'kerf/v1', '/shell-measurement', array(
		'methods'             => 'POST',
		'permission_callback' => function () {
			if ( ! current_user_can( 'edit_theme_options' ) ) {
				return false;
			}
			return kerf_pro_licensed() ? true : new WP_Error( 'kerf_pro_expired', __( 'Your Kerf Pro licence has expired: renew to measure the home page again.', 'kerf-pro' ), array( 'status' => 403 ) );
		},
		'callback'            => 'kerf_shell_rest_save_measurement',
	) );
}
add_action( 'rest_api_init', 'kerf_shell_rest_routes' );

/**
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_shell_rest_save_measurement( $request ) {
	$measurement = kerf_shell_clean_measurement( $request->get_json_params() );

	if ( empty( $measurement ) ) {
		return new WP_Error( 'kerf_empty_measurement', __( 'Nothing could be read from the home page.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	kerf_shell_save_measurement( $measurement );

	return rest_ensure_response( array( 'tokens' => kerf_shell_tokens() ) );
}

/**
 * Store a (clean) measurement.
 *
 * @param array $measurement
 */
function kerf_shell_save_measurement( $measurement ) {
	$measurement['measuredAt'] = time();
	update_option( KERF_SHELL_MEASURED_OPTION, $measurement, false );
}

/**
 * Keep only the fields a measurement has, as short plain strings and numbers.
 * The browser that sent it is the admin's, but what it read was the mockup.
 *
 * @param mixed $raw
 * @return array
 */
function kerf_shell_clean_measurement( $raw ) {
	if ( ! is_array( $raw ) ) {
		return array();
	}

	$text = function ( $value ) {
		return is_scalar( $value ) ? substr( sanitize_text_field( (string) $value ), 0, 300 ) : '';
	};

	$out = array();
	foreach ( array( 'fontBody', 'fontHeading', 'text', 'heading', 'surface', 'bodyBg', 'accent' ) as $key ) {
		if ( isset( $raw[ $key ] ) ) {
			$out[ $key ] = $text( $raw[ $key ] );
		}
	}
	if ( isset( $raw['heroImage'] ) ) {
		$out['heroImage'] = esc_url_raw( (string) $raw['heroImage'], array( 'http', 'https' ) );
	}
	if ( isset( $raw['container'] ) ) {
		$out['container'] = max( 0, min( 4000, (int) $raw['container'] ) );
	}
	foreach ( array(
		'button' => array( 'bg', 'color', 'radius', 'transform' ),
		'header' => array( 'position', 'height', 'overlap', 'bg', 'link' ),
		'footer' => array( 'bg', 'color' ),
	) as $group => $keys ) {
		if ( empty( $raw[ $group ] ) || ! is_array( $raw[ $group ] ) ) {
			continue;
		}
		foreach ( $keys as $key ) {
			if ( isset( $raw[ $group ][ $key ] ) ) {
				$out[ $group ][ $key ] = in_array( $key, array( 'height', 'overlap' ), true ) ? max( 0, min( 2000, (int) $raw[ $group ][ $key ] ) ) : $text( $raw[ $group ][ $key ] );
			}
		}
	}

	return array_filter( $out, function ( $value ) {
		return '' !== $value && array() !== $value;
	} );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE SCREEN
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Add Kerf → Inner pages.
 */
function kerf_shell_admin_menu() {
	add_submenu_page(
		'kerf',
		__( 'Inner pages', 'kerf-pro' ),
		__( 'Inner pages', 'kerf-pro' ),
		'edit_theme_options',
		'kerf-inner-pages',
		'kerf_shell_admin_render'
	);
}
add_action( 'admin_menu', 'kerf_shell_admin_menu', 15 );

/**
 * Where the preview frame can show each kind of page, if the site has one.
 *
 * @return array<string,string>
 */
function kerf_shell_preview_urls() {
	$urls = array();

	$posts_page = (int) get_option( 'page_for_posts' );
	if ( 'posts' === get_option( 'show_on_front' ) ) {
		$urls['blog'] = home_url( '/' );
	} elseif ( $posts_page ) {
		$urls['blog'] = get_permalink( $posts_page );
	} else {
		$categories = get_categories( array( 'number' => 1, 'hide_empty' => true ) );
		if ( $categories ) {
			$urls['blog'] = get_category_link( $categories[0] );
		}
	}

	$post = get_posts( array( 'numberposts' => 1, 'post_status' => 'publish' ) );
	if ( $post ) {
		$urls['post'] = get_permalink( $post[0] );
	}

	foreach ( get_pages( array( 'number' => 30, 'post_status' => 'publish' ) ) as $page ) {
		if ( ! kerf_shell_is_mockup_post( $page ) && (int) $page->ID !== $posts_page ) {
			$urls['page'] = get_permalink( $page );
			break;
		}
	}

	$urls['search'] = add_query_arg( 's', 'a', home_url( '/' ) );
	$urls['404']    = home_url( '/kerf-preview-not-found/' );

	foreach ( $urls as $key => $url ) {
		$urls[ $key ] = add_query_arg( 'kerf_preview', '1', $url );
	}

	return $urls;
}

/**
 * Font stacks the mockup's own CSS declares, for the font pickers.
 *
 * @return string[]
 */
function kerf_shell_mockup_fonts() {
	$fonts = array();

	foreach ( kerf_assets_get() as $asset ) {
		if ( 'css' !== ( isset( $asset['type'] ) ? $asset['type'] : '' ) ) {
			continue;
		}
		$css = '';
		if ( 'inline' === $asset['kind'] ) {
			$css = isset( $asset['content'] ) ? (string) $asset['content'] : '';
		} elseif ( 'file' === $asset['kind'] && ! empty( $asset['src'] ) && 0 === strpos( $asset['src'], trailingslashit( wp_upload_dir()['baseurl'] ) ) ) {
			$css = kerf_assets_editor_css( $asset['src'] );
		}
		if ( preg_match_all( '/font-family\s*:\s*([^;}{]+)/i', $css, $m ) ) {
			foreach ( $m[1] as $stack ) {
				$stack = trim( preg_replace( '/\s*!important\s*$/i', '', $stack ) );
				if ( '' !== $stack && false === stripos( $stack, 'var(' ) && false === stripos( $stack, 'inherit' ) ) {
					$fonts[ $stack ] = ( isset( $fonts[ $stack ] ) ? $fonts[ $stack ] : 0 ) + 1;
				}
			}
		}
	}

	arsort( $fonts );
	return array_slice( array_keys( $fonts ), 0, 16 );
}

/**
 * `#rrggbb` for a colour input, or ''.
 *
 * @param string $color
 * @return string
 */
function kerf_shell_hex( $color ) {
	$rgba = kerf_shell_rgba( $color );
	if ( ! $rgba ) {
		return '';
	}
	return sprintf( '#%02x%02x%02x', max( 0, min( 255, (int) round( $rgba[0] ) ) ), max( 0, min( 255, (int) round( $rgba[1] ) ) ), max( 0, min( 255, (int) round( $rgba[2] ) ) ) );
}

/**
 * Handle the screen's forms. Returns a notice, or ''.
 *
 * @return string
 */
function kerf_shell_admin_handle_post() {
	if ( empty( $_POST['kerf_shell_action'] ) ) {
		return '';
	}
	if ( ! current_user_can( 'edit_theme_options' )
		|| ! isset( $_POST['kerf_shell_nonce'] )
		|| ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kerf_shell_nonce'] ) ), 'kerf_shell' ) ) {
		return __( 'Security check failed. Reload the page and try again.', 'kerf-pro' );
	}

	$action = sanitize_key( wp_unslash( $_POST['kerf_shell_action'] ) );

	if ( 'save' === $action ) {
		$raw    = isset( $_POST['kerf_tokens'] ) && is_array( $_POST['kerf_tokens'] ) ? wp_unslash( $_POST['kerf_tokens'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per token below.
		$schema = kerf_shell_token_schema();
		$tokens = array();
		foreach ( $schema as $key => $type ) {
			if ( isset( $raw[ $key ] ) ) {
				$value = kerf_shell_sanitize_token( $type, $raw[ $key ] );
				if ( '' !== $value ) {
					$tokens[ $key ] = $value;
				}
			}
		}
		update_option( KERF_SHELL_TOKENS_OPTION, $tokens, false );

		$layout = isset( $_POST['kerf_layout'] ) && is_array( $_POST['kerf_layout'] ) ? wp_unslash( $_POST['kerf_layout'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized against the schema.
		foreach ( kerf_shell_layout_schema() as $key => $spec ) {
			if ( 'bool' === $spec[0] ) {
				$layout[ $key ] = empty( $layout[ $key ] ) ? 0 : 1;
			}
		}
		update_option( KERF_SHELL_LAYOUT_OPTION, kerf_shell_layout( $layout ), false );

		return __( 'Saved. Every page in the default style uses it now.', 'kerf-pro' );
	}

	if ( 'reset' === $action ) {
		delete_option( KERF_SHELL_TOKENS_OPTION );
		return __( 'Your changes were cleared: the default style follows the home page again.', 'kerf-pro' );
	}

	if ( 'revert' === $action && isset( $_POST['kerf_template'] ) ) {
		$id   = (int) $_POST['kerf_template'];
		$post = get_post( $id );
		if ( $post && 'wp_template' === $post->post_type && get_post_meta( $id, '_kerf_source', true ) ) {
			wp_delete_post( $id, true );
			return __( 'That page type is back on the default style.', 'kerf-pro' );
		}
	}

	return '';
}

/**
 * Enqueue the screen's scripts.
 *
 * @param string $hook
 */
function kerf_shell_admin_assets( $hook ) {
	$inner  = false !== strpos( $hook, 'kerf-inner-pages' );
	$import = function_exists( 'kerf_import_is_screen' ) && kerf_import_is_screen( $hook ); // Its report measures the home page after an import.
	if ( ( ! $inner && ! $import ) || ! kerf_pro_licensed() ) {
		return;
	}

	if ( $inner ) {
		wp_enqueue_style( 'kerf-inner-pages', kerf_pro_url( 'assets/css/kerf-inner-pages.css' ), array(), filemtime( kerf_pro_path( 'assets/css/kerf-inner-pages.css' ) ) );
	}
	// The free plugin's reader (kerf_import_register_reader()), given a measure.
	wp_enqueue_script( 'kerf-design-measure', kerf_pro_url( 'assets/js/kerf-design-measure.js' ), array( 'kerf-design-read' ), filemtime( kerf_pro_path( 'assets/js/kerf-design-measure.js' ) ), true );
	wp_enqueue_script( 'kerf-inner-pages', kerf_pro_url( 'assets/js/kerf-inner-pages.js' ), array( 'kerf-design-measure', 'wp-api-fetch' ), filemtime( kerf_pro_path( 'assets/js/kerf-inner-pages.js' ) ), true );
	wp_localize_script( 'kerf-inner-pages', 'KerfShellAdmin', array(
		'measureUrl' => add_query_arg( 'kerf_measure', '1', home_url( '/' ) ),
		'restPath'   => '/kerf/v1/shell-measurement',
		'strings'    => array(
			'reading' => __( 'Reading the home page…', 'kerf-pro' ),
			'done'    => __( 'Done — reloading.', 'kerf-pro' ),
			'failed'  => __( 'Could not read the home page:', 'kerf-pro' ),
		),
	) );
}
add_action( 'admin_enqueue_scripts', 'kerf_shell_admin_assets' );

/**
 * Render Kerf → Inner pages.
 */
function kerf_shell_admin_render() {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
		wp_die( esc_html__( 'You do not have permission to change the inner pages.', 'kerf-pro' ) );
	}
	// A lapsed licence: the pages keep the look they were given; changing it
	// waits for a renewal.
	if ( ! kerf_pro_licensed() ) {
		kerf_ui_open( __( 'Inner pages', 'kerf-pro' ) );
		kerf_pro_renew_notice();
		kerf_ui_close();
		return;
	}

	$notice = kerf_shell_admin_handle_post();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tab switch only.
	$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'style';
	$tabs = array(
		'style'  => __( 'Style', 'kerf-pro' ),
		'design' => __( 'Design your own', 'kerf-pro' ),
		'status' => __( 'Status', 'kerf-pro' ),
	);
	if ( ! isset( $tabs[ $tab ] ) ) {
		$tab = 'style';
	}

	kerf_ui_open( __( 'Inner pages', 'kerf-pro' ), array(
		'class' => 'kerf-shell-admin',
		'lede'  => __( 'Your design is a home page. A WordPress site also has a blog, its posts, pages you write later, archives, search results and a "page not found". Until you design them, they wear Kerf\'s default style — made from your home page\'s own fonts and colours.', 'kerf-pro' ),
	) );

	if ( '' !== $notice ) {
		echo kerf_ui_note( $notice, 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
	}

	echo '<nav class="kerf-tabs">';
	foreach ( $tabs as $key => $label ) {
		printf(
			'<a%s href="%s">%s</a>',
			$key === $tab ? ' aria-current="page"' : '',
			esc_url( add_query_arg( array( 'page' => 'kerf-inner-pages', 'tab' => $key ), admin_url( 'admin.php' ) ) ),
			esc_html( $label )
		);
	}
	echo '</nav>';

	if ( 'design' === $tab ) {
		kerf_shell_admin_render_design();
	} elseif ( 'status' === $tab ) {
		kerf_shell_admin_render_status();
	} else {
		kerf_shell_admin_render_style();
	}

	kerf_ui_close();
}

/**
 * The Style tab.
 */
function kerf_shell_admin_render_style() {
	$measured_raw = get_option( KERF_SHELL_MEASURED_OPTION, array() );
	$measured     = kerf_shell_tokens_from_measurement( $measured_raw );
	$overrides    = get_option( KERF_SHELL_TOKENS_OPTION, array() );
	$overrides    = is_array( $overrides ) ? $overrides : array();
	$effective    = kerf_shell_tokens();
	$layout       = kerf_shell_layout();
	$previews     = kerf_shell_preview_urls();
	$fonts        = array_values( array_unique( array_filter( array_merge(
		array( isset( $measured['font-heading'] ) ? $measured['font-heading'] : '', isset( $measured['font-body'] ) ? $measured['font-body'] : '' ),
		kerf_shell_mockup_fonts()
	) ) ) );

	$when = ! empty( $measured_raw['measuredAt'] )
		/* translators: %s: human time difference, e.g. "5 minutes". */
		? sprintf( __( 'Read from your home page %s ago.', 'kerf-pro' ), human_time_diff( (int) $measured_raw['measuredAt'] ) )
		: __( 'Your home page has not been read yet, so these pages use your mockup\'s CSS as it stands. Read it to take its fonts and colours.', 'kerf-pro' );

	$colors = array(
		'accent'      => __( 'Accent — links, buttons, highlights', 'kerf-pro' ),
		'accent-text' => __( 'Text on the accent', 'kerf-pro' ),
		'bg'          => __( 'Page background', 'kerf-pro' ),
		'surface'     => __( 'Cards', 'kerf-pro' ),
		'text'        => __( 'Text', 'kerf-pro' ),
		'heading'     => __( 'Headings', 'kerf-pro' ),
		'muted'       => __( 'Secondary text — dates, excerpts', 'kerf-pro' ),
		'border'      => __( 'Lines and borders', 'kerf-pro' ),
		'band-bg'     => __( 'Title band', 'kerf-pro' ),
		'band-text'   => __( 'Text on the title band', 'kerf-pro' ),
	);
	?>
	<div class="kerf-shell-style">
		<form method="post" class="kerf-card kerf-shell-controls" id="kerf-shell-form">
			<?php wp_nonce_field( 'kerf_shell', 'kerf_shell_nonce' ); ?>

			<div class="kerf-shell-measure">
				<p><?php echo esc_html( $when ); ?></p>
				<button type="button" class="kerf-btn" id="kerf-shell-read"><?php esc_html_e( 'Read from home page', 'kerf-pro' ); ?></button>
				<span class="kerf-shell-measure__status" aria-live="polite"></span>
			</div>

			<h2><?php esc_html_e( 'Fonts', 'kerf-pro' ); ?></h2>
			<datalist id="kerf-shell-fonts">
				<?php foreach ( $fonts as $font ) : ?>
					<option value="<?php echo esc_attr( $font ); ?>"></option>
				<?php endforeach; ?>
			</datalist>
			<?php
			foreach ( array( 'font-heading' => __( 'Headings', 'kerf-pro' ), 'font-body' => __( 'Body text', 'kerf-pro' ) ) as $key => $label ) {
				printf(
					'<p class="kerf-shell-row"><label for="kerf-token-%1$s">%2$s</label><input type="text" id="kerf-token-%1$s" name="kerf_tokens[%1$s]" value="%3$s" placeholder="%4$s" list="kerf-shell-fonts" data-token="%1$s" class="regular-text"></p>',
					esc_attr( $key ),
					esc_html( $label ),
					esc_attr( isset( $overrides[ $key ] ) ? $overrides[ $key ] : '' ),
					esc_attr( isset( $measured[ $key ] ) ? $measured[ $key ] : __( 'the mockup\'s own', 'kerf-pro' ) )
				);
			}
			?>

			<h2><?php esc_html_e( 'Colours', 'kerf-pro' ); ?></h2>
			<?php
			foreach ( $colors as $key => $label ) {
				printf(
					'<p class="kerf-shell-row kerf-shell-row--color"><label for="kerf-token-%1$s">%2$s</label><input type="color" value="%5$s" data-swatch="%1$s" aria-label="%2$s"><input type="text" id="kerf-token-%1$s" name="kerf_tokens[%1$s]" value="%3$s" placeholder="%4$s" data-token="%1$s" class="kerf-shell-color"></p>',
					esc_attr( $key ),
					esc_html( $label ),
					esc_attr( isset( $overrides[ $key ] ) ? $overrides[ $key ] : '' ),
					esc_attr( isset( $measured[ $key ] ) ? $measured[ $key ] : __( 'from the mockup', 'kerf-pro' ) ),
					esc_attr( kerf_shell_hex( $effective[ $key ] ) ? kerf_shell_hex( $effective[ $key ] ) : '#888888' )
				);
			}
			?>

			<h2><?php esc_html_e( 'Shape', 'kerf-pro' ); ?></h2>
			<?php
			foreach ( array(
				'container'     => __( 'Content width', 'kerf-pro' ),
				'radius'        => __( 'Card corners', 'kerf-pro' ),
				'button-radius' => __( 'Button corners', 'kerf-pro' ),
			) as $key => $label ) {
				printf(
					'<p class="kerf-shell-row"><label for="kerf-token-%1$s">%2$s</label><input type="text" id="kerf-token-%1$s" name="kerf_tokens[%1$s]" value="%3$s" placeholder="%4$s" data-token="%1$s" class="small-text"></p>',
					esc_attr( $key ),
					esc_html( $label ),
					esc_attr( isset( $overrides[ $key ] ) ? $overrides[ $key ] : '' ),
					esc_attr( isset( $measured[ $key ] ) ? $measured[ $key ] : '' )
				);
			}
			?>

			<h2><?php esc_html_e( 'Layout', 'kerf-pro' ); ?></h2>
			<p class="kerf-shell-row">
				<label for="kerf-layout-blog"><?php esc_html_e( 'Blog and archives', 'kerf-pro' ); ?></label>
				<select id="kerf-layout-blog" name="kerf_layout[blog]" data-layout="blog">
					<?php
					foreach ( array( 'grid-3' => __( 'Grid, three across', 'kerf-pro' ), 'grid-2' => __( 'Grid, two across', 'kerf-pro' ), 'list' => __( 'List', 'kerf-pro' ) ) as $value => $label ) {
						printf( '<option value="%s"%s>%s</option>', esc_attr( $value ), selected( $layout['blog'], $value, false ), esc_html( $label ) );
					}
					?>
				</select>
			</p>
			<p class="kerf-shell-row">
				<label for="kerf-layout-band"><?php esc_html_e( 'Title band', 'kerf-pro' ); ?></label>
				<select id="kerf-layout-band" name="kerf_layout[band]" data-layout="band">
					<?php
					foreach ( array( 'color' => __( 'Colour', 'kerf-pro' ), 'image' => __( 'A picture: each page\'s featured image, else your home page\'s hero image', 'kerf-pro' ), 'none' => __( 'None', 'kerf-pro' ) ) as $value => $label ) {
						printf( '<option value="%s"%s>%s</option>', esc_attr( $value ), selected( $layout['band'], $value, false ), esc_html( $label ) );
					}
					?>
				</select>
			</p>
			<fieldset class="kerf-shell-row kerf-shell-toggles">
				<legend><?php esc_html_e( 'Show on each post', 'kerf-pro' ); ?></legend>
				<?php
				foreach ( array(
					'image'    => __( 'Featured image', 'kerf-pro' ),
					'category' => __( 'Category', 'kerf-pro' ),
					'date'     => __( 'Date', 'kerf-pro' ),
					'author'   => __( 'Author', 'kerf-pro' ),
				) as $key => $label ) {
					printf(
						'<label><input type="checkbox" name="kerf_layout[%1$s]" value="1" data-layout="%1$s"%3$s> %2$s</label>',
						esc_attr( $key ),
						esc_html( $label ),
						checked( 1, (int) $layout[ $key ], false )
					);
				}
				?>
			</fieldset>
			<p class="kerf-shell-row">
				<label for="kerf-layout-excerpt"><?php esc_html_e( 'Excerpt length (words, 0 hides it)', 'kerf-pro' ); ?></label>
				<input type="number" min="0" max="80" id="kerf-layout-excerpt" name="kerf_layout[excerpt]" value="<?php echo esc_attr( (string) $layout['excerpt'] ); ?>" data-layout="excerpt" class="small-text">
			</p>

			<p class="kerf-shell-actions">
				<button type="submit" name="kerf_shell_action" value="save" class="kerf-btn kerf-btn--primary"><?php esc_html_e( 'Save', 'kerf-pro' ); ?></button>
				<button type="submit" name="kerf_shell_action" value="reset" class="kerf-btn"><?php esc_html_e( 'Reset to the home page\'s style', 'kerf-pro' ); ?></button>
			</p>
			<p class="description"><?php esc_html_e( 'Leave a field empty to use the value read from your home page. To move things around — the date above the title, a sidebar — edit these templates in Appearance → Editor.', 'kerf-pro' ); ?></p>
		</form>

		<div class="kerf-shell-preview">
			<div class="kerf-shell-preview__bar" role="group" aria-label="<?php esc_attr_e( 'Preview', 'kerf-pro' ); ?>">
				<?php
				$names = array( 'blog' => __( 'Blog', 'kerf-pro' ), 'post' => __( 'Post', 'kerf-pro' ), 'page' => __( 'Page', 'kerf-pro' ), 'search' => __( 'Search', 'kerf-pro' ), '404' => '404' );
				$first = true;
				foreach ( $names as $key => $label ) {
					if ( empty( $previews[ $key ] ) ) {
						continue;
					}
					printf(
						'<button type="button" class="kerf-btn kerf-btn--sm%s" data-preview="%s">%s</button>',
						$first ? ' is-pressed' : '',
						esc_url( $previews[ $key ] ),
						esc_html( $label )
					);
					$first = false;
				}
				?>
			</div>
			<div class="kerf-shell-preview__frame">
				<iframe title="<?php esc_attr_e( 'Preview', 'kerf-pro' ); ?>" src="<?php echo esc_url( reset( $previews ) ); ?>"></iframe>
			</div>
			<p class="description"><?php esc_html_e( 'The preview changes as you type; nothing is published until you save.', 'kerf-pro' ); ?></p>
		</div>
	</div>
	<?php
}

/**
 * The Design-your-own tab.
 */
function kerf_shell_admin_render_design() {
	$missing = array_diff_key( kerf_shell_page_types(), kerf_shell_designed_templates() );
	$ready   = kerf_shell_unprepared_pages();
	?>
	<div class="kerf-card kerf-shell-design">
		<h2><?php esc_html_e( 'Design these pages yourself', 'kerf-pro' ); ?></h2>
		<p><?php esc_html_e( 'The default style is a starting point. For pages that look exactly like the rest of your design, have them designed — by your designer, or with the AI that made your mockup — and import them. Copy the brief below, attach your mockup\'s index.html and its CSS files, and send it.', 'kerf-pro' ); ?></p>

		<?php if ( empty( $missing ) ) : ?>
			<p><strong><?php esc_html_e( 'Every page type already has a designed template.', 'kerf-pro' ); ?></strong></p>
		<?php else : ?>
			<p><?php esc_html_e( 'Still on the default style:', 'kerf-pro' ); ?> <?php echo esc_html( implode( ', ', wp_list_pluck( $missing, 'label' ) ) ); ?></p>
		<?php endif; ?>

		<div class="kerf-prompt">
			<textarea readonly rows="18" id="kerf-prompt-design"><?php echo esc_textarea( kerf_shell_prompt( 'design', array_keys( $missing ) ) ); ?></textarea>
			<button type="button" class="kerf-btn kerf-btn--primary" data-copy="kerf-prompt-design"><?php esc_html_e( 'Copy the brief', 'kerf-pro' ); ?></button>
		</div>

		<h2><?php esc_html_e( 'Your template already has these pages', 'kerf-pro' ); ?></h2>
		<?php if ( empty( $ready ) ) : ?>
			<p><?php esc_html_e( 'The last import had no other page that looks like a blog, a post, a search page or a 404.', 'kerf-pro' ); ?></p>
		<?php else : ?>
			<p>
				<?php
				printf(
					/* translators: %s: list of file names. */
					esc_html__( 'The last import found %s. Kerf needs them marked — which part is the post title, which repeats for each post — before it can fill them with your real posts. Nothing else about them has to change. This brief asks for exactly that; attach those files.', 'kerf-pro' ),
					'<code>' . implode( '</code>, <code>', array_map( 'esc_html', array_keys( $ready ) ) ) . '</code>'
				);
				?>
			</p>
			<div class="kerf-prompt">
				<textarea readonly rows="14" id="kerf-prompt-prepare"><?php echo esc_textarea( kerf_shell_prompt( 'prepare', array_values( $ready ), array_keys( $ready ) ) ); ?></textarea>
				<button type="button" class="kerf-btn" data-copy="kerf-prompt-prepare"><?php esc_html_e( 'Copy the brief', 'kerf-pro' ); ?></button>
			</div>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Then', 'kerf-pro' ); ?></h2>
		<ol>
			<li><?php esc_html_e( 'Put the new or updated HTML files next to index.html, in the same folder as your mockup.', 'kerf-pro' ); ?></li>
			<li><?php esc_html_e( 'Zip the folder and import it again under Kerf → Import Mockup, with "Import the other pages" ticked.', 'kerf-pro' ); ?></li>
			<li><?php esc_html_e( 'Each marked page becomes the template for its kind of page, filled with your real posts. The Status tab shows which.', 'kerf-pro' ); ?></li>
		</ol>
	</div>
	<?php
}

/**
 * The Status tab.
 */
function kerf_shell_admin_render_status() {
	$designed = kerf_shell_designed_templates();
	?>
	<div class="kerf-card">
		<table class="widefat striped kerf-shell-status">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Page', 'kerf-pro' ); ?></th>
					<th><?php esc_html_e( 'Uses', 'kerf-pro' ); ?></th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			<?php foreach ( kerf_shell_page_types() as $type => $info ) : ?>
				<tr>
					<td><?php echo esc_html( $info['label'] ); ?></td>
					<td>
						<?php
						if ( isset( $designed[ $type ] ) ) {
							$source = (string) get_post_meta( $designed[ $type ]->ID, '_kerf_source', true );
							echo '' !== $source
								/* translators: %s: file name. */
								? esc_html( sprintf( __( 'Your designer\'s page, from %s', 'kerf-pro' ), $source ) )
								: esc_html__( 'Customized in the Site Editor', 'kerf-pro' );
						} else {
							esc_html_e( 'Kerf\'s default style', 'kerf-pro' );
						}
						?>
					</td>
					<td class="kerf-shell-status__actions">
						<a href="<?php echo esc_url( admin_url( 'site-editor.php?postType=wp_template&postId=' . rawurlencode( get_stylesheet() . '//' . $info['slug'] ) . '&canvas=edit' ) ); ?>"><?php esc_html_e( 'Edit', 'kerf-pro' ); ?></a>
						<?php if ( isset( $designed[ $type ] ) && get_post_meta( $designed[ $type ]->ID, '_kerf_source', true ) ) : ?>
							<form method="post" class="kerf-inline-form">
								<?php wp_nonce_field( 'kerf_shell', 'kerf_shell_nonce' ); ?>
								<input type="hidden" name="kerf_template" value="<?php echo esc_attr( (string) $designed[ $type ]->ID ); ?>">
								<button type="submit" name="kerf_shell_action" value="revert" class="kerf-btn kerf-btn--danger kerf-btn--sm"><?php esc_html_e( 'Back to the default style', 'kerf-pro' ); ?></button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( ! get_option( 'page_for_posts' ) && 'page' === get_option( 'show_on_front' ) ) : ?>
			<p class="kerf-warning"><?php esc_html_e( 'Your site has no posts page, so the blog has no address of its own. Choose one under Settings → Reading.', 'kerf-pro' ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * The pages from the last import that look like inner pages but carry no
 * markers yet: file => page type.
 *
 * @return array<string,string>
 */
function kerf_shell_unprepared_pages() {
	$pages = get_option( 'kerf_import_pages', array() );
	$found = array();
	if ( ! is_array( $pages ) ) {
		return $found;
	}
	foreach ( $pages as $file => $info ) {
		if ( is_array( $info ) && ! empty( $info['type'] ) && isset( kerf_shell_page_types()[ $info['type'] ] ) && empty( $info['marked'] ) ) {
			$found[ $file ] = $info['type'];
		}
	}
	return $found;
}

/**
 * The copy-paste brief.
 *
 * @param string   $kind  'design' — make the missing pages; 'prepare' — mark up existing ones.
 * @param string[] $types Page types the brief is about.
 * @param string[] $files For 'prepare': the files to mark up.
 * @return string
 */
function kerf_shell_prompt( $kind, $types, $files = array() ) {
	$all    = kerf_shell_page_types();
	$types  = array_values( array_intersect( array_keys( $all ), $types ) );
	$tokens = kerf_shell_tokens_from_measurement( get_option( KERF_SHELL_MEASURED_OPTION, array() ) );
	$lines  = array();

	$sheets = array();
	foreach ( kerf_assets_get() as $asset ) {
		if ( 'css' === ( isset( $asset['type'] ) ? $asset['type'] : '' ) && 'file' === $asset['kind'] && ! empty( $asset['src'] ) ) {
			$sheets[] = kerf_shell_asset_label( $asset['src'] );
		}
	}

	$contract = kerf_shell_contract_lines();

	if ( 'prepare' === $kind ) {
		$lines[] = 'My website template came with ' . ( $files ? implode( ', ', $files ) : 'these pages' ) . ' (attached). It is being turned into a WordPress site with the Kerf theme, and WordPress will use these files as the templates for its own pages:';
		foreach ( $files as $i => $file ) {
			$type    = isset( $types[ $i ] ) ? $types[ $i ] : ( isset( $types[0] ) ? $types[0] : 'page' );
			$lines[] = '- ' . $file . ' → ' . ( isset( $all[ $type ] ) ? $all[ $type ]['label'] : $type ) . ' (data-kerf-template="' . $type . '")';
		}
		$lines[] = '';
		$lines[] = 'Add the attributes below to them. Change NOTHING else — not a tag, not a class, not the text, not the whitespace. Only add attributes.';
		$lines[] = '';
		$lines   = array_merge( $lines, $contract );
		$lines[] = '';
		$lines[] = 'Reply with the complete HTML of each file.';
		return implode( "\n", $lines );
	}

	return kerf_shell_prompt_design( $lines, $types, $all, $tokens, $sheets, $contract );
}

/**
 * "Design the missing pages": the brief for the pages the mockup did not draw.
 *
 * @param string[] $lines    Lines so far.
 * @param string[] $types    Page types to ask for.
 * @param array    $all      kerf_shell_page_types().
 * @param array    $tokens   The measured design.
 * @param string[] $sheets   The mockup's stylesheets, as the designer knows them.
 * @param string[] $contract kerf_shell_contract_lines().
 * @return string
 */
function kerf_shell_prompt_design( $lines, $types, $all, $tokens, $sheets, $contract ) {
	$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$lines[] = 'I have a website design' . ( '' !== $site ? ' for "' . $site . '"' : '' ) . '. Its home page is the attached index.html' . ( $sheets ? ', styled by these stylesheets:' : '.' );
	foreach ( $sheets as $sheet ) {
		$lines[] = '- ' . $sheet;
	}
	$style = array();
	if ( ! empty( $tokens['font-heading'] ) ) {
		$style[] = 'headings in ' . $tokens['font-heading'];
	}
	if ( ! empty( $tokens['font-body'] ) ) {
		$style[] = 'body text in ' . $tokens['font-body'];
	}
	if ( ! empty( $tokens['accent'] ) ) {
		$style[] = 'an accent colour of ' . kerf_shell_hex( $tokens['accent'] );
	}
	if ( ! empty( $tokens['bg'] ) ) {
		$style[] = 'a ' . ( kerf_shell_luminance( $tokens['bg'] ) < 0.2 ? 'dark' : 'light' ) . ' page background (' . kerf_shell_hex( $tokens['bg'] ) . ')';
	}
	if ( $style ) {
		$lines[] = 'The design uses ' . implode( ', ', $style ) . '.';
	}
	$lines[] = '';
	$lines[] = 'The site is now a WordPress site. WordPress also needs the pages below, and I want each designed in exactly the same visual style as the home page. Please create these HTML files:';

	$describe = array(
		'home'    => 'blog.html — the blog: a list of post cards (image, category, title, date, a short excerpt, a "read more" link) and page links (1, 2, 3, Next).',
		'single'  => 'single.html — one blog post: title, date, author, category, featured image, the article body, tags, links to the previous and next post, and a comments area with two sample comments and a form to leave one.',
		'page'    => 'page.html — an ordinary page such as "About": a title area and the page body.',
		'archive' => 'archive.html — the posts of one category: like blog.html, headed by the category name and its description.',
		'search'  => 'search.html — search results: the search terms as the heading, a search form, the results as a list, and a message for when nothing matched.',
		'404'     => '404.html — "page not found": a short friendly message and a search form.',
	);
	$n = 0;
	foreach ( ( $types ? $types : array_keys( $all ) ) as $type ) {
		$lines[] = ( ++$n ) . '. ' . $describe[ $type ];
	}

	$lines[] = '';
	$lines[] = 'Rules:';
	$lines[] = '- Use the same <head> as index.html: the same stylesheets and fonts, in the same order. If you need more CSS, put all of it in one new file, css/pages.css, linked after the others.';
	$lines[] = '- Copy the header and the footer from index.html exactly — same markup, same classes. Only what is between them is new.';
	$lines[] = '- Build from what the stylesheets already have wherever you can — their section wrappers, containers, headings, buttons and cards. Invent as little new styling as possible.';
	$lines[] = '- The body of a post and of a page is written in WordPress and arrives as plain HTML: h2, h3, paragraphs, lists, links, block quotes, images with captions, tables. Style those plain elements inside the content area, so any post looks right.';
	$lines[] = '- Use realistic placeholder text, and images from the mockup\'s own images folder.';
	$lines[] = '';
	$lines   = array_merge( $lines, $contract );
	$lines[] = '';
	$lines[] = 'Reply with the complete HTML of each file.';

	return implode( "\n", $lines );
}

/**
 * A stylesheet URL as the designer knows it: its path inside the mockup
 * folder for a staged file, the URL for a remote one.
 *
 * @param string $src
 * @return string
 */
function kerf_shell_asset_label( $src ) {
	$storage = kerf_assets_storage_for_url( $src );
	if ( $storage ) {
		// Either staged base, then mockup-<stamp>/<the designer's path>.
		$rest = substr( $src, strlen( $storage['url'] ) );
		$rest = preg_replace( '#^[^/]+/#', '', $rest );
		return (string) strtok( $rest, '?' );
	}
	return $src;
}

/**
 * The import's report, for the whole site: the home page measured for the
 * blog and the other pages, from the free plugin's reading of it.
 *
 * @param array $result
 */
function kerf_shell_report_items( $result ) {
	if ( ! empty( $result['dry_run'] ) || 'site' !== ( $result['scope'] ?? 'site' ) || ! kerf_pro_licensed() ) {
		return;
	}
	printf(
		'<li class="kerf-measure-after-import" data-done="%s" data-failed="%s">%s</li>',
		esc_attr__( 'Read your home page\'s fonts and colours for the blog, posts and other pages. Adjust them under Kerf → Inner pages.', 'kerf-pro' ),
		esc_attr__( 'Could not read your home page\'s style yet — open Kerf → Inner pages and choose "Read from home page".', 'kerf-pro' ),
		esc_html__( 'Reading your home page\'s fonts and colours for the blog, posts and other pages…', 'kerf-pro' )
	);
}
add_action( 'kerf_import_report_items', 'kerf_shell_report_items' );
