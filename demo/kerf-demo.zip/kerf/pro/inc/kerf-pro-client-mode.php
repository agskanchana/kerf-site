<?php
/**
 * Client mode: who edits a design's pages with the design locked (§5.38).
 *
 * The editor side is assets/js/kerf-client-mode.js. Here: who it is on for —
 * whoever may not change the theme, unless Kerf → Settings turned it off, and
 * an administrator who locked it for themselves — and the setting.
 *
 * Kerf Pro's (§8.14). The lock protects a client's site, so it never asks
 * kerf_pro_licensed(): it keeps running while the add-on is installed.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const KERF_CLIENT_MODE_OPTION = 'kerf_client_mode';

/**
 * Is the design locked for the current user?
 *
 * @return bool
 */
function kerf_client_mode_active() {
	if ( get_user_meta( get_current_user_id(), 'kerf_design_lock', true ) ) {
		return true;
	}
	return ! current_user_can( 'edit_theme_options' ) && 'off' !== get_option( KERF_CLIENT_MODE_OPTION, 'on' );
}

/**
 * The editor script, and what it needs to know.
 */
function kerf_client_mode_assets() {
	$rel  = 'assets/js/kerf-client-mode.js';
	$path = kerf_pro_path( $rel );
	if ( ! file_exists( $path ) ) {
		return;
	}
	wp_enqueue_script( 'kerf-client-mode', kerf_pro_url( $rel ), array( 'wp-data', 'wp-i18n', 'wp-element', 'wp-plugins', 'wp-editor', 'wp-api-fetch', 'wp-block-editor', 'wp-notices' ), filemtime( $path ), true );
	wp_set_script_translations( 'kerf-client-mode', 'kerf-pro', kerf_pro_path( 'languages' ) );
	wp_add_inline_script( 'kerf-client-mode', 'window.kerfClientMode = ' . wp_json_encode( array(
		'active'    => kerf_client_mode_active(),
		'canChoose' => current_user_can( 'edit_theme_options' ),
		'mine'      => (bool) get_user_meta( get_current_user_id(), 'kerf_design_lock', true ),
	) ) . ';', 'before' );
}
add_action( 'enqueue_block_editor_assets', 'kerf_client_mode_assets' );

/**
 * No code editor on a locked page: the markup IS the design, and the code
 * editor hands it over whole, past every lock the block editor holds.
 *
 * @param array                   $settings Editor settings.
 * @param WP_Block_Editor_Context $context  Where the editor is.
 * @return array
 */
function kerf_client_mode_editor_settings( $settings, $context ) {
	$post = isset( $context->post ) ? $context->post : null;
	if ( $post instanceof WP_Post && false !== strpos( (string) $post->post_content, '<!-- wp:kerf/' ) && kerf_client_mode_active() ) {
		$settings['codeEditingEnabled'] = false;
	}
	return $settings;
}
add_filter( 'block_editor_settings_all', 'kerf_client_mode_editor_settings', 10, 2 );

/**
 * The administrator's own lock, saved through the REST API.
 */
function kerf_client_mode_register_meta() {
	register_meta( 'user', 'kerf_design_lock', array(
		'type'          => 'boolean',
		'single'        => true,
		'show_in_rest'  => true,
		'auth_callback' => static function () {
			return current_user_can( 'edit_theme_options' );
		},
	) );
	register_setting( 'kerf_settings', KERF_CLIENT_MODE_OPTION, array(
		'type'              => 'string',
		'default'           => 'on',
		'sanitize_callback' => static function ( $value ) {
			return 'off' === $value ? 'off' : 'on';
		},
	) );
}
add_action( 'init', 'kerf_client_mode_register_meta' );

/**
 * The setting, on Kerf → Settings.
 */
function kerf_client_mode_settings_section() {
	$value = get_option( KERF_CLIENT_MODE_OPTION, 'on' );
	kerf_ui_setting_open(
		__( 'Client editing', 'kerf-pro' ),
		__( 'On a page built from your design, people who may not change the theme change its words, pictures and links — and cannot move, delete or restyle its parts. Administrators can try it from the editor\'s menu, "Lock the design".', 'kerf-pro' )
	);
	?>
	<input type="hidden" name="<?php echo esc_attr( KERF_CLIENT_MODE_OPTION ); ?>" value="off">
	<label class="kerf-switch">
		<input type="checkbox" name="<?php echo esc_attr( KERF_CLIENT_MODE_OPTION ); ?>" value="on" <?php checked( 'off' !== $value ); ?>>
		<span class="kerf-switch__text">
			<strong><?php esc_html_e( 'Lock the design for Editors and Authors', 'kerf-pro' ); ?></strong>
			<span><?php esc_html_e( 'Their words, pictures and links stay open to them.', 'kerf-pro' ); ?></span>
		</span>
	</label>
	<?php
	kerf_ui_setting_close();
}
add_action( 'kerf_settings_sections', 'kerf_client_mode_settings_section' );
