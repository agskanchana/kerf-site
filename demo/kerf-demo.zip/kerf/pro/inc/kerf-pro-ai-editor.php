<?php
/**
 * AI in the editor: Kerf AI's sidebar, its window and the "Change with AI"
 * button on a block (assets/js/kerf-ai-editor.js).
 *
 * The owner asked for AI where pages are made: a new page is made there from
 * their words — pasted from Word, Google Docs or a web page, or a Word,
 * Markdown or HTML file, read for its headings, lists and tables
 * (inc/kerf-pro-ai-words.php) — and any page, or one of its sections, is
 * changed there as they ask (inc/kerf-pro-ai-edit.php). What comes back goes
 * into the editor, never saved: the owner looks, undoes or saves.
 *
 * A job outlasts the page that started it only while that page asks after
 * it: reopened, the editor finds the person's job for this page — working,
 * or finished and not yet put in — and follows it or offers its result.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Can AI make and change pages for this person, here — and if not, why, and
 * what fixes it?
 *
 * @return array{ready:bool,why:string,fix:array}
 */
function kerf_pro_ai_editor_state() {
	$why = null;
	if ( ! current_user_can( 'edit_pages' ) ) {
		$why = new WP_Error( 'kerf_ai_forbidden', __( 'Only someone who may make pages can have one made.', 'kerf-pro' ) );
	}
	if ( ! $why ) {
		$why = kerf_pro_ai_refusal();
	}
	if ( ! $why ) {
		$ready = kerf_pro_ai_page_ready();
		$why   = true === $ready ? null : $ready;
	}
	$fix = array();
	if ( $why && 'kerf_ai_no_key' === $why->get_error_code() && current_user_can( 'manage_options' ) ) {
		$fix = array( 'label' => __( 'Add your Gemini key', 'kerf-pro' ), 'url' => admin_url( 'admin.php?page=kerf-settings' ) );
	} elseif ( $why && 'kerf_ai_no_design' === $why->get_error_code() ) {
		$fix = array( 'label' => __( 'Import a design', 'kerf-pro' ), 'url' => admin_url( 'admin.php?page=kerf-import' ) );
	}
	return array(
		'ready' => ! $why,
		'why'   => $why ? $why->get_error_message() : '',
		'fix'   => $fix,
	);
}

/**
 * The editor's script, for pages.
 */
function kerf_pro_ai_editor_assets() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$rel    = 'assets/js/kerf-ai-editor.js';
	if ( ! $screen || 'post' !== $screen->base || 'page' !== $screen->post_type || ! current_user_can( 'edit_pages' ) || ! file_exists( kerf_pro_path( $rel ) ) ) {
		return;
	}
	wp_enqueue_script(
		'kerf-ai-editor',
		kerf_pro_url( $rel ),
		array( 'wp-plugins', 'wp-element', 'wp-components', 'wp-i18n', 'wp-data', 'wp-blocks', 'wp-block-editor', 'wp-hooks', 'wp-compose', 'wp-api-fetch', 'wp-editor' ),
		filemtime( kerf_pro_path( $rel ) ),
		true
	);
	wp_set_script_translations( 'kerf-ai-editor', 'kerf-pro', kerf_pro_path( 'languages' ) );

	$kinds = array();
	foreach ( kerf_pro_ai_page_kinds() as $value => $kind ) {
		$kinds[] = array( 'value' => $value, 'label' => $kind['label'] );
	}
	wp_add_inline_script(
		'kerf-ai-editor',
		'window.kerfAiEditor = ' . wp_json_encode(
			kerf_pro_ai_editor_state() + array(
				'kinds'    => $kinds,
				'pictures' => KERF_PRO_AI_PAGE_PICTURES,
				'words'    => KERF_PRO_AI_PAGE_WORDS,
				'open'     => isset( $_GET['kerf_ai'] ) && 'make' === sanitize_key( wp_unslash( $_GET['kerf_ai'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- opens a window, changes nothing.
			)
		) . ';',
		'before'
	);

	$css = 'assets/css/kerf-pro-editor-ui.css';
	if ( file_exists( kerf_pro_path( $css ) ) ) {
		wp_enqueue_style( 'kerf-pro-editor-ui', kerf_pro_url( $css ), array(), filemtime( kerf_pro_path( $css ) ) );
	}
}
add_action( 'enqueue_block_editor_assets', 'kerf_pro_ai_editor_assets' );

/**
 * The person's AI work for a page — working, or finished within the day and
 * not yet put in the editor.
 *
 * @param int $post_id
 * @return array|null The job.
 */
function kerf_pro_ai_editor_job( $post_id ) {
	$best = null;
	foreach ( kerf_pro_ai_jobs() as $job ) {
		if ( ! is_array( $job ) || ! in_array( $job['kind'], array( 'page', 'edit' ), true ) || (int) $job['user'] !== get_current_user_id() ) {
			continue;
		}
		if ( (int) ( $job['data']['post'] ?? 0 ) !== (int) $post_id || ! empty( $job['taken'] ) ) {
			continue;
		}
		if ( 'working' !== $job['status'] && ( 'done' !== $job['status'] || (int) $job['updated'] < time() - DAY_IN_SECONDS ) ) {
			continue;
		}
		// Started in the same second, the later: jobs are kept in the order made.
		if ( ! $best || (int) $job['created'] >= (int) $best['created'] ) {
			$best = $job;
		}
	}
	return $best;
}

/**
 * GET kerf/v1/ai/editor?post_id= — the person's AI work for a page;
 * POST kerf/v1/ai/jobs/<id>/taken — its result is in the editor.
 */
function kerf_pro_ai_editor_routes() {
	register_rest_route( 'kerf/v1', '/ai/editor', array(
		'methods'             => 'GET',
		'callback'            => static function ( $request ) {
			$job = kerf_pro_ai_editor_job( (int) $request['post_id'] );
			return rest_ensure_response( array( 'job' => $job ? kerf_pro_ai_job_view( $job ) : null ) );
		},
		'permission_callback' => static function ( $request ) {
			return current_user_can( 'edit_post', (int) $request['post_id'] );
		},
		'args'                => array( 'post_id' => array( 'type' => 'integer', 'required' => true ) ),
	) );
	register_rest_route( 'kerf/v1', '/ai/jobs/(?P<id>[a-z0-9]{12})/taken', array(
		'methods'             => 'POST',
		'callback'            => static function ( $request ) {
			$job          = kerf_pro_ai_job_get( (string) $request['id'] );
			$job['taken'] = true;
			kerf_pro_ai_job_save( $job );
			return rest_ensure_response( array( 'taken' => true ) );
		},
		'permission_callback' => static function ( $request ) {
			$job = kerf_pro_ai_job_get( (string) $request['id'] );
			return $job && (int) $job['user'] === get_current_user_id();
		},
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_editor_routes' );
