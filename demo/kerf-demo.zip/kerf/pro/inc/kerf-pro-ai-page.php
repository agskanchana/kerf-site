<?php
/**
 * AI, phase 5: Kerf → Make a page — one new page, in the design the site
 * already has.
 *
 * The owner says what the page is (its kind and title), gives its words — kept
 * and arranged, never added to — and chooses its pictures. Gemini reads how
 * the site's pages are written: the home page and one of the design's other
 * pages as they render, the design's own stylesheet, the pages there are to
 * link to and the business's details. It writes the page's content — what the
 * site shows between its header and its footer. Kerf holds that to the rules
 * a generated design is held to (phase 3's checks: the chosen pictures only,
 * nothing that runs, nothing from other sites), converts it with the
 * import's converter — its pictures the chosen library ones, its links bound
 * to the site's pages, the business's details bound to Site details — and
 * saves it as a DRAFT page. Nothing on the site changes until the owner
 * publishes it; "Make it again" writes over the same draft, the version
 * before it kept in the page's revisions.
 *
 * Not inside the import's undo (§5.40): undo is one level, and recording a
 * draft page would take the last import's undo away. A draft is undone by
 * deleting it.
 *
 * A job (kerf-pro-ai-jobs.php): "Writing the page" asks the model; "Making the
 * draft" checks, converts and saves — so a failure there asks no model again.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Pages being made, and made: the newest five, by id. */
const KERF_PRO_AI_PAGES_OPTION = 'kerf_pro_ai_pages';

/** Pictures a page may be given. */
const KERF_PRO_AI_PAGE_PICTURES = 8;

/** The owner's words for a page, in characters. */
const KERF_PRO_AI_PAGE_WORDS = 20000;

/** Each rendered page shown to the model, in bytes. */
const KERF_PRO_AI_PAGE_SAMPLE = 60000;

/** The design's own CSS shown to the model, in bytes. */
const KERF_PRO_AI_PAGE_CSS = 150000;

/**
 * The kinds of page, each with what the model is told about it.
 *
 * @return array<string,array{label:string,about:string}>
 */
function kerf_pro_ai_page_kinds() {
	return array(
		'about'    => array(
			'label' => __( 'About', 'kerf-pro' ),
			'about' => 'An About page: who the business is, its story, what it believes in and the people behind it.',
		),
		'services' => array(
			'label' => __( 'Services', 'kerf-pro' ),
			'about' => 'A Services page: each service — what it is, who it is for, what it includes — and a call to action.',
		),
		'contact'  => array(
			'label' => __( 'Contact', 'kerf-pro' ),
			'about' => 'A Contact page: the business\'s details as given (phone, email, address, opening hours) and a contact form with name, email, phone and message. No map: no iframes are allowed.',
		),
		'team'     => array(
			'label' => __( 'Team', 'kerf-pro' ),
			'about' => 'A Team page: each person the owner names, with their role and a line about them, and their picture where one is given.',
		),
		'faq'      => array(
			'label' => __( 'Questions', 'kerf-pro' ),
			'about' => 'A questions-and-answers page: each of the owner\'s questions in a <details> element with the question in its <summary> (they open without script), grouped under headings when there are many.',
		),
		'pricing'  => array(
			'label' => __( 'Prices', 'kerf-pro' ),
			'about' => 'A prices page: the plans or prices the owner gives, as cards or a table. Where the owner gives no price, write "Ask us" — never a number.',
		),
		'landing'  => array(
			'label' => __( 'Landing page', 'kerf-pro' ),
			'about' => 'A landing page for one offer: a strong first section with one call to action, the benefits, how it works, and the call to action again at the end.',
		),
		'other'    => array(
			'label' => __( 'Something else', 'kerf-pro' ),
			'about' => 'The page the owner describes.',
		),
	);
}

/**
 * Can a page be made here: the Kerf theme, and a design imported for the
 * whole site to make it in?
 *
 * @return true|WP_Error
 */
function kerf_pro_ai_page_ready() {
	if ( function_exists( 'kerf_theme_active' ) && ! kerf_theme_active() ) {
		return new WP_Error( 'kerf_ai_no_theme', __( 'Make a page needs the Kerf theme: switch to it under Appearance → Themes.', 'kerf-pro' ), array( 'status' => 409 ) );
	}
	$home = get_post( (int) get_option( 'kerf_mockup_page' ) );
	if ( ! $home || 'trash' === $home->post_status || false === strpos( $home->post_content, '<!-- wp:kerf/' ) ) {
		return new WP_Error( 'kerf_ai_no_design', __( 'Import a design first, or build one with AI: a page is made in your site\'s design.', 'kerf-pro' ), array( 'status' => 409 ) );
	}
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// STARTING, AND WHAT IS KEPT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * The owner's words as they are sent: Markdown, kept as written — not
 * sanitize_textarea_field(), which takes out every `%2F` of a link's address
 * and every `<br>` of a table's cell. They are never printed as HTML; what the
 * model writes from them is checked as a design is (phase 3's checks).
 *
 * @param string $text
 * @param int    $max  Characters at most; 0 for no cut.
 * @return string
 */
function kerf_pro_ai_page_clean_words( $text, $max = 0 ) {
	$text = str_replace( array( "\r\n", "\r", "\0" ), array( "\n", "\n", '' ), wp_check_invalid_utf8( (string) $text, true ) );
	$text = trim( (string) preg_replace( '/[\x{0001}-\x{0008}\x{000B}\x{000C}\x{000E}-\x{001F}]/u', '', $text ) );
	return $max ? mb_substr( $text, 0, $max ) : $text;
}

/**
 * Start making a page: checked now, written by a job.
 *
 * Made from the editor (`post_id`, the page open there), nothing is saved: the
 * job answers with the page's blocks, and the editor puts them in, for the
 * owner to look at, undo or save (assets/js/kerf-ai-editor.js). From the
 * command line, a draft page is saved, as Kerf → Make a page did.
 *
 * @param array $input { kind, title, words, notes, pictures: int[], again?: string (the project made before), post_id?: int }.
 * @return array|WP_Error The job.
 */
function kerf_pro_ai_page_start( $input ) {
	$ready = kerf_pro_ai_page_ready();
	if ( true !== $ready ) {
		return $ready;
	}

	$target = isset( $input['post_id'] ) ? (int) $input['post_id'] : 0;
	if ( $target && ( ! get_post( $target ) || ! current_user_can( 'edit_post', $target ) ) ) {
		return new WP_Error( 'kerf_ai_page_target', __( 'You may not change this page.', 'kerf-pro' ), array( 'status' => 403 ) );
	}

	$kinds = kerf_pro_ai_page_kinds();
	$kind  = isset( $input['kind'] ) ? sanitize_key( (string) $input['kind'] ) : '';
	$kind  = isset( $kinds[ $kind ] ) ? $kind : 'other';
	$title = isset( $input['title'] ) ? mb_substr( trim( sanitize_text_field( (string) $input['title'] ) ), 0, 120 ) : '';
	$words = isset( $input['words'] ) ? kerf_pro_ai_page_clean_words( (string) $input['words'] ) : '';
	$notes = isset( $input['notes'] ) ? kerf_pro_ai_page_clean_words( (string) $input['notes'], 2000 ) : '';

	if ( '' === $title ) {
		return new WP_Error( 'kerf_ai_page_title', __( 'Give the page a title.', 'kerf-pro' ), array( 'status' => 400 ) );
	}
	if ( mb_strlen( $words ) > KERF_PRO_AI_PAGE_WORDS ) {
		/* translators: %s: a number of characters. */
		return new WP_Error( 'kerf_ai_page_words', sprintf( __( 'The page\'s words are longer than %s characters: make two pages, or shorten them.', 'kerf-pro' ), number_format_i18n( KERF_PRO_AI_PAGE_WORDS ) ), array( 'status' => 400 ) );
	}
	if ( mb_strlen( $words . $notes ) < 20 ) {
		return new WP_Error( 'kerf_ai_page_words', __( 'Say what the page should say — a few sentences at least. Gemini keeps your words and invents no facts.', 'kerf-pro' ), array( 'status' => 400 ) );
	}

	$ids = isset( $input['pictures'] ) ? array_slice( array_map( 'absint', (array) $input['pictures'] ), 0, KERF_PRO_AI_PAGE_PICTURES ) : array();
	// Named in img/ as a generated design's are; the converter finds them by it.
	$pictures = kerf_pro_ai_design_pictures( $ids );
	if ( is_wp_error( $pictures ) ) {
		return $pictures;
	}

	// "Make it again" writes over the draft made before — while it is a draft.
	$page_id = 0;
	$before  = ! empty( $input['again'] ) ? kerf_pro_ai_page_get( sanitize_key( (string) $input['again'] ) ) : null;
	if ( $before && (int) $before['user'] === get_current_user_id() && ! empty( $before['result']['page'] ) ) {
		$was = (int) $before['result']['page'];
		if ( 'draft' === get_post_status( $was ) && current_user_can( 'edit_post', $was ) ) {
			$page_id = $was;
		}
	}

	$project = array(
		'id'       => strtolower( wp_generate_password( 12, false, false ) ),
		'user'     => get_current_user_id(),
		'created'  => time(),
		'kind'     => $kind,
		'title'    => $title,
		'words'    => $words,
		'notes'    => $notes,
		'pictures' => $pictures,
		'page_id'  => $page_id,
		'target'   => $target,
		// Fixed when it starts: a step done later runs as whoever asks after it.
		'scripts'  => kerf_user_can_add_scripts(),
		'answer'   => null,
		'result'   => null,
	);
	kerf_pro_ai_page_save( $project );

	return kerf_pro_ai_job_create(
		'page',
		array(
			array( 'key' => 'write', 'label' => __( 'Writing the page', 'kerf-pro' ) ),
			array( 'key' => 'make', 'label' => $target ? __( 'Putting it in your design', 'kerf-pro' ) : __( 'Making the draft', 'kerf-pro' ) ),
		),
		array( 'project' => $project['id'], 'post' => $target )
	);
}

/**
 * A page's project, by id.
 *
 * @param string $id
 * @return array|null
 */
function kerf_pro_ai_page_get( $id ) {
	$all = kerf_pro_ai_fresh_option( KERF_PRO_AI_PAGES_OPTION );
	return is_array( $all ) && isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? $all[ $id ] : null;
}

/**
 * Keep a page's project — the newest five; the others as the database has
 * them (scar 100).
 *
 * @param array $project
 */
function kerf_pro_ai_page_save( $project ) {
	$all = kerf_pro_ai_fresh_option( KERF_PRO_AI_PAGES_OPTION );
	$all = is_array( $all ) ? $all : array();
	$all[ $project['id'] ] = $project;
	uasort( $all, static function ( $a, $b ) {
		return ( isset( $b['created'] ) ? (int) $b['created'] : 0 ) <=> ( isset( $a['created'] ) ? (int) $a['created'] : 0 );
	} );
	update_option( KERF_PRO_AI_PAGES_OPTION, array_slice( $all, 0, 5, true ), false );
}

/**
 * The job handler for pages.
 *
 * @param array $handlers
 * @return array
 */
function kerf_pro_ai_page_handler( $handlers ) {
	$handlers['page'] = 'kerf_pro_ai_page_step';
	return $handlers;
}
add_filter( 'kerf_pro_ai_job_handlers', 'kerf_pro_ai_page_handler' );

/**
 * One step of making a page.
 *
 * @param array $job  By reference.
 * @param array $step { key, label }.
 * @return true|WP_Error
 */
function kerf_pro_ai_page_step( &$job, $step ) {
	$project = kerf_pro_ai_page_get( isset( $job['data']['project'] ) ? (string) $job['data']['project'] : '' );
	if ( ! $project ) {
		return new WP_Error( 'kerf_ai_page_gone', __( 'This page\'s request is gone. Start it again.', 'kerf-pro' ) );
	}
	$done = 'write' === $step['key'] ? kerf_pro_ai_page_write( $project ) : kerf_pro_ai_page_make( $project );
	kerf_pro_ai_page_save( $project );
	if ( is_wp_error( $done ) ) {
		return $done;
	}
	if ( 'make' === $step['key'] ) {
		$job['result'] = $project['result'] + array( 'project' => $project['id'] );
	}
	return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
// HOW THE SITE'S PAGES ARE WRITTEN
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * What the model is shown of the design, and what the result is checked
 * against: the home page and one of the design's own pages as they render,
 * the design's own stylesheets, what loads from elsewhere, whether Tailwind
 * builds its styles, every class the design styles, and the site's pages.
 *
 * @param string $kind The page's kind: a design's own page of that name is the
 *                     one shown, when it has one.
 * @return array{home:string,inner:string,inner_id:int,inner_title:string,css:string,elsewhere:string[],tailwind:bool,classes:array<string,bool>,pages:array[]}
 */
function kerf_pro_ai_page_vocabulary( $kind = '' ) {
	$home  = (int) get_option( 'kerf_mockup_page' );
	$out   = array(
		'home'        => kerf_pro_ai_page_sample( $home ),
		'inner'       => '',
		'inner_id'    => 0,
		'inner_title' => '',
		'css'         => '',
		'elsewhere'   => array(),
		'tailwind'    => false,
		'classes'     => array(),
		'pages'       => array(),
	);

	// One of the design's own other pages — not a page an earlier design left
	// behind, whose classes are another design's: the last import's record.
	$record = get_option( 'kerf_import_pages', array() );
	$inner  = 0;
	foreach ( is_array( $record ) ? $record : array() as $file => $item ) {
		$id = isset( $item['page_id'] ) ? (int) $item['page_id'] : 0;
		if ( ! $id || 'page:ordinary' !== ( isset( $item['type'] ) ? $item['type'] : '' ) || ! in_array( get_post_status( $id ), array( 'publish', 'private' ), true ) || $id === $home ) {
			continue;
		}
		// The first, or the one named for this kind (contact.html for a Contact page).
		if ( ! $inner || ( '' !== $kind && 0 === strpos( (string) $file, $kind ) ) ) {
			$inner = $id;
		}
	}
	if ( $inner ) {
		$out['inner']       = kerf_pro_ai_page_sample( $inner );
		$out['inner_id']    = $inner;
		$out['inner_title'] = (string) get_post_field( 'post_title', $inner, 'raw' );
	}

	$uploads = trailingslashit( wp_upload_dir()['baseurl'] );
	$texts   = array();
	foreach ( kerf_assets_design( 0 )['assets'] as $asset ) {
		// The site's own, and the files the page shown loads alone (§5.26) —
		// a generated design's inner pages share css/pages.css — which the new
		// page will load too (kerf_pro_ai_page_dress()).
		if ( ! empty( $asset['only'] ) && ! kerf_pro_ai_page_loads( $asset, $inner ) ) {
			continue;
		}
		$src = isset( $asset['src'] ) ? (string) $asset['src'] : '';
		if ( 'js' === $asset['type'] ) {
			if ( preg_match( '#tailwindcss|@tailwindcss/browser#i', $src ) ) {
				$out['tailwind'] = true;
			}
			continue;
		}
		if ( ! in_array( $asset['type'], array( 'css', 'typed-style' ), true ) ) {
			continue;
		}
		if ( 'typed-style' === $asset['type'] ) {
			$out['tailwind'] = true;
		}
		if ( 'file' === $asset['kind'] ) {
			$css = kerf_assets_editor_css( $src );
			if ( 0 === strpos( $src, $uploads ) ) {
				$out['css'] .= kerf_pro_ai_page_lean_css( $css ) . "\n";
			} else {
				$out['elsewhere'][] = kerf_pro_ai_page_label( $src );
			}
			$texts[] = $css;
		} else {
			$css          = isset( $asset['content'] ) ? (string) $asset['content'] : '';
			$out['css']  .= kerf_pro_ai_page_lean_css( $css ) . "\n";
			$texts[]      = $css;
		}
	}
	// What Tailwind's script drew, as the editor has it (inc/kerf-capture.php).
	if ( function_exists( 'kerf_capture_editor_css' ) ) {
		$texts[] = kerf_capture_editor_css( 0 );
	}
	if ( strlen( $out['css'] ) > KERF_PRO_AI_PAGE_CSS ) {
		$out['css'] = substr( $out['css'], 0, (int) strrpos( substr( $out['css'], 0, KERF_PRO_AI_PAGE_CSS ), '}' ) + 1 ) . "\n/* … the rest of the stylesheet is left out */";
	}

	// Every class the design styles — in its stylesheets, or on its pages
	// (a framework's from elsewhere that could not be read).
	foreach ( $texts as $css ) {
		preg_match_all( '/\.(-?[_a-zA-Z][_a-zA-Z0-9-]*)/', (string) preg_replace( '#/\*.*?\*/#s', '', (string) $css ), $m );
		foreach ( $m[1] as $name ) {
			$out['classes'][ $name ] = true;
		}
	}
	foreach ( array( $out['home'], $out['inner'] ) as $sample ) {
		preg_match_all( '/\sclass="([^"]*)"/', $sample, $m );
		foreach ( $m[1] as $list ) {
			foreach ( preg_split( '/\s+/', $list, -1, PREG_SPLIT_NO_EMPTY ) as $name ) {
				$out['classes'][ $name ] = true;
			}
		}
	}

	$out['pages'][] = array( 'title' => __( 'Home', 'kerf-pro' ), 'path' => wp_make_link_relative( home_url( '/' ) ) );
	foreach ( get_pages( array( 'sort_column' => 'menu_order,post_title', 'number' => 60 ) ) as $page ) {
		if ( (int) $page->ID === $home && 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === $home ) {
			continue;
		}
		// By its slug, not its permalink: with plain permalinks that is
		// `/?page_id=6`, which the binder does not read as a page — every link
		// was said to go nowhere. A bound link renders the real address.
		$out['pages'][] = array( 'title' => (string) $page->post_title, 'path' => wp_make_link_relative( home_url( '/' . get_page_uri( $page ) . '/' ) ) );
	}
	return $out;
}

/**
 * Does a page-only file (§5.26) load on this page?
 *
 * @param array $asset
 * @param int   $page_id
 * @return bool
 */
function kerf_pro_ai_page_loads( $asset, $page_id ) {
	return $page_id && ! empty( $asset['only']['pages'] ) && in_array( (int) $page_id, array_map( 'intval', (array) $asset['only']['pages'] ), true );
}

/**
 * Give a page made here the files the design's page it was modelled on loads
 * alone (§5.26). A generated design keeps its inner pages' styles in
 * css/pages.css, loaded only where its own pages render: without it the new
 * page's banner had none of the design's padding, background or colours.
 *
 * @param int $page_id The page made.
 * @param int $model   The design's page the model was shown.
 * @return int How many files it was given.
 */
function kerf_pro_ai_page_dress( $page_id, $model ) {
	$assets = kerf_assets_get();
	$given  = 0;
	foreach ( $assets as $i => $asset ) {
		if ( kerf_pro_ai_page_loads( $asset, $model ) && ! kerf_pro_ai_page_loads( $asset, $page_id ) ) {
			$assets[ $i ]['only']['pages'][] = (int) $page_id;
			$given++;
		}
	}
	if ( $given ) {
		kerf_assets_save( $assets );
	}
	return $given;
}

/**
 * A page deleted for good leaves the page-only files' lists it was on — those
 * Make a page dressed it with, those added to it in WordPress (a pasted
 * section's styles, the CSS AI wrote), which go once no page loads them.
 * (Trashed, it stays in them: it can come back.)
 *
 * @param int $post_id
 */
function kerf_pro_ai_page_forget( $post_id ) {
	if ( in_array( get_post_type( (int) $post_id ), array( 'revision', 'attachment', 'nav_menu_item' ), true ) ) {
		return;
	}
	$assets = kerf_assets_get();
	$taken  = false;
	foreach ( $assets as $i => $asset ) {
		if ( kerf_pro_ai_page_loads( $asset, $post_id ) ) {
			$assets[ $i ]['only']['pages'] = array_values( array_diff( array_map( 'intval', (array) $asset['only']['pages'] ), array( (int) $post_id ) ) );
			$taken                         = true;
			if ( ! empty( $asset['added'] ) && ! $assets[ $i ]['only']['pages'] ) {
				unset( $assets[ $i ] );
			}
		}
	}
	if ( $taken ) {
		kerf_assets_save( array_values( $assets ) );
	}
}
add_action( 'before_delete_post', 'kerf_pro_ai_page_forget' );

/**
 * A page as it renders, between the site's header and footer, written lean
 * for the model: no scripts or styles, no comments, its pictures named only by
 * what they show (the model is not to reuse them), at most
 * KERF_PRO_AI_PAGE_SAMPLE bytes.
 *
 * @param int $post_id
 * @return string
 */
function kerf_pro_ai_page_sample( $post_id ) {
	global $post;
	$page = get_post( (int) $post_id );
	if ( ! $page ) {
		return '';
	}
	$was  = $post;
	$post = $page; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the blocks' bindings read the page; put back below.
	setup_postdata( $page );
	$html = '';
	foreach ( parse_blocks( $page->post_content ) as $block ) {
		$html .= render_block( $block );
	}
	$post = $was; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- put back.
	if ( $was ) {
		setup_postdata( $was );
	}

	$html = (string) preg_replace(
		array( '#<(script|style|noscript)\b[^>]*>.*?</\1\s*>#is', '#<!--.*?-->#s', '/\s(?:srcset|sizes|decoding|loading|fetchpriority)="[^"]*"/i', '/\s+/' ),
		array( '', '', '', ' ' ),
		$html
	);
	// WordPress's own classes are not the design's: copied, a heading came
	// back `wp-block-heading wp-block-heading` (core adds its own).
	$html = kerf_pro_ai_page_strip_wp_classes( $html );
	$html = (string) preg_replace( '/<([a-z][a-z0-9]*) >/i', '<$1>', $html );
	$html = (string) preg_replace( '/(<(?:img|source)\b[^>]*?\ssrc=")[^"]*(")/i', '$1(a picture of this page)$2', $html );
	// A style's pictures too — quoted as entities in a rendered attribute.
	$html = (string) preg_replace( '/url\([^)]*\)/i', 'url((a picture of this page))', $html );
	if ( strlen( $html ) > KERF_PRO_AI_PAGE_SAMPLE ) {
		$html = substr( $html, 0, (int) strrpos( substr( $html, 0, KERF_PRO_AI_PAGE_SAMPLE ), '>' ) + 1 ) . '<!-- … the rest of this page is left out -->';
	}
	return trim( $html );
}

/**
 * Markup without the classes WordPress adds to its own blocks (`wp-block-…`,
 * `wp-image-…`) — through the tag processor, which changes only the class
 * attribute; one left empty goes.
 *
 * @param string $html
 * @return string
 */
function kerf_pro_ai_page_strip_wp_classes( $html ) {
	$tags = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		foreach ( iterator_to_array( $tags->class_list(), false ) as $name ) {
			if ( preg_match( '/^wp-(?:block-[a-z0-9-]+|image-\d+)$/', $name ) ) {
				$tags->remove_class( $name );
			}
		}
		if ( '' === trim( (string) $tags->get_attribute( 'class' ) ) && null !== $tags->get_attribute( 'class' ) ) {
			$tags->remove_attribute( 'class' );
		}
	}
	return $tags->get_updated_html();
}

/**
 * A stylesheet, lean: no comments, no runs of white space.
 *
 * @param string $css
 * @return string
 */
function kerf_pro_ai_page_lean_css( $css ) {
	return trim( (string) preg_replace( array( '#/\*.*?\*/#s', '/\s+/' ), array( '', ' ' ), (string) $css ) );
}

/**
 * A file from elsewhere, named for the model: Bootstrap 5.3 is known by its
 * address.
 *
 * @param string $src
 * @return string
 */
function kerf_pro_ai_page_label( $src ) {
	$host = (string) wp_parse_url( $src, PHP_URL_HOST );
	$path = (string) wp_parse_url( $src, PHP_URL_PATH );
	return ( '' !== $host ? $host : '' ) . $path;
}

// ═══════════════════════════════════════════════════════════════════════════════
// WRITING
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Step one: ask the model for the page.
 *
 * @param array $project By reference: its answer.
 * @return true|WP_Error
 */
function kerf_pro_ai_page_write( &$project ) {
	$vocabulary = kerf_pro_ai_page_vocabulary( $project['kind'] );
	$answer     = kerf_pro_ai_request(
		'page',
		kerf_pro_ai_page_rules( $project, $vocabulary ),
		array_merge(
			array( array( 'text' => kerf_pro_ai_page_request( $project, $vocabulary ) ) ),
			kerf_pro_ai_design_picture_parts( $project )
		),
		array(
			'tier'        => 'pro',
			'json'        => true,
			'temperature' => 0.5,
			'schema'      => array(
				'type'       => 'OBJECT',
				'properties' => array(
					'html'  => array( 'type' => 'STRING' ),
					'css'   => array( 'type' => 'STRING' ),
					'notes' => array( 'type' => 'ARRAY', 'items' => array( 'type' => 'STRING' ) ),
				),
				'required'   => array( 'html' ),
			),
		)
	);
	if ( is_wp_error( $answer ) ) {
		return $answer;
	}
	$read = kerf_pro_ai_page_answer( $answer );
	if ( is_wp_error( $read ) ) {
		return $read;
	}
	$project['answer'] = $read;
	return true;
}

/**
 * What the model answered for a page or a part of one: its HTML, the CSS it
 * needs that the design lacks, its notes to the owner.
 *
 * @param array $answer From kerf_pro_ai_request().
 * @return array{html:string,css:string,notes:string[]}|WP_Error
 */
function kerf_pro_ai_page_answer( $answer ) {
	$html = isset( $answer['json']['html'] ) && is_string( $answer['json']['html'] ) ? trim( $answer['json']['html'] ) : '';
	if ( '' === $html || strlen( $html ) > 400000 ) {
		return new WP_Error( 'kerf_ai_retry', __( 'Gemini\'s page was empty or too long. Writing it again…', 'kerf-pro' ) );
	}
	$notes = array();
	foreach ( isset( $answer['json']['notes'] ) && is_array( $answer['json']['notes'] ) ? array_slice( $answer['json']['notes'], 0, 5 ) : array() as $note ) {
		$note = is_scalar( $note ) ? mb_substr( trim( wp_strip_all_tags( (string) $note ) ), 0, 300 ) : '';
		if ( '' !== $note ) {
			$notes[] = $note;
		}
	}
	$css = isset( $answer['json']['css'] ) && is_string( $answer['json']['css'] ) ? trim( $answer['json']['css'] ) : '';
	return array( 'html' => $html, 'css' => $css, 'notes' => $notes );
}

/**
 * The CSS the model wrote for a page, held to a page's rules: the owner's
 * pictures only, nothing loaded from elsewhere (no `@import`, fonts the
 * design's), no `</style>` way out (kerf_css_inert() at print besides), at
 * most 20 KB.
 *
 * @param string $css
 * @param array  $project With its `pictures`.
 * @param array  $notes   By reference: what was taken out, in plain words.
 * @return string
 */
function kerf_pro_ai_page_clean_css( $css, $project, &$notes ) {
	$css = (string) preg_replace( '#/\*.*?\*/#s', '', (string) $css );
	$css = (string) preg_replace( '/<\/?\s*style\b[^>]*>/i', '', $css );
	if ( preg_match( '/@import\b|@font-face\b/i', $css ) ) {
		$notes['css-import'] = __( 'Kerf took out fonts or files Gemini\'s styles loaded: the page uses your design\'s.', 'kerf-pro' );
		$css                 = (string) preg_replace( array( '/@import\b[^;]*;?/i', '/@font-face\s*\{[^}]*\}/i' ), '', $css );
	}
	$css = kerf_pro_ai_design_clean_css( $css, '', $project, $notes );
	// Its pictures are the owner's, by the paths the model was given: as the
	// library's addresses they are, on the page.
	foreach ( (array) $project['pictures'] as $picture ) {
		$url = ! empty( $picture['id'] ) ? (string) wp_get_attachment_url( (int) $picture['id'] ) : ( isset( $picture['url'] ) ? (string) $picture['url'] : '' );
		if ( '' !== $url ) {
			$css = (string) preg_replace( '/url\(\s*([\'"]?)' . preg_quote( $picture['path'], '/' ) . '\1\s*\)/i', 'url("' . esc_url_raw( $url ) . '")', $css );
		}
	}
	$css = trim( $css );
	if ( strlen( $css ) > 20000 ) {
		$notes['css-long'] = __( 'Gemini wrote more styles than a page needs; Kerf kept none of them. Make it again.', 'kerf-pro' );
		return '';
	}
	return $css;
}

/**
 * The rules for writing a page of this site.
 *
 * @param array $project
 * @param array $vocabulary From kerf_pro_ai_page_vocabulary().
 * @return string
 */
function kerf_pro_ai_page_rules( $project, $vocabulary ) {
	$kinds = kerf_pro_ai_page_kinds();
	return implode( "\n", array(
		'You write one new page for an existing website, in the website\'s own design. Kerf turns your HTML into the WordPress page, keeping every tag, class and style exactly as you write them — so write it finished: no placeholders, no TODOs, no lorem ipsum.',
		'',
		'What you write is the page\'s content: what the site shows between its header and its footer. The site adds its own header, menu and footer — never write those, and no <html>, <head> or <body>.',
		'Write it the way the site\'s pages are written — the pages you are shown: the same outer element when they have one (such as <main> with its classes — write the same), the same kinds of sections, the same classes for containers, headings, buttons, cards, grids and forms. It must look like the same site: the same colours, fonts, spacing and shapes. Use the classes the design styles' . ( $vocabulary['tailwind'] ? ', or Tailwind CSS utility classes: Tailwind builds this design\'s styles in the browser.' : ' (its stylesheet is below).' ),
		'Where the design has nothing for something this page needs (a table, a timeline, a price list), write the CSS for it in css: with the design\'s own colours, fonts, radii and spacing — its custom properties when it has them —, for classes you add on this page only (start their names with "pg-"); never restyle the design\'s own classes or elements. Otherwise css is empty.',
		'',
		'Rules:',
		'- Words: the owner\'s, kept. They come as Markdown: keep its structure — a "#" heading stays a heading (under the page\'s <h1>); a "-" or "1." list keeps every item, in its order, each with its own sub-items — as a list (<ul>, or <ol> when numbered), or as the design\'s cards when that suits the page, never merged into a sentence; a "|" table stays a table; **bold** and *italic* stay; a [link](address) stays a link. "[Picture: …]" marks where the owner\'s document had a picture: use one of the owner\'s pictures there if one fits, else leave it out. Shorten only for a heading or a button; fix typos. Never add facts: no prices, numbers, years, awards, reviews, quotes, names or details the owner did not give. Write in the owner\'s language.',
		'- Only what this page is for: no sections the owner did not ask for. A form only on a contact page or where the owner asks for one; the business\'s details only where the owner\'s words or a contact page call for them — the site\'s footer shows them already.',
		'- Pictures: only the owner\'s, by the paths you are given, each with alt text. No other picture — not those of the pages you are shown, no stock or placeholder services. With no pictures, use colour, type and the design\'s own shapes.',
		'- Links: to the site\'s pages by the paths you are given, to the business\'s details (tel:, mailto:, its social profiles), or "#". No other address on this site.',
		'- The business\'s details exactly as given: data-kerf-site="phone" on each tel: link, "email" on each mailto: link, "address" on the element holding the address, "hours" on the opening hours, and "facebook", "instagram", "x", "linkedin", "youtube", "tiktok" or "whatsapp" on each social link.',
		'- A form: <form data-kerf-form="contact"> (or "booking", "quote", "newsletter") with no action, every field with a name and a <label>, and inside it a thank-you <div data-kerf-form-success hidden>…</div> and an error <div data-kerf-form-error hidden>…</div>. Kerf makes it send to the owner.',
		'- Nothing that runs, and nothing from other sites: no scripts, no on… attributes, no <style> or <link> elements (CSS goes in css), no iframes, embeds, maps or videos.',
		'- Accessible: one <h1> — the page\'s title —, headings in order, a label on every field.',
		'',
		'This page: ' . $kinds[ $project['kind'] ]['about'],
		'',
		'Answer with JSON: html (the page\'s content), css (only what the design lacks, or empty), notes (at most five short sentences to the owner, in their language: what they should add or check — none when there is nothing to say).',
	) );
}

/**
 * What the model is given: the site, the owner's words for the page, how
 * the site's pages are written, its pages to link to, the pictures.
 *
 * @param array $project
 * @param array $vocabulary
 * @return string
 */
function kerf_pro_ai_page_request( $project, $vocabulary ) {
	$name    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	$tagline = wp_specialchars_decode( get_bloginfo( 'description' ), ENT_QUOTES );
	$about   = trim( (string) get_option( KERF_PRO_AI_ABOUT_OPTION, '' ) );
	$lines   = array( 'The site: ' . $name . ( '' !== $tagline ? ' — ' . $tagline : '' ) . '.' );
	if ( '' !== $about ) {
		$lines[] = 'About the business, in the owner\'s words:';
		$lines[] = $about;
	}
	$details = kerf_pro_ai_design_details( null );
	if ( $details ) {
		$lines[] = '';
		$lines[] = 'The business\'s details — exactly as given, only where the page needs them:';
		foreach ( $details as $key => $text ) {
			$lines[] = '- ' . $key . ': ' . $text;
		}
	}

	$lines[] = '';
	$lines[] = 'The page to write: “' . $project['title'] . '” (its title, and its <h1>).';
	if ( '' !== $project['words'] ) {
		$lines[] = 'The owner\'s words for it, in Markdown — keep them, and their structure:';
		$lines[] = '<<<';
		$lines[] = $project['words'];
		$lines[] = '>>>';
	}
	if ( '' !== $project['notes'] ) {
		$lines[] = 'The owner\'s notes on it:';
		$lines[] = $project['notes'];
	}

	$lines[] = '';
	if ( $project['pictures'] ) {
		$lines[] = 'The owner\'s pictures for this page — the only pictures it may show, by these paths (each is shown below):';
		foreach ( $project['pictures'] as $picture ) {
			$lines[] = '- ' . $picture['path'] . ( $picture['width'] ? ' (' . $picture['width'] . '×' . $picture['height'] . ')' : '' ) . ( '' !== $picture['alt'] ? ' — ' . $picture['alt'] : '' );
		}
	} else {
		$lines[] = 'The owner gave no pictures for this page: it shows none.';
	}

	$lines[] = '';
	$lines[] = 'The site\'s pages, for links:';
	foreach ( $vocabulary['pages'] as $page ) {
		$lines[] = '- ' . $page['title'] . ' — ' . $page['path'];
	}

	$lines[] = '';
	$lines[] = 'How the site\'s pages are written. The home page\'s content, between its header and footer:';
	$lines[] = $vocabulary['home'];
	if ( '' !== $vocabulary['inner'] ) {
		$lines[] = '';
		$lines[] = 'Another of its pages, “' . $vocabulary['inner_title'] . '” — a page like the one you write starts as this one does:';
		$lines[] = $vocabulary['inner'];
	}
	if ( '' !== trim( $vocabulary['css'] ) ) {
		$lines[] = '';
		$lines[] = 'The design\'s stylesheet:';
		$lines[] = $vocabulary['css'];
	}
	if ( $vocabulary['elsewhere'] ) {
		$lines[] = '';
		$lines[] = 'Also loaded, from other sites — their classes work too: ' . implode( ', ', $vocabulary['elsewhere'] ) . '.';
	}
	return implode( "\n", $lines );
}

// ═══════════════════════════════════════════════════════════════════════════════
// MAKING THE DRAFT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Step two: check what the model wrote, convert it, and save the draft.
 *
 * @param array $project By reference: its result.
 * @return true|WP_Error
 */
function kerf_pro_ai_page_make( &$project ) {
	if ( empty( $project['answer']['html'] ) ) {
		return new WP_Error( 'kerf_ai_page_order', __( 'Gemini\'s page is missing. Start it again.', 'kerf-pro' ) );
	}
	$notes = array();
	$html  = kerf_pro_ai_page_clean( (string) $project['answer']['html'], $project, $notes );
	if ( '' === trim( wp_strip_all_tags( $html ) ) && ! preg_match( '#<img\b#i', $html ) ) {
		return new WP_Error( 'kerf_ai_page_empty', __( 'Nothing was left of Gemini\'s page once it was held to the rules. Make it again.', 'kerf-pro' ) );
	}

	$vocabulary = kerf_pro_ai_page_vocabulary( $project['kind'] );
	if ( ! $vocabulary['tailwind'] ) {
		$unknown = kerf_pro_ai_page_unknown_classes( $html, $vocabulary['classes'], (string) ( $project['answer']['css'] ?? '' ) );
		if ( $unknown ) {
			$notes['classes'] = sprintf(
				/* translators: 1: how many, 2: a list of class names. */
				_n( 'Gemini used %1$d class your design does not style (%2$s): that part looks plain until it is styled.', 'Gemini used %1$d classes your design does not style (%2$s): those parts look plain until they are styled.', count( $unknown ), 'kerf-pro' ),
				count( $unknown ),
				implode( ', ', array_slice( $unknown, 0, 8 ) )
			);
		}
	}

	// As an import converts — its options, the chosen pictures as its media,
	// the site's details known — then its links bound to the site's pages.
	$result = kerf_mc_convert_html(
		$html,
		kerf_pro_ai_page_manifest( $project['pictures'] ),
		kerf_import_converter_options( array( 'directives' => ! empty( $project['scripts'] ) ) ) + array( 'site_known' => kerf_site_details() )
	);
	kerf_import_fill_alts( $result['markup'] );
	if ( ! empty( $result['site'] ) ) {
		kerf_site_remember( $result['site'] );
	}
	$links = kerf_links_bind( $result['markup'] );
	if ( ! empty( $links['unresolved'] ) ) {
		$notes['links'] = sprintf(
			/* translators: %s: a list of addresses. */
			__( 'Some links go to pages your site does not have yet (%s): make those pages, or change the links in the editor.', 'kerf-pro' ),
			implode( ', ', array_slice( array_keys( $links['unresolved'] ), 0, 5 ) )
		);
	}

	// The banner — the first of the owner's pictures in the page's first
	// section — shows the page's featured image, which is that picture: chosen
	// again later, it changes there (and on a share) too.
	$banner = kerf_pro_ai_page_banner( $links['markup'], wp_list_pluck( $project['pictures'], 'id' ) );

	// Made from the editor: the blocks go back to it, nothing is saved but the
	// files the page loads of its own — those its model page loads, and the
	// CSS the model wrote — which the editor draws at once.
	if ( ! empty( $project['target'] ) ) {
		$target = (int) $project['target'];
		if ( ! get_post( $target ) ) {
			return new WP_Error( 'kerf_ai_page_target', __( 'The page this was for is gone.', 'kerf-pro' ) );
		}
		$files = kerf_pro_ai_page_own_files( $target, (int) $vocabulary['inner_id'], (string) ( $project['answer']['css'] ?? '' ), $project, $notes );
		$project['result'] = array(
			'post'     => $target,
			'scope'    => 'page',
			'markup'   => $banner['markup'],
			'title'    => $project['title'],
			'featured' => (int) $banner['id'],
			'styles'   => $files['styles'],
			'removed'  => $files['removed'],
			'notes'    => array_values( array_merge( array_values( $notes ), $project['answer']['notes'] ) ),
		);
		return true;
	}

	$page_id = (int) $project['page_id'];
	$again   = $page_id && 'draft' === get_post_status( $page_id ) && current_user_can( 'edit_post', $page_id );
	$fields  = array(
		'post_title'   => $project['title'],
		// wp_slash() is mandatory (scar 1).
		'post_content' => wp_slash( $banner['markup'] ),
	);
	$saved = $again
		? wp_update_post( array( 'ID' => $page_id ) + $fields, true )
		: wp_insert_post( array(
			'post_type'   => 'page',
			'post_status' => 'draft',
			'post_author' => get_current_user_id(),
			'meta_input'  => array( '_kerf_ai_page' => $project['id'] ),
		) + $fields, true );
	if ( is_wp_error( $saved ) || ! $saved ) {
		return new WP_Error( 'kerf_ai_page_save', __( 'The draft could not be saved. Try again.', 'kerf-pro' ) );
	}
	$page_id            = (int) $saved;
	$project['page_id'] = $page_id;
	if ( $banner['id'] ) {
		set_post_thumbnail( $page_id, $banner['id'] );
	}
	kerf_pro_ai_page_own_files( $page_id, (int) $vocabulary['inner_id'], (string) ( $project['answer']['css'] ?? '' ), $project, $notes );
	$project['result']  = kerf_pro_ai_page_result( $page_id, array_values( array_merge( array_values( $notes ), $project['answer']['notes'] ) ), $again );
	return true;
}

/**
 * The files a page made or changed by AI loads of its own: those the design's
 * page it was modelled on loads (kerf_pro_ai_page_dress()), and the CSS the
 * model wrote for what the design lacks, as the page's own stylesheet (Kerf
 * Pro's page assets) — the one before it, from an earlier answer, replaced.
 *
 * A change to part of a page answers with the page's whole own CSS — what it
 * had, given to the model, and what the change needs — so a page keeps one;
 * an empty answer then leaves what it had.
 *
 * @param int    $page_id
 * @param int    $model   The design's page the model was shown, or 0.
 * @param string $css     What the model wrote.
 * @param array  $project With its `pictures`.
 * @param array  $notes   By reference.
 * @param bool   $keep    Keep the page's CSS when the model wrote none (a change).
 * @return array{styles:array[],removed:array[]} The editor's entries for the stylesheets
 *         that now load on the page, and for those that no longer do.
 */
function kerf_pro_ai_page_own_files( $page_id, $model, $css, $project, &$notes, $keep = false ) {
	// Marked as made by AI: deleted for good, it leaves the lists it is on.
	if ( '' === (string) get_post_meta( $page_id, '_kerf_ai_page', true ) ) {
		update_post_meta( $page_id, '_kerf_ai_page', isset( $project['id'] ) ? (string) $project['id'] : '1' );
	}
	$own    = kerf_pro_page_assets_own( $page_id );
	$before = array();
	foreach ( kerf_assets_design( $page_id )['assets'] as $asset ) {
		if ( kerf_pro_page_assets_loads( $asset, (int) $page_id, $own ) ) {
			$before[ kerf_pro_page_assets_key( $asset ) ] = true;
		}
	}
	if ( $model && ! $own ) {
		kerf_pro_ai_page_dress( $page_id, $model );
	}

	$removed = array();
	$css     = '' !== trim( $css ) ? kerf_pro_ai_page_clean_css( $css, $project, $notes ) : '';
	if ( '' !== $css || ! $keep ) {
		// The model's last CSS for this page goes; this answer's comes.
		foreach ( kerf_pro_page_assets_list( $page_id ) as $item ) {
			if ( 'ai' === $item['by'] ) {
				$entry = kerf_pro_page_assets_remove( $page_id, $item['key'] );
				if ( $entry ) {
					$removed[] = $entry;
				}
				unset( $before[ $item['key'] ] );
			}
		}
	}
	if ( '' !== $css ) {
		kerf_pro_page_assets_add( (int) $page_id, array( array( 'type' => 'css', 'kind' => 'inline', 'src' => '', 'content' => $css, 'position' => 'head', 'media' => 'all' ) ), 'ai' );
	}

	$styles = array();
	foreach ( kerf_assets_design( $page_id )['assets'] as $asset ) {
		if ( 'css' !== $asset['type'] || isset( $before[ kerf_pro_page_assets_key( $asset ) ] ) || ! kerf_pro_page_assets_loads( $asset, (int) $page_id, $own ) ) {
			continue;
		}
		$entry = kerf_assets_editor_entry( $asset );
		if ( $entry ) {
			$styles[] = $entry;
		}
	}
	return array( 'styles' => $styles, 'removed' => $removed );
}

/**
 * The CSS AI wrote for a page before, as the page loads it.
 *
 * @param int $page_id
 * @return string
 */
function kerf_pro_ai_page_css( $page_id ) {
	$own = kerf_pro_page_assets_own( $page_id );
	foreach ( kerf_assets_design( $page_id )['assets'] as $asset ) {
		if ( isset( $asset['added']['by'] ) && 'ai' === $asset['added']['by'] && 'inline' === $asset['kind'] && kerf_pro_page_assets_loads( $asset, (int) $page_id, $own ) ) {
			return (string) $asset['content'];
		}
	}
	return '';
}

/**
 * The page's banner bound to its featured image: in the first top-level
 * block, the first Element whose background (or picture) is one of the
 * owner's chosen pictures, looked for a few levels down — as an import binds
 * a banner the design marked `data-kerf-field="image"`.
 *
 * @param string $markup
 * @param int[]  $ids    The chosen pictures.
 * @return array{markup:string,id:int} The picture to make the page's featured image, or 0.
 */
function kerf_pro_ai_page_banner( $markup, $ids ) {
	$ids    = array_map( 'intval', (array) $ids );
	$blocks = parse_blocks( (string) $markup );
	$found  = 0;
	foreach ( $blocks as $i => $block ) {
		if ( empty( $block['blockName'] ) ) {
			continue;
		}
		$blocks[ $i ] = kerf_pro_ai_page_bind_banner( $block, $ids, $found, 0 );
		break;
	}
	return $found
		? array( 'markup' => serialize_blocks( $blocks ), 'id' => $found )
		: array( 'markup' => (string) $markup, 'id' => 0 );
}

/**
 * @param array $block
 * @param int[] $ids
 * @param int   $found Set to the picture bound.
 * @param int   $depth
 * @return array
 */
function kerf_pro_ai_page_bind_banner( $block, $ids, &$found, $depth ) {
	if ( $found || $depth > 4 ) {
		return $block;
	}
	$attrs = isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array();
	$post  = static function ( $key ) {
		return array( 'source' => 'kerf/post', 'args' => array( 'key' => $key, 'size' => 'full' ) );
	};

	$picture = 0;
	if ( 'kerf/div' === $block['blockName'] && ! empty( $attrs['backgroundImage'] ) && in_array( (int) ( $attrs['backgroundImageId'] ?? 0 ), $ids, true ) ) {
		$picture = (int) $attrs['backgroundImageId'];
		$block['attrs']['metadata']['bindings']['backgroundImage']   = $post( 'image' );
		$block['attrs']['metadata']['bindings']['backgroundImageId'] = $post( 'image-id' );
	} elseif ( 'kerf/image' === $block['blockName'] && in_array( (int) ( $attrs['mediaId'] ?? 0 ), $ids, true ) ) {
		$picture = (int) $attrs['mediaId'];
		$block['attrs']['metadata']['bindings']['src']     = $post( 'image' );
		$block['attrs']['metadata']['bindings']['alt']     = $post( 'image-alt' );
		$block['attrs']['metadata']['bindings']['mediaId'] = $post( 'image-id' );
	}
	if ( $picture ) {
		$found = $picture;
		return $block;
	}

	foreach ( (array) ( $block['innerBlocks'] ?? array() ) as $k => $inner ) {
		$block['innerBlocks'][ $k ] = kerf_pro_ai_page_bind_banner( $inner, $ids, $found, $depth + 1 );
		if ( $found ) {
			break;
		}
	}
	return $block;
}

/**
 * What the screen is told about a page made.
 *
 * @param int      $page_id
 * @param string[] $notes
 * @param bool     $again   It was made before, and written over.
 * @return array
 */
function kerf_pro_ai_page_result( $page_id, $notes, $again ) {
	return array(
		'page'    => (int) $page_id,
		'title'   => (string) get_post_field( 'post_title', $page_id, 'raw' ),
		'status'  => (string) get_post_status( $page_id ),
		'again'   => (bool) $again,
		'notes'   => $notes,
		'edit'    => (string) get_edit_post_link( $page_id, 'raw' ),
		// In Kerf's frame: no admin bar (kerf_shell_quiet_frames()).
		'preview' => add_query_arg( 'kerf_preview', '1', get_preview_post_link( $page_id ) ),
		'view'    => (string) get_permalink( $page_id ),
	);
}

/**
 * What the model wrote, held to the rules of a generated design (phase 3's
 * checks: removal only, never a re-serialized document — scar 3), and to a
 * page's: no header, menu or footer of its own, no styles of its own.
 *
 * @param string $html
 * @param array  $project
 * @param array  $notes By reference: what was taken out, in plain words.
 * @return string
 */
function kerf_pro_ai_page_clean( $html, $project, &$notes, $chrome = false ) {
	// A whole document after all: its body.
	if ( preg_match( '#<body\b#i', $html ) ) {
		$html = kerf_mc_extract_body( $html );
	}
	// The site's chrome, written again: a header holding a menu, a footer —
	// unless they are the page's own (a page with a design of its own, changed).
	$html = $chrome ? $html : (string) preg_replace_callback(
		'#<(header|footer)\b' . KERF_PRO_AI_DESIGN_TAG . '>.*?</\1\s*>#is',
		static function ( $m ) use ( &$notes ) {
			if ( 'header' === strtolower( $m[1] ) && ! preg_match( '#<nav\b#i', $m[0] ) ) {
				return $m[0]; // A page's own heading band.
			}
			$notes['chrome'] = __( 'Kerf took out the header or footer Gemini wrote: the site adds its own.', 'kerf-pro' );
			return '';
		},
		$html
	);
	$html = (string) preg_replace_callback(
		'#<(style|title)\b' . KERF_PRO_AI_DESIGN_TAG . '>.*?</\1\s*>#is',
		static function () use ( &$notes ) {
			$notes['style'] = __( 'Kerf took out the styles Gemini wrote: the page uses your design\'s.', 'kerf-pro' );
			return '';
		},
		$html
	);

	$html = kerf_pro_ai_design_clean_html( $html, '', array( 'scripts' => false, 'pictures' => $project['pictures'] ), $notes );
	$html = kerf_pro_ai_page_strip_wp_classes( $html );

	// Said for a page: the phase 3 words speak of a design's menu script and of
	// the owner's pictures as a whole.
	if ( isset( $notes['picture'] ) ) {
		$notes['picture'] = __( 'Kerf took out pictures Gemini used that are not the ones you chose.', 'kerf-pro' );
	}
	if ( isset( $notes['script'] ) ) {
		$notes['script'] = __( 'Kerf took out the scripts Gemini wrote.', 'kerf-pro' );
	}
	return trim( $html );
}

/**
 * The classes a page uses that the design styles nowhere — nor the page's own
 * CSS the model wrote with it.
 *
 * @param string              $html
 * @param array<string,bool> $known
 * @param string              $css   The page's own CSS.
 * @return string[]
 */
function kerf_pro_ai_page_unknown_classes( $html, $known, $css = '' ) {
	if ( '' !== trim( (string) $css ) && preg_match_all( '/\.(-?[_a-zA-Z][_a-zA-Z0-9-]*)/', (string) preg_replace( '#/\*.*?\*/#s', '', (string) $css ), $m ) ) {
		foreach ( $m[1] as $name ) {
			$known[ $name ] = true;
		}
	}
	$unknown = array();
	$tags    = new WP_HTML_Tag_Processor( $html );
	while ( $tags->next_tag() ) {
		foreach ( $tags->class_list() as $name ) {
			if ( ! isset( $known[ $name ] ) ) {
				$unknown[ $name ] = true;
			}
		}
	}
	return array_keys( $unknown );
}

/**
 * The chosen pictures as an import's media: the converter finds each by the
 * path the model was given, and nothing else in the library by name.
 *
 * @param array[] $pictures From kerf_pro_ai_design_pictures().
 * @return array{upload_url:string,media:array[]}
 */
function kerf_pro_ai_page_manifest( $pictures ) {
	return kerf_pro_ai_page_manifest_any( $pictures );
}

/**
 * Pictures as an import's media — a library picture by its id, any other (a
 * design's own file a page shows, changed by AI) by its address.
 *
 * @param array[] $pictures Each { id, path, url?, width, height }.
 * @return array{upload_url:string,media:array[]}
 */
function kerf_pro_ai_page_manifest_any( $pictures ) {
	$media = array();
	foreach ( $pictures as $picture ) {
		$id      = isset( $picture['id'] ) ? (int) $picture['id'] : 0;
		$media[] = array(
			'filename' => basename( $picture['path'] ),
			'path'     => $picture['path'],
			'id'       => $id,
			'url'      => $id ? (string) wp_get_attachment_url( $id ) : ( isset( $picture['url'] ) ? (string) $picture['url'] : '' ),
			'alt'      => $id ? trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) : '',
			'width'    => (int) $picture['width'],
			'height'   => (int) $picture['height'],
		);
	}
	return array( 'upload_url' => (string) wp_upload_dir()['baseurl'], 'media' => $media );
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE ROUTE
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * POST kerf/v1/ai/page — start making a page.
 */
function kerf_pro_ai_page_routes() {
	register_rest_route( 'kerf/v1', '/ai/page', array(
		'methods'             => 'POST',
		'callback'            => 'kerf_pro_ai_rest_page',
		'permission_callback' => 'kerf_pro_ai_page_permission',
		'args'                => array(
			'kind'     => array( 'type' => 'string', 'default' => 'other' ),
			'title'    => array( 'type' => 'string', 'required' => true ),
			'words'    => array( 'type' => 'string', 'default' => '' ),
			'notes'    => array( 'type' => 'string', 'default' => '' ),
			'pictures' => array( 'type' => 'array', 'items' => array( 'type' => 'integer' ), 'default' => array() ),
			'again'    => array( 'type' => 'string', 'default' => '' ),
			// The page open in the editor, which the answer goes into.
			'post_id'  => array( 'type' => 'integer', 'default' => 0 ),
		),
	) );
}
add_action( 'rest_api_init', 'kerf_pro_ai_page_routes' );

/**
 * Who may have a page made: whoever may make pages, and use AI.
 *
 * @param WP_REST_Request $request
 * @return true|WP_Error
 */
function kerf_pro_ai_page_permission( $request ) {
	if ( ! current_user_can( 'edit_pages' ) ) {
		return new WP_Error( 'kerf_ai_forbidden', __( 'Only someone who may make pages can have one made.', 'kerf-pro' ), array( 'status' => 403 ) );
	}
	return kerf_pro_ai_rest_permission( $request );
}

/**
 * Start a page.
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response|WP_Error
 */
function kerf_pro_ai_rest_page( $request ) {
	$job = kerf_pro_ai_page_start( array(
		'kind'     => (string) $request['kind'],
		'title'    => (string) $request['title'],
		'words'    => (string) $request['words'],
		'notes'    => (string) $request['notes'],
		'pictures' => (array) $request['pictures'],
		'again'    => (string) $request['again'],
		'post_id'  => (int) $request['post_id'],
	) );
	return is_wp_error( $job ) ? $job : rest_ensure_response( kerf_pro_ai_job_view( $job ) );
}


// ═══════════════════════════════════════════════════════════════════════════════
// IN THE MENU: THE EDITOR
// ═══════════════════════════════════════════════════════════════════════════════
//
// Kerf → Make a page was a screen of its own that saved a draft and showed it in
// a frame; the owner asked for it where pages are made — the editor
// (assets/js/kerf-ai-editor.js, inc/kerf-pro-ai-editor.php). The menu item and
// the Dashboard's tile stay, and open a new page there with the AI panel ready.

/**
 * Under Kerf, after Build with AI (kerf_ui_menu_order()): a new page in the
 * editor, its AI panel open.
 */
function kerf_pro_ai_page_menu() {
	$hook = add_submenu_page( 'kerf', __( 'Make a page', 'kerf-pro' ), __( 'Make a page', 'kerf-pro' ), 'edit_pages', 'kerf-page', '__return_null' );
	if ( $hook ) {
		add_action( 'load-' . $hook, 'kerf_pro_ai_page_open_editor' );
	}
}
add_action( 'admin_menu', 'kerf_pro_ai_page_menu', 22 );

/**
 * Where Kerf → Make a page goes: a new page, made with AI in the editor.
 */
function kerf_pro_ai_page_open_editor() {
	wp_safe_redirect( admin_url( 'post-new.php?post_type=page&kerf_ai=make' ) );
	exit;
}

/**
 * Its Dashboard tile, after Build with AI.
 *
 * @param array[] $tools
 * @return array[]
 */
function kerf_pro_ai_page_tool( $tools ) {
	$at = 1;
	foreach ( $tools as $i => $tool ) {
		if ( 'kerf-build' === $tool[0] ) {
			$at = $i + 1;
		}
	}
	array_splice( $tools, $at, 0, array( array(
		'kerf-page',
		'page',
		__( 'Make a page', 'kerf-pro' ),
		__( 'A new page in your design, made in the editor from your own words — pasted, or from a Word or Markdown file — and pictures. Change any page or section with AI there too.', 'kerf-pro' ),
	) ) );
	return $tools;
}
add_filter( 'kerf_dashboard_tools', 'kerf_pro_ai_page_tool' );
