<?php
/**
 * What one page loads of its own, added in WordPress: the styles and scripts
 * of a section pasted with Convert HTML, and the CSS AI wrote for a page it
 * made or changed (§5.46).
 *
 * A section a designer sends over comes with the CSS that styles it, and Convert
 * HTML said "not enqueued" and left the owner nowhere to put it: rewriting the
 * site's stylesheets for one section is no answer. It goes where a design's
 * other pages put theirs — a stylesheet only that page loads (§5.26), drawn in
 * its editor too — marked `added` (who, when) so it is told apart from the
 * design's own files: listed in the editor's sidebar, removable there, and kept
 * when a newer design replaces the asset list (kerf_assets_carry_added()).
 * A template edited in the Site Editor takes it as that template's; a header
 * or footer, which are on every page, as the site's.
 *
 * @package kerf-pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** CSS one page may be given at once, in bytes. */
const KERF_PRO_PAGE_CSS = 200000;

/**
 * Where a page's own files are kept: its own design's set (§5.39), or the
 * site's list.
 *
 * @param int $post_id
 * @return bool True for a page with a design of its own.
 */
function kerf_pro_page_assets_own( $post_id ) {
	$sets = kerf_asset_sets();
	return $post_id && isset( $sets[ (int) $post_id ] ) && is_array( $sets[ (int) $post_id ] );
}

/**
 * The list a page's files go in, and a way to save it.
 *
 * @param int $post_id 0 for the site's.
 * @return array{assets:array[],save:callable}
 */
function kerf_pro_page_assets_store( $post_id ) {
	if ( kerf_pro_page_assets_own( $post_id ) ) {
		$set = kerf_asset_sets()[ (int) $post_id ];
		return array(
			'assets' => isset( $set['assets'] ) && is_array( $set['assets'] ) ? $set['assets'] : array(),
			'save'   => static function ( $assets ) use ( $post_id, $set ) {
				$set['assets'] = array_values( $assets );
				kerf_asset_set_save( (int) $post_id, $set );
			},
		);
	}
	return array(
		'assets' => kerf_assets_get(),
		'save'   => static function ( $assets ) {
			kerf_assets_save( $assets );
		},
	);
}

/**
 * An asset's identity: its type and file, or its type and contents.
 *
 * @param array $asset
 * @return string
 */
function kerf_pro_page_assets_key( $asset ) {
	$what = 'file' === ( isset( $asset['kind'] ) ? $asset['kind'] : '' )
		? 'file|' . ( isset( $asset['src'] ) ? $asset['src'] : '' )
		: 'inline|' . ( isset( $asset['content'] ) ? $asset['content'] : '' );
	return 'k' . substr( md5( ( isset( $asset['type'] ) ? $asset['type'] : '' ) . '|' . $what ), 0, 12 );
}

/**
 * Does an asset load where this is: a page, or a template (`tpl:<slug>`), or
 * everywhere ('')?
 *
 * @param array      $asset
 * @param int|string $where A page id, `tpl:<slug>`, or ''.
 * @param bool       $own   The page has a design of its own: its set is all its own.
 * @return bool
 */
function kerf_pro_page_assets_loads( $asset, $where, $own = false ) {
	if ( $own || empty( $asset['only'] ) || ! is_array( $asset['only'] ) ) {
		return true;
	}
	if ( is_int( $where ) ) {
		return ! empty( $asset['only']['pages'] ) && in_array( $where, array_map( 'intval', (array) $asset['only']['pages'] ), true );
	}
	if ( 0 === strpos( (string) $where, 'tpl:' ) ) {
		return ! empty( $asset['only']['templates'] ) && in_array( substr( $where, 4 ), array_map( 'strval', (array) $asset['only']['templates'] ), true );
	}
	return false;
}

/**
 * Add files to a page, a template or the site, only from someone WordPress
 * trusts with code: stylesheets follow Additional CSS's rule as scripts do.
 *
 * @param int|string $where   A page id, `tpl:<slug>` for a template, '' for every page.
 * @param array[]    $assets  As kerf_assets_extract() reads them; relative files already the design's.
 * @param string     $by      Who added them: `convert` or `ai`.
 * @return array{added:string[],styles:array[],skipped:string[]} What was added (named), the editor's
 *         entries for the stylesheets that now load there, and what was left out (named).
 */
function kerf_pro_page_assets_add( $where, $assets, $by ) {
	$page    = is_int( $where ) ? $where : 0;
	$own     = $page && kerf_pro_page_assets_own( $page );
	$store   = kerf_pro_page_assets_store( $own ? $page : 0 );
	$list    = $store['assets'];
	$may_add = current_user_can( 'unfiltered_html' );
	$out     = array( 'added' => array(), 'styles' => array(), 'skipped' => array() );
	$index   = array();
	foreach ( $list as $i => $asset ) {
		$index[ kerf_pro_page_assets_key( $asset ) ] = $i;
	}
	$changed = false;

	foreach ( (array) $assets as $asset ) {
		$type = isset( $asset['type'] ) ? (string) $asset['type'] : '';
		if ( 'data' === $type || 'jsonld' === $type ) {
			continue;
		}
		$label = kerf_pro_page_assets_label( $asset );
		if ( ! $may_add ) {
			$out['skipped'][] = in_array( $type, array( 'css', 'typed-style' ), true )
				? sprintf(
					/* translators: %s: a stylesheet's name. */
					__( '%s (styles were left out: WordPress lets only users who may add code add stylesheets; on a network, only the super admin)', 'kerf-pro' ),
					$label
				)
				: $label;
			continue;
		}
		if ( in_array( $type, array( 'css', 'typed-style' ), true ) && 'inline' === $asset['kind'] && strlen( (string) $asset['content'] ) > KERF_PRO_PAGE_CSS ) {
			$out['skipped'][] = $label;
			continue;
		}
		$key = kerf_pro_page_assets_key( $asset );
		if ( isset( $index[ $key ] ) ) {
			$there = $list[ $index[ $key ] ];
			if ( kerf_pro_page_assets_loads( $there, $where, $own ) ) {
				continue; // It loads here already.
			}
			if ( '' === $where ) {
				$list[ $index[ $key ] ]['only'] = array();
				unset( $list[ $index[ $key ] ]['only'] );
			} else {
				$kind = $page ? 'pages' : 'templates';
				$list[ $index[ $key ] ]['only'][ $kind ][] = $page ? $page : substr( (string) $where, 4 );
			}
		} else {
			$asset['added'] = array( 'by' => (string) $by, 'at' => time() );
			if ( ! $own && '' !== $where ) {
				$asset['only'] = $page ? array( 'pages' => array( $page ) ) : array( 'templates' => array( substr( (string) $where, 4 ) ) );
			}
			$list[]        = $asset;
			$index[ $key ] = count( $list ) - 1;
		}
		$changed        = true;
		$out['added'][] = $label;
		if ( 'css' === $type ) {
			$entry = kerf_assets_editor_entry( $asset );
			if ( $entry ) {
				$out['styles'][] = $entry;
			}
		}
	}
	if ( $changed ) {
		call_user_func( $store['save'], $list );
		if ( ! $own ) {
			update_option( 'kerf_assets_version', (string) time(), false );
		}
	}
	return $out;
}

/**
 * The files a page loads of its own — added in WordPress, or brought by the
 * design's page it is — for the editor's sidebar.
 *
 * @param int $post_id
 * @return array[] Each { key, type, label, size, by, at, removable }.
 */
function kerf_pro_page_assets_list( $post_id ) {
	$own = kerf_pro_page_assets_own( $post_id );
	$out = array();
	foreach ( kerf_pro_page_assets_store( $own ? $post_id : 0 )['assets'] as $asset ) {
		$added = ! empty( $asset['added'] ) && is_array( $asset['added'] );
		// A page of its own: only what was added to it — the rest is its design.
		if ( $own ? ! $added : ( empty( $asset['only']['pages'] ) || ! kerf_pro_page_assets_loads( $asset, (int) $post_id ) ) ) {
			continue;
		}
		$out[] = array(
			'key'       => kerf_pro_page_assets_key( $asset ),
			'type'      => (string) $asset['type'],
			'label'     => kerf_pro_page_assets_label( $asset ),
			'size'      => 'inline' === $asset['kind'] ? strlen( (string) $asset['content'] ) : 0,
			'by'        => $added ? (string) $asset['added']['by'] : 'design',
			'at'        => $added ? (int) $asset['added']['at'] : 0,
			'removable' => $added,
		);
	}
	return $out;
}

/**
 * Take a file added in WordPress off a page: off its list of pages, and out
 * of the list once no page loads it.
 *
 * @param int    $post_id
 * @param string $key
 * @return array|null The editor's entry for a stylesheet taken off, to take out of the canvas; null when nothing was.
 */
function kerf_pro_page_assets_remove( $post_id, $key ) {
	$own   = kerf_pro_page_assets_own( $post_id );
	$store = kerf_pro_page_assets_store( $own ? $post_id : 0 );
	$list  = $store['assets'];
	foreach ( $list as $i => $asset ) {
		if ( empty( $asset['added'] ) || kerf_pro_page_assets_key( $asset ) !== $key || ! kerf_pro_page_assets_loads( $asset, (int) $post_id, $own ) ) {
			continue;
		}
		$pages = $own ? array() : array_values( array_diff( array_map( 'intval', (array) $asset['only']['pages'] ), array( (int) $post_id ) ) );
		if ( $pages ) {
			$list[ $i ]['only']['pages'] = $pages;
		} else {
			unset( $list[ $i ] );
		}
		call_user_func( $store['save'], array_values( $list ) );
		if ( ! $own ) {
			update_option( 'kerf_assets_version', (string) time(), false );
		}
		return 'css' === $asset['type'] ? (array) kerf_assets_editor_entry( $asset ) : array();
	}
	return null;
}

/**
 * A file named for the owner: its file name, or "Styles pasted with a section".
 *
 * @param array $asset
 * @return string
 */
function kerf_pro_page_assets_label( $asset ) {
	if ( 'file' === ( isset( $asset['kind'] ) ? $asset['kind'] : '' ) && ! empty( $asset['src'] ) ) {
		return kerf_pro_ai_page_label( (string) $asset['src'] );
	}
	$by = isset( $asset['added']['by'] ) ? (string) $asset['added']['by'] : '';
	if ( in_array( isset( $asset['type'] ) ? $asset['type'] : '', array( 'css', 'typed-style' ), true ) ) {
		return 'ai' === $by ? __( 'Styles Gemini wrote for this page', 'kerf-pro' ) : __( 'Styles pasted with a section', 'kerf-pro' );
	}
	return __( 'A script pasted with a section', 'kerf-pro' );
}

/**
 * A page's files carried through Update design, which writes the design's new
 * list: what was added in WordPress (the free kerf_assets_carry_added()), and
 * the pages a design file was given besides the design's own — a page Make a
 * page dressed with `css/pages.css` (kerf_pro_ai_page_dress()).
 *
 * @param array[] $assets The new list.
 * @return array[]
 */
function kerf_pro_page_assets_carry( $assets ) {
	$before = array();
	foreach ( kerf_assets_get() as $asset ) {
		if ( empty( $asset['added'] ) && ! empty( $asset['only']['pages'] ) ) {
			$before[ kerf_pro_page_assets_key( $asset ) ] = array_map( 'intval', (array) $asset['only']['pages'] );
		}
	}
	foreach ( $assets as $i => $asset ) {
		$key = kerf_pro_page_assets_key( $asset );
		if ( ! empty( $asset['only']['pages'] ) && isset( $before[ $key ] ) ) {
			$assets[ $i ]['only']['pages'] = array_values( array_unique( array_merge( array_map( 'intval', (array) $asset['only']['pages'] ), $before[ $key ] ) ) );
		}
	}
	return kerf_assets_carry_added( $assets );
}

/**
 * The design's files a pasted section's relative paths mean: the edited
 * page's own design's, or the site's (kerf_assets_design()), as staging.
 *
 * @param int $post_id
 * @return array{url:string,dir:string,base_rel:string}|array Empty when there are none.
 */
function kerf_pro_page_assets_staging( $post_id ) {
	$staged  = kerf_assets_design( (int) $post_id )['staging'];
	$url     = isset( $staged['url'] ) ? (string) $staged['url'] : '';
	$storage = kerf_assets_storage_for_url( $url );
	if ( ! $storage ) {
		return array();
	}
	return array(
		'url'      => trailingslashit( $url ),
		'dir'      => trailingslashit( $storage['dir'] . rawurldecode( substr( $url, strlen( $storage['url'] ) ) ) ),
		'base_rel' => isset( $staged['rel'] ) ? trim( (string) $staged['rel'], '/' ) : '',
	);
}

// ═══════════════════════════════════════════════════════════════════════════════
// THE ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * GET kerf/v1/page-assets?post_id= — what a page loads of its own;
 * POST kerf/v1/page-assets/remove { post_id, key } — take one added off.
 */
function kerf_pro_page_assets_routes() {
	$permission = static function ( $request ) {
		$id = (int) $request['post_id'];
		if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
			return new WP_Error( 'kerf_forbidden', __( 'You may not change this page.', 'kerf-pro' ), array( 'status' => 403 ) );
		}
		return true;
	};
	register_rest_route( 'kerf/v1', '/page-assets', array(
		'methods'             => 'GET',
		'callback'            => static function ( $request ) {
			return rest_ensure_response( kerf_pro_page_assets_list( (int) $request['post_id'] ) );
		},
		'permission_callback' => $permission,
		'args'                => array( 'post_id' => array( 'type' => 'integer', 'required' => true ) ),
	) );
	register_rest_route( 'kerf/v1', '/page-assets/remove', array(
		'methods'             => 'POST',
		'callback'            => static function ( $request ) {
			if ( ! kerf_pro_licensed() ) {
				return new WP_Error( 'kerf_pro_expired', __( 'Your Kerf Pro licence has expired: renew to change this here again.', 'kerf-pro' ), array( 'status' => 403 ) );
			}
			$entry = kerf_pro_page_assets_remove( (int) $request['post_id'], (string) $request['key'] );
			if ( null === $entry ) {
				return new WP_Error( 'kerf_not_found', __( 'That is not on this page any more.', 'kerf-pro' ), array( 'status' => 404 ) );
			}
			return rest_ensure_response( array( 'removed' => $entry, 'assets' => kerf_pro_page_assets_list( (int) $request['post_id'] ) ) );
		},
		'permission_callback' => $permission,
		'args'                => array(
			'post_id' => array( 'type' => 'integer', 'required' => true ),
			'key'     => array( 'type' => 'string', 'required' => true ),
		),
	) );
}
add_action( 'rest_api_init', 'kerf_pro_page_assets_routes' );
