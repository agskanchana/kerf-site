<?php
/**
 * The live demo's copy of Kerf (kerf.site, "Try the demo").
 *
 * The demo runs Kerf in WordPress Playground — a WordPress that runs inside the
 * visitor's browser — so its zip has to be public: the browser downloads it.
 * This file, added to that zip by tools/demo/build-demo.php (never to the
 * product's), makes the demo copy run only there. Anywhere else the theme loads
 * without its engine and Kerf Pro — a plain blog — and says where Kerf is sold.
 *
 * Playground answers both tests below (measured 2026-10-18 on
 * playground.wordpress.net, WordPress 7.1.3, PHP 8.3): the site's address is
 * `https://playground.wordpress.net/scope:<name>`, and its PHP is a WebAssembly
 * build (`php_uname()` "Emscripten emscripten 4.0.19 #1 wasm32"). Like any
 * check in a theme's PHP it can be edited out; it keeps the demo a demo for
 * everyone else.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is this copy running in WordPress Playground?
 *
 * @return bool
 */
function kerf_demo_allowed() {
	$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	return 'playground.wordpress.net' === $host && false !== stripos( php_uname(), 'emscripten' );
}

/**
 * Outside Playground: say what this copy is, on every admin screen.
 */
function kerf_demo_notice() {
	if ( ! current_user_can( 'switch_themes' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-warning"><p>%s <a href="https://kerf.site/">%s</a></p></div>',
		esc_html__( 'This copy of Kerf is the live demo, and it works only in WordPress Playground. Your own copy of Kerf comes from', 'kerf' ),
		esc_html( 'kerf.site' )
	);
}
