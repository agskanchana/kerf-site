<?php
/**
 * The live demo's copy of Kerf (kerf.site, "Try the demo").
 *
 * The demo runs Kerf in WordPress Playground — a WordPress that runs inside the
 * visitor's browser — so its zip has to be public: the browser downloads it.
 * This file, added to that zip by tools/demo/build-demo.php (never to the
 * product's), makes the demo copy run only there. Anywhere else the theme loads
 * without its engine and Kerf Pro — a plain blog — and says where Kerf is sold.
 *
 * Playground answers both tests below (measured 2026-10-18 on
 * playground.wordpress.net, WordPress 7.1.3, PHP 8.3): the site's address is
 * `https://playground.wordpress.net/scope:<name>`, and its PHP is a WebAssembly
 * build (`php_uname()` "Emscripten emscripten 4.0.19 #1 wasm32"). Like any
 * check in a theme's PHP it can be edited out; it keeps the demo a demo for
 * everyone else.
 *
 * @package kerf
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Is this copy running in WordPress Playground?
 *
 * @return bool
 */
function kerf_demo_allowed() {
	$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	return 'playground.wordpress.net' === $host && false !== stripos( php_uname(), 'emscripten' );
}

/**
 * Outside Playground: say what this copy is, on every admin screen.
 */
function kerf_demo_notice() {
	if ( ! current_user_can( 'switch_themes' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-warning"><p>%s <a href="https://kerf.site/">%s</a></p></div>',
		esc_html__( 'This copy of Kerf is the live demo, and it works only in WordPress Playground. Your own copy of Kerf comes from', 'kerf' ),
		esc_html( 'kerf.site' )
	);
}

/**
 * In the demo, what would open a new tab opens in the demo.
 *
 * kerf.site/demo/ runs Playground in a frame on kerf.site's own page, and the
 * WordPress in it is served by a service worker that frame registered. Browsers
 * keep a frame's service workers apart from those of a tab opened on the same
 * address (storage partitioning), so a new tab at the site's address
 * (`https://playground.wordpress.net/scope:<name>/`) finds no WordPress there:
 * "This site can't be reached" — reported by the owner 2026-10-21, after an
 * import's "View it". So a link to the site that would open another tab or
 * window — Kerf's "View it" and "View site", the editor's "View page", a design's
 * own `target="_blank"`, a Ctrl- or middle-click — opens in the demo's frame
 * instead; and what a script opens with `window.open()` — the editor's Preview —
 * opens in a panel over the page, which the editor fills as it would a tab.
 * Links to other sites open as they always do. Read after the page's own
 * handlers (a bubbling listener on the window), so a link whose script already
 * handled the click — Preview is a link with a target — is left to it.
 */
function kerf_demo_same_tab() {
	if ( ! kerf_demo_allowed() ) {
		return;
	}
	$script = <<<'JS'
( function () {
	var base = __HOME__.replace( /\/+$/, '' ), words = __WORDS__, panels = {};
	function ours( href ) {
		var url;
		try {
			url = new URL( String( href ), location.href ).href;
		} catch ( e ) {
			return false;
		}
		return url === base || [ '/', '?', '#' ].some( function ( c ) { return 0 === url.indexOf( base + c ); } );
	}
	function follow( event ) {
		var link = event.target && event.target.closest ? event.target.closest( 'a[href]' ) : null;
		if ( ! link || event.defaultPrevented || link.hasAttribute( 'download' ) || ! ours( link.href ) ) {
			return;
		}
		var target = ( link.getAttribute( 'target' ) || '' ).toLowerCase();
		if ( ( target && '_self' !== target ) || event.ctrlKey || event.metaKey || event.shiftKey || 1 === event.button ) {
			event.preventDefault();
			location.assign( link.href );
		}
	}
	window.addEventListener( 'click', follow );
	window.addEventListener( 'auxclick', follow );

	var style = document.createElement( 'style' );
	style.textContent = '.kerf-demo-panel{position:fixed;inset:0;z-index:1000000;display:flex;padding:24px;background:rgba(0,0,0,.6)}'
		+ '.kerf-demo-panel>div{flex:1;display:flex;flex-direction:column;overflow:hidden;border-radius:8px;background:#fff;box-shadow:0 12px 48px rgba(0,0,0,.5)}'
		+ '.kerf-demo-panel p{display:flex;align-items:center;gap:8px;margin:0;padding:8px 12px;background:#1d2327;color:#fff;font:13px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}'
		+ '.kerf-demo-panel span{flex:1}'
		+ '.kerf-demo-panel button{padding:4px 12px;border:1px solid #fff;border-radius:3px;background:transparent;color:#fff;font:inherit;cursor:pointer}'
		+ '.kerf-demo-panel iframe{flex:1;width:100%;border:0;background:#fff}';
	( document.head || document.documentElement ).appendChild( style );

	function close( box ) {
		box.remove();
		Object.keys( panels ).forEach( function ( k ) { if ( panels[ k ] === box ) { delete panels[ k ]; } } );
	}
	function panel( url, name ) {
		var key = name && '_blank' !== String( name ) ? String( name ) : '', box = key ? panels[ key ] : null;
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'kerf-demo-panel';
			var inner = document.createElement( 'div' ), bar = document.createElement( 'p' ), note = document.createElement( 'span' );
			var here = document.createElement( 'button' ), shut = document.createElement( 'button' ), frame = document.createElement( 'iframe' );
			note.textContent = words.note;
			here.type = shut.type = 'button';
			here.textContent = words.here;
			shut.textContent = words.close;
			here.onclick = function () { location.assign( frame.contentWindow.location.href ); };
			shut.onclick = function () { close( box ); };
			if ( key ) {
				frame.name = key;
				panels[ key ] = box;
			}
			bar.append( note, here, shut );
			inner.append( bar, frame );
			box.append( inner );
			box.addEventListener( 'click', function ( event ) { if ( event.target === box ) { close( box ); } } );
			document.body.appendChild( box );
		}
		var win = box.querySelector( 'iframe' ).contentWindow;
		if ( url && 'about:blank' !== String( url ) ) {
			win.location.href = new URL( String( url ), location.href ).href;
		}
		return win;
	}
	var open = window.open;
	window.open = function ( url ) {
		if ( url && 'about:blank' !== String( url ) && ! ours( url ) ) {
			return open.apply( window, arguments );
		}
		return panel( url, arguments[ 1 ] );
	};
	document.addEventListener( 'keydown', function ( event ) {
		var boxes = document.querySelectorAll( '.kerf-demo-panel' );
		if ( 'Escape' === event.key && boxes.length ) {
			close( boxes[ boxes.length - 1 ] );
		}
	} );
}() );
JS;
	wp_print_inline_script_tag(
		strtr(
			$script,
			array(
				'__HOME__'  => wp_json_encode( home_url( '/' ) ),
				'__WORDS__' => wp_json_encode(
					array(
						'note'  => __( 'In the live demo, a new tab opens here.', 'kerf' ),
						'here'  => __( 'Open it in place', 'kerf' ),
						'close' => __( 'Close', 'kerf' ),
					)
				),
			)
		)
	);
}
add_action( 'admin_head', 'kerf_demo_same_tab' );
add_action( 'wp_head', 'kerf_demo_same_tab' );
