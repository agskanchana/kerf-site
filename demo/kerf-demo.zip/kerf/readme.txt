=== Kerf ===
Contributors: agskanchana
Requires at least: 6.9
Tested up to: 7.1
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Give Kerf an HTML design from any AI tool or designer and it becomes an identical, editable WordPress site, with every tag, class, attribute and stylesheet kept as written; before a design is imported it is a plain, readable blog.

== Description ==

Kerf is a block theme made to stay out of the way.

Give Kerf an HTML design — from any AI tool or designer — and it becomes an identical, editable WordPress site: the design's own header, footer and pages, with every tag, class, attribute and stylesheet kept as written. The pages the design did not draw — the blog, posts, archives, search and "not found" — show its header and footer around the theme's own plain look.

Before a design is imported it is a plain, readable blog: a header with your site title and menu, a grid of your latest posts with their pictures, comfortable reading pages for posts and pages, and a simple footer. Every template is built from WordPress' own blocks, so all of it can be changed in the Site Editor.

== Frequently Asked Questions ==

= What happened to the Kerf Blocks and Kerf Pro plugins? =

They are part of the theme now. Deactivate and delete them: your design, pages and settings stay as they are.

= Can I change the colours and fonts? =

Yes, in the Site Editor, like any block theme. When a design is imported, the design's own stylesheets decide its look.

== Changelog ==

= 1.1.2 =
* Your licence: after activating the theme, enter your licence key once (Kerf asks for it); Kerf → Account shows it, and updates come to Appearance → Themes like any theme's. Kerf → Contact Us writes to kerf.site.
* Kerf recognises itself in any folder, so a copy unpacked under another folder name works as it should.

= 1.1.1 =
* A search overlay, booking pop-up or other dialog placed right after a design's header now goes with the header, so the header's button opens it on every page, not only the home page. Import the design again to move it.
* When a design's script stops on a page it was not written for — the blog, a post, search results — what it was going to fade in as the visitor scrolls (a footer's contact details, say) is shown anyway.
* The brief for AI tools asks for scripts that check an element is on the page before using it.
* The logo in the header goes to the home page from every page, even where the design linked it to "#", to the top of the page or to the business's old website, or did not link it at all.
* A design's search reaches WordPress search whatever it is: a search form, a search box with no form (Enter, or its search button), or a search icon with no box behind it (it opens the search page).
* A design whose home page file is not called index.html (index-1.html, say) has its logo and "Home" links go to the home page, and a link to a section of a page (index.html#services) goes to that section. Import the design again, or check its links again under Kerf → Links.
* The engine's script translations load from the theme's own folder; Settings no longer says form messages wait under Form entries while Kerf Pro's licence has lapsed.

= 1.1.0 =
* One product: the theme now includes Kerf Blocks and Kerf Pro. On a site that had the two plugins, deactivate Kerf Pro, then Kerf Blocks, and delete both — the design, pages and settings stay as they are.

= 1.0.1 =
* A smaller screenshot (a JPEG: a quarter of the size, the same picture).

= 1.0.0 =
* First release on WordPress.org.
* Posts written in the classic editor show as they should: captioned pictures, embedded videos and tables fit the screen, galleries keep their columns, a post split into pages links to its other pages, replies to comments are indented and the author's own comments marked, a sticky post stands out on the blog page, and the password form is styled.
* The plugin it works with is now called Kerf Blocks.

= 0.1.0 =
* The first version, tested privately.

== Copyright ==

Kerf WordPress Theme, (C) 2026 Janaka Gunawardhana.
Kerf is distributed under the terms of the GNU GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

== Resources ==

* Screenshot: the theme's own pages. The photographs in it were made for this theme by the author with an image generator; they show no real people or places. License: GPLv2 or later. Source: this theme.
